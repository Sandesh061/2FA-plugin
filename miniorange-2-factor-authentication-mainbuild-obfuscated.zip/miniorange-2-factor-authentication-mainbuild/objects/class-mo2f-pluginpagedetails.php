<?php


namespace TwoFA\Objects;

if (defined("\101\102\123\x50\101\x54\110")) {
    goto Mdn;
}
exit;
Mdn:
if (class_exists("\x4d\157\x32\146\x5f\120\x6c\x75\x67\151\x6e\x50\141\x67\145\104\x65\x74\141\x69\x6c\x73")) {
    goto ShJ;
}
class Mo2f_PluginPageDetails
{
    public function __construct($JR, $Wk, $HJ, $c_, $b1, $aL, $d1)
    {
        $this->page_title = $JR;
        $this->menu_slug = $Wk;
        $this->capability = $HJ;
        $this->url = add_query_arg(array("\160\141\x67\145" => $this->menu_slug), $c_);
        $this->url = remove_query_arg(array("\141\x64\144\157\156", "\x66\157\162\155", "\x73\x6d\x73", "\x73\165\x62\x70\141\147\145"), $this->url);
        $this->view = $b1;
        $this->show_in_nav = $aL;
        $this->nav_tabs = $d1;
    }
    public $page_title;
    public $menu_slug;
    public $url;
    public $view;
    public $capability;
    public $show_in_nav;
    public $nav_tabs;
}
ShJ:
