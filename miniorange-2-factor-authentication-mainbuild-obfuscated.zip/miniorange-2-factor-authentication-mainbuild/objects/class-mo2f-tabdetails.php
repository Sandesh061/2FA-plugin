<?php


namespace TwoFA\Objects;

use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Traits\Instance;
use TwoFA\Objects\Mo2f_Nav_Tab_Details;
use TwoFA\Helper\Mo2f_Common_Helper;
if (defined("\101\x42\x53\120\x41\124\x48")) {
    goto t3p;
}
exit;
t3p:
if (class_exists("\x4d\x6f\x32\146\137\124\141\142\104\145\164\141\x69\154\163")) {
    goto Kk8;
}
final class Mo2f_TabDetails
{
    use Instance;
    public $tab_details;
    public $parent_slug;
    public $mo2fa_nav_tab_details;
    public $wl_tab_details;
    public $reports_tab_details;
    public $ma_tab_details;
    public $ip_blocking_tab_details;
    private function __construct()
    {
        $SP = apply_filters("\155\157\x32\x66\137\x69\x73\x5f\x6c\166\137\156\x65\x65\144\x65\x64", false);
        $cB = new Mo2f_Common_Helper();
        $this->parent_slug = $cB->mo2f_get_default_page($SP);
        $xz = isset($_SERVER["\122\x45\x51\x55\105\x53\124\x5f\x55\x52\111"]) ? esc_url_raw(wp_unslash($_SERVER["\x52\105\121\x55\x45\123\x54\x5f\x55\122\111"])) : '';
        $c_ = remove_query_arg("\x61\144\144\x6f\x6e", $xz);
        $Gx = current_user_can("\x6d\x61\156\x61\x67\x65\x5f\157\160\164\x69\x6f\x6e\163");
        $this->mo2fa_nav_tab_details = $SP ? array("\x51\165\151\143\x6b\x20\123\145\164\165\160", "\123\x65\164\x74\151\x6e\x67\x73", "\x41\x64\166\141\x6e\143\x65\144\40\106\x65\x61\x74\165\162\x65\x73", "\x46\x6f\x72\x6d\40\x49\156\x74\145\x67\x72\141\x74\151\157\156") : array("\x51\x75\151\143\x6b\x20\x53\x65\164\x75\x70", "\x53\x65\164\164\x69\x6e\147\163", "\x41\144\166\141\x6e\143\145\144\x20\106\145\x61\x74\x75\x72\x65\163", "\x46\157\x72\155\40\111\x6e\164\145\147\162\141\x74\151\157\x6e");
        $this->wl_tab_details = $SP ? array("\114\157\147\151\x6e\x20\x50\157\x70\165\x70", "\x45\x6d\x61\151\154\40\124\x65\155\x70\x6c\x61\x74\x65\163", "\62\x46\101\x20\103\165\x73\x74\x6f\x6d\151\x7a\x61\x74\x69\157\156\163") : array("\x32\x46\x41\40\103\165\163\x74\x6f\x6d\x69\172\x61\164\x69\x6f\x6e\163", "\105\x6d\x61\151\x6c\40\124\145\155\x70\x6c\x61\x74\x65\x73", "\x4c\157\147\151\x6e\40\120\x6f\x70\165\160");
        $this->reports_tab_details = array("\x55\x73\145\162\163\40\62\x46\101\40\x53\164\x61\164\165\163", "\122\x65\155\145\x6d\x62\x65\162\145\144\x20\x44\145\x76\x69\x63\x65\x73", "\x4c\157\x67\x69\x6e\x20\122\145\x70\157\162\x74");
        $this->ma_tab_details = array("\115\x79\x20\x41\143\143\157\x75\x6e\164", "\x53\145\164\x75\x70\40\x59\x6f\165\162\40\62\106\x41");
        $this->ip_blocking_tab_details = array("\101\x64\166\141\156\143\145\144\40\102\154\157\143\153\x69\x6e\147", "\x49\x50\40\102\x6c\141\143\153\154\151\163\164");
        $this->tab_details = array(Mo2f_Tabs::TWO_FACTOR => new Mo2f_PluginPageDetails("\62\x46\x41\x20\103\x6f\x6e\x66\151\147\x75\x72\141\x74\151\x6f\x6e\163", "\x6d\x6f\x5f\62\146\x61\x5f\164\167\157\137\146\x61", "\162\145\141\x64", $c_, "\x32\x66\x61\x63\x6f\156\146\x69\x67\x75\162\141\164\x69\x6f\x6e\x73" . DIRECTORY_SEPARATOR . "\161\x75\151\x63\153\x73\145\x74\165\160\56\160\x68\x70", $Gx, $this->mo2fa_nav_tab_details), Mo2f_Tabs::WHITE_LABELLING => new Mo2f_PluginPageDetails("\127\150\151\x74\145\40\x4c\x61\142\145\154\154\x69\156\x67", "\x6d\x6f\x5f\x32\x66\141\137\167\150\x69\x74\x65\137\x6c\x61\x62\x65\154\x6c\151\156\x67", "\x6d\x61\156\141\x67\145\x5f\157\160\164\x69\x6f\x6e\163", $c_, "\167\x68\x69\164\x65\154\141\x62\x65\154\x6c\151\156\147" . DIRECTORY_SEPARATOR . "\x6c\x6f\x67\151\x6e\160\x6f\160\165\x70\x2e\x70\x68\160", $Gx, $this->wl_tab_details), Mo2f_Tabs::REPORTS => new Mo2f_PluginPageDetails("\122\145\160\x6f\x72\164\x73", "\155\157\137\62\x66\141\x5f\x72\x65\x70\157\x72\x74\163", "\155\x61\156\141\x67\x65\137\157\x70\x74\151\157\x6e\x73", $c_, "\162\x65\160\157\x72\164\163" . DIRECTORY_SEPARATOR . "\165\163\145\162\163\62\x66\x61\x73\x74\x61\164\165\x73\56\160\150\160", $Gx, $this->reports_tab_details), Mo2f_Tabs::MY_ACCOUNT => new Mo2f_PluginPageDetails("\x4d\171\40\101\x63\143\157\165\156\x74", "\155\157\x5f\62\x66\x61\x5f\155\x79\x5f\141\x63\143\157\x75\156\164", "\162\x65\x61\x64", $c_, $Gx ? "\x6d\x79\141\143\143\x6f\165\x6e\x74" . DIRECTORY_SEPARATOR . "\x6d\171\x61\x63\143\157\165\156\x74\56\160\x68\160" : "\x6d\171\x61\143\143\157\165\156\164" . DIRECTORY_SEPARATOR . "\x73\145\164\165\x70\x79\x6f\x75\162\62\146\x61\x2e\x70\x68\160", true, $this->ma_tab_details), Mo2f_Tabs::UPGRADE => new Mo2f_PluginPageDetails("\125\160\147\x72\141\x64\145", "\x6d\x6f\x5f\x32\146\141\x5f\165\x70\x67\x72\141\x64\145", "\x6d\141\x6e\x61\147\145\x5f\157\x70\x74\151\x6f\156\163", $c_, "\165\x70\147\162\x61\144\x65\x2e\x70\150\160", $Gx, array()), Mo2f_Tabs::TROUBLESHOOTING => new Mo2f_PluginPageDetails("\106\x41\x51\x73", "\155\x6f\137\62\x66\141\x5f\164\162\157\x75\142\154\x65\163\150\x6f\x6f\x74\151\x6e\x67", "\155\141\156\x61\147\x65\x5f\x6f\x70\164\x69\157\156\163", $c_, "\x66\x61\161\x73\56\160\x68\160", $Gx, array()));
        if ($SP) {
            goto uhp;
        }
        $Ka = array_search(Mo2f_Tabs::TROUBLESHOOTING, array_keys($this->tab_details), true);
        $JZ = array(Mo2f_Tabs::SETUPWIZARD_SETTINGS => new Mo2f_PluginPageDetails("\123\145\x74\165\x70\x20\127\x69\x7a\141\x72\x64", "\x6d\x6f\62\146\55\163\x65\x74\x75\x70\55\167\151\x7a\141\162\144", "\155\141\156\141\147\145\x5f\x6f\160\x74\x69\x6f\156\163", $c_, "\x73\x65\x74\x75\x70\167\151\x7a\141\x72\144\56\x70\150\x70", $Gx, array()));
        $this->tab_details = array_slice($this->tab_details, 0, $Ka, true) + $JZ + array_slice($this->tab_details, $Ka, null, true);
        uhp:
        if (!MoWpnsUtility::get_mo2f_db_option("\x6d\157\x5f\167\x70\156\163\137\x32\146\x61\137\167\151\164\150\137\156\145\x74\167\157\x72\x6b\x5f\x73\145\x63\165\x72\151\x74\171", "\163\151\x74\x65\x5f\x6f\x70\x74\x69\157\156")) {
            goto E1D;
        }
        array_push($this->tab_details, new Mo2f_PluginPageDetails("\111\x50\x20\102\154\157\143\x6b\x69\x6e\147", "\155\x6f\137\62\x66\x61\137\141\144\x76\x61\x6e\143\x65\144\142\154\x6f\x63\x6b\x69\x6e\x67", "\x6d\141\x6e\x61\147\145\137\x6f\x70\x74\x69\x6f\x6e\x73", $c_, "\x69\x70\142\154\x6f\x63\x6b\151\156\x67" . DIRECTORY_SEPARATOR . "\x61\144\166\141\x6e\143\x65\144\142\x6c\157\143\153\x69\156\147\x2e\x70\x68\x70", $Gx && MoWpnsUtility::get_mo2f_db_option("\x6d\157\x5f\167\160\156\x73\137\62\146\x61\137\167\x69\x74\x68\137\x6e\x65\164\x77\157\162\x6b\x5f\x73\145\143\x75\162\x69\164\171", "\x73\x69\164\x65\x5f\x6f\x70\x74\151\157\156"), $this->ip_blocking_tab_details));
        E1D:
    }
}
Kk8:
