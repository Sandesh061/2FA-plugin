<?php


namespace TwoFA\Objects;

if (defined("\x41\x42\x53\x50\x41\x54\x48")) {
    goto LsZ;
}
exit;
LsZ:
if (class_exists("\115\157\62\x66\x5f\124\141\142\x73")) {
    goto UhC;
}
final class Mo2f_Tabs
{
    const TWO_FACTOR = "\x74\x77\x6f\x5f\x66\x61\x63\164\157\x72";
    const WHITE_LABELLING = "\167\x68\x69\164\x65\x5f\x6c\x61\x62\145\x6c\x6c\151\156\x67";
    const REPORTS = "\x72\145\160\157\x72\164\x73";
    const UPGRADE = "\165\x70\147\x72\141\x64\145";
    const MY_ACCOUNT = "\155\171\137\141\143\x63\157\x75\x6e\164";
    const SETUPWIZARD_SETTINGS = "\x73\x65\x74\165\160\167\151\172\x61\x72\144\x5f\x73\x65\x74\x74\x69\x6e\x67\x73";
    const TROUBLESHOOTING = "\x74\x72\x6f\x75\142\x6c\x65\163\150\x6f\157\x74\151\x6e\147";
    const CONTACT_US = "\143\157\156\164\x61\x63\x74\137\165\x73";
    const IP_BLOCKING = "\151\x70\137\x62\154\157\x63\x6b\x69\x6e\x67";
}
UhC:
