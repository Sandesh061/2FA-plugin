<?php


namespace TwoFA\Helper;

use TwoFA\Helper\MoWpnsUtility;
if (defined("\101\x42\123\120\x41\x54\110")) {
    goto A18;
}
exit;
A18:
if (class_exists("\124\x77\x6f\x46\x41\x4d\x6f\x53\x65\163\163\151\157\156\x73")) {
    goto v_h;
}
class TwoFAMoSessions
{
    public static function add_session_var($t8, $gy)
    {
        switch (MO2F_SESSION_TYPE) {
            case "\x54\122\x41\116\x53\111\105\116\124":
                if (!isset($_COOKIE["\x74\x72\141\x6e\163\x69\145\x6e\x74\137\x6b\x65\171"])) {
                    goto Lew;
                }
                $ac = sanitize_text_field(wp_unslash($_COOKIE["\164\x72\x61\x6e\x73\151\145\x6e\x74\137\153\x65\171"]));
                goto NWM;
                Lew:
                if (!wp_cache_get("\164\162\141\x6e\x73\151\x65\x6e\164\x5f\x6b\x65\171")) {
                    goto n4R;
                }
                $ac = wp_cache_get("\164\x72\x61\156\163\151\145\x6e\164\x5f\153\145\x79");
                goto pQF;
                n4R:
                $ac = MoWpnsUtility::rand();
                if (!ob_get_contents()) {
                    goto lt1;
                }
                ob_clean();
                lt1:
                setcookie("\x74\x72\x61\156\163\151\x65\156\x74\x5f\x6b\145\x79", $ac, time() + 12 * HOUR_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN);
                wp_cache_add("\x74\x72\141\x6e\x73\151\x65\x6e\x74\x5f\x6b\x65\x79", $ac);
                pQF:
                NWM:
                set_site_transient($ac . $t8, $gy, 12 * HOUR_IN_SECONDS);
                goto zdA;
        }
        CCd:
        zdA:
    }
    public static function get_session_var($t8)
    {
        switch (MO2F_SESSION_TYPE) {
            case "\x54\x52\101\x4e\123\111\105\x4e\124":
                $ac = isset($_COOKIE["\x74\162\141\156\163\x69\x65\156\164\x5f\x6b\145\x79"]) ? sanitize_text_field(wp_unslash($_COOKIE["\164\x72\141\156\x73\x69\145\x6e\x74\137\153\x65\171"])) : wp_cache_get("\x74\162\x61\x6e\x73\x69\x65\156\x74\x5f\153\145\x79");
                return get_site_transient($ac . $t8);
        }
        KPF:
        hCa:
    }
    public static function unset_session($t8)
    {
        switch (MO2F_SESSION_TYPE) {
            case "\x54\x52\101\116\123\111\105\x4e\124":
                $ac = isset($_COOKIE["\164\162\141\x6e\163\x69\x65\156\x74\x5f\x6b\x65\x79"]) ? sanitize_text_field(wp_unslash($_COOKIE["\x74\162\x61\156\163\x69\145\156\x74\137\153\145\171"])) : wp_cache_get("\164\x72\x61\x6e\163\x69\145\156\x74\137\x6b\x65\171");
                if (MoWpnsUtility::check_empty_or_null($ac)) {
                    goto wQl;
                }
                delete_site_transient($ac . $t8);
                wQl:
                goto baJ;
        }
        tj3:
        baJ:
    }
}
v_h:
