<?php


namespace TwoFA\Onprem;

use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Traits\Instance;
if (class_exists("\x4d\157\x32\146\x5f\101\160\151")) {
    goto hmO;
}
class Mo2f_Api
{
    use Instance;
    public function mo2f_wp_remote_post($xz, $as = array())
    {
        $bC = wp_remote_post($xz, $as);
        if (!is_wp_error($bC)) {
            goto f0w;
        }
        $jD = MoWpnsMessages::SOMETHING_WENT_WRONG;
        return wp_json_encode(array("\x73\164\141\164\x75\163" => "\105\122\122\x4f\122", "\155\x65\163\163\x61\x67\x65" => $jD));
        goto kcJ;
        f0w:
        return $bC["\x62\157\x64\x79"];
        kcJ:
    }
    public function get_timestamp()
    {
        $E6 = round(microtime(true) * 1000);
        $E6 = number_format($E6, 0, '', '');
        return $E6;
    }
    public function mo2f_http_request($xz, $aV, $LB = array("\103\x6f\x6e\164\145\156\164\55\x54\x79\x70\145" => "\141\x70\160\x6c\x69\143\141\x74\x69\x6f\x6e\x2f\x6a\163\x6f\156", "\143\150\141\162\x73\145\164" => "\x55\124\x46\55\x38", "\x41\165\164\150\x6f\162\x69\x7a\141\164\x69\x6f\x6e" => "\x42\141\x73\x69\x63"))
    {
        if (!(gettype($aV) !== "\163\x74\x72\x69\156\x67")) {
            goto Cmn;
        }
        $aV = wp_json_encode($aV);
        Cmn:
        $as = array("\155\145\164\x68\x6f\x64" => "\120\117\123\124", "\142\x6f\144\171" => $aV, "\x74\151\x6d\145\x6f\x75\164" => "\x31\x30", "\x72\145\144\x69\x72\x65\143\164\151\157\x6e" => "\65", "\x73\x73\154\x76\x65\162\151\146\x79" => true, "\x68\x74\164\160\166\x65\162\163\151\157\x6e" => "\61\56\x30", "\142\154\x6f\x63\x6b\x69\156\147" => true, "\x68\x65\x61\144\x65\x72\163" => $LB);
        $bC = self::mo2f_wp_remote_post($xz, $as);
        return $bC;
    }
    public function get_http_header_array()
    {
        $hS = get_site_option("\155\x6f\62\146\x5f\x63\165\x73\x74\157\x6d\x65\x72\x4b\x65\x79");
        $Yl = get_site_option("\155\157\x32\146\137\x61\160\x69\137\x6b\x65\x79");
        $E6 = self::get_timestamp();
        $fk = $hS . $E6 . $Yl;
        $Zb = hash("\163\x68\141\x35\61\62", $fk);
        $Tp = array("\x43\157\x6e\x74\x65\156\x74\x2d\124\x79\x70\x65" => "\x61\160\160\154\x69\x63\141\164\151\157\156\x2f\152\163\157\156", "\103\x75\x73\164\157\x6d\145\162\55\x4b\x65\x79" => $hS, "\124\x69\155\x65\163\x74\141\x6d\160" => $E6, "\x41\x75\164\x68\x6f\162\151\172\x61\164\151\157\156" => $Zb);
        return $Tp;
    }
}
hmO:
