<?php


namespace TwoFA\Helper;

use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Onprem\Mo2f_Api;
use TwoFA\Onprem\Miniorange_Authentication;
if (defined("\101\x42\x53\x50\101\124\110")) {
    goto uo6;
}
exit;
uo6:
if (class_exists("\x4d\x6f\143\125\122\114")) {
    goto cHk;
}
class MocURL
{
    private $mo2f_api;
    public function __construct()
    {
        $this->mo2f_api = Mo2f_Api::instance();
    }
    public static function create_customer($fK, $ke, $uk, $T7 = '', $gN = '', $Nf = '')
    {
        $xz = MO_HOST_NAME . "\x2f\x6d\x6f\141\x73\x2f\x72\x65\163\164\x2f\143\165\x73\164\x6f\155\x65\x72\57\141\144\x64";
        $hS = MoWpnsConstants::DEFAULT_CUSTOMER_KEY;
        $Yl = MoWpnsConstants::DEFAULT_API_KEY;
        $aV = array("\143\x6f\155\160\141\156\x79\116\x61\155\145" => $ke, "\141\x72\145\x61\x4f\146\x49\156\164\x65\x72\x65\163\x74" => "\x57\157\x72\144\120\162\145\163\163\40\62\x20\106\141\x63\164\x6f\162\x20\x41\x75\164\x68\x65\156\x74\x69\143\141\164\x69\157\156\40\120\x6c\x75\x67\x69\x6e", "\x66\151\162\163\164\156\x61\155\x65" => $gN, "\x6c\141\x73\x74\156\x61\x6d\x65" => $Nf, "\x65\x6d\141\x69\154" => $fK, "\x70\150\x6f\156\145" => $T7, "\160\x61\163\163\167\157\x72\x64" => $uk);
        $ZF = wp_json_encode($aV);
        $sw = self::create_auth_header($hS, $Yl);
        $bC = self::call_api($xz, $ZF, $sw);
        return $bC;
    }
    public static function get_customer_key($fK, $uk)
    {
        $xz = MO_HOST_NAME . "\x2f\x6d\x6f\141\163\57\162\145\x73\x74\57\143\165\x73\x74\157\155\x65\162\x2f\153\x65\x79";
        $aV = array("\145\x6d\141\151\x6c" => $fK, "\x70\x61\163\163\167\157\x72\144" => $uk);
        $ZF = wp_json_encode($aV);
        $bC = self::call_api($xz, $ZF);
        return $bC;
    }
    public function submit_contact_us($Co, $z4, $wJ, $B1 = false)
    {
        $current_user = wp_get_current_user();
        $xz = MO_HOST_NAME . "\x2f\x6d\157\141\x73\57\162\145\163\x74\x2f\x63\165\x73\x74\157\155\145\162\x2f\x63\157\x6e\x74\141\x63\164\55\x75\x73";
        $jQ = MoWpnsUtility::get_mo2f_db_option("\x6d\x6f\62\146\x5f\151\x73\x5f\116\x43", "\163\151\164\145\137\157\x70\164\151\157\156") && MoWpnsUtility::get_mo2f_db_option("\155\x6f\x32\146\x5f\x69\163\x5f\x4e\x4e\103", "\x73\x69\x74\x65\x5f\x6f\x70\x74\x69\x6f\x6e");
        $RL = !MoWpnsUtility::get_mo2f_db_option("\x6d\157\62\x66\137\151\x73\137\116\103", "\x73\151\x74\145\137\157\160\x74\151\157\x6e");
        $Dr = MO2F_IS_ONPREM ? "\117" : "\103";
        $jK = '';
        if ($RL) {
            goto D5A;
        }
        if ($jQ) {
            goto OIu;
        }
        goto QSB;
        D5A:
        $jK = "\x56\x31";
        goto QSB;
        OIu:
        $jK = "\126\63";
        QSB:
        global $uz;
        if ($B1) {
            goto jPR;
        }
        $wJ = "\x5b\x57\157\x72\x64\x50\162\145\x73\163\x20\x32\x20\106\x61\143\x74\157\x72\x20\101\165\164\150\x65\156\164\x69\143\x61\164\x69\157\156\40\x50\x6c\x75\x67\151\156\x3a\40" . $Dr . $jK . "\x20\55\x20\126\x20" . MO2F_VERSION . "\40\x5d\72\x20" . $wJ;
        goto ZN9;
        jPR:
        $wJ = "\x5b\x43\x61\154\154\40\122\x65\x71\x75\145\163\164\40\x2d\x20\x57\x6f\162\x64\x50\x72\145\x73\163\x20\x32\40\x46\x61\x63\x74\157\162\x20\101\x75\x74\x68\145\156\x74\x69\143\141\x74\151\x6f\156\x20\120\x6c\x75\x67\x69\156\x3a\x20" . $Dr . $jK . "\x20\x2d\x20\x56\40" . MO2F_VERSION . "\x20\x5d\72\40" . $wJ;
        ZN9:
        $aV = array("\x66\x69\162\x73\164\116\141\155\145" => $current_user->user_firstname, "\x6c\141\x73\x74\116\x61\155\x65" => $current_user->user_lastname, "\143\x6f\x6d\160\141\x6e\x79" => isset($_SERVER["\123\105\x52\x56\105\x52\x5f\x4e\x41\115\105"]) ? sanitize_text_field(wp_unslash($_SERVER["\x53\105\122\126\105\122\137\116\x41\115\105"])) : '', "\145\155\141\x69\x6c" => $Co, "\143\143\105\155\x61\151\x6c" => "\x6d\x66\x61\x73\x75\x70\160\x6f\x72\x74\x40\170\x65\143\x75\x72\151\146\171\x2e\143\x6f\155", "\x70\x68\x6f\156\x65" => $z4, "\161\165\145\162\x79" => $wJ);
        $e5 = wp_json_encode($aV);
        $bC = self::call_api($xz, $e5);
        set_transient("\x6d\x6f\62\x66\137\x71\x75\x65\162\x79\137\163\145\156\x74", 1, 30);
        return true;
    }
    public function lookup_ip($CG)
    {
        $xz = MO_HOST_NAME . "\x2f\x6d\x6f\x61\163\57\162\x65\163\x74\x2f\163\145\143\x75\x72\x69\164\171\x2f\x69\x70\x6c\157\157\x6b\165\x70";
        $aV = array("\x69\160" => $CG);
        $ZF = wp_json_encode($aV);
        $bC = self::call_api($xz, $ZF);
        return $bC;
    }
    public function send_otp_token($dX, $T7 = null, $fK = null)
    {
        $rc = get_site_option("\155\157\62\146\x5f\143\x75\x73\164\x6f\x6d\145\x72\x4b\x65\171");
        $Yl = get_site_option("\x6d\157\x32\x66\x5f\141\160\x69\137\x6b\x65\x79");
        $xz = MO_HOST_NAME . "\57\x6d\x6f\x61\x73\x2f\141\x70\151\57\x61\x75\164\150\x2f\143\150\141\x6c\154\x65\x6e\x67\145";
        $aV = array("\143\165\x73\x74\157\155\145\x72\113\x65\171" => $rc, "\145\x6d\x61\151\154" => $fK, "\160\x68\x6f\156\x65" => $T7, "\165\x73\145\162\156\x61\x6d\145" => $fK, "\x61\x75\x74\150\124\171\160\x65" => $dX, "\164\162\141\x6e\163\x61\143\164\151\157\156\x4e\x61\155\145" => "\127\157\162\x64\120\x72\x65\x73\x73\40\x32\x20\106\141\143\164\157\x72\x20\101\x75\x74\x68\145\156\164\151\x63\141\x74\151\x6f\x6e\x20\x50\x6c\165\x67\x69\156");
        $ZF = wp_json_encode($aV);
        $sw = $this->create_auth_header($rc, $Yl);
        $bC = self::call_api($xz, $ZF, $sw);
        $hP = json_decode($bC, true);
        if (!("\x53\x55\103\103\105\x53\x53" === $hP["\x73\164\x61\x74\x75\x73"])) {
            goto MSv;
        }
        $bW = get_site_option("\143\x6d\126\x74\131\127\x6c\165\141\x57\65\156\x54\x31\x52\x51\x56\x48\112\150\142\x6e\116\150\131\x33\122\160\x62\62\65\x7a");
        update_site_option("\x63\155\x56\x74\x59\x57\154\x75\141\127\65\156\x54\61\122\x51\126\x48\112\150\x62\156\x4e\150\131\63\122\160\142\x32\x35\172", $bW - 1);
        $Bj = get_site_option("\143\155\126\x74\x59\127\154\x75\x61\127\x35\x6e\x54\61\x52\121");
        update_site_option("\x63\x6d\126\x74\x59\x57\x6c\165\141\127\x35\156\124\61\122\121", $Bj - 1);
        if (!("\x34" === get_site_option("\143\x6d\126\x74\131\127\154\x75\141\127\65\x6e\124\x31\122\x51\x56\x48\112\150\142\156\116\x68\x59\x33\x52\160\x62\x32\x35\x7a") && MoWpnsConstants::OTP_OVER_SMS === $dX)) {
            goto ZrM;
        }
        Miniorange_Authentication::mo2f_low_otp_alert("\x73\x6d\x73");
        ZrM:
        if (!("\65" === get_site_option("\143\155\x56\x74\x59\127\x6c\x75\x61\x57\65\x6e\x54\x31\122\121") && (MoWpnsConstants::OTP_OVER_EMAIL === $dX || MoWpnsConstants::OUT_OF_BAND_EMAIL === $dX))) {
            goto oWZ;
        }
        Miniorange_Authentication::mo2f_low_otp_alert("\x65\155\141\151\154");
        oWZ:
        MSv:
        return $bC;
    }
    public function miniorange_auth_challenge($Ww, $dX, $hS, $Yl, $cs = null)
    {
        $xz = MO_HOST_NAME . "\57\x6d\157\x61\x73\x2f\x61\160\x69\57\x61\165\x74\150\x2f\143\x68\141\x6c\154\x65\x6e\147\x65";
        $it = new Mo2f_Api();
        $Yl = $Yl;
        $Tp = $it->get_http_header_array();
        $aV = array("\x63\x75\163\x74\157\155\145\162\x4b\x65\171" => $hS, "\165\x73\x65\162\156\x61\x6d\x65" => $Ww, "\141\x75\164\x68\124\171\x70\x65" => $dX, "\x74\x72\x61\156\163\141\x63\164\151\157\156\116\141\x6d\145" => "\x57\x6f\x72\144\120\162\145\163\x73\x20\x32\40\106\x61\x63\x74\157\162\x20\101\x75\x74\x68\x65\156\x74\x69\x63\x61\164\151\x6f\156\40\120\x6c\165\147\x69\156");
        $e5 = wp_json_encode($aV);
        $hP = $it->mo2f_http_request($xz, $e5, $Tp);
        return $hP;
    }
    public function validate_otp_token($bO, $li, $Zi, $dX)
    {
        $xz = MO_HOST_NAME . "\57\x6d\157\141\x73\x2f\141\x70\x69\57\x61\165\x74\x68\57\166\141\x6c\151\144\141\164\145";
        $hS = get_site_option("\155\157\x32\x66\137\x63\x75\163\164\x6f\155\x65\162\113\145\171");
        $Yl = get_site_option("\x6d\x6f\x32\146\137\141\x70\151\137\153\145\171");
        $aV = array("\x63\165\163\x74\x6f\x6d\145\162\113\145\171" => $hS, "\x75\x73\x65\162\156\141\x6d\x65" => $Zi, "\141\x75\x74\x68\124\171\160\145" => $dX, "\164\x78\x49\144" => $bO, "\164\157\153\145\x6e" => !is_array($li) ? $li : null, "\141\x6e\x73\167\x65\x72\163" => is_array($li) ? array(array("\x71\x75\145\163\164\x69\157\x6e" => $li[0], "\141\156\x73\x77\145\162" => $li[1]), array("\161\x75\x65\x73\164\x69\157\156" => $li[2], "\141\156\x73\x77\145\162" => $li[3])) : null);
        $ZF = wp_json_encode($aV);
        $sw = $this->create_auth_header($hS, $Yl);
        $bC = self::call_api($xz, $ZF, $sw);
        return $bC;
    }
    public function check_customer($fK)
    {
        $xz = MO_HOST_NAME . "\x2f\155\157\141\x73\57\x72\145\x73\x74\57\143\165\163\164\x6f\x6d\145\162\x2f\x63\150\x65\x63\153\55\x69\x66\x2d\145\x78\x69\163\x74\163";
        $aV = array("\x65\x6d\x61\x69\154" => $fK);
        $ZF = wp_json_encode($aV);
        $bC = self::call_api($xz, $ZF);
        return $bC;
    }
    public function mo_wpns_forgot_password()
    {
        $xz = MO_HOST_NAME . "\x2f\x6d\157\141\163\57\x72\x65\x73\x74\x2f\x63\x75\163\x74\x6f\155\145\x72\57\160\x61\x73\x73\167\157\162\x64\x2d\162\145\163\145\x74";
        $fK = get_site_option("\155\x6f\62\146\137\145\x6d\141\151\x6c");
        $hS = get_site_option("\x6d\157\x32\146\137\x63\x75\163\164\x6f\155\145\162\x4b\145\171");
        $Yl = get_site_option("\155\157\x32\x66\137\141\x70\x69\x5f\x6b\x65\x79");
        $aV = array("\145\x6d\141\x69\154" => $fK);
        $ZF = wp_json_encode($aV);
        $sw = $this->create_auth_header($hS, $Yl);
        $bC = self::call_api($xz, $ZF, $sw);
        return $bC;
    }
    public function send_notification($RU, $a3, $hP, $p3, $VZ, $ZY)
    {
        $Tp = "\115\x49\115\105\x2d\126\x65\x72\163\151\157\x6e\72\x20\x31\56\x30" . "\15\xa";
        $Tp .= "\x43\157\x6e\164\145\156\164\x2d\164\171\160\145\72\x74\x65\x78\x74\57\x68\x74\x6d\x6c\73\x63\150\141\x72\x73\x65\164\x3d\x55\x54\106\x2d\70" . "\15\xa";
        $Tp .= "\106\162\157\x6d\x3a\40" . $VZ . "\x3c" . $p3 . "\x3e" . "\15\12";
        mail($RU, $a3, $hP, $Tp);
        return wp_json_encode(array("\163\164\x61\164\x75\x73" => "\123\125\103\x43\x45\x53\x53", "\163\164\x61\164\x75\163\x4d\145\x73\163\x61\147\x65" => "\x53\125\103\103\105\x53\x53"));
    }
    public function send_email_alert($fK, $T7, $jD, $uL)
    {
        global $uz;
        global $user;
        $xz = MO_HOST_NAME . "\57\x6d\157\x61\163\57\x61\x70\x69\57\156\157\x74\x69\146\171\57\163\x65\156\x64";
        $hS = MoWpnsConstants::DEFAULT_CUSTOMER_KEY;
        $Yl = MoWpnsConstants::DEFAULT_API_KEY;
        $p3 = "\156\x6f\x2d\162\x65\x70\x6c\171\x40\170\145\x63\x75\x72\x69\x66\171\x2e\x63\x6f\x6d";
        $DS = get_site_option("\116\157\137\x6f\146\137\x64\x61\171\163\x5f\x61\143\x74\x69\166\x65\137\x77\x6f\x72\x6b");
        $DS = intval($DS);
        if ("\x6d\x6f\x5f\167\160\x6e\163\x5f\x73\153\x69\160\x5f\146\145\145\x64\x62\141\143\x6b" === $uL) {
            goto s7x;
        }
        if ("\x6d\157\x5f\x77\160\156\163\137\x66\145\x65\x64\x62\141\x63\x6b" === $uL) {
            goto zWJ;
        }
        goto wqQ;
        s7x:
        $a3 = "\x44\145\x61\x63\164\151\x76\141\x74\x65\x20\x5b\x46\145\145\144\x62\141\x63\x6b\40\x53\153\x69\x70\x70\145\x64\x5d\72\x20\127\157\162\x64\x50\x72\x65\163\x73\40\155\x69\x6e\x69\x4f\162\x61\x6e\147\x65\x20\62\x2d\x46\x61\143\164\157\162\x20\x50\154\x75\147\x69\156\x20\x3a" . $DS;
        goto wqQ;
        zWJ:
        $a3 = "\106\145\145\144\142\141\x63\x6b\72\x20\x57\x6f\162\144\x50\162\145\x73\x73\x20\x6d\151\x6e\x69\x4f\162\141\156\x67\145\x20\x32\55\106\141\x63\x74\x6f\162\x20\x50\154\165\x67\x69\156\x20\x2d\40" . $fK . "\40\x3a\x20" . $DS;
        wqQ:
        $user = wp_get_current_user();
        $jQ = MoWpnsUtility::get_mo2f_db_option("\155\x6f\62\146\x5f\151\163\137\x4e\x43", "\x73\151\x74\x65\137\x6f\160\x74\151\157\x6e") && MoWpnsUtility::get_mo2f_db_option("\x6d\x6f\x32\146\137\151\163\137\x4e\x4e\x43", "\x73\151\164\x65\137\157\160\164\x69\x6f\156");
        $RL = !MoWpnsUtility::get_mo2f_db_option("\x6d\157\x32\x66\137\151\x73\137\116\103", "\163\151\164\145\x5f\x6f\160\x74\151\157\156");
        $Dr = MO2F_IS_ONPREM ? "\117" : "\103";
        $jK = '';
        if ($RL) {
            goto Lzn;
        }
        if ($jQ) {
            goto I1v;
        }
        goto H3x;
        Lzn:
        $jK = "\126\x31";
        goto H3x;
        I1v:
        $jK = "\x56\x33";
        H3x:
        $wJ = "\x5b\x57\157\162\144\x50\x72\145\163\x73\40\62\40\x46\141\x63\164\x6f\162\x20\x41\165\x74\x68\x65\x6e\164\151\x63\141\164\151\x6f\x6e\x20\120\x6c\x75\147\151\156\72\40" . $Dr . $jK . "\40\x2d\x20\x56\40" . MO2F_VERSION . "\135\72\x20" . $jD;
        $ke = isset($_SERVER["\123\x45\122\x56\x45\x52\137\116\101\x4d\x45"]) ? sanitize_text_field(wp_unslash($_SERVER["\x53\x45\122\x56\x45\122\x5f\x4e\x41\115\x45"])) : '';
        $hP = "\74\x64\151\166\x20\76\x48\145\154\154\x6f\54\40\x3c\x62\x72\x3e\x3c\142\x72\76\106\x69\162\x73\164\40\x4e\x61\155\145\x20\72" . $user->user_firstname . "\x3c\142\162\x3e\x3c\142\x72\x3e\x4c\x61\x73\x74\40\x20\x4e\141\x6d\x65\40\x3a" . $user->user_lastname . "\x20\40\x20\x3c\142\162\x3e\x3c\142\162\x3e\x43\157\155\160\x61\156\x79\x20\72\x3c\x61\x20\x68\162\145\x66\75\42" . $ke . "\42\40\164\141\162\x67\x65\164\x3d\42\137\x62\154\141\x6e\x6b\x22\x20\x3e" . sanitize_text_field(wp_unslash($_SERVER["\123\105\122\126\x45\122\137\116\101\115\x45"])) . "\74\x2f\141\x3e\x3c\x62\x72\76\x3c\x62\162\x3e\x50\x68\x6f\156\145\40\116\x75\x6d\142\145\x72\x20\x3a" . $T7 . "\x3c\x62\x72\x3e\x3c\x62\x72\76\x45\x6d\x61\x69\154\40\72\x3c\x61\x20\150\162\145\x66\x3d\42\x6d\141\151\154\164\x6f\72" . esc_html($fK) . "\42\40\164\x61\x72\147\x65\164\75\42\137\x62\154\141\156\153\42\76" . esc_html($fK) . "\74\57\x61\x3e\74\x62\162\x3e\74\142\162\x3e\121\x75\x65\162\171\x20\72" . wp_kses_post($wJ) . "\74\x2f\144\x69\x76\76";
        $aV = array("\x63\x75\163\x74\x6f\155\x65\162\x4b\145\x79" => $hS, "\163\x65\x6e\x64\105\155\141\151\x6c" => true, "\x65\155\x61\x69\x6c" => array("\143\x75\x73\x74\x6f\x6d\145\x72\113\x65\x79" => $hS, "\x66\x72\157\155\105\155\141\151\x6c" => $p3, "\146\162\x6f\155\116\x61\155\145" => "\130\x65\x63\x75\x72\151\146\x79", "\164\x6f\105\155\141\x69\x6c" => "\x6d\146\141\x73\165\160\x70\157\162\164\x40\x78\x65\143\165\162\x69\146\171\56\143\x6f\155", "\164\x6f\116\141\155\x65" => "\x6d\146\x61\x73\x75\x70\160\x6f\162\164\100\170\x65\143\x75\162\151\x66\171\56\x63\x6f\x6d", "\x73\165\142\152\x65\x63\x74" => $a3, "\143\x6f\156\164\x65\156\x74" => $hP));
        $e5 = wp_json_encode($aV);
        $sw = $this->create_auth_header($hS, $Yl);
        $bC = self::call_api($xz, $e5, $sw);
        return $bC;
    }
    private static function create_auth_header($hS, $Yl)
    {
        $NU = round(microtime(true) * 1000);
        $NU = number_format($NU, 0, '', '');
        $fk = $hS . $NU . $Yl;
        $sw = hash("\163\150\141\65\61\x32", $fk);
        $kd = array("\x43\x6f\x6e\x74\x65\156\x74\x2d\x54\x79\160\x65" => "\141\x70\160\154\151\143\141\164\151\157\x6e\x2f\x6a\x73\x6f\156", "\x43\x75\163\x74\157\155\145\x72\x2d\x4b\x65\171" => $hS, "\x54\151\155\x65\x73\164\141\x6d\x70" => $NU, "\x41\165\x74\x68\157\162\151\x7a\x61\x74\151\x6f\156" => $sw);
        return $kd;
    }
    private static function call_api($xz, $Wu, $LB = array("\103\157\x6e\164\x65\x6e\164\x2d\124\171\x70\x65" => "\x61\x70\160\x6c\x69\x63\141\x74\151\x6f\156\x2f\x6a\163\157\156", "\143\x68\141\x72\163\x65\x74" => "\x55\124\106\55\70", "\x41\x75\x74\150\157\x72\x69\172\141\x74\x69\x6f\156" => "\x42\x61\x73\151\x63"))
    {
        $as = array("\155\x65\x74\x68\157\x64" => "\x50\x4f\123\x54", "\x62\157\144\171" => $Wu, "\164\x69\x6d\x65\157\x75\x74" => "\61\x30\x30\x30\60", "\162\x65\144\x69\162\x65\x63\x74\x69\x6f\156" => "\x31\60", "\163\163\154\166\145\162\151\146\171" => false, "\x68\x74\x74\x70\x76\x65\162\163\x69\157\x6e" => "\x31\x2e\60", "\x62\154\x6f\x63\x6b\x69\156\147" => true, "\x68\145\x61\144\x65\162\x73" => $LB);
        $it = new Mo2f_Api();
        $bC = $it->mo2f_wp_remote_post($xz, $as);
        return $bC;
    }
    public function mo2f_get_backup_codes($y2, $EQ)
    {
        $xz = MoWpnsConstants::GENERATE_BACK_CODE;
        $mC = $this->mo2f_generate_backup_codes($y2, $EQ);
        $HC = array("\x6d\157\62\146\137\145\155\x61\x69\154" => $y2, "\x6d\x6f\62\146\x5f\144\157\x6d\x61\x69\x6e" => $EQ, "\110\x54\124\120\x5f\101\x55\124\110\x4f\x52\111\x5a\x41\124\111\117\116" => "\102\x65\141\x72\x65\x72\x7c" . $mC, "\x6d\157\x32\146\137\147\x65\x6e\x65\162\x61\x74\145\137\x62\x61\x63\153\165\x70\x5f\x63\157\x64\x65\163" => "\151\x6e\151\x74\x69\141\x74\145\144\137\x62\x61\143\153\165\x70\137\x63\157\x64\x65\x73");
        return $this->mo_2f_remote_call_function($xz, $HC);
    }
    public function mo2f_validate_backup_codes($vC, $y2)
    {
        $xz = MoWpnsConstants::VALIDATE_BACKUP_CODE;
        $EQ = site_url();
        $mC = $this->mo2f_generate_backup_codes($y2, $EQ);
        $HC = array("\x6d\157\x32\x66\137\157\x74\x70\137\x74\x6f\153\145\x6e" => $vC, "\155\157\x32\x66\x5f\x75\163\145\162\x5f\x65\155\x61\151\154" => $y2, "\x48\124\124\120\137\x41\125\x54\x48\117\x52\x49\132\101\x54\x49\117\116" => "\x42\x65\x61\162\x65\x72\174" . $mC, "\155\157\62\x66\137\x73\151\164\x65\137\165\x72\154" => $EQ);
        $as = array("\155\145\164\x68\x6f\144" => "\x50\117\x53\x54", "\x74\x69\155\145\x6f\x75\x74" => 45, "\163\x73\x6c\166\145\x72\151\146\x79" => false, "\150\x65\x61\144\145\162\x73" => array(), "\x62\157\x64\x79" => $HC);
        $mC = wp_remote_post($xz, $as);
        $mC = wp_remote_retrieve_body($mC);
        return $mC;
    }
    public function mo2f_generate_backup_codes($y2, $EQ)
    {
        $xz = MoWpnsConstants::AUTHENTICATE_REQUEST;
        $HC = array("\155\157\x32\146\x5f\145\155\x61\151\x6c" => $y2, "\x6d\x6f\62\146\x5f\x64\x6f\x6d\141\x69\156" => $EQ, "\155\157\x32\146\137\x63\x4b\145\171" => MoWpnsConstants::DEFAULT_CUSTOMER_KEY, "\155\157\x32\146\x5f\x63\x53\145\x63\162\145\x74" => MoWpnsConstants::DEFAULT_API_KEY);
        return $this->mo_2f_remote_call_function($xz, $HC);
    }
    public function mo2f_update_user_info($fK, $dX, $T7, $hF, $ch)
    {
        $xz = MO_HOST_NAME . "\x2f\155\x6f\141\163\x2f\x61\x70\x69\57\141\144\x6d\151\156\x2f\x75\163\145\162\x73\57\x75\x70\x64\141\164\x65";
        $hS = get_site_option("\155\x6f\x32\x66\x5f\x63\165\x73\x74\157\155\x65\162\113\x65\171");
        $aV = array("\143\x75\x73\x74\157\x6d\145\x72\x4b\145\171" => $hS, "\x75\x73\145\x72\156\x61\155\145" => $fK, "\160\x68\x6f\x6e\x65" => $T7, "\x61\165\x74\x68\124\171\160\x65" => $dX, "\164\x72\x61\x6e\x73\x61\x63\164\x69\x6f\156\x4e\141\x6d\145" => $hF, "\141\x64\155\x69\156\114\x6f\147\151\156\123\x65\143\157\156\x64\106\141\143\x74\x6f\x72" => $ch);
        $LB = $this->mo2f_api->get_http_header_array();
        $hP = $this->mo2f_api->mo2f_http_request($xz, $aV, $LB);
        return $hP;
    }
    public function mo2f_get_userinfo($fK)
    {
        $xz = MO_HOST_NAME . "\x2f\155\157\141\x73\x2f\x61\160\x69\x2f\141\x64\155\151\156\57\x75\x73\145\x72\163\57\147\145\x74";
        $hS = get_site_option("\x6d\x6f\62\x66\x5f\x63\165\x73\164\x6f\155\x65\x72\x4b\x65\171");
        $aV = array("\143\165\163\164\x6f\155\145\162\x4b\x65\171" => $hS, "\x75\163\x65\x72\x6e\x61\155\x65" => $fK);
        $it = new Mo2f_Api();
        $LB = $it->get_http_header_array();
        $mC = $it->mo2f_http_request($xz, $aV, $LB);
        if (is_array($mC)) {
            goto REd;
        }
        return $mC;
        goto G4U;
        REd:
        return wp_json_encode($mC);
        G4U:
    }
    public function mo_2f_remote_call_function($xz, $HC)
    {
        $as = array("\155\145\x74\x68\157\144" => "\120\x4f\x53\124", "\x74\x69\155\145\157\165\x74" => 45, "\163\163\154\166\x65\162\x69\x66\x79" => false, "\x68\145\x61\144\x65\x72\x73" => array(), "\x62\x6f\144\171" => $HC);
        $it = new Mo2f_Api();
        $mC = $it->mo2f_wp_remote_post($xz, $as);
        $l_ = wp_remote_retrieve_response_code(wp_remote_post($xz, $as));
        $gJ = json_decode($mC, true);
        if (is_array($gJ) && "\x45\x52\122\117\122" === $gJ["\163\164\x61\x74\165\163"] || 200 !== $l_) {
            goto pus;
        }
        return $mC;
        goto mxZ;
        pus:
        return "\111\156\164\x65\162\x6e\x65\164\x43\x6f\x6e\156\x65\143\x74\x69\x76\151\x74\x79\105\x72\x72\157\162";
        mxZ:
    }
    public function mo_check_user_already_exist($fK)
    {
        $xz = MO_HOST_NAME . "\x2f\x6d\x6f\x61\163\57\141\160\151\57\x61\x64\x6d\x69\156\x2f\165\x73\x65\x72\x73\x2f\163\x65\x61\x72\x63\150";
        $hS = get_site_option("\155\x6f\x32\146\x5f\x63\x75\x73\164\157\x6d\145\162\113\145\171");
        $aV = array("\x63\x75\163\164\157\155\145\162\x4b\x65\x79" => $hS, "\165\x73\x65\x72\x6e\141\155\145" => $fK);
        $LB = $this->mo2f_api->get_http_header_array();
        return $this->mo2f_api->mo2f_http_request($xz, $aV, $LB);
    }
    public function mo_create_user($cs, $fK)
    {
        $xz = MO_HOST_NAME . "\x2f\155\157\x61\x73\57\141\160\x69\57\141\x64\155\x69\x6e\57\x75\163\145\x72\x73\x2f\x63\x72\x65\141\x74\145";
        $hS = get_site_option("\155\157\62\146\x5f\x63\165\163\x74\x6f\x6d\145\162\113\x65\x79");
        $aV = array("\143\x75\x73\x74\157\x6d\145\x72\113\x65\171" => $hS, "\165\x73\x65\162\156\x61\x6d\145" => $fK, "\x66\151\x72\163\164\116\x61\155\145" => $cs->user_firstname, "\x6c\x61\163\164\x4e\141\x6d\145" => $cs->user_lastname);
        $LB = $this->mo2f_api->get_http_header_array();
        return $this->mo2f_api->mo2f_http_request($xz, $aV, $LB);
    }
    public function get_customer_transactions($Hf, $hG)
    {
        $xz = MO_HOST_NAME . "\x2f\155\157\141\163\57\x72\145\163\x74\x2f\x63\x75\x73\164\157\x6d\145\162\57\154\x69\x63\145\156\163\145";
        $hS = get_site_option("\x6d\157\62\146\137\143\165\x73\164\157\155\145\x72\113\145\171");
        $aV = array("\x63\x75\x73\x74\157\x6d\145\162\111\x64" => $hS, "\x61\160\x70\x6c\x69\143\x61\164\151\x6f\156\x4e\x61\155\145" => $Hf, "\154\151\143\145\x6e\163\x65\124\171\160\145" => $hG);
        $e5 = wp_json_encode($aV);
        $Tp = $this->mo2f_api->get_http_header_array();
        $hP = $this->mo2f_api->mo2f_http_request($xz, $e5, $Tp);
        return $hP;
    }
    public function mo2f_send_telegram_otp($Ww)
    {
        $li = '';
        $ET = 1;
        SuN:
        if (!($ET < 7)) {
            goto xFT;
        }
        $li .= wp_rand(0, 9);
        QBQ:
        $ET++;
        goto SuN;
        xFT:
        $bO = MoWpnsUtility::rand();
        TwoFAMoSessions::add_session_var("\x6d\x6f\x32\146\x5f\157\x74\160\x5f\x74\x6f\153\x65\x6e", $bO . $li);
        TwoFAMoSessions::add_session_var("\x6d\x6f\62\146\137\164\145\154\145\x67\162\x61\x6d\137\x74\151\x6d\145", time());
        $xz = esc_url(MoWpnsConstants::TELEGRAM_OTP_LINK);
        $HC = array("\x6d\157\x32\x66\x5f\157\x74\160\137\x74\x6f\153\x65\156" => $li, "\x6d\157\x32\146\x5f\143\x68\141\164\151\144" => $Ww);
        $as = array("\x6d\145\x74\x68\157\x64" => "\120\117\x53\124", "\164\151\155\145\x6f\x75\x74" => 10, "\163\163\154\166\145\x72\151\146\x79" => false, "\x68\x65\141\x64\x65\x72\163" => array(), "\142\157\144\x79" => $HC);
        $it = new Mo2f_Api();
        $mC = $it->mo2f_wp_remote_post($xz, $as);
        $hP = array("\x73\x74\x61\x74\165\x73" => $mC, "\164\170\111\144" => $bO);
        return $hP;
    }
    public function mo2f_validate_telegram_code($li, $G5)
    {
        $Ov = TwoFAMoSessions::get_session_var("\155\157\62\x66\x5f\157\x74\160\137\164\x6f\x6b\x65\156");
        $rs = TwoFAMoSessions::get_session_var("\x6d\x6f\x32\146\137\x74\145\154\145\147\162\141\155\137\164\x69\155\x65");
        $j9 = time() - 300;
        $rs = (int) $rs;
        if ((string) ($G5 . $li) === (string) $Ov) {
            goto nF5;
        }
        $hP = array("\163\164\x61\164\x75\163" => "\x49\116\126\101\x4c\x49\104\137\x4f\x54\120", "\155\x65\x73\x73\x61\147\x65" => MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_OTP));
        goto dG4;
        nF5:
        if ($j9 < $rs) {
            goto Ab4;
        }
        $hP = array("\x73\x74\x61\x74\x75\x73" => "\x45\x52\x52\x4f\x52", "\155\x65\163\x73\x61\x67\x65" => "\x4f\x54\120\x20\x68\141\163\x20\x62\x65\x65\x6e\40\145\x78\x70\x69\162\x65\144\40\160\154\145\x61\x73\x65\x20\x72\145\151\x6e\x69\164\x69\x61\164\145\x20\141\156\x6f\x74\150\145\162\x20\164\162\x61\x6e\x73\141\143\x74\x69\x6f\156\x2e");
        goto ZJS;
        Ab4:
        $hP = array("\163\164\x61\x74\x75\x73" => "\x53\125\x43\103\105\123\123");
        ZJS:
        dG4:
        return $hP;
    }
}
cHk:
