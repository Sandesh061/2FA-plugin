<?php


namespace TwoFA\Helper;

use TwoFA\Traits\Instance;
use TwoFA\Objects\Mo2f_TabDetails;
use TwoFA\Onprem\Mo2f_Main_Handler;
if (defined("\101\x42\123\x50\101\124\x48")) {
    goto sqB;
}
exit;
sqB:
if (class_exists("\x4d\x6f\x32\146\x5f\x4d\x65\x6e\165\111\164\x65\x6d\x73")) {
    goto T2W;
}
final class Mo2f_MenuItems
{
    use Instance;
    private $callback;
    private $menu_slug;
    private $menu_logo;
    private $tab_details;
    private function __construct()
    {
        $this->callback = array($this, "\155\157\x5f\167\x70\x6e\163");
        $this->menu_logo = plugin_dir_url(dirname(__FILE__)) . "\x69\x6e\x63\x6c\165\144\145\163\57\151\x6d\141\x67\x65\163\x2f\x6d\151\x6e\151\x6f\162\141\x6e\147\x65\x5f\x69\x63\x6f\x6e\56\160\156\147";
        $VD = Mo2f_TabDetails::instance();
        $this->tab_details = $VD->tab_details;
        $this->menu_slug = $VD->parent_slug;
        $this->add_main_menu();
        $this->add_sub_menus();
    }
    private function add_main_menu()
    {
        $user = wp_get_current_user();
        $v1 = $user->ID;
        $V1 = get_site_option("\x6d\x6f\62\146\137\x6f\156\x70\162\145\155\x5f\x61\x64\155\151\156");
        $y4 = new Mo2f_Main_Handler();
        $UQ = $y4->mo2f_check_if_twofa_is_enabled($user);
        $yu = $UQ || $v1 === (int) $V1;
        if (!$yu) {
            goto RGe;
        }
        add_menu_page("\x6d\x69\156\x69\117\x72\x61\x6e\147\x65\40\62\x2d\106\141\x63\164\157\x72", "\x6d\x69\x6e\151\117\x72\x61\156\x67\145\x20\x32\x2d\x46\141\x63\164\157\162", "\x72\145\141\144", $this->menu_slug, $this->callback, $this->menu_logo);
        RGe:
    }
    private function add_sub_menus()
    {
        foreach ($this->tab_details as $AR) {
            if (!$AR->show_in_nav) {
                goto QuE;
            }
            add_submenu_page($this->menu_slug, $AR->page_title, $AR->page_title, $AR->capability, $AR->menu_slug, $this->callback);
            QuE:
            l5w:
        }
        g55:
        if (!(isset($_GET["\x61\143\x74\x69\157\156"]) && "\x72\x65\x73\x65\164\x5f\x65\x64\x69\x74" === sanitize_text_field(wp_unslash($_GET["\141\x63\x74\x69\x6f\156"])))) {
            goto DRb;
        }
        $z3 = add_users_page("\122\145\163\x65\x74\40\62\156\x64\40\106\141\143\164\157\162", null, "\x6d\x61\156\141\x67\145\x5f\157\160\x74\x69\157\x6e\x73", "\x72\x65\x73\145\164", array($this, "\155\x6f\x32\146\x5f\162\x65\x73\145\164\137\62\x66\x61\x5f\146\157\162\137\x75\163\145\162\163\137\142\171\137\141\x64\x6d\x69\156"), 66);
        DRb:
    }
    public function mo_wpns()
    {
        global $GI, $Gw;
        $GI->mo_plugin_activate();
        $Gw->mo_plugin_activate();
        add_site_option("\105\155\141\x69\x6c\x54\162\x61\156\x73\141\x63\x74\x69\x6f\x6e\103\x75\x72\162\x65\156\x74", 30);
        include dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . "\143\157\x6e\164\162\x6f\154\154\145\162\163\x2f\x6d\x61\151\x6e\x2d\143\x6f\156\x74\162\x6f\x6c\154\145\x72\56\160\x68\160";
    }
    public function mo2f_reset_2fa_for_users_by_admin()
    {
        $dk = wp_create_nonce("\122\x65\x73\x65\x74\124\167\157\106\x6e\157\x6e\x63\x65");
        if (!(!isset($_GET["\x6d\157\62\146\x5f\162\x65\163\145\164\x2d\x32\x66\141"]) || !wp_verify_nonce(sanitize_key(wp_unslash($_GET["\x6d\157\62\146\x5f\162\145\163\x65\x74\55\62\146\141"])), "\x72\145\x73\x65\x74\137\x65\x64\x69\164"))) {
            goto DjP;
        }
        wp_send_json("\105\122\122\x4f\x52");
        DjP:
        if (!(isset($_GET["\141\143\x74\x69\x6f\156"]) && sanitize_text_field(wp_unslash($_GET["\x61\x63\164\x69\157\156"])) === "\162\x65\163\x65\x74\137\145\x64\151\164")) {
            goto p7i;
        }
        $v1 = isset($_GET["\165\x73\145\162\137\x69\144"]) ? sanitize_text_field(wp_unslash($_GET["\165\163\145\162\x5f\151\144"])) : '';
        $wf = get_userdata($v1);
        if (is_numeric($v1) && $wf) {
            goto zOw;
        }
        echo "\x9\11\11\x9\74\150\x32\x3e\x20\111\x6e\x76\x61\x6c\151\144\40\x55\163\x65\162\x20\x49\x64\x20\74\57\x68\x32\76\15\xa\11\x9\11\11\11";
        goto Vv2;
        zOw:
        echo "\x9\11\11\x9\x3c\144\x69\x76\x20\x63\x6c\x61\x73\163\75\x22\167\162\141\160\x22\x3e\15\12\x9\x9\x9\x9\11\74\146\157\x72\x6d\x20\x6d\145\164\150\x6f\144\x3d\42\160\157\163\x74\42\x20\156\x61\155\x65\x3d\x22\x72\145\163\x65\164\62\x66\141\42\40\x69\144\75\42\x72\145\163\145\164\62\146\x61\42\40\141\x63\164\151\x6f\x6e\75\42";
        echo esc_url(admin_url() . "\141\144\155\151\x6e\56\x70\150\x70\x3f\x70\x61\x67\145\75\155\x6f\137\62\146\x61\x5f\x72\145\160\157\162\x74\163\x26\163\x75\142\x70\141\147\x65\x3d\165\x73\x65\x72\x73\62\x66\x61\x73\164\x61\x74\165\x73");
        echo "\42\x3e\xd\xa\11\11\x9\11\x9\11\74\150\x31\76\122\145\x73\x65\164\40\x32\156\x64\x20\106\x61\143\x74\157\x72\x3c\x2f\x68\x31\76\xd\xa\xd\12\11\x9\11\x9\x9\11\x3c\160\76\x59\157\165\x20\x68\141\166\x65\40\x73\160\x65\x63\x69\x66\151\145\x64\40\x74\x68\x69\x73\x20\x75\163\145\162\40\146\157\162\40\x72\x65\163\145\x74\x3a\74\57\160\76\xd\xa\15\xa\x9\11\11\x9\11\11\74\x75\154\x3e\15\xa\11\11\x9\x9\11\x9\11\74\x6c\x69\x3e\111\x44\40\43";
        echo esc_html($wf->ID);
        echo "\x3a\40";
        echo esc_html($wf->user_login);
        echo "\74\x2f\x6c\151\x3e\xd\xa\11\x9\x9\x9\x9\11\74\x2f\165\x6c\76\15\xa\11\x9\11\11\x9\x9\74\151\156\x70\165\164\40\x74\171\160\145\x3d\x22\150\x69\x64\144\145\156\42\x20\x6e\141\x6d\x65\75\42\x75\x73\145\162\151\144\x22\x20\166\141\154\x75\x65\75\42";
        echo esc_attr($v1);
        echo "\42\x3e\15\12\11\x9\x9\x9\x9\x9\x3c\x69\x6e\160\x75\164\40\164\171\160\145\75\x22\150\x69\144\144\x65\x6e\x22\x20\156\x61\x6d\145\x3d\x22\155\151\156\x69\x6f\x72\x61\x6e\x67\x65\x5f\x72\145\163\145\164\137\62\146\141\137\157\160\164\151\x6f\156\42\x20\166\x61\x6c\x75\145\x3d\42\155\x6f\137\162\145\163\145\164\137\62\146\141\42\x3e\xd\xa\x9\x9\x9\x9\x9\11\x3c\151\x6e\160\165\164\x20\x74\x79\x70\x65\x3d\42\150\151\x64\144\x65\x6e\x22\40\156\141\x6d\145\x3d\42\156\x6f\x6e\x63\x65\x22\x20\166\141\x6c\165\145\x3d\x22";
        echo esc_attr($dk);
        echo "\42\76\xd\12\11\11\11\x9\11\11\x3c\x70\x20\143\x6c\141\x73\x73\75\x22\163\x75\142\155\151\x74\42\x3e\x3c\151\x6e\160\x75\164\40\x74\171\160\145\x3d\42\x73\x75\x62\x6d\x69\x74\x22\x20\x6e\141\x6d\145\x3d\x22\163\x75\x62\155\151\164\x22\x20\x69\144\x3d\42\x73\x75\x62\x6d\x69\x74\42\40\143\154\x61\163\163\75\42\x62\x75\x74\164\157\x6e\40\142\165\164\164\157\156\55\160\x72\x69\x6d\141\162\x79\x22\40\x76\141\154\165\x65\x3d\x22\x43\157\156\x66\x69\x72\x6d\40\x52\145\x73\x65\164\42\76\x3c\57\160\x3e\15\xa\x9\11\11\11\x9\74\x2f\x66\x6f\162\155\x3e\xd\12\11\11\11\11\74\x2f\x64\151\x76\76\xd\xa\xd\12\x9\x9\x9\x9\11";
        Vv2:
        p7i:
    }
}
T2W:
