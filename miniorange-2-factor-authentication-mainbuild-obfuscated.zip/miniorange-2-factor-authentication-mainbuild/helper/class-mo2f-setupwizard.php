<?php


use TwoFA\Onprem\Google_Auth_Onpremise;
use TwoFA\Onprem\MO2f_Utility;
use TwoFA\Database\Mo2fDB;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Onprem\MO2f_Cloud_Onprem_Interface;
if (defined("\x41\102\x53\120\101\124\110")) {
    goto Ioh;
}
exit;
Ioh:
if (class_exists("\115\157\62\146\x5f\123\145\164\x75\160\x77\x69\x7a\x61\162\x64")) {
    goto KOZ;
}
class Mo2f_Setupwizard
{
    public function __construct()
    {
        add_action("\141\144\x6d\x69\156\x5f\x69\x6e\151\x74", array($this, "\x6d\x6f\137\62\x66\137\164\x77\157\137\x66\x61\143\x74\x6f\x72\137\x73\145\164\x75\x77\151\172\x61\x72\x64"));
    }
    public function mo_2f_two_factor_setuwizard()
    {
        add_action("\x77\x70\137\x61\152\141\170\x5f\155\x6f\x5f\164\167\157\x5f\146\x61\x63\x74\x6f\x72\137\x61\152\x61\170", array($this, "\x6d\157\137\x74\167\x6f\x5f\146\141\x63\x74\157\162\137\141\152\141\170\137\163\145\164\x75\x70\167\151\x7a\x61\x72\x64"));
        add_action("\x77\160\x5f\141\152\141\x78\137\x6e\x6f\160\x72\x69\166\x5f\155\x6f\x5f\x74\167\x6f\x5f\x66\141\x63\164\x6f\162\x5f\x61\x6a\x61\170", array($this, "\155\x6f\137\164\167\157\137\146\x61\x63\164\157\162\x5f\141\152\x61\x78\x5f\163\x65\x74\x75\x70\167\151\172\x61\x72\x64"));
    }
    public function mo_two_factor_ajax_setupwizard()
    {
        $GLOBALS["\x6d\x6f\62\x66\x5f\151\163\x5f\x61\x6a\141\170\137\162\x65\x71\x75\145\163\164"] = true;
        if (check_ajax_referer("\x6d\x6f\55\x74\x77\157\55\x66\x61\143\x74\x6f\162\55\141\152\x61\x78\x2d\156\157\156\143\145", "\x6e\157\156\x63\145", false)) {
            goto g7B;
        }
        wp_send_json_error("\125\x6e\153\x6e\x6f\167\x6e\40\x65\x72\x72\x6f\x72\x20\157\x63\x63\x75\162\x65\x64\56\40\x50\154\145\141\163\145\x20\164\162\171\40\141\x67\x61\x69\156\x21");
        g7B:
        switch (isset($_POST["\155\157\137\x32\146\137\164\x77\x6f\x5f\x66\x61\x63\164\x6f\x72\137\x61\x6a\x61\170"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\x6f\137\x32\146\x5f\164\x77\x6f\137\x66\x61\x63\164\x6f\162\137\141\x6a\141\170"])) : '') {
            case "\155\157\x5f\x32\x66\141\x5f\x76\145\x72\x69\146\171\137\x47\101\137\163\145\x74\x75\x70\137\x77\x69\x7a\141\162\x64":
                $this->mo_2fa_verify_ga_setup_wizard();
                goto jF1;
            case "\155\157\137\62\x66\141\137\166\x65\x72\x69\x66\x79\x5f\x4b\x42\101\x5f\163\145\164\x75\160\137\x77\x69\172\141\162\144":
                $this->mo_2fa_verify_kba_setup_wizard();
                goto jF1;
            case "\x6d\x6f\x32\146\137\x73\x6b\151\160\x74\x77\x6f\x66\141\143\x74\157\x72\x5f\x77\151\x7a\x61\x72\x64":
                $this->mo2f_skiptwofactor_wizard();
                goto jF1;
        }
        dBQ:
        jF1:
    }
    public function mo_2fa_verify_kba_setup_wizard()
    {
        global $Gw;
        if (check_ajax_referer("\x6d\x6f\x2d\164\167\157\x2d\x66\x61\x63\164\157\162\x2d\141\152\x61\170\x2d\156\x6f\x6e\x63\x65", "\156\x6f\156\x63\145", false)) {
            goto RVK;
        }
        wp_send_json_error("\x6d\157\62\146\55\141\152\141\170");
        RVK:
        $mq = array("\x6b\142\x61\x5f\161\61" => "\155\157\62\x66\x5f\153\x62\x61\x71\165\x65\x73\164\151\x6f\156\137\x31", "\x6b\142\x61\137\x71\x32" => "\x6d\x6f\x32\146\x5f\153\x62\141\161\165\x65\x73\x74\151\157\156\x5f\62", "\x6b\x62\141\x5f\161\63" => "\155\x6f\x32\146\137\x6b\142\141\x71\x75\x65\x73\164\151\x6f\156\x5f\x33", "\x6b\x62\x61\137\141\61" => "\155\x6f\62\146\137\x6b\142\x61\x5f\141\156\x73\x31", "\153\142\x61\137\141\62" => "\155\x6f\x32\x66\x5f\153\142\141\137\x61\x6e\163\x32", "\153\142\141\x5f\141\x33" => "\155\157\62\x66\x5f\x6b\x62\x61\137\x61\x6e\x73\63");
        foreach ($mq as $t8 => $iY) {
            $mq[$t8] = isset($_POST[$iY]) ? sanitize_text_field(wp_unslash($_POST[$iY])) : null;
            Wz2:
        }
        kkZ:
        $user = wp_get_current_user();
        $this->mo2f_check_and_create_user($user->ID);
        if (!(MO2f_Utility::mo2f_check_empty_or_null($mq["\x6b\x62\141\x5f\161\61"]) || MO2f_Utility::mo2f_check_empty_or_null($mq["\x6b\x62\x61\137\x61\61"]) || MO2f_Utility::mo2f_check_empty_or_null($mq["\x6b\142\141\137\x71\62"]) || MO2f_Utility::mo2f_check_empty_or_null($mq["\x6b\142\x61\137\141\62"]) || MO2f_Utility::mo2f_check_empty_or_null($mq["\153\x62\141\x5f\161\63"]) || MO2f_Utility::mo2f_check_empty_or_null($mq["\153\x62\x61\x5f\141\x33"]))) {
            goto lbO;
        }
        wp_send_json_error("\x49\x6e\166\x61\x6c\x69\x64\x20\121\x75\145\x73\164\x69\157\156\163\40\157\x72\40\101\x6e\x73\167\145\x72\x73");
        lbO:
        if (!(strcasecmp($mq["\153\x62\141\137\x71\x31"], $mq["\153\142\x61\x5f\161\62"]) === 0 || strcasecmp($mq["\x6b\x62\141\x5f\161\62"], $mq["\x6b\x62\141\x5f\x71\x33"]) === 0 || strcasecmp($mq["\153\x62\x61\x5f\161\63"], $mq["\153\x62\x61\x5f\161\x31"]) === 0)) {
            goto QIs;
        }
        wp_send_json_error("\124\150\x65\40\x71\x75\145\163\x74\151\157\x6e\x73\x20\x79\157\x75\x20\163\x65\154\145\143\164\40\155\165\x73\x74\40\142\x65\x20\165\x6e\151\x71\165\145\56");
        QIs:
        foreach ($mq as $t8 => $iY) {
            $mq[$t8] = addcslashes(stripslashes($iY), "\x22\x5c");
            Ulu:
        }
        BbM:
        $fK = $user->user_email;
        $fI = new MO2f_Cloud_Onprem_Interface();
        $Gw->update_user_details($user->ID, array("\155\157\x32\x66\137\123\x65\x63\165\x72\x69\x74\x79\121\x75\x65\x73\x74\x69\157\156\x73\137\x63\157\156\x66\x69\x67\x5f\x73\164\x61\x74\x75\x73" => true, "\x6d\157\x5f\x32\146\x61\143\164\157\162\137\x75\163\x65\162\137\162\145\x67\151\x73\164\x72\x61\164\151\x6f\x6e\137\x73\x74\x61\x74\165\x73" => "\x4d\x4f\137\x32\137\x46\101\103\x54\x4f\x52\137\x50\114\x55\x47\111\116\x5f\123\105\x54\x54\x49\116\x47\x53", "\155\157\x32\x66\x5f\165\x73\x65\x72\137\x65\155\x61\151\154" => $fK));
        $w1 = json_decode($fI->mo2f_register_kba_details($fK, $mq["\153\142\141\x5f\161\61"], $mq["\153\x62\x61\x5f\x61\61"], $mq["\153\142\141\137\161\x32"], $mq["\x6b\x62\141\137\141\x32"], $mq["\153\142\x61\137\161\63"], $mq["\153\142\x61\137\x61\x33"], $user->ID), true);
        if ("\x53\x55\x43\x43\x45\123\x53" === $w1["\x73\x74\141\x74\x75\163"]) {
            goto wLQ;
        }
        wp_send_json_error("\x41\x6e\x20\x65\x72\x72\x6f\162\40\150\141\163\x20\x6f\x63\x63\165\x72\145\144\40\167\x68\x69\154\145\40\x73\x61\166\x69\156\x67\x20\113\102\101\40\x64\145\x74\141\151\154\x73\56\40\x50\154\145\141\x73\x65\x20\164\162\171\x20\141\147\x61\151\x6e\56");
        goto t06;
        wLQ:
        wp_send_json_success();
        t06:
    }
    public function mo_2fa_verify_ga_setup_wizard()
    {
        global $Gw;
        $z_ = dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . "\150\x61\x6e\x64\154\x65\x72" . DIRECTORY_SEPARATOR . "\x74\x77\157\x66\x61" . DIRECTORY_SEPARATOR . "\143\x6c\x61\163\163\x2d\147\157\157\x67\154\x65\x2d\x61\165\164\x68\x2d\x6f\156\160\x72\x65\x6d\x69\163\145\56\x70\150\160";
        include_once $z_;
        $el = new Google_auth_onpremise();
        $v1 = wp_get_current_user()->ID;
        if (check_ajax_referer("\x6d\157\x2d\164\167\157\x2d\x66\x61\143\x74\x6f\x72\x2d\141\152\x61\170\55\156\x6f\156\x63\145", "\x6e\x6f\156\x63\x65", false)) {
            goto LbM;
        }
        wp_send_json_error("\155\x6f\x32\146\x2d\x61\152\141\x78");
        LbM:
        $li = isset($_POST["\155\x6f\62\146\x5f\x67\x6f\x6f\147\154\145\137\141\165\x74\x68\x5f\x63\x6f\x64\x65"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\x6f\x32\146\137\147\157\157\x67\154\x65\x5f\141\165\164\x68\137\x63\157\144\x65"])) : null;
        $Ty = isset($_POST["\x6d\157\62\x66\x5f\x73\145\163\x73\151\157\156\x5f\151\144"]) ? sanitize_text_field(wp_unslash($_POST["\155\157\62\146\x5f\163\x65\x73\163\x69\157\156\x5f\x69\144"])) : null;
        $wG = $el->mo_a_auth_get_secret($v1);
        if (!$Ty) {
            goto CBQ;
        }
        $wG = MO2f_Utility::mo2f_get_transient($Ty, "\163\x65\143\162\145\x74\137\147\x61");
        CBQ:
        $hP = $el->mo2f_verify_code($wG, $li);
        $hP = json_decode($hP);
        if ("\x66\141\x6c\x73\145" === $hP->status) {
            goto sB0;
        }
        $el->mo_g_auth_set_secret($v1, $wG);
        $this->mo2f_check_and_create_user($v1);
        $Gw->update_user_details($v1, array("\x6d\x6f\62\x66\x5f\x47\x6f\157\x67\x6c\145\101\x75\164\x68\x65\156\x74\x69\143\x61\x74\x6f\162\137\x63\157\x6e\x66\x69\147\x5f\163\x74\x61\x74\165\163" => true, "\155\x6f\62\146\x5f\101\x75\164\x68\x79\101\x75\x74\150\x65\156\x74\x69\143\141\164\x6f\162\137\143\x6f\x6e\146\151\147\x5f\x73\164\141\164\165\163" => false, "\x6d\157\x32\146\x5f\143\x6f\x6e\x66\151\147\x75\x72\x65\x64\137\x32\106\x41\x5f\x6d\145\x74\x68\157\144" => MoWpnsConstants::GOOGLE_AUTHENTICATOR, "\x75\163\x65\x72\x5f\x72\145\147\x69\x73\164\x72\141\x74\x69\157\x6e\137\167\151\x74\x68\137\x6d\x69\156\x69\157\162\141\x6e\147\145" => "\123\125\x43\x43\x45\x53\x53", "\x6d\157\x32\x66\137\165\163\145\x72\137\145\x6d\x61\151\154" => wp_get_current_user()->user_email, "\x6d\157\137\62\x66\141\x63\x74\157\162\137\x75\163\x65\162\x5f\162\145\147\151\x73\164\162\141\164\151\x6f\156\x5f\163\164\141\164\x75\163" => "\x4d\117\x5f\x32\x5f\x46\101\103\124\x4f\122\x5f\120\114\x55\107\111\116\x5f\x53\x45\x54\124\x49\116\x47\x53"));
        wp_send_json_success();
        goto Ny7;
        sB0:
        wp_send_json_error("\x49\156\166\141\x6c\x69\x64\40\x4f\156\x65\40\x74\x69\x6d\145\40\x50\141\163\163\x63\x6f\144\x65\x2e\40\x50\x6c\145\141\163\145\40\x65\156\x74\x65\x72\40\141\x67\x61\x69\x6e");
        Ny7:
        exit;
    }
    public function mo2f_skiptwofactor_wizard()
    {
        if (!check_ajax_referer("\x6d\x6f\55\164\x77\x6f\55\x66\141\143\164\x6f\162\x2d\x61\152\141\170\55\156\157\x6e\x63\145", "\x6e\x6f\156\143\145", false)) {
            goto Thh;
        }
        $Me = isset($_POST["\x74\x77\x6f\146\141\143\164\x6f\162\163\x6b\x69\160\x70\x65\144\157\156"]) ? sanitize_text_field(wp_unslash($_POST["\164\x77\157\146\x61\143\x74\157\x72\163\x6b\x69\160\160\145\x64\x6f\156"])) : null;
        update_site_option("\155\x6f\x32\x66\x5f\x77\151\172\x61\x72\144\137\163\x6b\151\160\x70\145\x64", $Me);
        goto F9z;
        Thh:
        $jY = new WP_Error();
        $jY->add("\x65\155\160\164\171\137\x75\163\145\x72\156\141\155\145", "\x3c\163\x74\162\157\x6e\x67\x3e" . esc_html__("\105\122\x52\x4f\x52", "\x6d\151\x6e\x69\157\x72\x61\x6e\x67\x65\55\x32\55\x66\141\143\164\157\162\55\x61\x75\x74\x68\145\x6e\x74\151\143\141\x74\151\157\156") . "\x3c\x2f\163\164\162\x6f\x6e\x67\76\72\40" . esc_html__("\x49\x6e\166\x61\154\151\x64\x20\122\x65\161\165\x65\x73\164\x2e", "\x6d\x69\156\x69\157\162\x61\156\147\145\x2d\x32\x2d\x66\141\x63\164\x6f\x72\55\141\165\x74\150\x65\x6e\164\151\x63\x61\x74\x69\x6f\x6e"));
        wp_send_json_error("\155\x6f\62\x66\55\x61\152\x61\x78");
        exit;
        F9z:
    }
    public function mo2f_check_and_create_user($v1)
    {
        global $Gw;
        $Zf = new Mo2fDB();
        $VX = apply_filters("\x6d\157\x32\x66\x5f\x62\x61\x73\151\x63\137\160\154\141\156\x5f\163\x65\164\164\x69\x6e\147\x73\137\146\x69\154\164\145\162", $Gw->check_alluser_limit_exceeded($v1), "\x69\163\137\x75\x73\145\162\x5f\x6c\x69\x6d\151\x74\x5f\145\x78\x63\145\x65\x64\145\144", array());
        if (!$VX) {
            goto DEc;
        }
        echo "\x55\163\145\162\40\x4c\x69\155\151\164\40\150\x61\163\40\142\145\x65\x6e\40\145\170\x63\x65\x65\x64\x65\x64";
        exit;
        DEc:
        $Gw->insert_user($v1);
    }
}
new Mo2f_Setupwizard();
KOZ:
