<?php


namespace TwoFA\Helper;

if (defined("\x41\102\123\x50\x41\x54\x48")) {
    goto dcV;
}
exit;
dcV:
if (class_exists("\x4d\x6f\x57\160\x6e\x73\x48\141\x6e\144\154\x65\162")) {
    goto jOV;
}
class MoWpnsHandler
{
    public function mo_wpns_is_ip_blocked($nb)
    {
        global $GI;
        if (!empty($nb)) {
            goto TtO;
        }
        return false;
        TtO:
        $Ax = $GI->get_ip_blocked_count($nb);
        if (!$Ax) {
            goto AgQ;
        }
        $Ax = intval($Ax);
        AgQ:
        if (!($Ax > 0)) {
            goto USu;
        }
        return true;
        USu:
        return false;
    }
    public function get_blocked_ip_waf()
    {
        global $GI;
        $Df = $GI->get_total_blocked_ips_waf();
        if (!$Df) {
            goto Gb0;
        }
        $Df = intval($Df);
        Gb0:
        return $Df;
    }
    public function get_manual_blocked_ip_count()
    {
        global $GI;
        $Df = $GI->get_total_manual_blocked_ips();
        if (!$Df) {
            goto OQ0;
        }
        $Df = intval($Df);
        OQ0:
        return $Df;
    }
    public function get_blocked_ips()
    {
        global $GI;
        return $GI->get_blocked_ip_list();
    }
    public function mo_wpns_block_ip($nb, $e3, $h6)
    {
        global $GI;
        if (!empty($nb)) {
            goto eze;
        }
        return;
        eze:
        if (!$this->mo_wpns_is_ip_blocked($nb)) {
            goto L6E;
        }
        return;
        L6E:
        $R9 = null;
        if (!(!$h6 && get_site_option("\x6d\157\x32\x66\137\x74\x69\x6d\x65\137\157\x66\x5f\142\154\x6f\x63\x6b\151\x6e\147\137\x74\x79\160\145"))) {
            goto iaF;
        }
        $Jg = get_site_option("\155\157\62\x66\x5f\x74\x69\155\145\137\x6f\146\x5f\x62\x6c\x6f\x63\153\x69\x6e\x67\137\164\x79\160\x65");
        $Iu = 3;
        if (!get_site_option("\x6d\157\62\146\137\x74\x69\x6d\x65\137\157\x66\137\142\x6c\157\x63\153\x69\x6e\147\x5f\x76\141\x6c")) {
            goto aEM;
        }
        $Iu = get_site_option("\x6d\x6f\62\x66\137\x74\x69\x6d\x65\x5f\x6f\x66\137\142\x6c\157\x63\153\x69\x6e\x67\x5f\166\x61\x6c");
        aEM:
        if ("\x6d\x6f\156\164\150\163" === $Jg) {
            goto M2T;
        }
        if ("\x64\141\171\x73" === $Jg) {
            goto ATT;
        }
        if ("\150\x6f\x75\162\x73" === $Jg) {
            goto W0F;
        }
        goto LIo;
        M2T:
        $R9 = current_time("\164\151\x6d\145\163\164\x61\x6d\x70") + $Iu * 30 * 24 * 60 * 60;
        goto LIo;
        ATT:
        $R9 = current_time("\x74\151\x6d\x65\163\x74\x61\155\160") + $Iu * 24 * 60 * 60;
        goto LIo;
        W0F:
        $R9 = current_time("\x74\x69\x6d\x65\x73\x74\141\x6d\x70") + $Iu * 60 * 60;
        LIo:
        iaF:
        $GI->insert_blocked_ip($nb, $e3, $R9);
        global $uz;
        if (!MoWpnsUtility::get_mo2f_db_option("\155\157\x5f\167\x70\156\x73\137\x65\x6e\141\142\154\x65\137\151\160\137\x62\154\157\x63\153\x65\x64\x5f\x65\x6d\x61\151\x6c\137\x74\157\x5f\x61\144\155\151\x6e", "\163\x69\x74\x65\137\157\x70\x74\151\x6f\x6e")) {
            goto dPw;
        }
        $uz->sendIpBlockedNotification($nb, MoWpnsConstants::LOGIN_ATTEMPTS_EXCEEDED);
        dPw:
    }
    public function unblock_ip_entry($Of)
    {
        global $GI;
        $GI->delete_blocked_ip($Of);
    }
    public function is_whitelisted($nb)
    {
        global $GI;
        $Iv = $GI->get_whitelisted_ip_count($nb);
        if (!empty($nb)) {
            goto dOH;
        }
        return false;
        dOH:
        if (!$Iv) {
            goto IUe;
        }
        $Iv = intval($Iv);
        IUe:
        if (!($Iv > 0)) {
            goto DqZ;
        }
        return true;
        DqZ:
        return false;
    }
    public function whitelist_ip($nb)
    {
        global $GI;
        if (!empty($nb)) {
            goto Be9;
        }
        return;
        Be9:
        if (!$this->is_whitelisted($nb)) {
            goto YpJ;
        }
        return;
        YpJ:
        $GI->insert_whitelisted_ip($nb);
    }
    public function remove_whitelist_entry($Of)
    {
        global $GI;
        $GI->delete_whitelisted_ip($Of);
    }
    public function get_whitelisted_ips()
    {
        global $GI;
        return $GI->get_whitelisted_ips_list();
    }
    public function is_email_sent_to_user($Zi, $nb)
    {
        global $GI;
        if (!empty($nb)) {
            goto YTF;
        }
        return false;
        YTF:
        $PT = $GI->get_email_audit_count($nb, $Zi);
        if (!$PT) {
            goto WX2;
        }
        $PT = intval($PT);
        WX2:
        if (!($PT > 0)) {
            goto mpT;
        }
        return true;
        mpT:
        return false;
    }
    public function audit_email_notification_sent_to_user($Zi, $nb, $e3)
    {
        if (!(empty($nb) || empty($Zi))) {
            goto Uw8;
        }
        return;
        Uw8:
        global $GI;
        $GI->insert_email_audit($nb, $Zi, $e3);
    }
    public function add_transactions($nb, $Zi, $qJ, $yY, $xz = null)
    {
        global $GI;
        $GI->insert_transaction_audit($nb, $Zi, $qJ, $yY, $xz);
    }
    public function get_login_transaction_report()
    {
        global $GI;
        return $GI->get_login_transaction_report();
    }
    public function move_failed_transactions_to_past_failed($nb)
    {
        global $GI;
        $GI->update_transaction_table(array("\x73\x74\141\164\x75\163" => MoWpnsConstants::FAILED, "\151\160\x5f\x61\144\x64\162\x65\x73\x73" => $nb), array("\163\164\141\164\x75\163" => MoWpnsConstants::PAST_FAILED));
    }
    public function is_ip_blocked_in_anyway($Px)
    {
        $WB = false;
        if ($this->mo_wpns_is_ip_blocked($Px)) {
            goto h7q;
        }
        if ($this->is_ip_range_blocked($Px)) {
            goto piN;
        }
        goto pTy;
        h7q:
        $WB = true;
        goto pTy;
        piN:
        $WB = true;
        pTy:
        return $WB;
    }
    public function is_ip_range_blocked($Px)
    {
        if (!empty($Px)) {
            goto BEB;
        }
        return false;
        BEB:
        $z0 = 0;
        if (!is_numeric(get_site_option("\x6d\157\x5f\x77\x70\x6e\163\x5f\151\x70\162\x61\x6e\147\145\x5f\143\157\165\x6e\x74"))) {
            goto lSu;
        }
        $z0 = intval(get_site_option("\155\x6f\x5f\167\160\x6e\x73\x5f\x69\x70\162\141\156\x67\x65\137\143\x6f\165\x6e\x74"));
        lSu:
        $ET = 1;
        gDT:
        if (!($ET <= $z0)) {
            goto llP;
        }
        $K_ = get_site_option("\155\x6f\137\x77\160\156\x73\137\x69\160\x72\141\x6e\147\145\137\x72\x61\156\147\x65\x5f" . $ET);
        $aU = explode("\x2d", $K_);
        if (!(2 === count($aU))) {
            goto xjq;
        }
        $Lj = ip2long(trim($aU[0]));
        $yQ = ip2long(trim($aU[1]));
        if (!(ip2long($Px) >= $Lj && ip2long($Px) <= $yQ)) {
            goto nVw;
        }
        $wB = new MoWpnsHandler();
        $wB->mo_wpns_block_ip($Px, MoWpnsConstants::IP_RANGE_BLOCKING, true);
        return true;
        nVw:
        xjq:
        lCu:
        $ET++;
        goto gDT;
        llP:
        return false;
    }
    public function locked_out_link()
    {
        if (MO2F_IS_ONPREM) {
            goto XF8;
        }
        return MoWpnsConstants::CLOUDLOCKOUT;
        goto MQA;
        XF8:
        return MoWpnsConstants::ONPREMISELOCKEDOUT;
        MQA:
    }
}
jOV:
