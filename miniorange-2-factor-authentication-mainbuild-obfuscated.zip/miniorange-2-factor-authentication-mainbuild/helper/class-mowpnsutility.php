<?php


namespace TwoFA\Helper;

use TwoFA\Traits\Instance;
use TwoFA\Helper\MoWpnsHandler;
use TwoFA\Onprem\Miniorange_Authentication;
use WP_Session_Tokens;
require_once dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . "\164\x72\141\151\164\163" . DIRECTORY_SEPARATOR . "\143\x6c\x61\163\163\55\x69\156\x73\x74\141\x6e\143\145\56\160\x68\160";
if (defined("\x41\x42\x53\120\x41\x54\x48")) {
    goto dI_;
}
exit;
dI_:
if (class_exists("\115\x6f\127\x70\156\x73\x55\164\151\x6c\151\164\171")) {
    goto ChI;
}
class MoWpnsUtility
{
    use Instance;
    public static function icr()
    {
        $fK = get_option("\155\x6f\x32\x66\137\145\155\141\151\154");
        $hS = get_option("\x6d\x6f\x32\x66\137\x63\x75\163\x74\157\155\x65\x72\x4b\145\x79");
        if (!$fK || !$hS || !is_numeric(trim($hS))) {
            goto Vfn;
        }
        return 1;
        goto Ihn;
        Vfn:
        return 0;
        Ihn:
    }
    public static function check_empty_or_null($iY)
    {
        if (!(!isset($iY) || empty($iY))) {
            goto H3N;
        }
        return true;
        H3N:
        return false;
    }
    public static function rand()
    {
        $La = wp_rand(0, 15);
        $ei = "\60\x31\x32\x33\x34\x35\66\x37\x38\71\x61\x62\x63\x64\145\x66\x67\x68\151\152\x6b\154\155\156\157\x70\x71\162\x73\x74\165\166\167\x78\x79\x7a\101\x42\103\x44\105\106\107\x48\111\x4a\x4b\114\x4d\116\x4f\x50\x51\x52\123\124\x55\x56\x57\x58\x59\x5a";
        $S6 = '';
        $ET = 0;
        eE0:
        if (!($ET < $La)) {
            goto otr;
        }
        $S6 .= $ei[wp_rand(0, strlen($ei) - 1)];
        fHi:
        $ET++;
        goto eE0;
        otr:
        return $S6;
    }
    public static function is_curl_installed()
    {
        if (in_array("\143\x75\x72\154", get_loaded_extensions(), true)) {
            goto c3O;
        }
        return 0;
        goto Kre;
        c3O:
        return 1;
        Kre:
    }
    public static function mo2f_is_valid_ip($CG)
    {
        $hI = explode("\x2c", $CG);
        if (!is_array($hI)) {
            goto mHk;
        }
        $CG = $hI[0];
        mHk:
        return filter_var(self::get_unique_ip($CG), FILTER_VALIDATE_IP) !== false;
    }
    public static function get_client_ip()
    {
        if (isset($_SERVER["\122\x45\x4d\x4f\124\105\137\x41\x44\104\122"]) && is_string($_SERVER["\122\105\115\x4f\124\105\x5f\x41\x44\104\122"]) && !empty($_SERVER["\x52\x45\115\x4f\x54\x45\x5f\x41\x44\104\x52"]) && self::mo2f_is_valid_ip(sanitize_text_field(wp_unslash($_SERVER["\122\x45\x4d\117\124\x45\137\101\x44\104\x52"])))) {
            goto g8d;
        }
        return "\125\116\113\116\x4f\x57\116";
        goto xpk;
        g8d:
        return self::get_unique_ip(sanitize_text_field(wp_unslash($_SERVER["\122\x45\115\117\124\105\137\101\x44\104\122"])));
        xpk:
    }
    public static function get_unique_ip($CG)
    {
        $CG = explode("\x2c", $CG);
        if (!is_array($CG)) {
            goto u10;
        }
        return sanitize_text_field($CG[0]);
        u10:
        return sanitize_text_field($CG);
    }
    public static function check_if_valid_email($fK)
    {
        $EA = explode("\100", $fK);
        if (2 === count($EA)) {
            goto kli;
        }
        return false;
        goto kEm;
        kli:
        return in_array(trim($EA[1]), MoWpnsConstants::$domains, true);
        kEm:
    }
    public static function get_current_url()
    {
        $Nd = !empty($_SERVER["\x48\x54\124\120\123"]) && "\x6f\x66\146" !== sanitize_text_field(sanitize_text_field(wp_unslash($_SERVER["\x48\x54\124\x50\x53"]))) || isset($_SERVER["\123\x45\x52\126\105\122\137\120\117\122\124"]) && 443 === sanitize_text_field(wp_unslash($_SERVER["\x53\x45\x52\x56\x45\122\137\120\x4f\122\124"])) ? "\x68\x74\x74\x70\163\72\x2f\x2f" : "\x68\x74\164\x70\72\57\x2f";
        $xz = $Nd . (isset($_SERVER["\110\124\124\x50\x5f\x48\117\123\x54"]) ? sanitize_text_field(wp_unslash($_SERVER["\x48\124\x54\x50\137\110\117\x53\x54"])) : '') . (isset($_SERVER["\122\105\x51\x55\105\123\x54\x5f\x55\122\x49"]) ? esc_url_raw(wp_unslash($_SERVER["\122\105\121\125\x45\123\x54\x5f\x55\122\111"])) : '');
        return $xz;
    }
    public static function get_mo2f_db_option($iY, $qJ)
    {
        if ("\163\151\x74\x65\x5f\x6f\160\x74\x69\x6f\156" === $qJ) {
            goto FEm;
        }
        $hJ = get_option($iY, $GLOBALS[$iY]);
        goto kLp;
        FEm:
        $hJ = get_site_option($iY, $GLOBALS[$iY]);
        kLp:
        return $hJ;
    }
    public static function mo_2fa_send_configuration($Ig = false)
    {
        global $Gw;
        $he = wp_get_current_user();
        $sj = $Gw->get_all_user_2fa_methods();
        $yZ = array_count_values($sj);
        $IK = array();
        foreach ($yZ as $la => $Iv) {
            if (empty($la)) {
                goto e4R;
            }
            array_push($IK, "\40" . $la . "\40\50" . $Iv . "\x29");
            e4R:
            RtS:
        }
        lAm:
        $IK = implode("\x2c", $IK);
        $t8 = get_option("\x6d\x6f\62\146\137\x63\x75\x73\164\157\155\145\x72\x4b\x65\171");
        $nC = is_plugin_active_for_network(MoWpnsConstants::TWO_FACTOR_SETTINGS);
        $gX = MO2F_IS_ONPREM;
        $i5 = get_site_option("\x6d\157\x32\x66\141\137\x76\151\x73\x69\x74", 0);
        $BW = $Gw->get_no_of_2fa_users();
        $Mb = get_site_option("\155\x6f\x32\146\137\x69\x73\137\151\156\x6c\x69\x6e\145\x5f\x75\163\145\x64");
        $st = get_site_option("\155\157\62\x66\x5f\x6c\157\147\151\x6e\x5f\167\151\x74\x68\137\x6d\146\x61\x5f\165\x73\x65");
        $i9 = self::get_mo2f_db_option("\x63\x6d\x56\164\131\x57\154\165\141\x57\x35\x6e\x54\x31\122\x51", "\163\x69\164\x65\x5f\157\x70\164\151\x6f\x6e");
        $BZ = get_site_option("\143\x6d\x56\x74\131\127\154\165\141\x57\65\x6e\124\61\122\121\x56\110\x4a\x68\x62\x6e\x4e\x68\131\x33\x52\160\x62\x32\x35\x7a") ? get_site_option("\x63\x6d\126\x74\131\x57\x6c\x75\x61\x57\65\156\x54\x31\122\121\x56\110\x4a\150\142\156\x4e\x68\x59\x33\122\x70\142\62\65\x7a") : 0;
        $h7 = "\74\x73\x70\141\x6e\x3e\x26\x6e\x62\x73\x70\73\46\156\x62\163\x70\73\x26\156\x62\163\x70\x3b\74\57\163\160\141\x6e\76";
        $Ax = isset(count_users()["\x74\157\x74\x61\154\137\165\163\145\162\x73"]) ? count_users()["\x74\157\x74\x61\154\137\x75\163\145\x72\163"] : '';
        $Qw = array("\125\115\137\106\x75\x6e\143\x74\x69\x6f\156\163" => "\x55\154\x74\x69\x6d\141\164\x65\x20\115\145\155\x62\x65\x72", "\x77\x63\137\147\x65\x74\137\160\162\157\x64\165\x63\x74" => "\127\x6f\157\103\157\x6d\155\145\x72\x63\x65", "\x70\155\160\162\157\137\x67\x61\x74\x65\x77\x61\171\163" => "\x50\141\151\144\40\x4d\x65\155\142\145\x72\x53\150\151\x70\40\120\162\x6f", "\x4d\157\x4f\124\x50" => "\117\124\120");
        $zD = get_user_meta($he->ID, "\x6d\x6f\62\x66\x5f\x62\141\x63\x6b\x75\x70\137\143\x6f\144\x65\x73", true);
        if (is_array($zD)) {
            goto pSQ;
        }
        $zD = 0;
        goto Bqd;
        pSQ:
        $zD = count($zD);
        Bqd:
        $vT = "\x3c\x62\162\76\74\x62\x72\x3e\74\x49\76\120\154\165\147\151\x6e\x20\x43\x6f\156\x66\x69\147\165\x72\141\x74\x69\x6f\156\40\72\55\x3c\x2f\111\76" . $h7 . "\117\156\x2d\x70\x72\x65\155\x69\163\x65\72" . ($gX ? "\131\x65\x73" : "\116\x6f") . $h7 . "\114\157\x67\151\156\40\167\x69\164\150\x20\x4d\x46\101\72" . ("\x31" === $st ? "\131\x65\x73" : "\116\x6f") . $h7 . "\111\x6e\154\x69\x6e\x65\40\x52\145\x67\151\163\x74\162\141\164\151\157\x6e\72" . ("\61" === $Mb ? "\x59\x65\x73" : "\116\157") . $h7 . "\x4e\x6f\56\x20\x6f\146\x20\x32\x46\101\x20\165\x73\x65\162\163\40\x3a" . $BW . $h7 . "\124\x6f\164\141\154\x20\165\163\x65\162\163\x20\72\x20" . $Ax . $h7 . "\115\x65\164\150\x6f\144\163\x20\x6f\146\x20\x75\x73\145\x72\x73\72" . ('' === $IK ? "\116\x4f\116\105" : $IK) . $h7 . "\105\x6d\141\151\x6c\40\x74\x72\x61\156\x73\141\x63\x74\151\x6f\156\163\x3a" . $i9 . $h7 . "\123\115\x53\40\124\162\141\156\163\141\x63\x74\x69\x6f\x6e\163\x3a" . $BZ . $h7 . (is_multisite() ? "\115\165\154\x74\x69\163\151\164\x65\72\131\145\163" : "\x53\x69\x6e\x67\x6c\x65\55\163\151\164\x65\x3a\131\145\x73") . (Miniorange_Authentication::mo2f_is_customer_registered() ? $h7 . "\103\x75\x73\164\x6f\x6d\x65\162\x20\x4b\x65\171\x3a" . $t8 : $h7 . "\x43\x75\163\164\157\x6d\x65\x72\x20\x52\145\x67\151\163\x74\145\x72\x65\x64\x3a\47\116\157");
        if (!(get_user_meta($he->ID, "\x6d\x6f\x5f\x62\141\x63\153\x75\x70\137\x63\x6f\x64\145\137\x67\x65\x6e\x65\x72\x61\x74\x65\144", true) || get_user_meta($he->ID, "\x6d\x6f\x5f\x62\x61\143\153\x75\x70\137\143\x6f\144\x65\137\x64\157\167\x6e\x6c\157\x61\144\x65\144", true))) {
            goto oyc;
        }
        $vT = $vT . $h7 . "\102\x61\143\153\165\x70\40\103\157\144\x65\x73\x3a" . $zD . "\x2f\x35";
        oyc:
        $eb = '';
        foreach ($Qw as $lj => $pa) {
            if (!(class_exists($lj) || function_exists($lj))) {
                goto uWE;
            }
            $eb = $eb . "\x3c\163\x70\x61\156\x3e\x26\156\142\x73\x70\73\74\57\163\x70\x61\x6e\76\x27" . $pa . "\x27";
            uWE:
            AUX:
        }
        bIv:
        $vT = $vT . ('' !== $eb ? $h7 . "\x49\x6e\x73\x74\141\154\x6c\x65\144\x20\x50\x6c\165\147\x69\156\x73\72" . $eb : '');
        if (!is_multisite()) {
            goto FD0;
        }
        $vT = $vT . $h7 . ($nC ? "\116\145\164\x77\x6f\x72\x6b\40\x61\143\x74\151\x76\141\x74\145\144\x3a\47\131\x65\x73" : "\x53\x69\164\x65\40\x61\143\164\x69\166\x61\164\145\144\72\x27\131\145\x73");
        FD0:
        $vT = $vT . $h7 . "\x50\162\151\143\151\x6e\x67\x20\x50\141\x67\145\40\x76\151\163\151\164\163\40\x3a\x20" . $i5;
        if (!(time() - get_site_option("\x6d\x6f\137\62\146\x61\137\x70\x6e\160") < 2592000 && (get_site_option("\155\x6f\x5f\x32\x66\141\x5f\160\154\x61\x6e\137\x74\x79\x70\x65") || get_site_option("\155\x6f\137\x32\x66\141\x5f\x61\144\x64\157\156\137\160\x6c\141\156\137\x74\x79\x70\x65")))) {
            goto sBI;
        }
        $vT = $vT . $h7 . "\x43\150\145\143\153\145\x64\40\x70\x6c\x61\156\x73\72\x27";
        if (!get_site_option("\x6d\157\x5f\x32\146\x61\137\160\154\141\x6e\x5f\164\x79\x70\145")) {
            goto tpo;
        }
        $vT = $vT . get_site_option("\x6d\157\137\x32\x66\141\137\160\x6c\141\x6e\x5f\x74\171\160\x65") . "\47";
        tpo:
        if (!get_site_option("\155\x6f\x5f\x32\146\141\137\141\x64\144\x6f\156\x5f\x70\x6c\x61\x6e\x5f\164\171\x70\x65")) {
            goto Shc;
        }
        $vT = $vT . "\x3c\163\x70\141\156\76\x26\x6e\x62\163\160\x3b\x3c\x2f\163\x70\141\x6e\x3e\x27" . get_site_option("\x6d\157\137\62\146\141\137\141\x64\144\157\x6e\137\160\x6c\141\156\137\164\171\160\x65") . "\x27";
        Shc:
        sBI:
        $vT = $vT . $h7 . "\120\110\x50\x5f\x76\x65\162\x73\x69\157\x6e\x3a" . phpversion();
        if (!get_site_option("\x6d\157\62\x66\137\x67\162\x61\x63\145\x5f\160\145\162\x69\157\x64")) {
            goto WKz;
        }
        $vT = $vT . $h7 . "\107\x72\141\143\145\x20\x50\145\x72\x69\x6f\144\x3a\x20" . esc_html(get_site_option("\155\157\62\x66\137\x67\162\141\143\x65\137\160\x65\x72\x69\157\144\137\x76\x61\154\x75\145")) . "\74\x73\160\x61\156\76\x26\x6e\x62\163\160\73\x3c\57\163\x70\141\156\76" . esc_html(get_site_option("\155\x6f\62\x66\137\147\x72\x61\143\x65\x5f\x70\145\162\x69\157\144\137\x74\171\x70\145"));
        WKz:
        $sy = get_option("\x6d\x6f\62\146\137\167\x69\x7a\x61\162\x64\x5f\x73\145\154\145\143\x74\x65\x64\137\155\x65\x74\x68\157\144") ? esc_html(get_option("\155\157\x32\146\137\167\151\172\x61\x72\x64\x5f\163\x65\x6c\x65\x63\x74\145\144\x5f\155\145\164\x68\x6f\x64")) : esc_html(get_option("\155\157\62\146\137\x77\151\x7a\x61\x72\144\137\x73\x6b\151\160\160\x65\x64"));
        if (get_option("\155\x6f\62\x66\137\167\x69\x7a\141\162\144\x5f\x73\x6b\x69\160\x70\145\144")) {
            goto p26;
        }
        $vT = $vT . $h7 . "\x53\x65\x74\165\160\x20\127\151\172\x61\162\x64\x20\123\153\151\x70\x70\x65\144\x3a\x20\116\157";
        goto XVx;
        p26:
        $vT = $vT . $h7 . "\123\x65\x74\x75\160\x20\127\151\172\x61\x72\144\40\x53\153\x69\160\x70\x65\x64\72\40" . $sy;
        XVx:
        if ($Ig) {
            goto sLs;
        }
        return $vT;
        sLs:
        return $vT;
    }
    public function send_notification_to_user_for_unusual_activities($Zi, $Zq, $e3)
    {
        $hP = '';
        if (!get_option($Zq . $e3)) {
            goto GDI;
        }
        return wp_json_encode(array("\163\164\141\x74\165\163" => "\123\x55\x43\103\x45\123\x53", "\x73\164\141\x74\x75\x73\115\x65\x73\163\141\147\145" => "\123\125\x43\103\105\123\x53"));
        GDI:
        $user = get_user_by("\154\157\147\151\156", $Zi);
        if ($user && !empty($user->user_email)) {
            goto H11;
        }
        return;
        goto h_m;
        H11:
        $RU = $user->user_email;
        h_m:
        $wB = new MoWpnsHandler();
        if (!$wB->is_email_sent_to_user($Zi, $Zq)) {
            goto mzd;
        }
        return;
        mzd:
        $p3 = get_option("\x6d\x6f\x32\x66\x5f\145\155\x61\151\x6c");
        $a3 = self::get_mo2f_db_option("\155\157\62\x66\137\x32\x66\x61\x5f\156\x65\x77\x5f\x69\160\137\x64\145\x74\145\143\x74\145\144\x5f\x65\155\x61\x69\x6c\137\163\x75\x62\x6a\145\x63\164", "\163\x69\164\145\137\x6f\x70\164\x69\157\x6e");
        if (get_option("\x63\x75\163\x74\x6f\155\137\x75\x73\x65\162\137\x74\x65\155\x70\x6c\x61\x74\145")) {
            goto euQ;
        }
        $hP = $this->get_message_content($e3, $Zq, $Zi, $p3);
        goto bE2;
        euQ:
        $hP = get_option("\143\x75\163\x74\x6f\155\x5f\x75\163\x65\x72\x5f\x74\145\x6d\x70\154\141\x74\x65");
        $hP = str_replace("\x23\43\151\x70\x61\144\144\162\145\163\x73\43\43", $Zq, $hP);
        $hP = str_replace("\x23\43\x75\x73\x65\162\156\x61\x6d\x65\x23\43", $Zi, $hP);
        bE2:
        $wB->audit_email_notification_sent_to_user($Zi, $Zq, $e3);
        $yY = $this->wp_mail_send_notification($RU, $a3, $hP, $p3);
        return $yY;
    }
    public function get_message_content($e3, $Zq, $Zi = null, $p3 = null)
    {
        switch ($e3) {
            case MoWpnsConstants::LOGIN_ATTEMPTS_EXCEEDED:
                $hP = "\x48\x65\x6c\154\x6f\54\x3c\x62\162\x3e\74\x62\x72\76\124\x68\145\40\165\163\x65\x72\40\167\x69\164\150\x20\111\x50\x20\x41\144\x64\x72\145\x73\x73\x20\x3c\142\x3e" . $Zq . "\74\57\x62\x3e\x20\x68\x61\x73\40\x65\170\143\x65\145\x64\145\144\x20\141\x6c\154\157\167\x65\x64\x20\146\141\151\154\x65\x64\x20\x6c\x6f\147\x69\x6e\40\x61\164\x74\x65\155\x70\164\163\40\157\156\40\x79\157\x75\162\40\167\145\x62\x73\x69\164\145\40\74\x62\x3e" . get_bloginfo() . "\x3c\57\142\76\40\141\156\144\x20\x77\x65\40\150\141\x76\x65\x20\142\154\x6f\143\x6b\x65\x64\40\150\x69\x73\x20\x49\x50\40\x61\x64\x64\162\x65\x73\x73\x20\x66\157\162\x20\x66\x75\162\x74\x68\x65\x72\x20\x61\143\143\x65\163\x73\40\x74\x6f\40\x77\145\142\x73\x69\164\145\56\x3c\142\162\76\74\142\162\x3e\131\157\x75\x20\143\141\156\40\154\157\147\151\156\x20\x74\157\40\x79\x6f\x75\162\x20\x57\157\162\x64\120\162\x65\x73\163\40\144\x61\x73\x68\141\142\x6f\141\162\x64\40\x74\x6f\40\x63\150\x65\143\153\x20\155\157\x72\145\40\144\145\164\141\x69\154\x73\x2e\x3c\x62\162\76\x3c\142\x72\x3e\124\150\141\x6e\x6b\x73\54\x3c\142\x72\x3e\x6d\x69\x6e\x69\x4f\162\x61\156\147\x65";
                return $hP;
            case MoWpnsConstants::IP_RANGE_BLOCKING:
                $hP = "\110\145\x6c\x6c\157\x2c\x3c\x62\x72\76\x3c\x62\162\76\124\150\145\x20\x75\163\145\162\x27\163\40\111\120\40\101\144\x64\x72\145\163\163\40\74\x62\x3e" . $Zq . "\x3c\x2f\x62\76\x20\x77\141\163\x20\x66\157\165\156\144\40\x69\156\40\111\x50\40\x52\x61\x6e\x67\x65\40\163\160\145\x63\151\146\x69\x65\x64\x20\142\171\40\171\157\x75\40\151\x6e\40\101\x64\x76\141\x6e\x63\145\144\40\x49\x50\40\102\x6c\157\143\153\151\156\x67\x20\141\156\x64\40\167\x65\x20\150\x61\x76\x65\40\142\154\x6f\x63\x6b\x65\144\40\x68\x69\163\40\x49\x50\40\141\x64\144\x72\145\x73\x73\40\146\157\x72\x20\146\x75\x72\x74\x68\145\162\x20\141\x63\x63\x65\x73\163\40\x74\x6f\x20\x79\x6f\x75\x72\40\167\145\x62\x73\x69\164\145\x20\74\142\x3e" . get_bloginfo() . "\x3c\x2f\x62\x3e\56\74\142\x72\x3e\x3c\142\x72\x3e\131\x6f\165\40\x63\x61\156\40\x6c\x6f\x67\x69\156\x20\164\157\40\171\x6f\165\162\40\x57\x6f\162\x64\x50\x72\x65\x73\x73\x20\x64\x61\x73\150\x61\x62\x6f\141\162\144\x20\164\157\40\x63\x68\x65\x63\153\40\155\157\x72\145\40\144\145\164\x61\151\x6c\x73\x2e\x3c\142\x72\x3e\x3c\x62\162\76\124\150\x61\x6e\x6b\x73\54\x3c\x62\x72\x3e\x6d\151\156\151\117\x72\x61\x6e\147\145";
                return $hP;
            case MoWpnsConstants::BLOCKED_BY_ADMIN:
                $hP = "\x48\x65\x6c\x6c\157\x2c\x3c\142\162\76\x3c\142\x72\x3e\x54\150\145\40\x75\163\x65\162\40\x77\x69\x74\150\x20\x49\120\x20\101\x64\144\x72\x65\163\163\40\74\142\76" . $Zq . "\x3c\x2f\142\x3e\40\150\x61\x73\x20\x62\x6c\157\143\153\145\x64\40\142\x79\40\141\x64\x6d\151\156\40\141\156\x64\x20\167\145\x20\150\141\x76\x65\x20\142\154\x6f\143\153\145\144\x20\150\151\x73\40\111\x50\x20\141\x64\144\162\145\x73\x73\x20\146\x6f\162\40\x66\x75\x72\x74\150\145\162\40\x61\x63\143\145\163\163\40\164\157\40\x77\145\142\x73\x69\164\x65\56\74\142\162\x3e\x3c\x62\162\76\x59\x6f\165\40\143\141\x6e\x20\x6c\157\x67\x69\156\x20\164\157\40\171\x6f\165\x72\40\127\x6f\162\x64\x50\x72\145\x73\163\x20\144\141\163\150\141\x62\x6f\141\162\144\40\x74\157\40\143\x68\145\x63\x6b\40\155\x6f\x72\145\40\144\x65\164\x61\151\154\x73\x2e\74\x62\162\x3e\74\142\x72\x3e\124\x68\x61\x6e\x6b\x73\54\x3c\x62\x72\x3e\x6d\151\x6e\151\x4f\162\141\x6e\147\x65";
                return $hP;
            case MoWpnsConstants::LOGGED_IN_FROM_NEW_IP:
                $hP = self::get_mo2f_db_option("\x6d\x6f\62\146\x5f\156\x65\x77\137\151\160\137\x64\x65\164\145\x63\x74\x65\x64\137\145\155\x61\151\154\137\164\x65\155\x70\x6c\141\x74\145", "\x73\151\x74\145\x5f\157\x70\164\x69\157\156");
                $hP = str_replace("\x23\43\151\160\141\144\144\x72\x65\163\x73\43\43", $Zq, $hP);
                return $hP;
            case MoWpnsConstants::FAILED_LOGIN_ATTEMPTS_FROM_NEW_IP:
                $a3 = "\x53\x6f\x6d\x65\x6f\x6e\145\40\x74\162\171\151\156\x67\x20\164\157\40\141\143\x63\x65\163\163\x20\171\x6f\165\40\x61\x63\x63\157\x75\156\x74\x20\x7c\40" . get_bloginfo();
                $hP = "\110\x65\154\x6c\157\40" . $Zi . "\54\x3c\142\162\x3e\74\142\x72\76\x53\157\155\145\x6f\x6e\x65\x20\164\x72\x69\x65\144\x20\164\x6f\x20\x6c\x6f\147\151\156\40\164\157\x20\x79\157\165\x72\40\141\143\x63\x6f\165\x6e\164\x20\x66\x72\157\x6d\40\x6e\145\167\40\x49\120\40\x41\144\144\162\145\163\163\x20\74\x62\x3e" . $Zq . "\x3c\x2f\142\76\x20\x6f\x6e\40\x77\145\142\x73\x69\164\x65\x20\74\142\76" . get_bloginfo() . "\74\57\142\x3e\x20\x77\x69\x74\150\40\x66\141\x69\154\145\144\40\154\x6f\147\x69\x6e\40\141\x74\164\145\155\160\x74\163\x2e\40\x50\154\x65\141\163\145\40\74\x61\40\x68\x72\x65\146\x3d\47\x6d\141\x69\154\x74\x6f\x3a" . $p3 . "\47\76\143\x6f\156\x74\x61\x63\164\x20\x75\163\x3c\x2f\141\x3e\40\151\146\40\x79\x6f\x75\x20\144\157\x6e\x27\x74\40\162\x65\143\x6f\x67\156\151\x73\x65\x20\x74\x68\151\x73\40\141\x63\x74\151\x76\x69\164\x79\x2e\x3c\142\162\76\74\142\x72\76\x54\150\141\x6e\153\163\54\74\x62\x72\x3e" . get_bloginfo();
                return $hP;
            default:
                if (is_null($Zi)) {
                    goto lS6;
                }
                $hP = "\x48\145\154\x6c\157\x20" . $Zi . "\54\74\x62\162\76\74\x62\162\x3e\x59\157\165\162\40\141\x63\143\157\x75\x6e\x74\40\x77\141\163\40\x6c\x6f\147\147\x65\144\40\151\x6e\40\x66\x72\x6f\x6d\40\x6e\145\x77\40\x49\120\x20\101\144\144\x72\x65\163\163\x20\x3c\x62\76" . $Zq . "\x3c\57\142\76\40\157\156\40\167\x65\142\x73\151\164\145\40\74\x62\x3e" . get_bloginfo() . "\x3c\57\142\x3e\56\40\120\x6c\x65\141\x73\x65\40\x3c\x61\40\x68\x72\x65\146\75\47\x6d\x61\151\154\x74\x6f\72" . $p3 . "\x27\x3e\143\x6f\156\x74\x61\143\x74\x20\x75\163\74\x2f\x61\x3e\40\x69\x66\x20\171\157\165\40\x64\157\x6e\47\164\x20\162\145\143\157\147\x6e\151\x73\x65\40\x74\x68\151\163\40\x61\x63\x74\151\166\x69\164\171\x2e\x3c\142\162\x3e\x3c\142\x72\x3e\124\x68\x61\x6e\x6b\163\x2c\x3c\x62\x72\76" . get_bloginfo();
                goto amR;
                lS6:
                $hP = "\x48\x65\x6c\154\157\x2c\74\x62\162\76\x3c\142\x72\76\x54\x68\x65\x20\165\163\x65\x72\x20\x77\151\164\150\x20\111\120\x20\101\x64\144\x72\145\163\x73\x20\x3c\x62\x3e" . $Zq . "\x3c\57\142\76\x20\150\x61\163\x20\145\170\143\x65\145\144\145\144\x20\x61\154\154\157\x77\x65\x64\x20\164\162\141\x73\141\143\164\151\157\x6e\x20\x6c\x69\155\x69\x74\x20\157\x6e\40\171\157\x75\x72\40\x77\145\142\x73\x69\x74\x65\40\x3c\x62\x3e" . get_bloginfo() . "\x3c\57\142\x3e\40\x61\156\144\40\167\145\x20\150\x61\x76\x65\40\142\x6c\157\x63\x6b\145\x64\x20\150\x69\163\x20\x49\120\40\141\144\144\162\145\163\163\x20\x66\x6f\x72\x20\x66\x75\162\164\x68\145\x72\40\x61\x63\143\x65\x73\163\x20\164\x6f\40\167\145\142\x73\151\x74\145\56\x3c\x62\162\x3e\74\142\x72\76\x59\157\x75\40\143\141\156\x20\154\157\147\x69\x6e\x20\x74\x6f\40\x79\x6f\x75\x72\x20\x57\x6f\162\x64\120\162\x65\x73\x73\40\x64\x61\x73\x68\141\x62\x6f\x61\x72\x64\x20\164\157\x20\143\150\x65\143\x6b\40\x6d\157\x72\x65\40\x64\145\164\x61\151\154\163\x2e\x3c\142\162\x3e\x3c\142\162\x3e\x54\x68\x61\x6e\153\x73\54\x3c\142\x72\x3e\x6d\151\x6e\x69\x4f\162\141\156\x67\x65";
                amR:
                return $hP;
        }
        K7e:
        agk:
    }
    public function wp_mail_send_notification($RU, $a3, $hP)
    {
        $Tp = array("\103\157\156\x74\x65\x6e\x74\x2d\124\x79\160\145\x3a\40\164\x65\x78\164\x2f\150\164\x6d\154\x3b\x20\x63\150\x61\x72\163\145\164\x3d\x55\x54\x46\55\x38");
        wp_mail($RU, $a3, $hP, $Tp);
    }
    public function mo2f_check_session_management_details($user)
    {
        $do = get_site_option("\x6d\x6f\62\146\x5f\x6d\141\170\151\x6d\x75\155\137\x61\154\x6c\157\x77\x65\144\137\163\x65\163\163\x69\157\156", 1);
        $ua = WP_Session_Tokens::get_instance($user->ID);
        $cK = count($ua->get_all());
        if (!($cK >= (int) $do)) {
            goto zRn;
        }
        $Gm = get_site_option("\x6d\157\x32\146\137\x73\145\x73\163\x69\x6f\x6e\x5f\x61\154\154\157\x77\x65\x64\x5f\x74\x79\160\x65", "\x61\154\154\x6f\167\137\x61\143\143\145\163\163");
        if ("\141\x6c\x6c\157\167\x5f\141\143\x63\x65\163\x73" === $Gm) {
            goto dpV;
        }
        wp_send_json_error(MoWpnsConstants::SESSION_LIMIT_REACHED);
        goto a_1;
        dpV:
        $Xf = WP_Session_Tokens::get_instance($user->ID);
        $vv = $Xf->destroy_all();
        a_1:
        zRn:
    }
}
ChI:
