<?php


if (defined("\101\102\x53\120\x41\124\x48")) {
    goto qiQ;
}
exit;
qiQ:
use TwoFA\Helper\MocURL;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Onprem\Two_Factor_Setup_Onprem_Cloud;
function mo2fa_save_success_customer_config($fK, $L4, $Yl, $CS, $iX)
{
    global $Gw, $Xw;
    $user = wp_get_current_user();
    update_option("\x6d\x6f\x32\x66\x5f\x63\165\x73\164\157\155\145\162\113\145\x79", $L4);
    update_option("\x6d\157\x32\x66\x5f\141\160\x69\x5f\153\x65\x79", $Yl);
    update_option("\155\x6f\x32\x66\x5f\143\x75\163\164\157\155\145\162\137\164\157\153\145\x6e", $CS);
    update_option("\x6d\x6f\62\146\x5f\x61\160\160\x5f\x73\145\x63\x72\145\164", $iX);
    update_option("\155\x6f\x5f\x77\x70\156\x73\137\x65\x6e\x61\142\x6c\145\x5f\x6c\157\147\137\x72\x65\x71\165\145\x73\164\163", true);
    update_option("\155\x6f\x32\146\x5f\155\x69\156\151\x6f\162\x61\156\x67\x65\137\x61\x64\155\x69\156", $user->ID);
    update_site_option("\155\x6f\137\62\x66\x61\143\164\157\162\x5f\141\x64\x6d\151\x6e\137\x72\145\147\x69\163\164\x72\141\x74\x69\157\156\x5f\163\x74\141\x74\x75\x73", "\x4d\x4f\137\x32\137\106\x41\103\x54\117\122\137\x43\x55\x53\124\117\115\x45\122\137\122\x45\107\x49\123\124\x45\122\x45\104\137\123\125\x43\103\x45\123\x53");
    $Gw->update_user_details($user->ID, array("\x6d\157\62\x66\x5f\x75\163\145\x72\137\x65\x6d\141\151\154" => $fK, "\165\x73\145\162\137\x72\x65\147\x69\x73\x74\162\x61\x74\x69\157\156\x5f\167\x69\164\x68\x5f\155\x69\156\x69\157\x72\x61\156\x67\145" => "\x53\x55\103\103\105\123\x53"));
    $VN = new MocURL();
    $Yy = json_decode($VN->mo2f_get_userinfo($fK), true);
    $Z0 = "\x4e\117\x4e\x45";
    if (!(json_last_error() === JSON_ERROR_NONE)) {
        goto Evt;
    }
    if (!("\x53\x55\x43\103\105\x53\x53" === $Yy["\163\x74\x61\164\x75\163"])) {
        goto gzO;
    }
    $Z0 = mo2f_update_and_sync_user_two_factor($user->ID, $Yy);
    gzO:
    Evt:
    if (!("\x4e\117\116\105" !== $Z0)) {
        goto r4G;
    }
    if (!in_array($Z0, array(MoWpnsConstants::OUT_OF_BAND_EMAIL, MoWpnsConstants::AUTHY_AUTHENTICATOR, MoWpnsConstants::OTP_OVER_SMS, MoWpnsConstants::OTP_OVER_EMAIL), true)) {
        goto Yl8;
    }
    $VN->mo2f_update_user_info($fK, "\x4e\x4f\116\x45", null, '', true);
    Yl8:
    r4G:
    delete_user_meta($user->ID, "\162\x65\x67\151\163\x74\145\162\137\141\143\143\157\165\156\164");
    $xT = get_option("\x6d\x6f\62\x66\x5f\143\x75\x73\x74\x6f\x6d\x65\x72\x5f\x73\145\x6c\145\143\x74\145\x64\137\x70\154\x61\x6e");
    if (!empty($xT)) {
        goto AHe;
    }
    if ("\x4e\x4f\116\105" === $Z0) {
        goto du9;
    }
    goto Qrk;
    AHe:
    delete_option("\155\x6f\x32\146\x5f\143\165\163\x74\157\155\x65\162\137\x73\145\154\x65\143\x74\145\x64\x5f\x70\154\141\156");
    if (MoWpnsUtility::get_mo2f_db_option("\155\x6f\62\x66\137\160\154\x61\156\x6e\141\x6d\145", "\x73\151\164\x65\137\x6f\160\x74\x69\157\156") === "\141\144\x64\x6f\156\x5f\x70\154\141\156") {
        goto tGh;
    }
    echo "\x9\x9\11\11\74\163\x63\x72\151\160\x74\76\x77\151\156\144\157\167\x2e\x6c\157\143\x61\x74\151\157\x6e\x2e\x68\162\145\146\75\42\141\144\x6d\151\x6e\56\x70\x68\x70\x3f\160\141\147\x65\x3d\155\x6f\137\62\x66\x61\x5f\165\x70\147\x72\x61\x64\x65\42\73\x3c\57\163\x63\162\x69\x70\x74\76\15\xa\11\11\11\11";
    goto Nkm;
    tGh:
    echo "\74\x73\x63\x72\151\160\164\76\167\x69\x6e\x64\157\x77\56\154\x6f\x63\141\x74\151\x6f\156\x2e\150\x72\145\146\x3d\42\x61\144\x6d\x69\x6e\56\x70\150\x70\x3f\x70\141\x67\145\75\x6d\157\137\x32\146\x61\x5f\x61\x64\144\157\156\163\42\x3b\x3c\x2f\x73\143\162\151\x70\x74\x3e\xd\12\x9\x9\x9";
    Nkm:
    goto Qrk;
    du9:
    if (!get_user_meta($user->ID, "\162\145\147\x69\163\x74\145\162\137\141\143\143\157\x75\156\x74\x5f\160\157\x70\165\160", true)) {
        goto LEB;
    }
    update_user_meta($user->ID, "\155\157\x32\146\137\x63\157\156\146\151\147\165\x72\145\137\62\x46\101", 1);
    LEB:
    Qrk:
    delete_user_meta($user->ID, "\162\x65\x67\151\x73\164\x65\162\137\x61\x63\x63\x6f\165\156\164\137\160\157\160\165\x70");
    delete_option("\x6d\x6f\x5f\x77\x70\156\163\x5f\166\x65\162\151\146\x79\x5f\143\x75\163\164\157\x6d\145\x72");
    delete_option("\x6d\x6f\x5f\x77\160\156\x73\x5f\x72\145\147\x69\x73\164\162\141\x74\x69\157\x6e\137\x73\x74\x61\x74\x75\x73");
    delete_option("\x6d\157\x5f\167\160\156\163\x5f\x70\141\163\163\167\157\x72\144");
}
function mo2fa_get_current_customer($fK, $uk)
{
    $uU = new MocURL();
    $hP = $uU->get_customer_key($fK, $uk);
    $hS = json_decode($hP, true);
    $pd = new MoWpnsMessages();
    if (json_last_error() === JSON_ERROR_NONE) {
        goto RyH;
    }
    $Oc = is_string($hP) ? $hP : '';
    $pd->mo2f_show_message(MoWpnsMessages::lang_translate($Oc), "\105\x52\122\x4f\122");
    goto Yh1;
    RyH:
    if ("\123\125\x43\103\105\x53\123" === $hS["\x73\164\141\x74\x75\163"]) {
        goto AMH;
    }
    update_option("\x6d\157\137\62\x66\141\143\164\157\162\x5f\x61\x64\155\x69\x6e\x5f\162\x65\x67\151\163\x74\162\x61\164\151\x6f\x6e\137\x73\x74\x61\x74\165\163", "\x4d\x4f\x5f\x32\137\106\x41\x43\x54\117\122\x5f\126\x45\122\111\x46\131\x5f\103\125\x53\x54\x4f\x4d\x45\x52");
    update_option("\x6d\157\x5f\x77\x70\156\x73\137\x76\145\162\x69\x66\x79\137\143\165\x73\164\x6f\155\x65\162", "\x74\x72\165\145");
    delete_option("\x6d\157\137\167\160\156\163\137\156\145\x77\137\162\145\147\151\x73\164\x72\x61\164\x69\x6f\156");
    $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ACCOUNT_EXISTS), "\x45\122\122\x4f\122");
    return;
    goto Ytf;
    AMH:
    if (!isset($hS["\x70\x68\157\156\x65"])) {
        goto j8O;
    }
    update_option("\155\x6f\x5f\x77\160\x6e\x73\137\x61\144\x6d\x69\156\x5f\160\x68\x6f\x6e\x65", $hS["\160\150\x6f\x6e\x65"]);
    j8O:
    update_option("\x6d\157\x32\146\137\145\x6d\x61\151\x6c", $fK);
    $L4 = isset($hS["\x69\x64"]) ? $hS["\x69\144"] : '';
    $Yl = isset($hS["\x61\160\151\113\145\171"]) ? $hS["\141\160\151\x4b\x65\x79"] : '';
    $CS = isset($hS["\x74\157\x6b\145\156"]) ? $hS["\164\157\x6b\x65\156"] : '';
    $iX = isset($hS["\141\x70\x70\x53\x65\x63\162\145\164"]) ? $hS["\141\160\x70\x53\145\x63\x72\145\164"] : '';
    mo2fa_save_success_customer_config($fK, $L4, $Yl, $CS, $iX);
    update_site_option(base64_encode("\x74\157\164\x61\154\x55\x73\145\162\163\x43\x6c\157\165\144"), get_site_option(base64_encode("\164\x6f\164\141\x6c\125\x73\x65\162\163\x43\154\157\165\144")) + 1);
    $Td = new Two_Factor_Setup_Onprem_Cloud();
    $hP = json_decode($Td->get_customer_transactions(get_option("\155\157\x32\146\137\143\x75\163\x74\x6f\x6d\x65\x72\113\x65\171"), get_option("\x6d\157\x32\146\x5f\x61\160\x69\x5f\x6b\x65\x79"), "\x50\x52\x45\x4d\111\125\115"), true);
    if ("\123\x55\x43\x43\x45\123\123" === $hP["\x73\164\x61\164\165\163"]) {
        goto pQ5;
    }
    update_site_option("\155\x6f\62\x66\x5f\x6c\151\143\145\x6e\163\145\x5f\164\x79\160\x65", "\x44\105\x4d\117");
    $hP = json_decode($Td->get_customer_transactions(get_option("\155\157\x32\x66\x5f\143\x75\x73\164\x6f\x6d\145\162\x4b\145\x79"), get_option("\x6d\157\62\x66\x5f\141\x70\151\x5f\153\x65\171"), "\x44\105\115\117"), true);
    goto gmu;
    pQ5:
    update_site_option("\155\157\62\146\137\x6c\x69\x63\x65\x6e\x73\145\x5f\164\x79\x70\145", "\120\x52\x45\115\111\x55\115");
    gmu:
    if (isset($hP["\163\x6d\x73\122\145\155\x61\151\x6e\151\x6e\x67"])) {
        goto iEz;
    }
    if (isset($hP["\x73\x74\141\164\165\163"]) && "\123\x55\x43\x43\x45\x53\x53" === $hP["\163\164\x61\164\165\163"]) {
        goto AH6;
    }
    goto yUY;
    iEz:
    update_site_option("\x63\155\x56\x74\131\x57\154\165\x61\x57\x35\156\x54\61\x52\121\126\110\112\x68\x62\156\116\150\x59\63\x52\x70\x62\62\x35\x7a", $hP["\x73\155\x73\x52\145\155\x61\151\156\x69\156\147"]);
    goto yUY;
    AH6:
    update_site_option("\x63\155\x56\164\x59\x57\154\165\141\127\x35\156\124\61\122\121\x56\x48\112\x68\142\x6e\x4e\x68\x59\63\x52\x70\x62\62\65\172", 0);
    yUY:
    if (!isset($hP["\x65\155\141\151\154\122\x65\x6d\x61\151\156\x69\x6e\147"])) {
        goto tUm;
    }
    if (MO2F_IS_ONPREM) {
        goto cRC;
    }
    update_site_option("\x63\x6d\126\164\131\127\154\165\141\x57\65\156\x54\x31\x52\121", $hP["\145\x6d\141\151\154\x52\x65\x6d\141\x69\x6e\151\x6e\x67"]);
    goto oAn;
    cRC:
    if (get_site_option("\x63\155\126\164\131\x57\x6c\165\141\x57\65\156\124\61\122\x51")) {
        goto CWY;
    }
    update_site_option("\x63\155\x56\x74\131\x57\x6c\x75\141\127\x35\156\124\61\122\x51", 30);
    CWY:
    oAn:
    tUm:
    $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::REG_SUCCESS), "\123\125\x43\103\x45\123\123");
    return;
    Ytf:
    Yh1:
}
function mo2f_update_and_sync_user_two_factor($v1, $Yy)
{
    global $Gw;
    $Z0 = isset($Yy["\141\165\164\150\x54\171\160\145"]) && !empty($Yy["\141\165\x74\x68\x54\x79\x70\x65"]) ? $Yy["\141\x75\x74\x68\x54\x79\160\x65"] : "\x4e\117\x4e\105";
    if (!MO2F_IS_ONPREM) {
        goto T3G;
    }
    $Z0 = $Gw->get_user_detail("\155\x6f\x32\146\x5f\x63\x6f\156\146\x69\147\x75\162\145\144\137\x32\106\x41\137\155\145\x74\150\157\144", $v1);
    $Z0 = $Z0 ? $Z0 : "\x4e\117\116\x45";
    return $Z0;
    T3G:
    $Gw->update_user_details($v1, array("\155\x6f\x32\x66\x5f\165\x73\x65\162\x5f\145\155\141\x69\154" => $Yy["\x65\155\141\151\154"]));
    if (MoWpnsConstants::OUT_OF_BAND_EMAIL === $Z0) {
        goto P3b;
    }
    if (MoWpnsConstants::OTP_OVER_SMS === $Z0 && !MO2F_IS_ONPREM) {
        goto ifj;
    }
    if (MoWpnsConstants::SECURITY_QUESTIONS === $Z0) {
        goto ZmY;
    }
    if (MoWpnsConstants::GOOGLE_AUTHENTICATOR === $Z0) {
        goto Cqj;
    }
    goto X4R;
    P3b:
    $Gw->update_user_details($v1, array("\x6d\x6f\x32\x66\x5f\x45\x6d\x61\151\x6c\x56\x65\162\x69\x66\x69\x63\x61\x74\151\x6f\156\137\143\157\x6e\x66\x69\147\137\163\164\141\164\x75\x73" => true));
    goto X4R;
    ifj:
    $Uf = isset($Yy["\160\x68\157\x6e\x65"]) ? sanitize_text_field($Yy["\160\x68\x6f\x6e\x65"]) : '';
    $Gw->update_user_details($v1, array("\x6d\157\x32\146\137\x4f\x54\x50\x4f\166\x65\162\123\x4d\123\137\143\157\156\146\151\147\137\x73\x74\141\x74\x75\163" => true));
    $_SESSION["\x75\x73\x65\x72\137\x70\x68\x6f\156\145"] = $Uf;
    goto X4R;
    ZmY:
    $Gw->update_user_details($v1, array("\x6d\157\x32\146\x5f\x53\145\x63\x75\x72\151\x74\x79\121\165\x65\x73\164\x69\157\156\x73\137\143\157\156\x66\151\x67\x5f\x73\164\141\x74\x75\x73" => true));
    goto X4R;
    Cqj:
    $C2 = get_user_meta($v1, "\155\157\x32\x66\137\145\x78\164\145\162\156\141\x6c\x5f\x61\x70\160\x5f\x74\x79\x70\x65", true);
    if (MoWpnsConstants::AUTHY_AUTHENTICATOR === $C2) {
        goto wtE;
    }
    $Gw->update_user_details($v1, array("\x6d\157\x32\146\137\x47\x6f\157\147\154\145\x41\165\164\x68\x65\156\x74\x69\143\x61\164\157\x72\137\143\157\x6e\146\x69\x67\x5f\x73\x74\141\x74\165\x73" => true));
    update_user_meta($v1, "\x6d\157\62\x66\137\x65\170\x74\145\x72\x6e\x61\154\x5f\141\x70\x70\137\164\x79\x70\145", MoWpnsConstants::GOOGLE_AUTHENTICATOR);
    goto DIH;
    wtE:
    $Gw->update_user_details($v1, array("\x6d\x6f\x32\x66\x5f\101\x75\164\x68\x79\x41\x75\164\x68\x65\156\164\x69\x63\x61\164\157\x72\x5f\x63\x6f\x6e\x66\x69\x67\137\x73\164\x61\164\x75\x73" => true));
    DIH:
    X4R:
    return $Z0;
}
