jQuery(document).ready(function () {
	const activeTemplate = localStorage.getItem('activeTemplate') || 'mo2f_email_template_otp_btn';
    switchEmailTemplates(activeTemplate);
    jQuery('[id^="mo2f_email_template_"]').click(function () {
        const buttonId = jQuery(this).attr('id');
        switchEmailTemplates(buttonId);
    });
	const activeTab = localStorage.getItem('activeTab') || 'mo2f_registered_users_btn';
    switchTwofaStatus(activeTab);
    jQuery('#mo2f_registered_users_btn').click(function () {
        switchTwofaStatus('mo2f_registered_users_btn');
    });
    jQuery('#mo2f_unregistered_users_btn').click(function () {
        switchTwofaStatus('mo2f_unregistered_users_btn');
    });
	let nonce = settings_page_object.nonce;
	$ = jQuery;
	// Add nonce field form along with button for notices.
	// show and hide instructions
	$("#auth_help").click(function () {
		$("#auth_troubleshoot").toggle();
	});
	$("#conn_help").click(function () {
		$("#conn_troubleshoot").toggle();
	});

	$("#conn_help_user_mapping").click(function () {
		$("#conn_user_mapping_troubleshoot").toggle();
	});

	// show and hide attribute mapping instructions
	$("#toggle_am_content").click(function () {
		$("#show_am_content").toggle();
	});

	// Instructions
	$("#mo_wpns_help_curl_title").click(function () {
		$("#mo_wpns_help_curl_desc").slideToggle(600);
	});

	$("#mo_wpns_issue_in_scanning_QR").click(function () {
		$("#mo_wpns_issue_in_scanning_QR_solution").slideToggle(600);
	});

	$("#mo_wpns_help_get_back_to_account").click(function () {
		$("#mo_wpns_help_get_back_to_account_solution").slideToggle(600);
	});

	$("#mo_wpns_help_multisite").click(function () {
		$("#mo_wpns_help_multisite_solution").slideToggle(600);
	});

	$("#mo_wpns_help_adv_user_ver_title").click(function () {
		$("#mo_wpns_help_adv_user_ver_desc").slideToggle(600);
	});
	$("#mo_wpns_help_forgot_password").click(function () {
		$("#mo_wpns_help_forgot_password_solution").slideToggle(600);
	});
	$("#mo_wpns_help_MFA_propmted").click(function () {
		$("#mo_wpns_help_MFA_propmted_solution").slideToggle(600);
	});

	$("#mo_wpns_help_redirect_back").click(function () {
		$("#mo_wpns_help_redirect_back_solution").slideToggle(600);
	});
	$("#mo_wpns_help_alternet_login").click(function () {
		$("#mo_wpns_help_alternet_login_solution").slideToggle(600);
	});
	$("#mo_wpns_help_lost_ability").click(function () {
		$("#mo_wpns_help_lost_ability_solution").slideToggle(600);
	});
	$("#mo_wpns_help_translate").click(function () {
		$("#mo_wpns_help_translate_solution").slideToggle(600);
	});
	$("#mo_wpns_help_particular_use_role").click(function () {
		$("#mo_wpns_help_particular_use_role_solution").slideToggle(600);
	});
	$("#mo_wpns_help_enforce_MFA").click(function () {
		$("#mo_wpns_help_enforce_MFA_solution").slideToggle(600);
	});
	$("#mo_wpns_help_reset_MFA").click(function () {
		$("#mo_wpns_help_reset_MFA_solution").slideToggle(600);
	});

	$(".backup_codes_dismiss").click(function () {
		ajaxCall("dismisscodeswarning", ".backupcodes-notice", true);
	});

	$(".whitelist_self").click(function () {
		ajaxCall("whitelistself", ".whitelistself-notice", true);
	});

	$(".sms_low_dismiss").click(function () {
		ajaxCall("dismissSms", ".low_sms-notice", true);
	});

	$(".sms_low_dismiss_always").click(function () {
		ajaxCall("dismissSms_always", ".low_sms-notice", true);
	});

	$(".email_low_dismiss").click(function () {
		ajaxCall("dismissEmail", ".low_email-notice", true);
	});

	$(".email_low_dismiss_always").click(function () {
		ajaxCall("dismissEmail_always", ".low_email-notice", true);
	});

	$(".new_plugin_dismiss").click(function () {
		ajaxCall("dismissplugin", ".plugin_warning_hide-notice", true);
	});

	$(".plugin_warning_never_show_again").click(function () {
		ajaxCall(
			"plugin_warning_never_show_again",
			".plugin_warning_hide-notice",
			true
		);
	});

	$(".mo2f_banner_never_show_again").click(function () {
		ajaxCall("mo2f_banner_never_show_again", ".mo2f_offer_main_div", true);
	});

	$(".wpns_premium_option :input").attr("disabled", true);

	$("#setuptwofa_redirect").click(function (e) {
		localStorage.setItem("last_tab", "setup_2fa");
	});
	jQuery('.mo2f-premium-feature').find('a, input, button, select').each(function () {
		if (jQuery(this).is('a')) {
			jQuery(this).on('click', function (e) {
				e.preventDefault();
			}).css('pointer-events', 'none').css('color', 'gray');
		} else if (jQuery(this).is('button')) {
			jQuery(this).prop('disabled', true).css('pointer-events', 'none').css('background-color', '#cccccc');
		} else {
			jQuery(this).prop('disabled', true).css('pointer-events', 'none');
		}
	});
});

function ajaxCall(option, element, hide) {
	let nonce = settings_page_object.nonce;
	jQuery.ajax({
		url: "",
		type: "GET",
		data: "option=" + option + "&nonce=" + nonce,
		crossDomain: !0,
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		success: function (o) {
			if (hide != undefined) {
				jQuery(element).slideUp();
			}
		},
		error: function (o, e, n) {},
	});
}

function success_msg(msg) {
	jQuery("#wpns_nav_message").empty();
	jQuery("#wpns_nav_message").append(
		"<div id='notice_div' class='overlay_success' style='z-index:9999'><div class='popup_text'>" +
			msg +
			"</div></div>"
	);
	window.onload = nav_popup();
}

function error_msg(msg) {
	jQuery("#wpns_nav_message").empty();
	jQuery("#wpns_nav_message").append(
		"<div id='notice_div' class='overlay_error'><div class='popup_text'>" +
			msg +
			"</div></div>"
	);
	window.onload = nav_popup();
}

function saveSettingsSuccessMsg(id,msg){
    
	jQuery('.' + id ).after('<div class="mo2f-save-settings-success-message">' + msg + '</div>');
	setTimeout(function() {
		jQuery('.mo2f-save-settings-success-message').fadeOut(function() {
            $(this).remove();
        });
        jQuery('#' + id ).prop('disabled', false);
	}, 3000);
}

function saveSettingsErrorsMsg(id,msg){
	jQuery('.' + id ).after('<div class="mo2f-save-settings-error-message">' + msg + '</div>');
	setTimeout(function() {
		jQuery('.mo2f-save-settings-error-message').fadeOut('hidden');
        jQuery('#' + id ).prop('disabled', false);
	}, 3000);
}

function nav_popup() {
	if (document.getElementById("notice_div") !== null) {
		document.getElementById("notice_div").style.width = "40%";
		setTimeout(function () {
			jQuery("#notice_div").fadeOut("slow");
		}, 3000);
	}
}

// OFFER TIMER
var countDownDate = new Date("Jan 15, 2022 23:59:59").getTime();

var x = setInterval(function () {
	var now = new Date().getTime();
	var distance = countDownDate - now;

	var days = Math.floor(distance / (1000 * 60 * 60 * 24));
	var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
	var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
	var seconds = Math.floor((distance % (1000 * 60)) / 1000);
	if (document.getElementById("mo2f_offer_timer") != null) {
		document.getElementById("mo2f_offer_timer").innerHTML =
			days + "d " + hours + "h " + minutes + "m " + seconds + "s ";
	}

	if (distance < 0) {
		clearInterval(x);
		if (document.getElementById("mo2f_offer_timer") != null) {
			document.getElementById("mo2f_offer_timer").innerHTML = "EXPIRED";
		}
	}
}, 1000);
// -----OFFER TIMER

function mo2FASupportOnClick(query){
    $mo = jQuery;
   // document.getElementById('contactQuery').value = query;
    $mo("#contact-us-toggle").prop('checked', true);
    $mo(".mo2fa_contactus_popup_container").show();
    $mo("#mo-contact-form").show();
    $mo(".mo_contactus_popup_wrapper").show();
}

//Close pop-up button on contact us form
function mo_2fa_contactus_goback() {
    $mo('.mo2f-scrollable-div').removeAttr('style');
    $mo(".mo2fa_contactus_popup_container").hide();
    $mo(".mo_contactus_popup_wrapper").hide();
   // $mo("#mo_query_email").hide();
    $mo("#mo-contact-form").hide();
}
jQuery(document).ready(function(jQuery) {
	let nonce = settings_page_object.contactus_nonce;
	jQuery("#mo2f_send_query").click(function() {
		var data = {
			action: "mo_two_factor_ajax",
			mo_2f_two_factor_ajax: "mo2f_handle_support_form",
			nonce: nonce,
			mo2f_send_configuration: jQuery("input[name=mo2f_send_configuration]").is(":checked"),
			mo2f_query_email : jQuery("input[name=mo2f_query_email]").val(),
			mo2f_query_phone: jQuery("input[name=mo2f_query_phone]").val(),
			mo2f_query : jQuery("#mo2f_query").val(),
		};
		jQuery.post(ajaxurl, data, function(response) {
			if (response.success) {
				 success_msg(response.data);
				 window.location.reload(true);
			 } else {
				 error_msg(response.data);
			 }
  
		});
	});
  
});
jQuery(document).ready(function()
{
    jQuery("#mo_logout").click(function()
    {   
        jQuery("#mo2f_2fa_popup_dashboard").html("<span class=\'mo2f_loader\' id=\'mo2f_loader\'></span>");
        jQuery("#mo2f_2fa_popup_dashboard").css("display", "block");
        var data =  
        {
            'action': "mo_two_factor_ajax",
            'mo_2f_two_factor_ajax': "mo2f_remove_miniorange_account",
            'nonce'                   : settings_page_object.contactus_nonce  
        };
        jQuery.post(ajaxurl, data, function(response) {
            mo2fCloseLoader();
            if( response.success ){
                success_msg(response.data);
                window.location.reload(true);
            } else{
                error_msg(response.data);
            }

        });
    });
    jQuery("#mo2f_transaction_check").click(function()
    {   mo2fShowLoader();
        var data =  
        {  
            'action'                  : 'mo_two_factor_ajax',
            'mo_2f_two_factor_ajax' : 'mo2f_check_transactions', 
            'nonce'                   : settings_page_object.contactus_nonce  
        };
        jQuery.post(ajaxurl, data, function(response) {
            mo2fCloseLoader();
            success_msg(response.data);
        });
    });
    jQuery("#mo2f_check_license").click(function() {
        mo2fShowLoader();
       var data = {
           action: "mo2f_two_factor_ajax",
           option: "mo2f_verify_license",
           nonce: settings_page_object.contactus_nonce,
           mo2fa_licence_key: jQuery("input[name=mo2fa_licence_key]").val(),
           license_consent : jQuery("#license_conditions").is(":checked")
       };
       jQuery.post(ajaxurl, data, function(response) {
            mo2fCloseLoader();
               if (response.success) {
                success_msg(response.data);
                window.location.reload(true);
            } else {
                error_msg(response.data);
            }
 
       });
   });
    jQuery("#mo2f_go_back_account").click(function() {
       mo2fShowLoader();
       var data = {
           action: "mo2f_two_factor_ajax",
           option: "mo_2fa_back_account",
           nonce: settings_page_object.contactus_nonce,
       };
       jQuery.post(ajaxurl, data, function(response) {
            mo2fCloseLoader();
               if (response.success) {
                window.location.reload(true);
            } else {
                error_msg(response.data);
            }
 
       });
   });
   jQuery('#mo2f_clear_login_report').click(function () {
  
	var noDataRow = jQuery('#mo2f_login_transactions_table tbody tr:contains("No data available in table")');
	if (noDataRow.length > 0) {
		error_msg("No data available to clear.");
		return;
	} 
    mo2fShowLoader();
	var data = {
		'action': 'mo2f_advance_settings_ajax',
		'option': 'mo_wpns_manual_clear',
		'nonce': settings_page_object.contactus_nonce,

	};
	jQuery.post(ajaxurl, data, function (response) {
        mo2fCloseLoader();
		if (response.success === true) {
			jQuery("#mo2f_login_transactions_table tbody").empty();
			jQuery("#mo2f_login_transactions_table tbody").append('<tr><td colspan="4">No data available in table</td></tr>');
			success_msg("Report cleared successfully.");
		} else {
			error_msg("Unknown error occurred. Please try again!");
		}
	});
	
});
jQuery("#mo2f_login_transactions_table").DataTable({
	"order": [[3, "desc"]]
});
jQuery('#mo2f_passwordless_login_save_button').click(function(){
    mo2fShowLoader();
	var data =  {
			'action'          : 'mo2f_advance_settings_ajax',
			'option'          : 'mo2f_passwordless_login_settings',
			'login_with_password': jQuery('input[name="mo2f_login_option"]:checked').val(),
			'enable_login_with_2fa'  : jQuery("#mo2f_enable_passwordless_login").is(":checked"),
			'nonce'          : settings_page_object.contactus_nonce,
		};
		jQuery.post(ajaxurl, data, function(response) {
            mo2fCloseLoader();
			if (response.success){
				success_msg(response.data);
			}else{
				error_msg(response.data);
			}
		});
});
jQuery('#mo2f-showpreview').on('click', function () {
    if (jQuery("#mo2f-preview1").is(":visible") || jQuery("#mo2f-preview2").is(":visible")) {
        jQuery('#mo2f-preview2').hide();
        jQuery('#mo2f-preview1').hide();
        jQuery('#mo2f-showpreview').html('Show Preview');
    } else if (jQuery("#mo2f-preview1").is(":hidden") || jQuery("#mo2f-preview2").is(":hidden")) {
        if (jQuery("#mo2f_enable_passwordless_login").is(":checked")) {
            jQuery('#mo2f-preview2').show();
        } else {
            jQuery('#mo2f-preview1').show();
        }
        jQuery('#mo2f-showpreview').html('Hide Preview');
    }
});
jQuery('#mo2f-showpreview2').on('click', function () {
    if (jQuery("#mo2f-preview2").is(":visible")) {
        jQuery('#mo2f-preview2').hide();
        jQuery('#mo2f-showpreview2').html('Show Preview');
    } else if (jQuery("#mo2f-preview2").is(":hidden")) {
        jQuery('#mo2f-preview2').show();
        jQuery('#mo2f-showpreview2').html('Hide Preview');
    }
});
if (jQuery('#mo2f_with_password').is(':checked')) {
    jQuery('#mo2f-pwdless-login-content').hide();
}
jQuery('input[name="mo2f_login_option"]').on('change', function () {
    if (jQuery('#mo2f_without_password').is(':checked')) {
        jQuery('#mo2f-pwdless-login-content').slideDown();
    } else if (jQuery('#mo2f_with_password').is(':checked')) {
        jQuery('#mo2f-pwdless-login-content').slideUp();
    }
});
jQuery('#mo2f_with_password').on('click', function() {
	jQuery('#mo2f_enable_passwordless_login').prop('checked', false);
});
jQuery('#mo2f_enable_passwordless_login').on('change', function () {
    if (jQuery(this).is(':checked')) {
        jQuery('#mo2f_without_password').prop('checked', true);
        if (jQuery("#mo2f-preview1").is(":visible")) {
            jQuery('#mo2f-preview1').hide();
            jQuery('#mo2f-preview2').show();
        }
    } else if (jQuery("#mo2f-preview2").is(":visible")) {
        jQuery('#mo2f-preview2').hide();
        jQuery('#mo2f-preview1').show();
    }
});
jQuery("#mo2f_email_verification_response_reset_button").click(function () {
	jQuery("#mo2f_login_popup_reset_button_form2").submit();
});
	jQuery('#mo2f_session_restriction_save_button').click(function(){
        mo2fShowLoader();
        var data = {
            'action': 'mo2f_advance_settings_ajax',
            'option': 'mo2f_save_session_management_settings',
            'enable_session_setting': jQuery("#mo2f_sesssion_restriction").is(":checked"),
            'enable_session_expiry': jQuery("#mo2f_session_logout_time_enable").is(":checked"),
            'max_sessions_allowed': jQuery('input[name="mo2fa_simultaneous_session_allowed"]').val(),
            'max_sessions_time': jQuery('input[name="mo2f_number_of_timeout_hours"]').val(),
            'restriction_type': jQuery('input[name="mo2f_enable_simultaneous_session"]:checked').val(),
            'nonce': settings_page_object.contactus_nonce,

        };
        jQuery.post(ajaxurl, data, function (response) {
            mo2fCloseLoader();
            if (response.success) {
                success_msg(response.data);
            } else {
                error_msg(response.data);
            }
        });
	});
    if (!jQuery('#mo2f_sesssion_restriction').is(':checked')) {
		jQuery('#mo2f_simultaneous_sessions_content').hide();
	}
	jQuery('#mo2f_sesssion_restriction').on('change', function () {
		if (jQuery(this).is(':checked')) {
			jQuery('#mo2f_simultaneous_sessions_content').slideDown(); // Show content
		} else {
			jQuery('#mo2f_simultaneous_sessions_content').slideUp(); // Hide content
		}
	});
	if (!jQuery('#mo2f_session_logout_time_enable').is(':checked')) {
		jQuery('#mo2f_session_expiry_time_content').hide();
	}
	jQuery('#mo2f_session_logout_time_enable').on('change', function () {
		if (jQuery(this).is(':checked')) {
			jQuery('#mo2f_session_expiry_time_content').slideDown(); // Show content
		} else {
			jQuery('#mo2f_session_expiry_time_content').slideUp(); // Hide content
		}
	});
	jQuery("#mo2f_rba_save_button").click(function(){
        mo2fShowLoader();
        var data = {
                'action'  : 'mo2f_advance_settings_ajax',
                'option'  : 'mo2f_save_rba_settings',
                'enable_rba'  : jQuery("#mo2f_check_rba").is(":checked"),
                'rba_type': jQuery('input[name="mo2f_enable_rba_types"]:checked').val(),
                'nonce'   : settings_page_object.contactus_nonce,
                'rba_device_limit'   : jQuery('input[name="mo2fa_device_limit"]').val(),
                'rba_expiry'  : jQuery('input[name="mo2fa_device_expiry"]').val(),
                'rba_login'   : jQuery('input[name="mo2f_rba_login_limit"]:checked').val(),
        };
        jQuery.post(ajaxurl, data, function(response) {
            mo2fCloseLoader();
            if (response.success){
                success_msg(response.data);
            }else{
                error_msg(response.data);
            }
        });
    });
    if (!jQuery('#mo2f_check_rba').is(':checked')) {
		jQuery('#mo2f-rba-content').hide();
	}
	jQuery('#mo2f_check_rba').on('change', function () {
		if (jQuery(this).is(':checked')) {
			jQuery('#mo2f-rba-content').slideDown();
		} else {
			jQuery('#mo2f-rba-content').slideUp();
		}
	});
jQuery("#mo2f_upload_logo_reset_button").click(function(){
	jQuery("#mo2f_upload_logo_reset_button_form").submit();
});
jQuery("#mo2f_enable_login_popup_customization").click(function(){
	var data = {
			'action': 'mo2f_white_labelling_ajax',
			'option': 'mo2f_login_popup_customization',
			'nonce': settings_page_object.whitelabeling_nonce,
			'customization_enabled': jQuery("#mo2f_enable_login_popup_customization").is(":checked"),
	};
	jQuery.post(ajaxurl, data, function (response) {
		if (response.success) {
			success_msg(response.data);
		} else {
			error_msg(response.data);
		}
	});

});
jQuery("#mo2f_login_popup_reset_button").click(function(){
	jQuery("#mo2f_login_popup_reset_button_form").submit();
});
jQuery( '#mo2f_backup_code_email_template_reset_button' ).click(function(){
    jQuery( '#mo2f_backup_code_email_reset_form').submit();
});
jQuery( '#mo2f_reconfig_link_email_template_reset_button' ).click(function(){
    jQuery( '#mo2f_reconfig_link_email_reset_form').submit();
});
jQuery( '#mo2f_out_of_band_email_template_reset_button' ).click(function(){
    jQuery( '#mo2f_out_of_band_email_reset_form').submit();
});
jQuery( '#mo2f_otp_over_email_template_reset_button' ).click(function(){
    jQuery( '#mo2f_otp_over_email_reset_form').submit();
});
jQuery( '#mo2f_new_ip_detected_email_template_reset_button' ).click(function(){
    jQuery( '#mo2f_new_ip_detected_email_reset_form').submit();
});
});
function getlicensekeysform(){
    jQuery("#mo2f_view_licensekey_form").submit();
}
function mo2f_enable_login_transactions_toggle(){
    var data =  {
        'action'                        : 'mo2f_advance_settings_ajax',
        'option'                        : 'mo2f_enable_transactions_report',
        'nonce'         				: settings_page_object.contactus_nonce,
        'mo2f_enable_transaction_report':  jQuery('#mo2f_enable_login_report').is(":checked"),
    };
    jQuery.post(ajaxurl, data, function(response) {
        if ( response =='true' ){
            success_msg("Login report is enabled.");
        }else if( response =='false'){
            error_msg("Login report is disabled.");
        }else{
            error_msg(response.data);
        }
    });

}
function removeRememberedDevice(user_id,fingerprint)
{
    var data = {
    'action'                  : 'mo2f_advance_settings_ajax',
    'option'                  : 'mo2f_remove_remembered_device', 
    'user_id'                 :  user_id,
    'fingerprint'             :  fingerprint,
    'nonce'                   :  settings_page_object.contactus_nonce,
    };
    jQuery.post(ajaxurl, data, function(response) {
        if (response.success){
            jQuery("#"+user_id+fingerprint).css('display','none');
            success_msg(response.data);
        }else{
            error_msg(response.data);
        }
    });
}  
jQuery(document).ready(function () {
	jQuery("#login_reports").DataTable({
		"order": [[ 3, "desc" ]]
	});
	jQuery('#mo2f_google_appname_save_button').click(function () {
        mo2fShowLoader()
		var nonce = jQuery("#mo2f_nonce").val();
		var data = {
			'action': 'mo2f_white_labelling_ajax',
			'option': 'mo2f_google_app_name',
			'nonce': nonce,
			'mo2f_google_auth_appname': jQuery("#mo2f_change_app_name").val(),
		};
		jQuery.post(ajaxurl, data, function (response) {
        mo2fCloseLoader();
			if (response.success) {
				success_msg("App name saved successfully!");
			} else {
				error_msg(response.data);
			}
		});
	});
	jQuery(document).on('click', '.mo2f_add_question', function() {
        const currentRow = jQuery(this).closest('tr');
        const table = jQuery('.mo2f_kba_table');
        const rowCount = table.find('tr').length;
		const newRowNumber = rowCount + 1;
		const newRow = currentRow.clone();
		newRow.find('td:first').text(`Q${newRowNumber}:`);
		newRow.find('input').attr('id', `mo2f_kbaquestion_custom_admin_${newRowNumber}`).val('');
		newRow.find('input').attr('placeholder', 'Enter your custom question here');
		currentRow.after(newRow);
        updateQuestionNumbers();
    });
    jQuery(document).on('click', '.mo2f_remove_question', function() {
        const totalRows = jQuery('.mo2f_kba_body').length;

        if (totalRows > 3) {
            jQuery(this).closest('tr').remove();
            updateQuestionNumbers();
        } else {
            error_msg('At least three questions must remain.');
        }
    });
    function updateQuestionNumbers() {
        jQuery('.mo2f_kba_body').each(function(index) {
            jQuery(this).find('td:first').text('Q' + (index + 1) + ':');
            jQuery(this).find('input').attr('id', 'mo2f_kbaquestion_custom_admin_' + (index + 1));
        });
    }
    jQuery('#mo2f-save-custom-kba-settings').on('click', function(e) {
        e.preventDefault(); 
        let isValid = true;
        let customQuestions = [];
        jQuery('input[name="mo2f_kbaquestion_custom_admin[]"]').each(function() {
            let question = jQuery(this).val().trim();
            if (question === '') {
                error_msg('All custom question fields must be filled.');
                isValid = false;
                return false;
            }
            customQuestions.push(question);
        });
        if (!isValid) {
            return false;
        }
        let defaultQuestionCount = parseInt(jQuery('#mo2f_default_kbaquestions_users').val()) || 2;
        let availableCustomQuestions = customQuestions.length;
        if (defaultQuestionCount > availableCustomQuestions) {
            error_msg('Default question count cannot exceed the number of available custom questions.');
            return false;
        }
        if (isValid) {
            mo2fShowLoader();
            let nonce = jQuery("#mo2f_whitelabelling_nonce").val();
            let data = {
                'action': 'mo2f_white_labelling_ajax',
			    'option': 'mo2f_custom_security_questions_settings',
                'nonce': nonce,
                'mo2f_default_kbaquestions_users': defaultQuestionCount,
                'mo2f_custom_kbaquestions_users': jQuery('#mo2f_custom_kbaquestions_users').val(),
                'mo2f_kbaquestion_custom_admin': customQuestions
            };
            jQuery.post(ajaxurl, data, function(response) {
                mo2fCloseLoader();
                if (response.success) {
                    success_msg('Settings saved successfully!');
                } else {
                    error_msg(response.data);
                }
            })
        }
    });
jQuery("#mo2f_custom_security_questions_reset_button").click(function () {
        jQuery("#mo2f_login_popup_reset_button_form_second").submit();
    });
});
jQuery(document).ready(function() {
    jQuery("#mo2f_device_details").DataTable({
        "order": [[ 3, "desc" ]]
    });
});
function switchEmailTemplates(tabId) {
    localStorage.setItem('activeTemplate', tabId);
    const emailMappings = {
        'mo2f_email_template_otp_btn': '#mo2f_email_subject',
        'mo2f_email_template_link_btn': '#mo2f_email_ver_subject',
        'mo2f_email_template_reconfig_link_btn': '#mo2f_2fa_reconfig_email_subject',
        'mo2f_email_template_backupcode_btn': '#mo2f_2fa_backup_code_email_subject',
        'mo2f_email_template_new_ip_btn': '#mo2f_2fa_new_ip_detected_email_subject',
    };
    Object.entries(emailMappings).forEach(([buttonId, templateId]) => {
        const isActive = buttonId === tabId;
        jQuery(templateId).toggleClass('hidden', !isActive);
        jQuery(`#${buttonId}`).toggleClass('mo2f-active', isActive);
    });
    jQuery("#mo2f_backup_code_email_template_config_message_ifr").css("height", "522px"); 
    jQuery("#mo2f_reconfig_link_email_template_config_message_ifr").css("height", "444px"); 
    jQuery("#mo2f_new_ip_detected_email_template_config_message_ifr").css("height", "405px"); 
    jQuery("#mo2f_out_of_band_email_template_config_message_ifr").css("height", "444px"); 
    jQuery("#mo2f_otp_over_email_template_config_message_ifr").css("height", "405px"); 
}
function switchTwofaStatus(tabId) {
    localStorage.setItem('activeTab', tabId);
    const registeredButton = jQuery('#mo2f_registered_users_btn');
    const unregisteredButton = jQuery('#mo2f_unregistered_users_btn');
    
    if (tabId === 'mo2f_registered_users_btn') {
        jQuery('#mo2f_registered_user_details').show();
        jQuery('#mo2f_unregistered_user_details').hide();
        registeredButton.addClass('mo2f-active');
        unregisteredButton.removeClass('mo2f-active');
        if (DataTable.isDataTable("#mo2f_unregistered_user_details")) {
            jQuery("#mo2f_unregistered_user_details").DataTable().destroy();
        }
        jQuery("#mo2f_registered_user_details").DataTable({
            "order": [[ 0, "desc" ]],
        });

    } else{
        jQuery('#mo2f_unregistered_user_details').show();
        jQuery('#mo2f_registered_user_details').hide();
        registeredButton.removeClass('mo2f-active');
        unregisteredButton.addClass('mo2f-active');
        if (DataTable.isDataTable("#mo2f_registered_user_details")) {
            jQuery("#mo2f_registered_user_details").DataTable().destroy();
        }
        jQuery("#mo2f_unregistered_user_details").DataTable({
            "order": [[ 0, "desc" ]],
        });

    }

}
document.addEventListener('DOMContentLoaded', function () {
    const myAccountButton = document.getElementById('mo_2fa_my_account');
    const submenu = document.getElementById('mo2f-myaccount-submenu');

    myAccountButton.addEventListener('mouseenter', function () {
        submenu.style.display = 'block';
    });
    if( ! jQuery('#mo_2fa_my_account').hasClass('side-nav-active') ){
        myAccountButton.addEventListener('mouseleave', function () {
        
            submenu.style.display = 'none';
        });
        submenu.addEventListener('mouseleave', function () {
            submenu.style.display = 'none';
            myAccountButton.classList.remove("mo2f-hovered");
        });
    }
    submenu.addEventListener('mouseenter', function () {
        myAccountButton.classList.add("mo2f-hovered");
        submenu.style.display = 'block';
    });

    
});
function mo2fShowLoader(){
	jQuery("#mo2f_2fa_popup_dashboard").html("<span class=\'mo2f_loader\' id=\'mo2f_loader\'></span>");
	jQuery("#mo2f_2fa_popup_dashboard").css("display", "block");
}
function mo2fCloseLoader(){
    jQuery("#mo2f_2fa_popup_dashboard").css("display", "none");
}