function mo2f_validate_gauth(nonce, ga_secret){
    var data = {
        "action"                 : "mo_two_factor_ajax",
        "mo_2f_two_factor_ajax"  : "mo2f_validate_google_authenticator",
        "nonce"                  : nonce,	
        "otp_token"              : jQuery("#google_auth_code").val(),
        "ga_secret"              : ga_secret,
    };
    jQuery.ajax({
        url: ajaxurl,
        type: "POST",
        dataType: "json",
        data: data,
        success: function (response) {
            if (response.success) {
                success_msg(response.data);
                setTimeout(function() {
                    jQuery('#mo2f_2factor_test_prompt_cross').submit();
                }, 1000);
            } else {
                error_msg(response.data);
            }
        }
    });
}