jQuery("a[href=\"#mo2f_scanbarcode_a\"]").click(function(e){
    jQuery("#mo2f_secret_key").slideToggle();
});
jQuery(document).ready (function () {
    var serverTime = new Date(Number(gAuthValidate.server_time));
    var server_time = serverTime.toLocaleTimeString();
    document.getElementById("mo2f_server_time").innerHTML = server_time;
    jQuery('#google_auth_code').keypress(function(event) {
        if (event.which === 13) {
            event.preventDefault();
            mo2f_validate_gauth(gAuthValidate.nonce, gAuthValidate.ga_secret);
        }
    });
    jQuery("#mo2f_save_otp_ga_tour").click(function(){
        mo2f_validate_gauth(gAuthValidate.nonce, gAuthValidate.ga_secret);
    });
});

jQuery(document).ready (function () {  
    jQuery("#authenticator_type").change (function () {
        var selectedAuthenticator = jQuery(this).children("option:selected").data("apptype");
        var playStoreLink = jQuery(this).children("option:selected").data('playstorelink');
        var appStoreLink = jQuery(this).children("option:selected").data("appstorelink");
        jQuery("#links_to_apps").html("<p style='background-color:#e8e4e4;padding:5px;width:100%'>" +
            "Get the Authenticator App - <br><a href=" + playStoreLink + " target='_blank'>Android Play Store</a> &emsp;" +
            "<a href=" + appStoreLink + " target='_blank'>iOS App Store&nbsp;</p>");
        jQuery("#links_to_apps").show();
        var data = {
            "action"  : "mo_two_factor_ajax",
            "mo_2f_two_factor_ajax" : "mo2f_google_auth_set_transient",
            "auth_name"             : selectedAuthenticator,
            "micro_soft_url"        : gAuthValidate.ms_url,
            "g_auth_url"            : gAuthValidate.gu_url,
            "session_id"            : gAuthValidate.session_id,
            "nonce"                 : gAuthValidate.nonce,	
        };
        jQuery.post(ajaxurl, data, function(response) {
            if( ! response["success"] && ! is_inline ){
                error_msg("Unknown error occured. Please try again!");
            }
        });

        if( selectedAuthenticator == "msft_authenticator" ){
            jQuery("#mo2f_microsoft_auth_qr_code").css("display","block");
            jQuery("#mo2f_google_auth_qr_code").css("display","none");
        }else{
            jQuery("#mo2f_microsoft_auth_qr_code").css("display","none");
            jQuery("#mo2f_google_auth_qr_code").css("display","block");
        }
        mo2f_show_auth_methods(selectedAuthenticator);
    });

    jQuery('.mo2f_gauth').qrcode({
                    'render': 'image',
                    size: 175,
                    'text': jQuery('.mo2f_gauth').data('qrcode')
                });
    jQuery('.mo2f_gauth_microsoft').qrcode({
        'render': 'image',
        size: 175,
        'text': jQuery('.mo2f_gauth_microsoft').data('qrcode')
    });

    jQuery(this).scrollTop(0);
    jQuery("#links_to_apps").html("<p style='background-color:#e8e4e4;padding:5px;'>" +
        "Get the Authenticator App - <br><a href='https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2' target='_blank'>Android Play Store</a> &emsp;" +
        "<a href='http://itunes.apple.com/us/app/google-authenticator/id388497605' target='_blank'>iOS App Store&nbsp;</p>");
    jQuery("#mo2f_change_app_name").show();
    jQuery("#links_to_apps").show();
}); 
function mo2f_show_auth_methods( selected_method ) {
    var auth_methods = ["google_authenticator", "msft_authenticator", "authy_authenticator", "last_pass_auth", "free_otp_auth", "duo_auth" ];
    auth_methods.forEach ( function( method ) {
    if ( method == selected_method ) {
            jQuery( "#mo2f_" + method + "_instructions" ) . css( "display", "block" );
    } else {
            jQuery( "#mo2f_" + method + "_instructions" ) . css( "display", "none" );
    }
    } ); 
} 
