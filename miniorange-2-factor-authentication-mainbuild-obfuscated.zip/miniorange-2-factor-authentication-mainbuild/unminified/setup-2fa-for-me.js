jQuery('#mo_2f_generate_codes').click(function(){
    jQuery("#mo2f_2factor_generate_backup_codes").submit();
});		
jQuery('a[href="#dashboard"]').click(function() {
    jQuery("#mo2f_2fa_popup_dashboard").fadeOut();
    closeVerification = true;
});
function configureOrSet2ndFactor_free_plan(authMethod, action, cloudswitch=null,allowed=null) { 
    if(action != 'select2factor') {
        prompt_2fa_popup_dashboard( authMethod, 'setup' );
    }else{
        jQuery('#mo2f_configured_2FA_method_free_plan').val(authMethod);
        jQuery('#mo2f_selected_action_free_plan').val(action);
        jQuery('#mo2f_save_free_plan_auth_methods_form').submit();
    }
}

function testAuthenticationMethod(authMethod) {
    var requestType = 'test';
    prompt_2fa_popup_dashboard( authMethod, requestType );
}
function prompt_2fa_popup_dashboard( methodName, requesttype ) {

    jQuery("#mo2f_2fa_popup_dashboard").html('<span class="mo2f_loader" id="mo2f_loader"></span>');
    jQuery('#mo2f_2fa_popup_dashboard').css('display', 'block');
    var nonce = setup2faForMe.nonce;
    var data = {
        'action'                    : 'mo_two_factor_ajax',
        'mo_2f_two_factor_ajax'     : 'mo2f_start_setup_2fa_dashboard',
        'nonce'                     : nonce,
        'auth_method'               : methodName,
        'requesttype'               : requesttype 
    };
    jQuery.ajax({
        url: ajaxurl,
        method: 'POST',
        data: data,
        dataType: 'json',
        success: function(response) {
            console.log(response);
            if (response.success) {
                jQuery("#mo2f_2fa_popup_dashboard").html(response.data);
            } else {
                var errorMessage = response.data;
                jQuery('#mo2f_2fa_popup_dashboard').css('display', 'none');
                error_msg(errorMessage);
            }
        },
        error: function (o, e, n) {
            console.log('error' + n);
            jQuery('#mo2f_2fa_popup_dashboard').css('display', 'none');
            error_msg('An unknown error occured. Please try again.');
        },
    });
}
jQuery("#mo_2fa_my_account").addClass("side-nav-active");
jQuery("#mo2f-myaccount-setup-2fa").addClass("side-nav-active");
jQuery("#mo2f-myaccount-submenu").css("display", "block");
