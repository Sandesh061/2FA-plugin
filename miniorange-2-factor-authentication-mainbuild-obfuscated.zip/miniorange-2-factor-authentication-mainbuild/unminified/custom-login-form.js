jQuery( window ).bind(
	'load',
	function (){

				let submitSelector    = my_ajax_object.submitSelector;
				let passSelector      = my_ajax_object.passSelector;
				let emailSelector     = my_ajax_object.emailSelector;
				let passLabelSelector = my_ajax_object.passLabelSelector;
				let formSelector      = my_ajax_object.formSelector;
				let formStrings       = my_ajax_object.formStrings;

				jQuery( emailSelector ).attr( "id","mo2f_email" );
				jQuery( passSelector ).attr( "id","mo2f_pass" );
				jQuery( submitSelector ).attr( "id","mo2f_submit" );
				jQuery( formSelector ).attr( "id","mo2f_form" );
				jQuery( passLabelSelector ).attr( "id","mo2f_passLabel" );
				jQuery( '#mo2f_form' ).removeAttr( 'action' );
				jQuery( '#mo2f_form' ).removeAttr( 'method' );

				if (formSelector != '') {
					jQuery( '#mo2f_form' ).after(
						'<form name="mo2f_loginform" id="mo2f_loginform" method="post" action="" hidden >' +
						'<input type="text" name="mo2fa_login_user_name" id="mo2fa_login_user_name" hidden />' +
						'<input type="text" name="mo2fa_login_user_password" id="mo2fa_login_user_password" hidden />' +
						'<input type="hidden" name="miniorange_url_login_nonce" value="' + my_ajax_object.nonce + '"/>' +
						'<input type ="hidden" name="miniorange_url_ajax_login_nonce" value="' + my_ajax_object.ajax_nonce + '"/>' +
						'</form>'
					)
					jQuery( '#mo2f_form' ).before( '<div id="mo2f_error_message"></div>' )
				} else {
					jQuery( '#mo2f_submit' ).after(
						'<form name="mo2f_loginform" id="mo2f_loginform" method="post" action="" hidden >' +
						'<input type="text" name="mo2fa_login_user_name" id="mo2fa_login_user_name" hidden />' +
						'<input type="text" name="mo2fa_login_user_password" id="mo2fa_login_user_password" hidden />' +
						'<input type="hidden" name="miniorange_url_login_nonce" value="' + my_ajax_object.nonce + '"/>' +
						'<input type ="hidden" name="miniorange_url_ajax_login_nonce" value="' + my_ajax_object.ajax_nonce + '"/>' +
						'</form><div id="mo2f_error_message"></div>' 
		
					)
				}

				if(my_ajax_object.mo2f_remember_device==1){
					jQuery('#mo2fa_login_user_password, #mo2f_pass').after("<input type='hidden' id='miniorange_rba_attribures' name='miniorange_rba_attribures' value=''/>");
					setTimeout(
					() => {
						jQuery(document).ready(function() {
						jQuery('input[name="miniorange_rba_attribures"]').val(JSON.stringify(rbaAttributes.attributes));
						});
					}, 1000);
				}

				if (my_ajax_object.mo2f_login_option == '0') {

					if (jQuery( ".mo2f-login-container" ).length) {
						jQuery( ".mo2f-login-container" ).remove();
					}

					if (my_ajax_object.mo2f_show_loginwith_phone == '1') {

						jQuery( '#mo2f_email' ).attr( 'id','mo2fa_passwordless_username' );
						jQuery( '#mo2f_pass' ).hide();
						if (passLabelSelector != '') {
							jQuery( '#mo2f_passLabel' ).hide();
						}
						jQuery( '#mo2f_submit' ).attr( 'id','miniorange_login_submit' );

					} else {

						if (formSelector != '') {
							jQuery( '#mo2f_form' ).after(
								"<p align='center'><strong>OR</strong></p>" +
								"<p><label for='mo2fa_username'>" + formStrings['email_label'] + "</label><input type='text' id='mo2fa_passwordless_username' size='20' placeholder='Enter username or Email'/></p>" +
								"<br>" +
								"<button id='miniorange_login_submit'>" + formStrings['passwordless_login_btn'] + "</button>"
							);
						} else {
							jQuery( '#mo2f_submit' ).after(
								"<p align='center'><strong>OR</strong></p>" +
								"<p><label for='mo2fa_username'>" + formStrings['email_label'] + "</label><input type='text' id='mo2fa_passwordless_username' size='20'/></p>" +
								"<button id='miniorange_login_submit'>" + formStrings['passwordless_login_btn'] + "</button>"
							);
						}
					}
				}

				jQuery( document ).on(
					'submit',
					'#mo2f_form',
					function(e){
						e.preventDefault();
					}
				)

				jQuery( '#mo2f_pass' ).keypress(
					function (e) {
						if (e.which == 13) {// Enter key pressed

							e.preventDefault();
							mo2f_login();
						}
					}
				);
				jQuery( '#mo2f_submit' ).click(
					function(e){
						e.preventDefault();
						mo2f_login();
				
					}
				);
				jQuery( '#mo2f_email' ).keypress(
					function (e){
						if (e.which == 13) {// Enter key pressed
							e.preventDefault();
							mo2f_login();
						}
					}
				);
				jQuery( '#mo2fa_passwordless_username' ).keypress(
	
					function (e) {
						if (e.which == 13) {// Enter key pressed
							e.preventDefault();
							var username = jQuery( '#mo2fa_passwordless_username' ).val();
							document.getElementById( "mo2f_loginform" ).elements[0].value = username;
							mo2f_passwordless_form_submit( username );
						}
					}
				);

				jQuery( '#miniorange_login_submit' ).click(

					function(e){
						e.preventDefault();
						var username = jQuery( '#mo2fa_passwordless_username' ).val();
						document.getElementById( "mo2f_loginform" ).elements[0].value = username;
						mo2f_passwordless_form_submit( username );
					}
				);

				function mo2f_passwordless_form_submit(username){
					var data = {
						'action'                             : 'mo2f_custom_login_form_ajax',
						'option'                             : 'mo2f_ajax_verify_credentials_passwordless',
						'nonce'                              : my_ajax_object.ajax_nonce,
						'mo2fa_login_passwordless_username'  : username,
					};
					jQuery.post(
						my_ajax_object.ajax_url,
						data,
						function(response){
							if (response.data == 'Invalid Credentials') {
								jQuery( '#mo2f_error_message' ).show();
								jQuery( '#mo2f_error_message' ).text( formStrings['invalid_credentials'] );
							} else if(response.data == 'Session limit reached') {
							  jQuery('#mo2f_error_message').show();
							  jQuery('#mo2f_error_message').text(formStrings['session_restriction']);
							} else if (response.data == 'Two Factor not configured') {
								if (my_ajax_object.mo2f_show_loginwith_phone == '1') {
									jQuery('#miniorange_login_submit').off('click');
									jQuery('#mo2fa_passwordless_username').off('click');
									document.getElementById('mo2fa_passwordless_username').id = 'mo2f_email';
									jQuery( '#mo2f_pass' ).show();
									if (passLabelSelector != '') {
										jQuery( '#mo2f_passLabel' ).show();
									}
									document.getElementById('miniorange_login_submit').id = 'mo2f_submit';
									jQuery('#mo2f_submit').click(function(e) {
										e.preventDefault();
										mo2f_login();  // Call the login function
									});
									jQuery( '#mo2f_error_message' ).show();
									jQuery( '#mo2f_error_message' ).text( formStrings['two_factor_not_configured'] );
								} else {
									jQuery( '#mo2f_error_message' ).show();
									jQuery( '#mo2f_error_message' ).text( formStrings['two_factor_not_configured'] );

								}
							} else {
								jQuery( '#mo2f_loginform' ).submit();
							}
						}
					)

				}

				function mo2f_login(){
					var username = jQuery( '#mo2f_email' ).val();
					var password = jQuery( '#mo2f_pass' ).val();
					var data     = {
						'action'                  : 'mo2f_custom_login_form_ajax',
						'option'                  : 'mo2f_ajax_verify_credentials',
						'nonce'                   : my_ajax_object.ajax_nonce,
						'mo2fa_login_username'    : username,
						'mo2f_login_password'     : password,
					};
					jQuery.post(
						my_ajax_object.ajax_url,
						data,
						function(response){
							if (response.data == 'Invalid Credentials') {
								jQuery( '#mo2f_error_message' ).show();
								jQuery( '#mo2f_error_message' ).text( formStrings['invalid_credentials'] );
							} else if(response.data == 'Session limit reached') {
								jQuery('#mo2f_error_message').show();
								jQuery('#mo2f_error_message').text(formStrings['session_restriction']);
							} else if (response.data == 'Validated') {
								if (my_ajax_object.mo2f_remember_device == 1) {
									if (typeof jQuery( '#miniorange_rba_attribures' ).val() != 'undefined') {
										jQuery( '#miniorange_rba_attribures' ).val( JSON.stringify( rbaAttributes.attributes ) );
										var rba = jQuery( '#miniorange_rba_attribures' ).val();
									} else {
										var rba = "";
									}
									document.getElementById( "mo2f_loginform" ).elements[2].value = rba;
								}
								document.getElementById( "mo2f_loginform" ).elements[0].value = username;
								document.getElementById( "mo2f_loginform" ).elements[1].value = password;
								jQuery( '#mo2f_loginform' ).submit();
							} else {
								jQuery( '#mo2f_error_message' ).show();
								jQuery( '#mo2f_error_message' ).text( formStrings['invalid_request'] );
							}
						}
					);

				}

			

	}
)
