const activeTab = localStorage.getItem('activeTab') || 'mo2f_login_btn';
function switchTab(tabId) {
	localStorage.setItem('activeTab', tabId);
	const loginSettings = jQuery('#mo2f_login_form_settings');
	const registrationSettings = jQuery('#mo2f_registration_form_settings');
	const loginButton = jQuery('#mo2f_login_btn');
	const registerButton = jQuery('#mo2f_register_button');

	if (tabId === 'mo2f_login_btn') {
		loginSettings.removeClass('hidden');
		registrationSettings.addClass('hidden');
		loginButton.addClass('mo2f-active');
		registerButton.removeClass('mo2f-active');
	} else {
		loginSettings.addClass('hidden');
		registrationSettings.removeClass('hidden');
		loginButton.removeClass('mo2f-active');
		registerButton.addClass('mo2f-active');
	}
}
function validate_selector(selector){
	let is_valid = false
	if(/^#/.test(selector))
		is_valid = true
	if(/^\./.test(selector))
		is_valid = true
	if(/^input\[name=/.test(selector))
		is_valid = true

	return is_valid;
}
function registerwithminiOrange(){
	jQuery('#my_account_2fa').click();
}
jQuery(document).ready(function () {
	const activeTab = localStorage.getItem('activeTab') || 'mo2f_login_btn';
	switchTab(activeTab);

	jQuery('#mo2f_login_btn').click(function() {
		switchTab('mo2f_login_btn');
	});

	jQuery('#mo2f_register_button').click(function() {
		switchTab('mo2f_register_button');
	});
	function toggleFields() {
		if ($('#mo2f_method_email').is(':checked')) {
			$('#mo2fa_emailDiv').show();
			$('#mo2fa_phoneDiv').hide();
		} else if ($('#mo2f_method_phone').is(':checked')) {
			$('#mo2fa_phoneDiv').show();
			$('#mo2fa_emailDiv').hide();
		}
	}
	toggleFields();
	$('input[name="mo2f_auth_method"]').on('change', function() {
		toggleFields();
	});
	let $mo = jQuery;
	let formArray = forms.formArray;
	let customForm = false;
	is_registered   = forms.isRegistered;

	
	let checked = $mo('#mo2f_method_phone').is(':checked')
		if(checked)
		{
			$mo('#mo2fa_phoneDiv').css('display','inherit');
			$mo('#mo2fa_emailDiv').css('display','none');
		}
		else
		{
			$mo('#mo2fa_phoneDiv').css('display','none');
			$mo('#mo2fa_emailDiv').css('display','inherit');
		}

	if(!is_registered)
	{
		$mo('#mo2fa_use_shortcode_config').prop('checked',false)
		$mo('#mo2fa_use_shortcode_config').prop('disabled',true)
	}

	jQuery("#regFormList").change(function() {

	let index = $mo("#regFormList").prop('selectedIndex');
	let count = $mo('#regFormList option').length-1;

	if(index>count) {
	$mo('#mo2fa_selector_div').css('display','none');
	} else {
	$mo('#mo2f_shortcode_email_selector').prop('disabled', false);
	$mo('#mo2f_shortcode_form_selector').prop('disabled', false);
	$mo('#mo2f_shortcode_phone_selector').prop('disabled', false);
	$mo('#mo2f_shortcode_submit_selector').prop('disabled', false);

	$mo('#mo2fa_selector_div').css('display', 'inherit');
	}

	$mo('#mo2f_shortcode_form_selector').val(formArray[index]["formSelector"]);
	$mo('#mo2f_shortcode_submit_selector').val(formArray[index]["submitSelector"]);
	$mo('#mo2f_shortcode_email_selector').val(formArray[index]["emailSelector"]);
	$mo('#mo2f_shortcode_phone_selector').val('');


	if ($('#mo2f_method_phone').is(':checked')) {
		$mo('#mo2fa_phoneDiv').css('display','inherit');
		$mo('#mo2f_shortcode_phone_selector').attr('placeholder', 'example #phone_field_id');
	}

	});
	$mo('#mo2f_form_config_save').click(function (e) {
		e.preventDefault();
		if(!is_registered)
			error_msg("Please Register/Login with miniOrange");
		else
		{
			let sms,email,authType,enableShortcode,formSubmit;
			formSubmit      = $mo('#mo2f_form_submit_after_validation').is(':checked');
			enableShortcode = $mo('#mo2fa_use_shortcode_config').is(':checked');
			sms             = $mo('#mo2f_method_phone').is(':checked');
			email           = $mo('#mo2f_method_email').is(':checked');
			email_selector  = $mo('#mo2f_shortcode_email_selector').val();
			phone_selector  = $mo('#mo2f_shortcode_phone_selector').val();
			form_selector   = $mo('#mo2f_shortcode_form_selector').val();
			submit_selector = $mo('#mo2f_shortcode_submit_selector').val();
			reg_form_name   = $mo('#regFormList').val();
			authType = (email === true) ? forms.authTypeEmail : forms.authTypePhone;
			error = "";
			if (authType === forms.authTypeEmail) {
				if (email_selector === '') {
					error = "Add email selector to use OTP Over Email";
				}
				else if(!validate_selector(email_selector) || !validate_selector(form_selector) || !validate_selector(submit_selector)){
					error = "ERROR: Invalid Selector(s) detected.";
				}
			}
			else if (authType === forms.authTypePhone) {
				if (phone_selector === '') {
					error = "Add phone selector to use Phone Verification";
				}
				else if(!validate_selector(phone_selector) || !validate_selector(form_selector) || !validate_selector(submit_selector)){
					error = "ERROR: Invalid Selector(s) detected.";
				}
			}
			if(error != ""){
				error_msg(error);
			}
			else{
				mo2fShowLoader();
				let data =  {
					'action'                        : 'mo2f_login_settings_ajax',
					'option'                        : 'mo2f_save_custom_registration_form_settings',
					'nonce'                         :  forms.nonce,
					'submit_selector'               :  submit_selector,
					'form_selector'                 :  form_selector,
					'email_selector'                :  email_selector,
					'phone_selector'                :  phone_selector,
					'authType'                      :  authType,
					'customForm'                    :  customForm,
					'formSubmit'                    :  formSubmit,
					'enableShortcode'               :  enableShortcode,
					'regFormList'                   :  reg_form_name,
				};
				jQuery.post(ajaxurl, data, function(response) {
					mo2fCloseLoader();
					if(response.success)
					{
						success_msg(response.data);
					} else{
						error_msg(response.data);
					}
				});
			}
		}
	});
	jQuery("#mo2fa_use_shortcode_config").click(function(){
		var data = {
				'action': 'mo2f_login_settings_ajax',
				'option': 'mo2f_custom_registration_form',
				'nonce': forms.nonce,
				'mo2f_enable_shortcodes': jQuery("#mo2fa_use_shortcode_config").is(":checked"),
		};
		jQuery.post(ajaxurl, data, function (response) {
			if (response.success) {
				success_msg(response.data);
			} else {
				error_msg(response.data);
			}
		});

	});
});
jQuery(document).ready(function ($) {
	jQuery('#mo2f_custom_login_form_config_save').click(function () {
		let url, email, pass, submit,enableshortcode,error,form;
		url = jQuery('#mo2f_login_url_selector').val();
		email = jQuery('#mo2f_login_email_selector').val();
		pass  = jQuery('#mo2f_login_password_selector').val();
		passLabel = jQuery('#mo2f_login_password_label').val();
		submit  = jQuery('#mo2f_login_submit_selector').val();
		form = jQuery('#mo2f_login_form_selector').val();
		error="";
		if(email === '' || pass === '' || submit === '' || url === '') {
			error = "Please enter all field selectors."
		}
		if( !validate_url(url) && url !=''){
			error = "Please enter correct login form url."
		}
		if(!validate_selector(email) || !validate_selector(pass) || !validate_selector(submit) || (form != '' && !validate_selector(form)) || (passLabel!='' && !validate_selector(passLabel))) {
			error = "NOTE: Choosing your Selector: Element\'s ID Selector looks like #element_id and Element\'s name Selector looks like input[name=element_name]"
		}
		if(error !='')
		{
			error_msg(error);
		}
		else
		{  	mo2fShowLoader();
            let data = {
                'action'                              : 'mo2f_login_settings_ajax',
                'option'                              : 'mo2f_save_login_form_settings',
                'nonce'                               :  forms.nonce,
                'submit_selector'                     :  submit,
                'email_selector'                      :  email,
                'pass_selector'                       :  pass,
                'url'                                 :  url,
                'form_selector'                       :  form, 
                'passlabelSelector'                  :  passLabel

            };
            jQuery.post(ajaxurl, data, function(response) {
				mo2fCloseLoader();
                if(response.success)
                { 
                    success_msg(response.data);
                }
                else
                { 
                    error_msg(response.data);
                }
            });
        }
    });
	jQuery("#mo2f_enable_login_form").click(function(){
		var data = {
				'action': 'mo2f_login_settings_ajax',
				'option': 'mo2f_enable_disable_login_form',
				'nonce': forms.nonce,
				'login_form_enabled': jQuery("#mo2f_enable_login_form").is(":checked"),
		};
		jQuery.post(ajaxurl, data, function (response) {
			if (response.success) {
				success_msg(response.data);
			} else {
				error_msg(response.data);
			}
		});

	});
});
function validate_url(url){
	var pattern = new RegExp('^(https?:\\/\\/)?' + // protocol
			'((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // domain name
			'((\\d{1,3}\\.){3}\\d{1,3}))' + // OR ip (v4) address
			'(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
			'(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
			'(\\#[-a-z\\d_]*)?$', 'i'); // fragment locator

	if(url.includes(','))
	{
		let multipleurls = url.split(',');
		multipleurls.forEach((url, index, urlarr)=>{
			if(pattern.test(url))
				urlarr[index]='true';
			else
				urlarr[index]='false';
		})
		if(multipleurls.includes('false'))
		{
			return false;
		}
		return true;
	}
	else{
	if(pattern.test(url))
		return true;
	return false;
	}
}
function mo2fShowLoader(){
	jQuery("#mo2f_2fa_popup_dashboard").html("<span class=\'mo2f_loader\' id=\'mo2f_loader\'></span>");
	jQuery("#mo2f_2fa_popup_dashboard").css("display", "block");
}
function mo2fCloseLoader(){
    jQuery("#mo2f_2fa_popup_dashboard").css("display", "none");
}