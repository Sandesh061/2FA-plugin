setTimeout(function(){
	jQuery(document).ready(function () {
		let $mo = jQuery;
		let ajaxurl = otpverificationObj.siteURL;
		let nonce = otpverificationObj.nonce;
		let submitSelector = otpverificationObj.submitSelector;
		let formSubmit = otpverificationObj.formSubmit;
		let formName = otpverificationObj.formname;
		let emailSelector = otpverificationObj.emailselector;
		let phoneSelector = otpverificationObj.phoneSelector;
		let notificationSelector = otpverificationObj.notificationSelector;
		let successClass = otpverificationObj.successClass;
		let errorClass = otpverificationObj.errorClass;
		let txId = "";
		let txIdNew = "";
		let isValidated = false;
		let isSecond = false;
		let authType = otpverificationObj.authType;
		let isShortEnabled = otpverificationObj.isEnabledShortcode;
		let isRegistered = otpverificationObj.isRegistered;
		const messageTextMobile =
			'<p id="otpphonemessage">' + otpverificationStringsObj.otp_sent_phone + "</p>";
		const messageTextEmail =
			'<p id="otpemailmessage">' + otpverificationStringsObj.otp_sent_email + "</p>";
		function createInputField(name, id, placeholder, displayStyle = 'display:none;', additionalClass = '') {
			return '<input type="text" ' +
				`name="${name}" ` +
				`id="${id}" ` +
				`placeholder="${placeholder}" ` +
				`class="${additionalClass}" ` +
				`style="${displayStyle}">`;
		}
		function createButton(buttonId, buttonText, timerId, buttonStyle = '', additionalClass = '', timerStyle = 'display:none;margin-top:1em') {
			return '<button type="button" class="button ' + additionalClass + '" ' +
				`id="${buttonId}" style="${buttonStyle}">` +
				buttonText + "</button> " +
				`<div class="button" id="${timerId}" style="${timerStyle}">00</div>`;
		}
		function createValidationButton(buttonId, buttonText, displayStyle = 'display:none;margin-top:1em', additionalClass = '') {
			return '<button type="button" class="button ' + additionalClass + '" ' +
				`id="${buttonId}" ` +
				`style="${displayStyle}">` +
				buttonText + "</button><br>";
		}
		var otpphoneEdit = createInputField('edit_phone_otp', 'mo2f_edit_phone_otp', 'Enter OTP');
		var otpemailEdit = createInputField('edit_email_otp', 'mo2f_edit_email_otp', 'Enter OTP');
		var sendphonebutton = createButton('mo2f_otp_send_phone_button', otpverificationStringsObj.send_otp, 'timer_phone');
		var sendemailbutton = createButton('mo2f_otp_send_email_button', otpverificationStringsObj.send_otp, 'timer_email');
		var validatephoneButton = createValidationButton('mo2f_validate_phone_otp', otpverificationStringsObj.validate_otp);
		var validateemailButton = createValidationButton('mo2f_validate_email_otp', otpverificationStringsObj.validate_otp);
		if (formName === '.woocommerce-form-register') {
			sendphonebutton = createButton('mo2f_otp_send_phone_button', otpverificationStringsObj.send_otp, 'timer_phone', '', 'woocommerce-Button woocommerce-button button wp-element-button', 'display:none;margin-top:1em');
			sendemailbutton = createButton('mo2f_otp_send_email_button', otpverificationStringsObj.send_otp, 'timer_email', '', 'woocommerce-Button woocommerce-button button wp-element-button', 'display:none;margin-top:1em');
			validatephoneButton = createValidationButton('mo2f_validate_phone_otp', otpverificationStringsObj.validate_otp, 'display:none;margin-top:1em', 'woocommerce-Button woocommerce-button button wp-element-button');
			validateemailButton = createValidationButton('mo2f_validate_email_otp', otpverificationStringsObj.validate_otp, 'display:none;margin-top:1em', 'woocommerce-Button woocommerce-button button wp-element-button');
			otpphoneEdit = createInputField('edit_phone_otp', 'mo2f_edit_phone_otp', 'Enter OTP', 'display:none;', 'woocommerce-Input woocommerce-Input--text input-text');
			otpemailEdit = createInputField('edit_email_otp', 'mo2f_edit_email_otp', 'Enter OTP', 'display:none;', 'woocommerce-Input woocommerce-Input--text input-text');
		}
		if (formName !== "#registerform" && formName !== ".woocommerce-form-register" && formName !== ".bbp-login-form" && formName !== ".register") {
			otpphoneEdit = createInputField('edit_phone_otp', 'mo2f_edit_phone_otp', 'Enter OTP', 'display:none; padding: 10px; font-size: 14px; width: 100%; border: 1px solid #ccc; border-radius: 4px; margin-top: 10px;', '');
			otpemailEdit = createInputField('edit_email_otp', 'mo2f_edit_email_otp', 'Enter OTP', 'display:none; padding: 10px; font-size: 14px; width: 100%; border: 1px solid #ccc; border-radius: 4px; margin-top: 10px;', '');
			sendphonebutton = createButton('mo2f_otp_send_phone_button', otpverificationStringsObj.send_otp, 'timer_email', 'padding: 10px 20px; background-color: #0073aa; color: white; border: none; border-radius: 4px; margin-top: 10px;', '', 'display:none; margin-top:10px; padding: 10px 20px; background-color: #ccc; color: white;');
			sendemailbutton = createButton('mo2f_otp_send_email_button', otpverificationStringsObj.send_otp, 'timer_email', 'padding: 10px 20px; background-color: #0073aa; color: white; border: none; border-radius: 4px; margin-top: 10px;', '', 'display:none; margin-top:10px; padding: 10px 20px; background-color: #ccc; color: white;');
			validatephoneButton = createValidationButton('mo2f_validate_phone_otp', otpverificationStringsObj.validate_otp, 'padding: 10px 20px; background-color: #28a745; color: white; border: none; border-radius: 4px; margin-top: 10px; display:none;', '');
			validateemailButton = createValidationButton('mo2f_validate_email_otp', otpverificationStringsObj.validate_otp, 'padding: 10px 20px; background-color: #28a745; color: white; border: none; border-radius: 4px; margin-top: 10px; display:none;', '');
		}	
		const style = document.createElement("style");
		style.innerHTML = `
				  .mo2f_red {
					color:red;
				  }
				  .mo2f_green {
					color:green;
				  }
				`;
	
		document.head.appendChild(style);
		
		if (isRegistered === "false") {
			const messageNotRegistered =
				'<p id="registermessage" style="color: red;font-size: 18px;border: red 1px solid;padding: 5px" > ' +
				otpverificationStringsObj.account_register +
				"</p>";
			jQuery(emailSelector).after("<br>" + messageNotRegistered);
		} else if (
			($mo(formName).length || $mo(submitSelector).length) &&
			isRegistered !== false &&
			isShortEnabled !== "0"
		) {
			function mo2f_setMessage(message_key, color, authType) {
				setMessage(otpverificationStringsObj[message_key], color, authType);
			}
			function setMessage(message, color, authType) {
				notificationSelector = authType.toUpperCase() == 'EMAIL' ? '#otpemailmessage' : '#otpphonemessage';
				var offset = $mo(notificationSelector).offset();
				$mo(notificationSelector).text("");
				if (color == "red") {
					$mo(notificationSelector)
						.text(message)
						.removeClass(successClass)
						.css("display", "block")
						.addClass(errorClass);
					window.location.href = notificationSelector;
					if(offset?.top != 0){
						window.scroll({
							top: offset?.top-screen.height*0.25,
							behavior: 'smooth'
						  });
					}
				} else {
					$mo(notificationSelector)
						.text(message)
						.css("display", "block")
						.removeClass(errorClass)
						.addClass(successClass);
				}
			}
			function sendChallenge(authType, phone, email, nonce, ajaxurl) {
				txId = "";
				let timeLeft = 0;
				let timerId;
				let data = {
					action: "mo_shortcode",
					mo_action: "challenge",
					email: email,
					phone: phone,
					nonce: nonce,
					authTypeSend: authType,
				};
				if(authType == 'EMAIL')
				{
						$mo("#mo2f_otp_send_email_button").text(otpverificationStringsObj.sending_otp);
				}
				else
				{
						$mo("#mo2f_otp_send_phone_button").text(otpverificationStringsObj.sending_otp);
				}
				$mo.post(ajaxurl, data, function (response) {
					if (response === null) {
						mo2f_setMessage("contact_admin", "red", authType);
					} else {
						switch (response.status) {
							case "SUCCESS":
								if(authType == 'EMAIL') {
									$mo("#mo2f_edit_email_otp").css("display", "block");
									$mo("#mo2f_validate_email_otp").css("display", "block");								
								}
								else {
									$mo("#mo2f_edit_phone_otp").css("display", "block");
									$mo("#mo2f_validate_phone_otp").css("display", "block");		
								}

								setMessage(response.message, "green", authType);
	
								txId = response.txId;
								if (isSecond) {
									clearInterval(timerId);
								} else {
									timeLeft = 30;
								}
								$mo("#mo2f_validate_phone_otp").click(function (e) {
									e.preventDefault();
									otp = $mo("#mo2f_edit_phone_otp").val();
									validateOTP(otp, nonce, phone, txId, email, authType);
								});
								$mo("#mo2f_validate_email_otp").click(function (e) {
									
									e.preventDefault();
									otp = $mo("#mo2f_edit_email_otp").val();
									validateOTP(otp, nonce, phone, txId, email, authType);
								});
								timerId = setInterval(countdown, 1000);
	
								function countdown() {
									if (timeLeft === 0) {
										clearTimeout(timerId);
										if(authType == 'EMAIL')
										{
											$mo("#mo2f_otp_send_email_button").css("display", "block");
											$mo("#timer_email").css("display", "none");
											$mo("#mo2f_otp_send_email_button").text(
												otpverificationStringsObj.resend_otp
											);
											$mo("#mo2f_otp_send_email_button").css('margin-top', '10px');
										}
										else {
											$mo("#mo2f_otp_send_phone_button").css("display", "block");
											$mo("#timer_phone").css("display", "none");
											$mo("#mo2f_otp_send_phone_button").text(
												otpverificationStringsObj.resend_otp
											);
											$mo("#mo2f_otp_send_phone_button").css('margin-top', '10px');
										}

									} else {
										if(authType == 'EMAIL')
										{
											$mo("#mo2f_otp_send_email_button").css("display", "none");
											$mo("#timer_email").css("display", "block");
											$mo("#timer_email").text(timeLeft);
										}
										else
										{
											$mo("#mo2f_otp_send_phone_button").css("display", "none");
											$mo("#timer_phone").css("display", "block");
											$mo("#timer_phone").text(timeLeft);
										}
										timeLeft--;
									}
								}
								break;
								case "FAILED":
								case "ERROR":
									if(authType == 'EMAIL')
									{
										$mo("#mo2f_otp_send_email_button").text(otpverificationStringsObj.send_otp);
									}
									else
									{
										$mo("#mo2f_otp_send_phone_button").text(otpverificationStringsObj.send_otp);
									}
									setMessage(response.message, "red", authType);
									break;
							}
						}
					});
				}
				function validateOTP(otp, nonce, phone, txId, email, authType) {
				let data = {
					action: "mo_shortcode",
					mo_action: "validate",
					otp: otp,
					nonce: nonce,
					mobile: phone,
					txId: txId,
					email: email,
					authType: authType,
				};
				if ( ! isValidated ) {
					$mo.post(ajaxurl, data, function (response) {
						if (response === null) {
							mo2f_setMessage("validation_error", "red", authType);
							isValidated = false;
						} else
							switch (response.status) {
								case "SUCCESS":
									setMessage(response.message, "green", authType);
									isValidated = true;
									if (submitSelector === ".ur-submit-button") {
										setTimeout(function () {
											location.reload();
										}, 1000);
									}
									if(formSubmit == 'true'){
										$mo(submitSelector).unbind("click").click();
									}else{
										$mo(submitSelector).unbind("click"); 
									}
									return true;
								case "FAILED":
									setMessage(response.message, "red", authType);
									$mo(submitSelector).removeAttr("disabled");
									return false;
								case "ERROR":
									setMessage(response.message, "red", authType);
									$mo(submitSelector).removeAttr("disabled");
									return false;
							}
					});
				} else {
				}
			}

			let phone, email, otp;
			switch (authType) {
				case "SMS":
					if ( !$mo(phoneSelector).length ) {
						const messageNotRegistered =
							'<p id="phoneFieldLabel" style="color: red;font-size: 18px;border: red 1px solid;padding: 5px" >' +
							otpverificationStringsObj.phone_field_not_found +
							"</p>";
						$mo(emailSelector).after("<br>" + messageNotRegistered);
						return;
					}
					$mo(phoneSelector).css('padding-left','50px');
					$mo(phoneSelector).after(
						messageTextMobile + otpphoneEdit + sendphonebutton + validatephoneButton
					);
					$mo(phoneSelector).intlTelInput({});
					$mo("#mo2f_otp_send_phone_button").click(function () {
						phone = $mo(phoneSelector).val();
						phone = phone.replace(/\s+/g, "");
						email = $mo(emailSelector).val();
						if (!validatePhone(phone)) {
							mo2f_setMessage("invalid_phone", "red", 'phone');
							return;
						}
						isSecond = false;
						sendChallenge(authType,phone,null,nonce,ajaxurl)
					});
	
					$mo(submitSelector).click(function (e) {
						e.preventDefault();
						if (isValidated === false) {
							otp = $mo("#mo2f_edit_phone_otp").val();
							if (!otp) {
								mo2f_setMessage("validate_phone", "red", 'phone');
							} else { 
								validateOTP(otp, nonce, phone, txId, email,authType);
							}
						} else {
						}
					});
	
					break;
	
				case "EMAIL":
					if ($mo("#reg_passmail").length) {
						$mo("#reg_passmail").css("visibility", "hidden");
						$mo(".clear").remove();
					}
					let a = $mo(emailSelector).attr("class");
					$mo("#mo2f_edit_email_otp").addClass(a);
	
					let b = $mo(submitSelector).attr("class");
					$mo("#mo2f_otp_send_email_button").attr("class", b);
	
					if (!$mo(emailSelector).length) {
						const messageNotRegistered =
							'<p id="emailFieldLabel" style="color: red;font-size: 18px;border: red 1px solid;padding: 5px" > ' +
							otpverificationStringsObj.email_field +
							emailSelector +
							otpverificationStringsObj.not_found +
							"</p>";
						if ($mo(formName).length)
							$mo(formName).after("<br>" + messageNotRegistered);
						else if ($mo(submitSelector).length)
							$mo(submitSelector).after("<br>" + messageNotRegistered);
						return;
					}
	
					$mo(emailSelector).after(
						messageTextEmail + otpemailEdit + sendemailbutton + validateemailButton
					);
	
					$mo("#mo2f_otp_send_email_button").click(function () {
						email = $mo(emailSelector).val();
						if (!validateEmail(email)) {
							mo2f_setMessage("invalid_email", "red", 'email');
							return;
						}
						isSecond = false;
						sendChallenge(authType,null,email,nonce,ajaxurl)
					});
	
					$mo(submitSelector).click(function (e) {
						e.preventDefault();
						if (isValidated === false) {
							otp = $mo("#mo2f_edit_email_otp").val();
							if (!otp) {
								mo2f_setMessage("validate_email", "red", 'email');
							} else {
								validateOTP(otp, nonce, phone, txId, email, 'EMAIL');
							}
						} else {
						}
					});
	
					break;
			}
	
			function validateEmail(email_address) {
				let email_regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i;
				if (!email_regex.test(email_address)) {
					return false;
				}
				return true;
			}
			function validatePhone(phone) {
				let intRegex = /[0-9 -()+]+$/;
				if (phone.length < 10 || phone.length == 0 || !intRegex.test(phone)) {
					return false;
				}
				return true;
			}
		} else {
			
		}
	});
	},1000);