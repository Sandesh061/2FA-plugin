
jQuery(document).ready(function ($) {
	jQuery(function () {
		jQuery("#mo2f_grace_hour").click(function () {
			jQuery("#mo2f_grace_period").focus();
		});
		jQuery("#mo2f_grace_day").click(function () {
			jQuery("#mo2f_grace_period").focus();
		});
	});
});
var nonce = loginSettings.nonce;
jQuery('#mo2f_enable2FA_save_button').click(function () {
	mo2fShowLoader();
	var saveButtonId = jQuery(this).attr('id');
	var enabledrole = [];
	$.each(jQuery("input[name='role']:checked"), function () {
		enabledrole.push($(this).val());
	});
	var eneble2FA = jQuery("#mo2f_enable2FA").is(":checked");
	var data = {
		'action': 'mo2f_login_settings_ajax',
		'option': 'mo2f_enable2FA_save_option',
		'nonce': nonce,
		'mo2f_enable_2fa_settings': eneble2FA,
		'enabledrole': enabledrole,
		'mo2f_graceperiod_value': jQuery('#mo2f_grace_period').val(),
		'mo2f_graceperiod_type': jQuery('input[name="mo2f_graceperiod_type"]:checked').val(),
		'mo2f_graceperiod_action': jQuery('input[name="mo2f_grace_period_action"]:checked').val(),
	};
	handleAjaxrequest(ajaxurl, data, saveButtonId);
});
jQuery('#mo2f_enable_graceperiod_save').click(function () {
	mo2fShowLoader();
	var saveButtonId = jQuery(this).attr('id');
	var eneblegraceperiod = jQuery("#mo2f_enable_graceperiod").is(":checked");
	var data = {
		'action': 'mo2f_login_settings_ajax',
		'option': 'mo2f_graceperiod_save_option',
		'nonce': nonce,
		'mo2f_enable_graceperiod_settings': eneblegraceperiod,
		'mo2f_graceperiod_value': jQuery('#mo2f_grace_period').val(),
		'mo2f_graceperiod_type': jQuery('input[name="mo2f_graceperiod_type"]:checked').val(),
		'mo2f_graceperiod_action': jQuery('input[name="mo2f_grace_period_action"]:checked').val(),
	};
	handleAjaxrequest(ajaxurl, data, saveButtonId);
});

function mo2f_showSettings(element) {
	if (jQuery(element).is(":checked")) {
		jQuery("#" + element.id + "_settings").slideDown();
		jQuery("#" + element.id + "_settings").css("display", "flex");
		jQuery("#" + element.id + "_save").css("display", "flex");
		jQuery("#" + element.id + "_save").show();
	} else {
        var singleSettingCheckboxIds = ["mo2f_disable_inline_2fa", "mo2f_mfa_login", "mo2f_enable_shortcodes"];
        if (element.id!='mo2f_enable2FA' && ! singleSettingCheckboxIds.includes(element.id)){
            jQuery("#" + element.id + "_settings").slideUp();
            jQuery("#" + element.id + "_save").css("display", "none");
            var data = {
                'action': 'mo2f_login_settings_ajax',
                'option': element.id + '_disable',
                'nonce': nonce,
            };
            handleAjaxrequest(ajaxurl, data, element.id);
            
        }
	
	}
}

jQuery(document).on('click', '.mo2f-add-row', function() {
	let currentRow = jQuery(this).closest('tr');
	let clonedRow = currentRow.clone();
	clonedRow.find('input').val('');
	clonedRow.find('select').prop('selectedIndex', 0);
	currentRow.after(clonedRow);
});
jQuery(document).on('click', '.mo2f-remove-row', function() {
	let currentRow = $(this).closest('tr'); // Get the current row
	let rowCount = jQuery('#mo2f_custom_redirect_url_table tr').length;
	if (rowCount > 2) {
		currentRow.remove(); 
	} else {
		error_msg('This row can not be removed.');
	}
});


jQuery('#mo2f_add_custom_redirect_url').click( function () {
	var $lastRow = jQuery('#mo2f_custom_redirect_url_table tr:last');
	var $newRow = $lastRow.clone();
	$newRow.find('#mo2f_add_custom_redirect_url').remove();
	$lastRow.after($newRow);
});

jQuery('#mo2f_enable_custom_redirect_save_button').click(function () {
	mo2fShowLoader();
	var saveButtonId = jQuery(this).attr('id');
	var enableCustomRedirect = jQuery("#mo2f_enable_custom_redirect").is(":checked");
	const roles = document.querySelectorAll('.mo2f_custom_redirections_roles');
	const urls = document.querySelectorAll('.mo2f_custom_redirections_urls');
	const customRedirectionRoles = [];
	const customRedirectionUrls = [];
	roles.forEach(function (roleDiv) {
		const userRole = roleDiv.querySelector('.mo2f_redirect_url_roles').value;
		customRedirectionRoles.push(userRole);
	});
	urls.forEach(function (roleDiv) {
		const redirectUrl = roleDiv.querySelector('.mo2f_redirection_url').value;
		customRedirectionUrls.push(redirectUrl);
	});
	const customRolesUrls = customRedirectionRoles.map((key, index) => ({ [key]: customRedirectionUrls[index] }));
	var data = {
		'action': 'mo2f_login_settings_ajax',
		'option': 'mo2f_enable_custom_redirect_option',
		'nonce': nonce,
		'mo2f_enable_custom_redirect': enableCustomRedirect,
		'mo2f_redirect_url_for_users': jQuery("input[name=\"mo2f_redirect_url_for_users\"]:checked").val(),
		'mo2f_custom_redirect_url': jQuery("#redirect_url_all").val(),
		'mo2f_custom_roles_and_urls': customRolesUrls,

	};
	handleAjaxrequest(ajaxurl, data, saveButtonId);
});

jQuery("input[type=\"checkbox\"]").click(function () {
	var checkboxId = jQuery(this).attr('id');
    var checkboxName = jQuery(this).attr('name');
	var singleSettingCheckboxIds = ["mo2f_disable_inline_2fa", "mo2f_mfa_login", "mo2f_enable_shortcodes"];
	if (singleSettingCheckboxIds.includes(checkboxId)) {
		var data = {
			'action': 'mo2f_login_settings_ajax',
			'option': checkboxId + '_option',
			'nonce': nonce,
			[checkboxId]: jQuery("#" + checkboxId).is(":checked"),
		};
		handleAjaxrequest(ajaxurl, data, checkboxId);
	}
    if(checkboxName == 'role'){
        if( jQuery("input[name=\"role\"]").is(":checked") ){
            document.getElementById('mo2f_enable2FA').checked = true;
        }    
    }
});

jQuery('#mo2f_enable_backup_methods_save_button').click(function () {
	mo2fShowLoader();
	var saveButtonId = jQuery(this).attr('id');
	var enabledBackupMethods = [];
	$.each(jQuery("input[name='mo2f_enabled_backup_method']:checked"), function () {
		enabledBackupMethods.push($(this).val());
	});
	var enableBackupLogin = jQuery("#mo2f_enable_backup_methods").is(":checked");
	var data = {
		'action': 'mo2f_login_settings_ajax',
		'option': 'mo2f_enable_backup_methods',
		'nonce': nonce,
		'mo2f_enable_backup_login': enableBackupLogin,
		'mo2f_enabled_backup_methods': enabledBackupMethods,
	};
	handleAjaxrequest(ajaxurl, data, saveButtonId);
});

function handleAjaxrequest(ajaxurl, data, saveButtonId) {
	jQuery.post(ajaxurl, data, function (response) {
		jQuery("#mo2f_2fa_popup_dashboard").css("display", "none");
		if (response['success']) {
			success_msg(response.data);
		} else {
			error_msg(response.data);
		}
	});
}

function success_msg(msg) {
    jQuery("#wpns_nav_message").empty();
    jQuery("#wpns_nav_message").append(
        "<div id='notice_div' class='overlay_success' style='z-index:9999'><div class='popup_text'>" +
            msg +
            "</div></div>"
    );
    window.onload = nav_popup();
}

function error_msg(msg) {
	jQuery("#wpns_nav_message").empty();
	jQuery("#wpns_nav_message").append(
		"<div id='notice_div' class='overlay_error'><div class='popup_text'>" +
			msg +
			"</div></div>"
	);
	window.onload = nav_popup();
}
jQuery('#mo2f_selected_2fa_methods_save').click(function () {
	var saveButtonId = jQuery(this).attr('id');
	var selectMethods = jQuery("#mo2f_select_methods_for_users").is(":checked");
	var selectedType  = jQuery('input[name="mo2f_methods_for_users"]:checked').val();
	var data = {
		'action': 'mo2f_login_settings_ajax',
		'option': 'mo2f_save_selected_2fa_methods',
		'nonce': nonce,
		'user_roles': {},
		'twofa_methods': [],
		'select_methods': selectMethods,
		'selection_type': selectedType,
	};
	jQuery('input[name="mo2f_methods[]"]:checked').each(function() {
		data.twofa_methods.push(jQuery(this).val());
	});
    var hasError = false; // Flag to track if there's an error
    jQuery('input[name="mo2f_user_role[]"]:checked').each(function() {
        var role = jQuery(this).val();
        data.user_roles[role] = [];
        jQuery('[data-role="' + role + '"] input:checked').each(function() {
            data.user_roles[role].push(jQuery(this).val());
        });
        if (data.user_roles[role].length < 1 && selectedType !== "0" ) {
            error_msg('Please select at least one 2FA method for ' + role + ' user role.');
            hasError = true; // Set the error flag
            return false; // Break the loop for the current role
        }
    });
    if (hasError) {
        return false; // Stop further execution if there's an error
    }
	mo2fShowLoader();
	handleAjaxrequest(ajaxurl, data, saveButtonId);
});

function mo2f_show_specific_twofa_settings(element) {
	if (jQuery(element).is(":checked")) {
		jQuery("#" + element.id + "_settings").slideDown();
		jQuery("#" + element.id + "_settings").css("display", "flex");
		jQuery("#" + element.id + "_save").css("display", "flex");
	} else {
		jQuery("#" + element.id + "_settings").slideUp();
		jQuery("#" + element.id + "_save").css("display", "none");
		jQuery("#" + element.id + "_settings").css("display", "none");
	
	}
}
jQuery('#2fa_methods_for_roles').click(function () {
	jQuery("#mo2f_all_2fa_methods_div").css("display", "none");
	jQuery("#mo2f_2fa_methods_for_roles_div").css("display", "flex");
});
jQuery('#2fa_methods_for_all').click(function () {
	jQuery("#mo2f_2fa_methods_for_roles_div").css("display", "none");
	jQuery("#mo2f_all_2fa_methods_div").css("display", "flex");
});
function selectAllRoles(checkbox) {
	const roleCheckboxes = document.querySelectorAll('#mo2f_role_checkbox');
	roleCheckboxes.forEach(function(roleCheckbox) {
		roleCheckbox.checked = checkbox.checked;
	});
	if (checkbox.checked) {
		document.getElementById('mo2f_enable2FA').checked = true;
	} else {
		document.getElementById('mo2f_enable2FA').checked = false;
	}
}
function updateSelectAll(roleCheckbox) {
	const allChecked = [...document.querySelectorAll('#mo2f_role_checkbox')].every(function(checkbox) {
		return checkbox.checked;
	});
	
	document.getElementById('mo2f_select_all_roles').checked = allChecked;
	if (!roleCheckbox.checked) {
		document.getElementById('mo2f_select_all_roles').checked = false;
	}
	const anyChecked = [...document.querySelectorAll('#mo2f_role_checkbox')].some(function(checkbox) {
		return checkbox.checked;
	});

	if (!anyChecked) {
		document.getElementById('mo2f_enable2FA').checked = false;
	}
}
document.addEventListener('DOMContentLoaded', function () {
	const roleCheckboxes = document.querySelectorAll('#mo2f_role_checkbox');
	const allChecked = [...roleCheckboxes].every(function (checkbox) {
		return checkbox.checked;
	});
	document.getElementById('mo2f_select_all_roles').checked = allChecked;
});
function mo2f_enable_new_ip_notification(){
	var enablednotification = jQuery("#mo2f_new_ip_login_notification").is(":checked");
	var data = {
		"action": "mo2f_login_settings_ajax",
		"option": "mo2f_new_ip_login_notification",
		"nonce": nonce,
		"is_notification_enabled": enablednotification,
	};
	handleAjaxrequest(ajaxurl, data, "#mo2f_new_ip_login_notification");
}
function mo2fShowLoader(){
	jQuery("#mo2f_2fa_popup_dashboard").html("<span class=\'mo2f_loader\' id=\'mo2f_loader\'></span>");
	jQuery("#mo2f_2fa_popup_dashboard").css("display", "block");
}