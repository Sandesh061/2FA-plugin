<?php


namespace TwoFA\Cloud;

use TwoFA\Onprem\Mo2f_Api;
require_once dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . "\150\145\154\160\145\x72" . DIRECTORY_SEPARATOR . "\x63\154\141\x73\163\x2d\x6d\x6f\x32\x66\x2d\x61\x70\151\56\160\x68\160";
if (class_exists("\x54\167\157\x5f\x46\141\x63\164\x6f\x72\137\x53\x65\164\x75\x70")) {
    goto l4;
}
class Two_Factor_Setup
{
    public $email;
    public function mo2f_register_kba_details($fK, $jr, $VF, $wj, $d2, $BR, $aW, $v1 = null)
    {
        $xz = MO_HOST_NAME . "\x2f\x6d\157\x61\x73\x2f\141\160\151\57\141\165\164\x68\x2f\x72\x65\147\x69\x73\x74\145\162";
        $hS = get_site_option("\x6d\157\x32\146\137\143\x75\x73\164\x6f\155\145\x72\x4b\145\x79");
        $BB = "\x5b\x7b\42\161\x75\x65\163\164\151\x6f\x6e\42\72\42" . $jr . "\x22\x2c\x22\x61\x6e\163\167\145\x72\42\72\x22" . $VF . "\42\40\x7d\54\x7b\42\x71\x75\145\x73\x74\x69\x6f\156\x22\x3a\x22" . $wj . "\42\x2c\42\x61\156\163\x77\145\162\42\x3a\x22" . $d2 . "\42\40\x7d\54\x7b\x22\161\165\x65\163\164\x69\x6f\x6e\42\72\42" . $BR . "\x22\54\42\141\156\163\x77\x65\x72\42\72\42" . $aW . "\42\40\x7d\135";
        $e5 = "\x7b\42\143\x75\x73\164\157\155\145\162\113\145\171\x22\x3a\42" . $hS . "\x22\54\x22\x75\163\x65\x72\156\x61\x6d\145\x22\72\x22" . $fK . "\x22\x2c\x22\x71\165\145\163\x74\x69\x6f\x6e\x41\156\163\x77\145\x72\114\x69\x73\164\x22\x3a" . $BB . "\x7d";
        $it = new Mo2f_Api();
        $LB = $it->get_http_header_array();
        $bC = $it->mo2f_http_request($xz, $e5, $LB);
        return $bC;
    }
}
new Two_Factor_Setup();
l4:
