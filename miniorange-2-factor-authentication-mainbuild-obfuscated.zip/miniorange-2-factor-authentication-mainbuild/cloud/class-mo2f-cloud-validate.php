<?php


namespace TwoFA\Cloud;

use TwoFA\Onprem\MO2f_Utility;
use TwoFA\Onprem\Miniorange_Password_2Factor_Login;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Onprem\Mo2f_Api;
use TwoFA\Helper\TwoFAMoSessions;
use WP_Error;
if (defined("\101\102\x53\x50\101\124\110")) {
    goto Nf;
}
exit;
Nf:
if (class_exists("\x4d\157\x32\146\x5f\x43\x6c\x6f\x75\144\x5f\126\141\154\151\x64\x61\164\145")) {
    goto aC;
}
class Mo2f_Cloud_Validate
{
    public function mo2f_google_auth_validate($UG, $CH, $wG)
    {
        $xz = MO_HOST_NAME . "\x2f\155\x6f\141\163\57\x61\x70\151\x2f\x61\165\164\x68\57\166\141\154\151\144\141\164\145\55\147\157\x6f\x67\x6c\145\x2d\141\165\164\x68\x2d\x73\x65\143\162\145\x74";
        $it = new Mo2f_Api();
        $hS = get_site_option("\155\157\x32\x66\x5f\x63\165\163\164\x6f\155\x65\x72\113\145\x79");
        $e5 = array("\x63\165\x73\x74\x6f\155\145\162\x4b\145\171" => $hS, "\165\x73\145\162\156\x61\x6d\x65" => $UG, "\x73\145\x63\162\145\164" => $wG, "\x6f\164\x70\x54\x6f\153\x65\x6e" => $CH, "\141\165\x74\150\145\x6e\164\151\143\141\164\157\x72\x54\x79\x70\x65" => MoWpnsConstants::GOOGLE_AUTHENTICATOR);
        $LB = $it->get_http_header_array();
        return $it->mo2f_http_request($xz, $e5, $LB);
    }
    public function mo2f_login_kba_verification($v1, $jg, $ok)
    {
        global $Gw, $Xw;
        $kZ = new Miniorange_Password_2Factor_Login();
        $oJ = $Gw->get_user_detail("\155\x6f\62\146\137\x75\x73\x65\162\x5f\145\x6d\x61\x69\x6c", $v1);
        $hP = $Xw->send_otp_token(null, $oJ, MoWpnsConstants::SECURITY_QUESTIONS);
        $bC = json_decode($hP, true);
        if (JSON_ERROR_NONE === json_last_error()) {
            goto DG;
        }
        $kZ->remove_current_activity($jg);
        $jY = new WP_Error();
        $jY->add("\x65\155\x70\x74\x79\x5f\165\x73\x65\x72\x6e\x61\155\145", __("\74\163\x74\162\157\x6e\147\76\105\122\122\x4f\122\x3c\57\x73\164\x72\157\156\x67\x3e\x3a\40\101\x6e\x20\145\x72\162\157\x72\40\157\x63\143\x75\162\x65\x64\40\x77\x68\x69\154\x65\x20\160\x72\x6f\143\x65\163\163\151\156\x67\x20\171\157\165\162\40\x72\145\161\x75\145\x73\164\x2e\40\x50\154\145\x61\x73\145\40\124\x72\171\x20\x61\147\141\151\156\x2e"));
        return $jY;
        goto E2;
        DG:
        if ("\x53\x55\103\103\x45\123\x53" === $bC["\163\x74\141\164\x75\163"]) {
            goto h6;
        }
        if ("\x45\x52\x52\x4f\x52" === $bC["\x73\x74\x61\164\x75\163"]) {
            goto Oy;
        }
        goto nn;
        h6:
        MO2f_Utility::mo2f_set_transient($jg, "\x6d\x6f\62\146\x5f\164\x72\x61\x6e\163\141\143\164\151\x6f\156\111\x64", $bC["\x74\x78\x49\144"]);
        $yp = array($bC["\161\x75\x65\163\x74\151\x6f\156\163"][0]["\161\x75\145\163\164\151\157\x6e"], $bC["\161\x75\x65\163\164\151\157\156\163"][1]["\161\x75\145\163\x74\x69\x6f\x6e"]);
        TwoFAMoSessions::add_session_var("\155\x6f\137\x32\x5f\146\141\x63\164\x6f\162\x5f\153\x62\141\x5f\161\x75\x65\163\x74\x69\157\156\163", $yp);
        return $yp;
        goto nn;
        Oy:
        $kZ->remove_current_activity($jg);
        $jY = new WP_Error();
        $jY->add("\x65\x6d\160\x74\x79\x5f\x75\163\x65\x72\156\141\x6d\x65", __("\x3c\163\x74\162\x6f\x6e\x67\76\105\122\x52\117\122\74\57\163\x74\162\157\156\147\76\72\40\x41\x6e\x20\145\162\x72\157\162\x20\157\x63\x63\165\x72\145\x64\x20\167\150\x69\x6c\x65\x20\160\162\157\143\145\x73\163\151\156\147\x20\171\x6f\165\162\40\162\145\161\x75\145\x73\164\x2e\x20\120\154\x65\141\163\x65\40\x54\x72\171\40\x61\147\141\151\156\x2e"));
        return $jY;
        nn:
        E2:
    }
}
aC:
