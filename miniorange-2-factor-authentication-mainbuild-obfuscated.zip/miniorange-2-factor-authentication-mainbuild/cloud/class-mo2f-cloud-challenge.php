<?php


namespace TwoFA\Cloud;

use TwoFA\Onprem\MO2f_Utility;
if (defined("\101\102\x53\x50\x41\124\x48")) {
    goto q9;
}
exit;
q9:
if (class_exists("\115\x6f\x32\146\x5f\x43\154\157\165\144\137\103\x68\141\154\154\145\x6e\x67\x65")) {
    goto vZ;
}
class Mo2f_Cloud_Challenge
{
    public function mo2f_gauth_setup($user, $jg)
    {
        if (get_user_meta($user->ID, "\155\157\62\146\x5f\x67\x6f\157\x67\154\145\x5f\x61\x75\164\150", true)) {
            goto he;
        }
        Mo2f_Cloud_Utility::mo2f_get_g_a_parameters($user);
        he:
        $uX = get_user_meta($user->ID, "\x6d\x6f\62\146\x5f\x67\157\x6f\x67\154\145\137\141\165\x74\150", true);
        $mC = isset($uX["\147\141\x5f\x71\162\x43\x6f\144\145"]) ? $uX["\x67\141\x5f\161\162\x43\x6f\x64\145"] : null;
        $CM = isset($uX["\147\x61\x5f\x73\145\143\162\145\164"]) ? $uX["\147\x61\137\163\x65\x63\162\x65\164"] : null;
        MO2f_Utility::mo2f_set_transient($jg, "\163\x65\x63\x72\145\x74\137\x67\141", $CM);
        MO2f_Utility::mo2f_set_transient($jg, "\x67\x61\137\x71\x72\x43\x6f\x64\x65", $mC);
    }
}
vZ:
