<?php


namespace TwoFA\Cloud;

use TwoFA\Onprem\Mo2f_Api;
use TwoFA\Onprem\Miniorange_Authentication;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Traits\Instance;
use TwoFA\Helper\MocURL;
use TwoFA\Onprem\Miniorange_Password_2Factor_Login;
use TwoFA\Onprem\MO2f_Utility;
use TwoFA\Helper\MoWpnsMessages;
use WP_Error;
if (defined("\101\102\123\x50\101\124\110")) {
    goto mk;
}
exit;
mk:
if (class_exists("\103\x75\x73\164\x6f\x6d\x65\162\x5f\103\x6c\x6f\165\x64\x5f\123\x65\x74\x75\160")) {
    goto aq;
}
class Customer_Cloud_Setup
{
    use Instance;
    public $email;
    public $phone;
    public $customer_key;
    public $transaction_id;
    private $mo2f_api;
    public function __construct()
    {
        $this->mo2f_api = Mo2f_Api::instance();
    }
    public function mo2f_plan_methods()
    {
        $xu = array(MoWpnsConstants::GOOGLE_AUTHENTICATOR => array("\144\x6f\x63" => MoWpnsConstants::GA_DOCUMENT_LINK, "\166\x69\x64\x65\x6f" => MoWpnsConstants::GA_YOUTUBE, "\x64\145\x73\143" => "\125\x73\x65\40\117\156\145\40\x54\x69\x6d\145\x20\120\x61\163\x73\167\x6f\162\x64\40\x73\150\x6f\167\x6e\x20\x69\156\40\x3c\x62\x3e\x47\x6f\157\147\154\x65\x2f\101\165\x74\150\171\57\x4d\x69\x63\162\157\163\157\x66\164\40\101\x75\x74\x68\x65\156\164\151\143\x61\x74\157\x72\x20\101\x70\x70\74\57\x62\x3e\x20\x74\157\x20\154\x6f\x67\151\156"), MoWpnsConstants::OTP_OVER_SMS => array("\144\x6f\143" => MoWpnsConstants::OTP_OVER_SMS_DOCUMENT_LINK, "\x76\151\x64\145\157" => MoWpnsConstants::OTP_OVER_SMS_YOUTUBE, "\144\x65\163\143" => "\x41\40\117\x6e\x65\40\124\151\x6d\145\40\x50\x61\163\163\143\157\144\145\40\50\x4f\x54\120\51\x20\167\151\x6c\154\40\142\145\x20\163\x65\x6e\x74\x20\x74\157\40\x79\157\x75\162\40\x50\150\157\x6e\145\x20\x6e\165\155\x62\145\x72"), MoWpnsConstants::OTP_OVER_EMAIL => array("\x64\157\143" => MoWpnsConstants::OTP_OVER_EMAIL_DOCUMENT_LINK, "\166\151\144\x65\x6f" => null, "\x64\145\x73\143" => "\x41\40\x4f\156\145\40\124\x69\x6d\x65\40\120\141\163\x73\143\157\x64\145\x20\x28\x4f\124\120\51\40\x77\151\x6c\x6c\x20\x62\145\40\163\x65\x6e\164\40\x74\157\40\171\x6f\x75\x72\40\x45\155\141\151\x6c\x20\141\144\x64\162\145\163\x73"), MoWpnsConstants::OUT_OF_BAND_EMAIL => array("\x64\157\143" => MoWpnsConstants::EMAIL_VERIFICATION_DOCUMENT_LINK, "\x76\x69\x64\145\x6f" => MoWpnsConstants::EMAIL_VERIFICATION_YOUTUBE, "\144\x65\x73\x63" => "\101\x63\x63\145\x70\164\x20\164\x68\x65\x20\166\x65\162\151\146\151\x63\141\x74\x69\157\156\40\x6c\151\x6e\x6b\x20\163\145\x6e\x74\40\164\x6f\x20\x79\157\165\x72\40\145\x6d\141\x69\x6c\x20\141\x64\144\162\x65\x73\163"), MoWpnsConstants::OTP_OVER_TELEGRAM => array("\x64\157\x63" => MoWpnsConstants::OTP_OVER_TELEGRAM_DOCUMENT_LINK, "\x76\x69\x64\x65\157" => MoWpnsConstants::OTP_OVER_TELEGRAM_YOUTUBE, "\144\145\x73\143" => "\x45\156\x74\145\162\x20\164\x68\145\40\117\156\145\40\x54\x69\x6d\145\x20\120\x61\x73\x73\143\x6f\144\145\x20\x73\145\156\x74\40\164\x6f\x20\x79\157\x75\x72\x20\x54\145\154\145\x67\x72\x61\155\40\141\143\x63\x6f\165\156\x74"), MoWpnsConstants::SECURITY_QUESTIONS => array("\144\157\x63" => MoWpnsConstants::KBA_DOCUMENT_LINK, "\x76\x69\144\x65\157" => MoWpnsConstants::KBA_YOUTUBE, "\144\x65\x73\x63" => "\x43\x6f\x6e\x66\151\147\x75\x72\145\x20\141\x6e\144\40\101\156\x73\167\145\x72\40\x54\x68\x72\145\145\40\123\145\x63\x75\x72\151\x74\171\x20\121\x75\145\163\x74\x69\157\156\163\40\x74\157\x20\154\157\x67\151\x6e"), MoWpnsConstants::OTP_OVER_WHATSAPP => array("\x64\x6f\x63" => MoWpnsConstants::OTP_OVER_WA_DOCUMENT_LINK, "\166\151\x64\145\x6f" => null, "\144\145\163\x63" => "\x45\x6e\x74\x65\x72\40\164\x68\145\x20\x4f\x6e\x65\x20\x54\151\155\x65\x20\120\x61\163\x73\143\x6f\x64\x65\40\163\x65\x6e\x74\x20\x74\157\40\x79\x6f\x75\x72\x20\127\x68\141\x74\163\101\160\x70\x20\x61\143\x63\157\x75\156\x74\x2e", "\143\x72\157\167\156" => true));
        return $xu;
    }
    public function get_customer_key()
    {
        $xz = MO_HOST_NAME . "\57\155\157\141\x73\x2f\x72\x65\163\x74\57\143\165\163\x74\157\155\145\162\x2f\153\145\171";
        $fK = get_site_option("\155\157\x32\x66\137\x65\x6d\x61\x69\x6c");
        $uk = get_site_option("\155\157\x32\146\x5f\160\x61\x73\163\x77\x6f\x72\x64");
        $aV = array("\x65\x6d\141\x69\x6c" => $fK, "\160\x61\163\163\x77\157\x72\144" => $uk);
        $e5 = wp_json_encode($aV);
        $Tp = array("\103\157\156\164\x65\156\x74\55\x54\x79\x70\x65" => "\x61\160\160\154\x69\143\x61\164\x69\157\156\x2f\152\x73\157\156", "\143\x68\141\x72\163\145\164" => "\125\x54\106\x2d\70", "\x41\165\164\x68\157\162\151\172\141\164\151\157\156" => "\102\141\163\151\143");
        $hP = $this->mo2f_api->mo2f_http_request($xz, $e5);
        return $hP;
    }
    public function mo2f_update_user_info($v1, $eX, $ix, $Bv, $Q3, $yG, $fK, $T7 = null, $hF = null, $M4 = null)
    {
        $Ip = new MocURL();
        $hP = $Ip->mo2f_update_user_info($fK, $ix, $T7, $hF, $M4);
        if (!isset($v1)) {
            goto Bq;
        }
        $Mc = new Miniorange_Password_2Factor_Login();
        $Mc->mo2fa_update_user_details($v1, $eX, $ix, $Bv, $Q3, $yG, $fK, $T7);
        Bq:
        return $hP;
    }
    public function send_otp_token($T7, $fK, $dX, $cs)
    {
        $xs = new MocURL();
        $hP = $xs->send_otp_token($dX, $T7, $fK);
        return $hP;
    }
    public function validate_otp_token($dX, $Zi, $bO, $li, $current_user = null)
    {
        $Nt = new MocURL();
        $hP = $Nt->validate_otp_token($bO, $li, $Zi, $dX);
        return $hP;
    }
    public function submit_contact_us($Co, $z4, $wJ)
    {
        $xz = MO_HOST_NAME . "\57\155\157\141\163\57\x72\145\x73\164\57\143\165\163\x74\x6f\155\x65\162\x2f\x63\157\156\x74\x61\143\x74\x2d\165\163";
        global $user;
        $user = wp_get_current_user();
        $jQ = MoWpnsUtility::get_mo2f_db_option("\155\x6f\62\146\137\151\x73\137\116\x43", "\x73\x69\164\145\137\x6f\x70\x74\151\157\x6e") && MoWpnsUtility::get_mo2f_db_option("\155\157\62\x66\x5f\x69\x73\137\116\116\103", "\163\151\164\145\137\157\x70\164\151\x6f\x6e");
        $RL = !MoWpnsUtility::get_mo2f_db_option("\x6d\x6f\x32\146\137\x69\163\137\116\103", "\163\x69\164\145\137\x6f\160\164\151\x6f\156");
        $jK = '';
        if ($RL) {
            goto uQ;
        }
        if ($jQ) {
            goto uo;
        }
        goto zf;
        uQ:
        $jK = "\x56\x31";
        goto zf;
        uo:
        $jK = "\126\63";
        zf:
        global $uz;
        $wJ = "\x5b\x57\157\162\144\x50\x72\145\163\x73\x20\x32\x20\x46\x61\143\164\157\x72\40\x41\165\x74\x68\x65\156\164\x69\x63\x61\x74\151\157\156\x20\120\x6c\165\147\x69\x6e\72\x20" . $jK . "\40\55\40\126\x20" . MO2F_VERSION . "\x20\135\x3a\x20" . $wJ;
        $aV = array("\146\x69\162\163\x74\116\x61\x6d\x65" => $user->user_firstname, "\x6c\141\x73\x74\116\141\x6d\145" => $user->user_lastname, "\143\x6f\x6d\160\141\156\171" => isset($_SERVER["\123\x45\122\x56\105\x52\x5f\116\101\115\x45"]) ? esc_url_raw(wp_unslash($_SERVER["\123\105\x52\x56\x45\122\137\x4e\x41\115\x45"])) : null, "\145\x6d\141\x69\x6c" => $Co, "\x63\x63\105\155\x61\151\x6c" => "\x6d\146\x61\163\165\160\x70\157\x72\x74\x40\170\x65\143\165\x72\x69\146\x79\56\x63\157\155", "\x70\150\x6f\156\145" => $z4, "\161\165\145\x72\171" => $wJ);
        $e5 = wp_json_encode($aV);
        $Tp = array("\103\x6f\x6e\164\145\156\x74\x2d\x54\171\160\x65" => "\x61\160\160\x6c\151\x63\141\x74\x69\x6f\156\x2f\152\x73\157\x6e", "\143\150\x61\162\163\145\x74" => "\x55\124\106\55\x38", "\x41\165\x74\150\x6f\x72\x69\172\x61\x74\151\x6f\x6e" => "\102\x61\163\151\143");
        $hP = $this->mo2f_api->mo2f_http_request($xz, $e5);
        return true;
    }
    public function mo2f_gauth_setup($user, $jg)
    {
        $vN = new Mo2f_Cloud_Challenge();
        $vN->mo2f_gauth_setup($user, $jg);
    }
    public function mo2f_send_verification_link($oJ, $Z0, $current_user)
    {
        $hP = $this->send_otp_token(null, $oJ, $Z0, $current_user);
        return $hP;
    }
    public function mo2f_oobe_get_dashboard_script($Sl, $bO)
    {
        $lW = "\x3c\163\x63\x72\x69\160\x74\76\15\12\x20\x20\40\40\x20\40\40\40\40\x20\40\x20\x76\141\x72\40\143\141\154\x6c\x73\x20\x3d\40\x30\x3b\xd\xa\x20\x20\40\40\40\x20\40\x20\40\40\x20\40\x76\141\162\x20\x72\145\161\165\145\163\x74\x54\171\160\145\x20\x3d\x20\x22" . esc_js($Sl) . "\x22\73\xd\12\40\40\x20\40\40\x20\40\40\40\40\x20\40\166\x61\x72\40\164\162\141\x6e\163\x49\x64\x20\75\40\42" . esc_js($bO) . "\x22\73\xd\xa\x20\x20\x20\40\40\40\40\x20\x20\x20\40\40\145\x6d\141\x69\x6c\x56\145\162\151\x66\x69\x63\x61\164\151\x6f\156\x50\157\x6c\x6c\x28\51\x3b\15\12\40\x20\40\40\x20\x20\x20\40\x20\40\x20\x20\146\165\x6e\x63\x74\151\x6f\x6e\40\x65\155\x61\x69\154\126\145\x72\151\146\151\x63\x61\164\x69\157\x6e\x50\157\x6c\x6c\x28\51\xd\12\40\40\x20\40\40\x20\x20\x20\40\40\x20\40\x7b\15\12\40\x20\x20\x20\x20\40\x20\40\40\x20\x20\40\x20\x20\40\40\x63\141\154\154\163\40\x3d\40\x63\x61\x6c\x6c\163\x20\x2b\40\61\73\xd\xa\40\x20\x20\x20\40\40\x20\x20\x20\x20\40\40\x20\40\x20\x20\166\141\162\40\x64\141\164\141\40\x3d\x20\173\42\x74\x78\x49\144\42\x3a\42" . esc_js($bO) . "\42\175\x3b\xd\xa\40\40\40\x20\x20\40\40\40\x20\40\x20\x20\x20\x20\40\40\152\x51\x75\x65\x72\x79\x2e\141\x6a\x61\x78\50\173\xd\12\x20\x20\40\x20\x20\x20\40\x20\x20\40\x20\40\x20\40\x20\40\x20\40\40\x20\x75\162\154\x3a\x20\42" . esc_url(MO_HOST_NAME) . "\57\x6d\x6f\141\x73\x2f\141\160\x69\57\x61\x75\x74\x68\x2f\x61\x75\x74\x68\x2d\163\164\x61\164\x75\x73\42\54\15\12\40\x20\x20\x20\x20\x20\40\40\40\x20\40\x20\x20\x20\40\40\x20\40\40\40\164\171\160\x65\x3a\x20\x22\x50\117\x53\x54\42\54\15\12\x20\40\x20\40\x20\x20\40\40\x20\40\x20\x20\40\40\40\40\40\40\x20\40\144\141\x74\141\124\171\160\145\72\x20\x22\x6a\163\x6f\x6e\x22\x2c\15\12\40\x20\40\40\x20\x20\x20\40\40\x20\40\x20\40\x20\40\x20\x20\x20\x20\40\144\141\164\141\72\40\x4a\x53\117\116\x2e\x73\x74\162\151\156\x67\151\146\171\x28\x64\x61\164\141\x29\x2c\x20\57\57\40\123\x74\162\x69\156\x67\x69\x66\171\40\112\x53\x4f\116\40\144\x61\164\x61\15\xa\40\40\40\x20\40\x20\x20\40\40\40\x20\40\40\x20\x20\40\x20\x20\x20\40\143\157\156\x74\145\156\x74\124\x79\160\145\x3a\40\x22\141\160\160\154\x69\x63\141\164\x69\157\x6e\x2f\x6a\x73\157\156\x3b\40\x63\150\141\162\163\145\164\x3d\x75\164\x66\x2d\70\42\x2c\xd\xa\x20\x20\40\x20\40\x20\x20\x20\x20\40\x20\40\40\x20\x20\40\40\x20\40\x20\x73\165\143\143\x65\163\x73\72\40\146\x75\156\x63\164\151\x6f\x6e\x20\x28\162\x65\x73\x75\x6c\x74\51\x20\173\15\xa\40\x20\40\40\x20\x20\40\40\x20\40\40\x20\40\40\40\40\x20\40\x20\x20\x20\40\40\x20\x76\x61\x72\40\163\x74\141\164\x75\x73\x20\x3d\x20\x72\145\x73\165\x6c\164\x2e\x73\x74\x61\x74\165\x73\x3b\15\12\40\40\40\x20\x20\x20\40\x20\x20\40\40\x20\40\40\40\x20\40\x20\40\x20\x20\x20\x20\x20\151\x66\x20\x28\163\164\141\x74\x75\163\x20\75\75\x3d\x20\42\123\x55\x43\x43\105\123\x53\42\x29\x20\x7b\xd\xa\40\x20\40\40\x20\40\x20\x20\40\x20\x20\40\40\40\40\x20\x20\x20\x20\x20\40\x20\x20\40\x20\x20\x20\40\x69\x66\x20\x28\162\x65\x71\165\145\x73\x74\124\x79\160\145\40\x3d\x3d\x3d\40\x22\x63\157\x6e\x66\151\x67\165\x72\x65\x5f\x32\x66\141\x22\51\x20\x7b\xd\xa\x20\40\x20\x20\40\x20\x20\40\40\x20\40\40\40\40\x20\40\x20\x20\x20\40\40\x20\40\x20\40\40\x20\40\40\40\40\x20\x6a\x51\x75\145\162\171\50\42\43\155\157\62\146\137\x32\x66\x61\143\x74\157\x72\137\164\145\x73\164\x5f\160\x72\157\x6d\x70\x74\137\143\x72\157\163\163\42\x29\56\x73\x75\142\155\x69\x74\x28\x29\73\15\12\x20\40\40\40\40\40\40\40\x20\x20\40\40\x20\40\x20\40\x20\40\40\x20\40\x20\x20\40\x20\40\x20\40\x7d\x20\x65\154\x73\145\40\x7b\15\12\40\40\x20\40\x20\x20\x20\x20\40\40\x20\x20\40\40\x20\40\x20\40\40\40\40\x20\x20\x20\40\x20\x20\x20\40\x20\40\40\152\x51\165\x65\162\x79\x28\42\43\155\x6f\x32\x66\x5f\x32\146\141\137\160\x6f\160\x75\160\x5f\144\141\163\150\142\157\141\162\x64\42\51\x2e\143\x73\163\x28\x22\144\151\x73\x70\154\x61\x79\42\54\x20\42\156\x6f\x6e\x65\x22\x29\x3b\15\12\x20\x20\40\x20\x20\40\40\40\x20\40\40\40\x20\x20\x20\40\40\40\40\40\40\40\x20\40\40\x20\40\40\40\40\x20\40\x73\x75\x63\143\145\163\163\137\x6d\163\147\x28\x22\x59\x6f\x75\40\150\x61\x76\x65\x20\163\x75\x63\x63\145\163\163\x66\165\154\154\171\x20\143\x6f\155\x70\154\145\x74\145\144\x20\x74\150\145\40\x74\145\x73\x74\56\42\x29\x3b\15\xa\40\40\x20\x20\x20\x20\40\x20\40\40\40\40\40\40\x20\40\x20\x20\x20\40\x20\x20\40\40\40\40\40\40\x7d\15\xa\x20\40\40\40\40\40\x20\x20\40\40\x20\40\40\40\40\40\x20\40\40\x20\40\x20\40\40\x7d\40\x65\x6c\x73\145\x20\x69\146\x20\x28\163\164\x61\164\x75\163\x20\75\75\x3d\40\x22\105\x52\x52\x4f\x52\x22\x20\174\174\x20\163\x74\141\164\165\x73\40\x3d\x3d\75\x20\42\x46\101\111\114\x45\104\42\40\174\174\40\x73\164\x61\164\165\163\40\75\75\x3d\40\x22\104\105\116\111\x45\104\42\x20\174\x7c\40\x73\164\x61\x74\x75\163\40\x3d\75\x3d\40\60\x29\40\x7b\15\12\40\x20\40\40\x20\x20\40\40\x20\x20\x20\40\x20\x20\40\x20\x20\x20\40\x20\x20\x20\40\40\x20\40\40\x20\x6a\x51\x75\x65\162\x79\50\x22\x23\x6d\x6f\62\x66\137\x32\146\141\137\160\x6f\x70\x75\160\137\x64\141\163\x68\142\157\141\x72\144\42\x29\56\146\141\x64\145\117\x75\x74\x28\x29\x3b\xd\12\40\40\x20\x20\x20\40\x20\40\40\40\40\40\40\40\40\x20\40\x20\x20\x20\x20\40\x20\x20\40\x20\40\40\x63\x6c\157\163\145\x56\145\162\x69\146\151\143\141\x74\x69\157\156\x20\x3d\40\x74\162\x75\145\73\15\xa\x20\40\40\40\40\x20\x20\x20\40\40\x20\x20\40\x20\x20\40\x20\x20\x20\40\40\40\40\40\x20\40\x20\x20\145\x72\162\x6f\x72\137\x6d\163\x67\50\42\x59\157\165\40\x68\141\166\x65\x20\x64\x65\156\151\x65\144\40\x74\150\x65\x20\164\162\x61\156\x73\x61\x63\x74\151\157\156\56\x22\51\73\15\xa\x20\x20\40\x20\x20\x20\x20\40\x20\40\40\x20\x20\x20\x20\x20\x20\40\x20\40\40\40\40\x20\x7d\x20\145\x6c\x73\x65\40\x7b\xd\12\40\x20\x20\40\x20\x20\x20\x20\x20\x20\40\40\x20\x20\x20\40\x20\40\40\40\x20\40\40\40\40\40\x20\40\151\x66\x20\50\x63\x61\x6c\x6c\163\x20\x3c\40\63\60\x30\51\xd\xa\x20\x20\40\x20\x20\x20\x20\40\40\40\x20\x20\40\40\40\x20\40\x20\40\x20\x20\x20\x20\x20\x20\40\40\40\x7b\15\xa\40\40\40\x20\x20\40\40\x20\40\40\40\40\x20\x20\x20\x20\40\40\x20\40\x20\x20\x20\40\x20\40\40\40\40\x20\x20\40\164\x69\155\145\x6f\165\x74\x20\75\40\163\x65\x74\x54\x69\x6d\x65\x6f\165\x74\x28\145\155\x61\151\x6c\x56\145\162\x69\146\151\143\141\164\x69\157\156\x50\157\x6c\x6c\x2c\40\x31\x30\60\x30\x29\x3b\xd\xa\x20\x20\x20\x20\x20\x20\x20\40\x20\40\40\40\x20\x20\40\x20\x20\40\x20\x20\x20\40\40\40\40\40\40\x20\x7d\xd\12\40\x20\x20\40\40\40\x20\40\40\x20\40\x20\x20\40\40\40\x20\40\x20\x20\x20\40\x20\x20\40\x20\40\x20\x65\154\x73\x65\15\xa\40\x20\40\x20\x20\x20\40\x20\40\x20\x20\40\x20\x20\40\x20\40\40\x20\x20\x20\x20\40\40\40\40\x20\40\x7b\15\xa\x20\40\x20\40\x20\40\x20\x20\x20\x20\x20\x20\40\40\40\40\x20\x20\40\x20\40\40\40\40\x20\40\40\x20\40\x20\40\40\152\x51\x75\145\162\x79\x28\x22\43\155\157\62\x66\137\62\x66\141\x5f\160\x6f\160\165\160\137\144\141\x73\150\142\157\141\162\x64\42\51\x2e\x66\x61\144\x65\117\165\x74\50\51\73\15\xa\40\40\x20\40\40\40\x20\x20\x20\40\40\x20\x20\x20\x20\40\x20\40\x20\40\40\40\40\40\x20\x20\x20\40\40\x20\x20\x20\x63\154\157\163\145\126\145\x72\151\146\151\143\x61\164\x69\157\x6e\x20\75\40\164\x72\x75\145\73\15\12\40\40\x20\40\x20\40\x20\40\40\x20\40\x20\x20\x20\40\40\x20\40\40\x20\40\x20\40\40\40\x20\40\x20\x20\40\x20\x20\145\x72\x72\x6f\162\137\x6d\x73\147\x28\x22\123\x65\x73\x73\151\x6f\156\x20\164\151\x6d\x65\x6f\x75\164\56\42\51\x3b\xd\12\x20\x20\40\x20\x20\40\40\40\40\x20\x20\x20\40\40\x20\x20\40\40\40\x20\40\x20\40\40\x20\40\40\x20\x7d\15\xa\40\40\40\40\x20\x20\x20\40\x20\x20\x20\40\40\x20\40\x20\x20\40\x20\x20\40\x20\x20\x20\x7d\xd\xa\40\40\x20\x20\x20\x20\x20\x20\x20\x20\40\x20\40\40\40\x20\40\40\x20\40\x7d\15\12\x20\40\x20\x20\x20\x20\40\x20\40\40\40\x20\40\40\x20\x20\x7d\x29\x3b\15\12\40\x20\40\40\x20\40\40\40\x20\40\x20\40\175\xd\xa\x20\40\x20\40\x20\40\40\40\40\x20\74\57\163\x63\162\151\160\164\x3e";
        return $lW;
    }
    public function mo2f_oobe_get_login_script($Sl, $bO)
    {
        $lW = "\x3c\x73\143\x72\x69\160\164\x3e\15\12\40\x20\x20\x20\40\x20\x20\x20\x20\40\40\x20\x76\141\162\x20\143\x61\154\154\x73\40\75\40\60\x3b\15\xa\x20\x20\40\x20\x20\x20\40\x20\40\x20\x20\40\166\141\x72\40\162\x65\161\165\145\x73\x74\x54\171\x70\x65\x20\x3d\40\x22" . esc_js($Sl) . "\x22\73\15\xa\x20\x20\x20\40\x20\40\x20\40\40\40\x20\40\x76\141\162\x20\164\162\x61\x6e\163\111\144\40\x3d\x20\42" . esc_js($bO) . "\x22\73\15\xa\40\x20\40\40\x20\40\40\40\x20\x20\40\40\145\x6d\x61\x69\154\126\x65\x72\x69\146\x69\x63\x61\164\151\x6f\156\x50\157\x6c\x6c\50\51\73\15\12\x20\x20\40\x20\x20\x20\x20\40\x20\40\x20\x20\x66\165\156\x63\x74\x69\157\156\40\x65\155\141\151\x6c\126\x65\x72\151\146\151\x63\141\x74\151\x6f\x6e\120\x6f\x6c\154\x28\51\xd\xa\40\x20\x20\40\40\40\40\40\x20\40\x20\x20\173\15\12\40\40\x20\40\40\40\40\x20\x20\x20\x20\x20\40\x20\x20\40\143\141\x6c\x6c\x73\x20\x3d\x20\143\x61\154\x6c\x73\x20\53\x20\61\73\15\xa\40\40\40\x20\40\40\40\x20\40\x20\x20\x20\x20\x20\x20\x20\166\141\162\40\x64\141\x74\141\40\x3d\x20\x7b\42\164\x78\111\x64\x22\x3a\42" . esc_js($bO) . "\x22\x7d\x3b\15\xa\x20\40\40\x20\40\40\40\x20\40\x20\x20\40\40\x20\x20\x20\152\121\165\145\x72\171\x2e\x61\152\x61\170\50\173\xd\xa\x20\x20\40\x20\x20\40\40\x20\x20\40\x20\x20\40\x20\x20\40\40\40\40\x20\165\162\x6c\72\x20\x22" . esc_url(MO_HOST_NAME) . "\57\155\x6f\x61\163\x2f\141\x70\151\57\x61\165\164\x68\x2f\141\x75\164\150\55\x73\164\141\164\165\x73\x22\x2c\15\12\x20\x20\x20\x20\x20\40\x20\x20\40\40\40\40\x20\40\40\x20\40\40\x20\40\164\x79\160\x65\72\x20\x22\x50\x4f\123\x54\x22\54\15\12\40\x20\x20\x20\40\40\x20\x20\x20\x20\40\x20\40\40\x20\40\40\40\40\x20\144\141\x74\x61\124\171\160\145\x3a\x20\42\x6a\163\157\156\42\x2c\15\12\x20\x20\40\x20\x20\40\40\x20\x20\40\40\40\x20\x20\x20\x20\x20\40\40\x20\144\x61\x74\x61\72\x20\x4a\x53\x4f\116\56\163\x74\x72\x69\156\147\x69\146\171\50\144\x61\164\x61\x29\54\x20\x2f\57\x20\123\164\x72\151\156\x67\x69\x66\x79\x20\112\123\117\116\40\x64\x61\x74\x61\15\12\x20\x20\x20\40\x20\x20\40\40\x20\x20\x20\x20\x20\x20\40\x20\40\40\x20\x20\143\x6f\x6e\164\145\x6e\x74\124\x79\x70\145\x3a\x20\42\x61\160\x70\154\151\143\141\x74\151\x6f\x6e\x2f\152\163\157\156\73\x20\x63\150\141\x72\163\x65\164\x3d\165\164\x66\x2d\70\x22\x2c\xd\12\x20\x20\40\x20\x20\40\40\x20\x20\x20\x20\x20\x20\x20\x20\40\x20\40\x20\40\x73\x75\x63\x63\145\163\x73\72\40\146\x75\x6e\143\x74\x69\x6f\x6e\x20\50\x72\x65\x73\x75\x6c\164\51\40\173\xd\xa\40\x20\x20\40\40\x20\x20\40\40\x20\x20\40\x20\x20\40\40\x20\40\x20\x20\x20\40\40\40\166\141\x72\x20\x73\x74\141\x74\x75\163\40\x3d\40\x72\145\x73\165\154\164\x2e\x73\164\x61\164\x75\x73\x3b\15\12\40\x20\40\40\40\40\40\x20\40\x20\40\x20\x20\40\x20\40\x20\40\x20\x9\11\x69\x66\40\50\x73\x74\141\x74\x75\x73\x20\x3d\75\x3d\40\x22\123\125\103\x43\x45\123\x53\42\x29\x20\x7b\xd\xa\11\x9\x9\11\x9\x9\x9\x6a\x51\x75\145\162\171\50\42\x23\155\157\x32\146\x5f\x6d\157\x62\151\x6c\145\137\166\141\x6c\x69\x64\141\164\151\157\x6e\x5f\146\x6f\162\x6d\x22\51\56\163\x75\x62\155\151\164\x28\x29\x3b\15\12\11\x9\x9\x9\11\11\175\x20\x65\x6c\163\145\x20\x69\146\40\x28\x73\164\141\164\x75\163\x20\75\x3d\75\40\42\x45\122\x52\x4f\122\x22\40\174\x7c\40\x73\164\x61\x74\x75\163\x20\x3d\75\x3d\x20\42\x46\101\x49\114\x45\104\42\x20\174\174\40\x73\164\x61\x74\x75\163\40\75\75\x3d\x20\42\104\105\x4e\111\x45\x44\42\40\174\174\x20\x73\x74\x61\164\x75\x73\40\x3d\x3d\75\40\x30\51\40\x7b\15\12\11\x9\11\11\x9\11\x9\x6a\121\165\x65\162\x79\50\42\x23\155\157\x32\x66\x5f\145\155\x61\151\154\137\166\x65\162\x69\146\x69\x63\141\x74\151\157\156\137\146\x61\151\x6c\145\144\x5f\x66\x6f\162\x6d\x22\51\x2e\x73\165\142\x6d\x69\164\50\51\73\15\12\x9\11\11\x9\11\x9\x7d\40\145\x6c\x73\x65\x20\173\xd\xa\11\11\11\11\11\11\11\x69\x66\x28\x63\141\154\x6c\163\74\x33\60\x30\x29\15\xa\x9\11\11\x9\x9\x9\11\173\15\12\11\11\11\x9\x9\x9\11\11\164\151\155\145\x6f\165\164\x20\x3d\40\x73\x65\164\x54\151\155\x65\157\x75\x74\x28\x65\x6d\141\x69\154\x56\x65\x72\151\146\151\143\141\164\x69\x6f\x6e\x50\x6f\154\154\54\x20\61\60\x30\x30\x29\73\15\xa\11\11\x9\11\x9\11\x9\x7d\15\xa\11\x9\11\x9\11\11\x9\145\x6c\163\145\xd\xa\x9\11\x9\x9\x9\x9\11\173\x9\x6a\x51\165\145\x72\x79\x28\42\43\x6d\x6f\62\146\x5f\145\155\141\x69\x6c\x5f\166\x65\x72\151\x66\x69\x63\x61\164\151\x6f\156\137\146\141\x69\x6c\145\144\137\146\157\x72\155\42\x29\56\x73\x75\x62\155\151\x74\50\51\73\15\xa\11\11\11\x9\x9\x9\11\175\xd\xa\x9\x9\11\x9\x9\11\175\xd\12\x20\x20\x20\40\x20\40\40\40\40\x20\x20\40\x20\x20\x20\x20\40\40\x20\40\x7d\15\xa\x20\40\40\40\40\40\40\x20\40\x20\40\x20\x20\x20\x20\40\175\51\x3b\xd\12\40\x20\x20\40\40\x20\x20\40\x20\40\40\x20\x7d\xd\12\40\x20\x20\40\x20\40\x20\40\40\40\74\x2f\x73\143\162\x69\160\x74\x3e";
        return $lW;
    }
    public function mo2f_set_gauth_secret($v1, $fK, $CM)
    {
        $EU = new Mo2f_Cloud_Utility();
        $SV = json_decode($EU->mo2f_google_auth_service($fK, "\x6d\151\156\x69\x4f\x72\x61\156\147\145\x41\x75"), true);
        return $SV;
    }
    public function mo2f_email_verification_call($current_user)
    {
        $fK = $current_user->user_email;
        $hP = $this->send_otp_token(null, $fK, MoWpnsConstants::OUT_OF_BAND_EMAIL, $current_user);
        $bC = json_decode($hP, true);
        $pd = new MoWpnsMessages();
        if (json_last_error() === JSON_ERROR_NONE) {
            goto uJ;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_REQ), "\105\122\122\117\122");
        goto gF;
        uJ:
        if (isset($bC["\x73\164\141\x74\165\x73"]) && "\105\x52\x52\117\122" === $bC["\163\164\x61\x74\165\x73"]) {
            goto e6;
        }
        if ("\123\x55\103\x43\105\123\x53" === $bC["\x73\x74\x61\x74\165\163"]) {
            goto y0;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_DURING_PROCESS), "\105\122\122\117\122");
        goto LD;
        y0:
        update_user_meta($current_user->ID, "\x6d\157\62\x66\137\x74\162\141\x6e\163\141\x63\164\x69\x6f\x6e\111\144", $bC["\164\170\111\x64"]);
        update_site_option("\155\157\x32\x66\137\164\x72\141\x6e\163\x61\143\x74\x69\157\x6e\x49\144", $bC["\x74\x78\111\144"]);
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::VERIFICATION_EMAIL_SENT) . "\x3c\142\76\x20" . $fK . "\x3c\x2f\142\x3e\x2e\40" . MoWpnsMessages::lang_translate(MoWpnsMessages::ACCEPT_LINK_TO_VERIFY_EMAIL), "\x53\125\103\103\x45\x53\x53");
        LD:
        goto so;
        e6:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate($bC["\x6d\145\163\163\141\147\145"]), "\x45\x52\122\x4f\122");
        so:
        gF:
    }
    public function mo2f_cloud_set_oob_email($current_user, $YE)
    {
        global $Gw;
        $current_user = get_userdata($current_user->ID);
        $fK = $current_user->user_email;
        $Lv = new Miniorange_Password_2Factor_Login();
        $bC = $Lv->create_user_in_miniorange($current_user->ID, $fK, $YE);
        if (isset($bC["\163\164\141\164\x75\x73"]) && "\105\x52\122\117\x52" === $bC["\x73\x74\x61\x74\165\x73"]) {
            goto Gh;
        }
        $Gw->update_user_details($current_user->ID, array("\x6d\157\x32\x66\x5f\145\x6d\141\151\154\137\166\x65\x72\x69\x66\151\x63\141\x74\x69\x6f\x6e\137\163\164\x61\x74\165\x73" => true, "\155\x6f\62\x66\137\x63\157\156\146\x69\147\165\x72\145\144\x5f\x32\146\141\137\155\145\x74\150\x6f\x64" => MoWpnsConstants::OUT_OF_BAND_EMAIL, "\x6d\x6f\x32\146\x5f\x75\163\x65\x72\137\145\x6d\x61\x69\x6c" => $fK));
        $AP = "\115\117\137\62\x5f\x46\x41\x43\124\117\122\x5f\123\x45\x54\x55\x50\137\123\x55\x43\x43\105\123\123";
        $we = '';
        goto sm;
        Gh:
        $AP = MoWpnsConstants::MO_2_FACTOR_PROMPT_USER_FOR_2FA_METHODS;
        $we = $bC["\155\x65\x73\x73\141\x67\x65"] . "\x53\153\x69\160\x20\164\150\145\x20\164\167\157\55\x66\x61\143\164\x6f\162\40\146\x6f\162\x20\x6c\157\147\151\156";
        sm:
        return array("\155\157\62\146\141\x5f\154\157\x67\x69\156\137\163\164\x61\x74\x75\163" => $AP, "\x6d\x6f\x32\x66\141\x5f\x6c\x6f\147\151\156\x5f\155\145\x73\163\x61\x67\145" => $we);
    }
    public function mo2f_set_otp_over_email($current_user, $YE, $Ty, $ok)
    {
        global $Gw;
        $Lv = new Miniorange_Password_2Factor_Login();
        $fK = $current_user->user_email;
        $bC = $Lv->create_user_in_miniorange($current_user->ID, $fK, $YE);
        if (isset($bC["\163\164\141\164\x75\x73"]) && "\x45\122\x52\x4f\x52" === $bC["\163\x74\x61\x74\x75\163"] || null === $bC) {
            goto Kr;
        }
        $oJ = $Gw->get_user_detail("\155\157\x32\x66\x5f\x75\x73\x65\162\x5f\145\155\141\x69\x6c", $current_user->ID);
        if (!(!empty($oJ) && !is_null($oJ))) {
            goto hN;
        }
        $fK = $oJ;
        hN:
        $Lv->mo2f_otp_over_email_send($fK, $ok, $Ty, $current_user);
        goto RG;
        Kr:
        $AP = MoWpnsConstants::MO_2_FACTOR_PROMPT_USER_FOR_2FA_METHODS;
        $we = isset($bC["\x6d\x65\x73\163\x61\x67\145"]) ? $bC["\155\145\x73\x73\x61\147\x65"] : "\x41\x6e\x20\165\156\x6b\156\x6f\167\156\x20\145\x72\x72\x6f\x72\x20\157\x63\143\165\162\145\x64\56";
        $we = $we . "\x20\x50\154\145\x61\163\145\x20\x74\x72\171\40\x61\147\141\151\156\x20\x6f\x72\40\x73\145\x6c\145\143\164\40\x61\x6e\157\164\150\x65\162\40\155\x65\164\150\x6f\x64\x2e";
        return array("\x6d\157\x32\146\x61\x5f\154\x6f\x67\x69\x6e\137\x73\x74\x61\164\x75\x73" => $AP, "\x6d\157\62\146\141\137\154\x6f\147\151\x6e\137\155\x65\163\163\x61\147\145" => $we);
        RG:
    }
    public function mo2f_set_google_authenticator($current_user, $YE, $EF, $Ty)
    {
        global $Gw;
        $fK = $current_user->user_email;
        $WM = $Gw->get_user_detail("\x6d\x6f\62\146\137\x75\x73\x65\162\137\145\155\x61\x69\x6c", $current_user->ID);
        if (!(!isset($WM) && !is_null($WM) && !empty($WM))) {
            goto F1;
        }
        $fK = $WM;
        F1:
        $Lv = new Miniorange_Password_2Factor_Login();
        $bC = $Lv->create_user_in_miniorange($current_user->ID, $fK, $YE);
        $we = '';
        $AP = '';
        if (isset($bC["\163\x74\141\x74\x75\x73"]) && "\105\x52\122\117\122" === $bC["\x73\164\141\164\x75\x73"]) {
            goto ON;
        }
        $Gw->update_user_details($current_user->ID, array("\155\157\62\146\x5f\x63\x6f\156\146\151\147\x75\x72\145\144\x5f\x32\x66\141\x5f\x6d\x65\x74\x68\157\x64" => $YE));
        $EU = new Mo2f_Cloud_Utility();
        $SV = json_decode($EU->mo2f_google_auth_service($fK, $EF), true);
        if (!(JSON_ERROR_NONE === json_last_error())) {
            goto pO;
        }
        if ("\x53\125\x43\x43\105\123\x53" === $SV["\x73\164\141\164\x75\x73"]) {
            goto sT;
        }
        $we = __("\x49\156\x76\x61\x6c\x69\x64\x20\x72\x65\x71\165\x65\x73\164\x2e\x20\x50\x6c\x65\141\x73\x65\x20\x72\x65\x67\x69\x73\x74\145\162\40\167\151\164\150\x20\x6d\x69\x6e\151\117\x72\x61\x6e\147\145\x20\x74\157\40\143\157\x6e\x66\151\x67\165\x72\x65\40\x32\x20\x46\x61\x63\x74\x6f\162\40\x70\x6c\x75\x67\151\x6e\x2e", "\155\151\156\x69\x6f\162\x61\x6e\x67\145\55\62\55\146\141\x63\x74\x6f\x72\x2d\x61\x75\164\150\145\156\164\x69\x63\x61\x74\151\x6f\156");
        goto n2;
        sT:
        $uX = array();
        $uX["\147\141\137\161\x72\103\x6f\144\x65"] = $SV["\161\162\x43\157\x64\145\x44\141\164\x61"];
        $uX["\x67\141\x5f\163\x65\x63\x72\145\x74"] = $SV["\x73\x65\143\x72\145\x74"];
        MO2f_Utility::mo2f_set_transient($Ty, "\163\x65\x63\x72\x65\x74\x5f\x67\141", $uX["\147\x61\137\163\x65\143\162\145\164"]);
        MO2f_Utility::mo2f_set_transient($Ty, "\147\141\137\x71\x72\x43\x6f\x64\x65", $uX["\x67\x61\137\161\x72\x43\x6f\144\145"]);
        n2:
        pO:
        goto jU;
        ON:
        $we = $bC["\x6d\145\x73\163\x61\x67\145"];
        $AP = MoWpnsConstants::MO_2_FACTOR_PROMPT_USER_FOR_2FA_METHODS;
        jU:
        return array("\155\x6f\x32\x66\141\x5f\154\x6f\147\x69\x6e\137\x73\164\x61\x74\165\x73" => $AP, "\155\x6f\x32\146\x61\137\x6c\157\x67\x69\156\x5f\x6d\145\163\x73\141\x67\145" => $we);
    }
    public function mo2f_set_user_two_fa($current_user, $YE)
    {
        global $Gw;
        $Lv = new Miniorange_Password_2Factor_Login();
        $current_user = get_userdata($current_user->ID);
        $fK = $current_user->user_email;
        $we = '';
        $AP = '';
        $bC = $Lv->create_user_in_miniorange($current_user->ID, $fK, $YE);
        if (!is_null($bC) && "\x45\122\122\117\x52" === $bC["\163\164\x61\164\x75\163"]) {
            goto ED;
        }
        $AP = MoWpnsConstants::MO_2_FACTOR_PROMPT_USER_FOR_2FA_METHODS;
        $Gw->update_user_details($current_user->ID, array("\x6d\157\62\146\x5f\143\157\x6e\146\x69\147\165\x72\145\x64\137\62\146\141\x5f\155\145\164\150\157\144" => $YE));
        goto ia;
        ED:
        $we = $bC["\155\x65\x73\x73\141\x67\145"];
        ia:
        return array("\155\157\62\x66\141\137\x6c\x6f\147\x69\x6e\137\163\164\141\x74\165\163" => $AP, "\155\x6f\x32\146\x61\x5f\154\x6f\147\x69\156\137\x6d\145\x73\x73\141\147\x65" => $we);
    }
    public function mo2f_user_profile_ga_setup($user)
    {
        if (get_user_meta($user->ID, "\155\157\x32\146\137\x67\157\157\x67\154\145\137\141\x75\x74\x68", true)) {
            goto yr;
        }
        Mo2f_Cloud_Utility::mo2f_get_g_a_parameters($user);
        yr:
        $uX = get_user_meta($user->ID, "\155\157\62\146\137\x67\157\x6f\x67\154\x65\x5f\141\165\164\150", true);
        $mC = isset($uX["\x67\x61\x5f\161\162\103\157\x64\x65"]) ? $uX["\x67\x61\137\161\x72\x43\x6f\144\145"] : null;
        $CM = isset($uX["\147\x61\x5f\x73\x65\143\x72\145\x74"]) ? $uX["\x67\141\137\163\x65\143\162\145\x74"] : null;
        echo "\74\x62\x72\x3e\74\144\151\x76\x20\x69\144\x3d\x22\144\151\163\160\154\141\x79\121\x72\103\x6f\x64\145\42\x3e\xd\12\11\x9\x9\74\151\x6d\147\40\151\x64\75\42\x6d\x6f\62\x66\137\147\141\165\x74\150\x22\40\x73\x74\171\x6c\x65\75\x22\x6c\x69\156\145\x2d\150\x65\151\x67\x68\x74\x3a\40\x30\x3b\x62\141\x63\x6b\x67\x72\x6f\x75\156\x64\x3a\x77\150\x69\164\x65\x3b\42\40\x73\x72\143\x3d\x22\144\x61\x74\x61\x3a\x69\x6d\141\147\145\x2f\152\x70\x67\73\142\x61\x73\145\66\64\54" . esc_attr($mC) . "\x22\40\x2f\x3e\15\12\x9\11\x9\x3c\57\144\x69\x76\76";
        return $CM;
    }
    public function mo2f_login_kba_verification($v1, $jg, $ok)
    {
        $HF = new Mo2f_Cloud_Validate();
        return $HF->mo2f_login_kba_verification($v1, $jg, $ok);
    }
    public function mo2f_get_user_2ndfactor($user)
    {
        global $Gw;
        $y2 = $Gw->get_user_detail("\155\157\x32\146\137\165\163\x65\162\x5f\x65\155\141\x69\x6c", $user->ID);
        $dX = $Gw->get_user_detail("\x6d\157\x32\x66\137\143\157\x6e\x66\151\147\x75\162\145\x64\x5f\62\146\141\137\x6d\145\164\x68\x6f\x64", $user->ID);
        $zh = MoWpnsConstants::OTP_OVER_TELEGRAM === $dX;
        if ($zh) {
            goto me;
        }
        $VN = new MocURL();
        $Yy = json_decode($VN->mo2f_get_userinfo($y2), true);
        if (json_last_error() === JSON_ERROR_NONE) {
            goto PU;
        }
        $Z0 = "\116\x4f\x4e\x45";
        goto iz;
        PU:
        if ("\x45\x52\x52\117\122" === $Yy["\x73\x74\141\164\x75\163"]) {
            goto bf;
        }
        if ("\123\125\103\x43\x45\x53\123" === $Yy["\163\164\141\x74\165\163"]) {
            goto nY;
        }
        if ("\x46\x41\111\114\x45\x44" === $Yy["\x73\164\141\164\x75\x73"]) {
            goto F2;
        }
        $Z0 = "\116\x4f\116\105";
        goto Ji;
        bf:
        $Z0 = "\x4e\117\x4e\x45";
        goto Ji;
        nY:
        $Z0 = $Yy["\141\x75\164\x68\124\x79\160\145"];
        goto Ji;
        F2:
        $Z0 = "\x55\x53\105\x52\137\x4e\117\124\137\106\117\125\x4e\104";
        Ji:
        iz:
        goto Cq;
        me:
        $Z0 = $dX;
        Cq:
        return $Z0;
    }
    public function mo2f_cloud_register_kba($fK, $jr, $wj, $BR, $VF, $d2, $aW)
    {
        $bC = new Mo2f_Cloud_Utility();
        return $bC->mo2f_cloud_register_kba($fK, $jr, $wj, $BR, $VF, $d2, $aW);
    }
    public function mo2f_google_auth_validate($UG, $CH, $wG)
    {
        $uU = new Mo2f_Cloud_Validate();
        $hP = $uU->mo2f_google_auth_validate($UG, $CH, $wG);
        return $hP;
    }
    public function mo2f_create_user_in_miniorange($user, $fK)
    {
        global $Gw;
        $Ip = new MocURL();
        $pd = new MoWpnsMessages();
        $Gy = json_decode($Ip->mo_check_user_already_exist($fK), true);
        if (!(json_last_error() === JSON_ERROR_NONE)) {
            goto j2;
        }
        if ("\x45\x52\x52\x4f\122" === $Gy["\x73\164\x61\164\x75\x73"]) {
            goto sf;
        }
        if (strcasecmp($Gy["\163\x74\x61\164\165\163"], "\125\x53\105\122\137\106\x4f\125\x4e\104") === 0) {
            goto Wc;
        }
        if (strcasecmp($Gy["\163\x74\141\164\x75\163"], "\x55\x53\x45\122\x5f\x4e\117\x54\x5f\106\x4f\125\116\104") === 0) {
            goto Ha;
        }
        if (strcasecmp($Gy["\163\x74\141\164\165\x73"], "\x55\x53\x45\x52\137\106\x4f\x55\116\x44\x5f\x55\x4e\x44\x45\x52\x5f\104\x49\x46\x46\105\122\x45\116\x54\137\103\x55\123\124\x4f\115\105\x52") === 0) {
            goto Pz;
        }
        goto cG;
        sf:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate($Gy["\x6d\x65\163\163\141\x67\145"]), "\x45\x52\x52\x4f\122");
        return;
        goto cG;
        Wc:
        $Gw->update_user_details($user->ID, array("\x75\x73\x65\x72\137\x72\145\x67\151\x73\164\x72\141\164\151\157\x6e\137\x77\151\x74\x68\137\155\x69\x6e\x69\157\162\x61\156\x67\x65" => "\x53\125\x43\103\x45\123\x53", "\155\157\62\146\x5f\165\163\145\x72\137\145\155\141\151\154" => $fK));
        update_site_option(base64_encode("\x74\157\164\141\x6c\x55\163\x65\162\x73\103\x6c\157\165\x64"), intval(get_site_option(base64_encode("\x74\157\164\141\154\125\163\x65\162\163\x43\x6c\157\x75\144"))) + 1);
        goto cG;
        Ha:
        $hP = json_decode($Ip->mo_create_user($user, $fK), true);
        if (!(json_last_error() === JSON_ERROR_NONE)) {
            goto Eb;
        }
        if (!(strcasecmp($hP["\163\164\141\164\165\163"], "\x53\x55\x43\103\105\123\x53") === 0)) {
            goto mM;
        }
        update_site_option(base64_encode("\164\x6f\x74\x61\154\x55\x73\x65\x72\x73\x43\154\x6f\x75\x64"), intval(get_site_option(base64_encode("\x74\157\x74\141\x6c\125\x73\x65\x72\163\x43\154\157\x75\x64"))) + 1);
        $Gw->update_user_details($user->ID, array("\x75\163\145\x72\x5f\x72\145\x67\x69\163\164\x72\141\x74\151\157\156\x5f\167\151\164\150\137\x6d\x69\156\x69\x6f\x72\141\x6e\147\145" => "\x53\125\103\103\x45\x53\123", "\155\x6f\62\x66\137\165\163\x65\x72\137\145\x6d\141\151\154" => $fK));
        mM:
        Eb:
        goto cG;
        Pz:
        $we = esc_html__("\x54\150\x65\40\x65\155\x61\x69\154\x20\141\163\163\x6f\143\x69\141\164\145\x64\x20\x77\151\x74\150\x20\x79\x6f\x75\162\40\141\143\x63\x6f\x75\x6e\164\40\151\x73\x20\x61\x6c\x72\145\141\144\171\x20\x72\x65\147\x69\x73\164\145\x72\x65\144\x20\151\x6e\40\155\x69\156\151\117\162\141\156\x67\145\56\40\x50\154\145\x61\x73\x65\40\103\x68\157\157\163\145\x20\141\156\x6f\x74\150\145\162\x20\145\x6d\141\151\154\40\157\162\40\x63\157\x6e\x74\x61\143\x74\40\x6d\151\x6e\x69\x4f\x72\x61\x6e\147\x65\56", "\155\151\x6e\x69\157\x72\x61\156\147\145\x2d\x32\x2d\146\141\x63\164\x6f\x72\x2d\141\x75\164\150\x65\156\x74\x69\143\x61\x74\x69\x6f\156");
        $pd->mo2f_show_message($we, "\x45\x52\122\117\122");
        return;
        cG:
        j2:
    }
}
aq:
