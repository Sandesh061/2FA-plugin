<?php


namespace TwoFA\Cloud;

use TwoFA\OnPrem\Mo2f_Api;
use TwoFA\Helper\MoWpnsMessages;
if (defined("\x41\x42\x53\x50\101\x54\x48")) {
    goto tC;
}
exit;
tC:
require_once dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . "\150\x65\x6c\x70\145\x72" . DIRECTORY_SEPARATOR . "\143\154\x61\x73\163\55\155\x6f\62\146\x2d\x61\x70\151\x2e\160\150\x70";
if (class_exists("\115\157\x32\146\x5f\103\154\157\x75\144\x5f\126\x61\154\151\x64\141\x74\145")) {
    goto sE;
}
class Mo2f_Cloud_Utility
{
    private $mo2f_api;
    public function __construct()
    {
        $this->mo2f_api = Mo2f_Api::instance();
    }
    public static function mo2f_get_g_a_parameters($user)
    {
        global $Gw;
        $fK = $Gw->get_user_detail("\155\157\x32\146\x5f\x75\163\x65\x72\x5f\145\x6d\x61\x69\x6c", $user->ID);
        $ic = get_site_option("\155\x6f\62\146\137\147\x6f\x6f\147\154\145\x5f\141\160\160\156\x61\x6d\x65");
        $ic = $ic ? $ic : "\x6d\x69\x6e\151\117\162\x61\156\x67\x65\x41\165";
        $mj = new Mo2f_Cloud_Utility();
        $SV = json_decode($mj->mo2f_google_auth_service($fK, $ic), true);
        $pd = new MoWpnsMessages();
        if (json_last_error() === JSON_ERROR_NONE) {
            goto DP;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_DURING_USER_REGISTRATION), "\105\122\122\117\x52");
        goto hH;
        DP:
        if ("\x53\125\x43\103\105\x53\x53" === $SV["\163\164\x61\164\165\163"]) {
            goto f3;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_DURING_USER_REGISTRATION), "\x45\x52\122\117\122");
        goto Yw;
        f3:
        $uX = array();
        $uX["\x67\141\137\x71\162\x43\x6f\144\145"] = $SV["\x71\162\103\x6f\x64\x65\x44\x61\164\x61"];
        $uX["\147\141\x5f\x73\x65\x63\x72\145\164"] = $SV["\163\x65\x63\x72\x65\x74"];
        update_user_meta($user->ID, "\x6d\157\62\146\x5f\x67\157\157\147\x6c\145\137\x61\165\164\150", $uX);
        Yw:
        hH:
    }
    public function mo2f_google_auth_service($UG, $nv = '')
    {
        $xz = MO_HOST_NAME . "\x2f\x6d\157\141\x73\57\x61\160\151\57\141\x75\x74\150\x2f\147\157\157\x67\x6c\x65\55\141\165\x74\x68\x2d\x73\145\x63\x72\x65\164";
        $hS = get_site_option("\155\157\x32\146\137\x63\x75\x73\164\157\155\145\162\113\x65\x79");
        $e5 = array("\x63\165\163\164\157\x6d\x65\x72\x4b\145\x79" => $hS, "\x75\x73\x65\x72\x6e\x61\155\x65" => $UG, "\x61\165\x74\150\x65\156\x74\x69\143\x61\164\157\162\116\141\155\x65" => $nv);
        $LB = $this->mo2f_api->get_http_header_array();
        return $this->mo2f_api->mo2f_http_request($xz, $e5, $LB);
    }
    public function mo2f_cloud_register_kba($fK, $jr, $wj, $BR, $VF, $d2, $aW)
    {
        $xz = MO_HOST_NAME . "\x2f\x6d\x6f\x61\x73\x2f\141\x70\151\57\141\165\x74\x68\x2f\x72\x65\147\151\163\x74\x65\x72";
        $hS = get_site_option("\155\x6f\62\146\137\x63\165\x73\x74\157\155\x65\162\x4b\x65\x79");
        $BB = "\133\x7b\x22\161\165\x65\163\x74\151\x6f\x6e\x22\x3a\42" . $jr . "\x22\x2c\42\x61\x6e\x73\x77\145\162\x22\x3a\42" . $VF . "\x22\x20\175\x2c\173\x22\x71\x75\x65\163\x74\151\x6f\156\42\x3a\42" . $wj . "\x22\54\x22\141\156\163\167\x65\x72\x22\72\42" . $d2 . "\42\x20\x7d\54\x7b\42\x71\165\x65\163\x74\151\x6f\156\42\x3a\x22" . $BR . "\x22\54\x22\141\x6e\163\x77\145\162\42\72\x22" . $aW . "\42\40\175\x5d";
        $e5 = "\x7b\42\143\x75\x73\164\x6f\155\145\162\x4b\145\171\42\72\x22" . $hS . "\x22\x2c\42\165\163\145\162\x6e\x61\155\x65\x22\x3a\x22" . $fK . "\42\54\x22\161\x75\x65\x73\164\x69\157\x6e\101\156\x73\167\145\x72\x4c\x69\163\164\x22\72" . $BB . "\175";
        $LB = $this->mo2f_api->get_http_header_array();
        $bC = $this->mo2f_api->mo2f_http_request($xz, $e5, $LB);
        return $bC;
    }
}
new Mo2f_Cloud_Utility();
sE:
