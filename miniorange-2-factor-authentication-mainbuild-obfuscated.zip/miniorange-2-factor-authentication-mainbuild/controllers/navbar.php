<?php


use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Helper\MoWpnsHandler;
if (defined("\x41\x42\x53\x50\x41\124\x48")) {
    goto rB;
}
exit;
rB:
$dk = isset($_POST["\x6d\157\137\x73\x65\143\x75\162\151\164\x79\x5f\146\145\x61\164\165\162\145\163\137\156\157\x6e\x63\145"]) ? sanitize_key(wp_unslash($_POST["\x6d\157\137\x73\145\x63\165\x72\151\164\x79\x5f\146\145\x61\x74\165\x72\145\x73\x5f\x6e\x6f\156\x63\x65"])) : '';
if (!wp_verify_nonce($dk, "\155\x6f\x5f\x32\x66\141\137\x73\x65\143\165\x72\151\164\x79\x5f\146\x65\141\x74\165\162\x65\163\137\156\x6f\x6e\143\x65")) {
    goto s6;
}
global $uz, $V0;
if (!(current_user_can("\155\141\156\x61\147\145\137\157\x70\164\151\157\156\163") && isset($_POST["\x6f\x70\x74\x69\157\156"]))) {
    goto By;
}
switch (sanitize_text_field(wp_unslash($_POST["\157\x70\164\x69\157\x6e"]))) {
    case "\x6d\157\x5f\x77\160\156\x73\x5f\62\x66\141\137\167\151\164\150\x5f\156\x65\x74\167\x6f\162\x6b\x5f\163\145\x63\165\162\x69\x74\x79":
        $OV = new Mo2fa_Security_Features();
        $OV->wpns_2fa_with_network_security($_POST);
        goto LR;
}
ig:
LR:
By:
goto y8;
s6:
$s0 = new WP_Error();
$s0->add("\x65\155\160\x74\171\137\x75\x73\145\162\156\141\x6d\145", "\x3c\163\164\162\157\x6e\147\76" . __("\x45\x52\122\117\122", "\155\151\156\x69\x6f\x72\141\156\147\145\55\62\55\x66\141\x63\164\157\162\x2d\x61\165\164\150\x65\x6e\x74\151\x63\141\164\151\157\x6e") . "\74\x2f\163\164\x72\x6f\156\x67\x3e\72\x20" . __("\111\x6e\166\x61\x6c\151\144\40\x52\x65\x71\165\x65\163\x74\x2e", "\x6d\151\x6e\151\x6f\x72\x61\156\147\x65\x2d\x32\x2d\146\x61\143\x74\x6f\162\x2d\x61\165\164\150\x65\156\164\151\x63\x61\x74\151\x6f\x6e"));
y8:
$cx = MoWpnsUtility::get_mo2f_db_option("\155\157\x5f\167\x70\x6e\x73\137\x32\x66\141\137\167\x69\164\x68\x5f\x6e\145\164\x77\157\x72\153\137\x73\x65\x63\165\x72\x69\164\171", "\x73\151\164\x65\x5f\x6f\160\164\151\x6f\x6e") ? "\x63\x68\x65\x63\153\x65\x64" : '';
if (!isset($_GET["\160\x61\x67\x65"])) {
    goto Ag;
}
$yk = get_site_option("\155\x6f\x32\146\137\164\141\142\x5f\143\157\x75\x6e\164", 0);
switch (sanitize_text_field(wp_unslash($_GET["\x70\x61\147\x65"]))) {
    case "\x6d\x6f\137\x32\146\141\x5f\x61\x64\166\x61\156\143\x65\x64\x62\x6c\157\x63\x6b\151\x6e\147":
        update_site_option("\x6d\157\x5f\62\146\137\x73\167\x69\164\x63\150\137\x61\144\166\x5f\142\x6c\157\x63\x6b", 1);
        if (!($yk < 5 && !get_site_option("\155\x6f\x5f\x32\146\x5f\163\x77\151\x74\143\x68\137\x61\144\x76\x5f\x62\x6c\157\x63\x6b"))) {
            goto QK;
        }
        update_site_option("\x6d\x6f\62\x66\137\x74\141\142\x5f\x63\x6f\x75\156\164", get_site_option("\x6d\x6f\x32\146\x5f\164\x61\142\137\x63\157\165\x6e\x74") + 1);
        QK:
        goto Rp;
}
Q0:
Rp:
Ag:
$LN = esc_url(add_query_arg(array("\x70\x61\147\145" => "\x6d\157\x5f\62\x66\x61\x5f\162\145\x71\165\x65\163\164\137\x6f\x66\146\x65\162"), isset($_SERVER["\x52\x45\121\125\105\123\124\137\x55\122\x49"]) ? esc_url_raw(wp_unslash($_SERVER["\x52\105\121\x55\x45\123\124\x5f\125\122\x49"])) : ''));
$AZ = plugin_dir_url(dirname(__FILE__)) . "\x69\x6e\143\154\x75\144\145\x73\x2f\x69\155\x61\147\x65\x73\x2f\x6d\151\x6e\x69\157\x72\141\156\x67\x65\x2d\156\145\x77\x2d\154\157\x67\157\56\160\156\147";
$nM = new MoWpnsHandler();
$BC = $nM->is_whitelisted($uz->get_client_ip());
$Hd = isset($_GET["\160\x61\x67\145"]) ? sanitize_text_field(wp_unslash($_GET["\160\x61\147\145"])) : '';
$v1 = get_current_user_id();
$HP = $Gw->get_user_detail("\x6d\157\62\x66\137\x63\x6f\x6e\146\151\x67\x75\x72\145\144\x5f\x32\x46\x41\x5f\x6d\x65\164\150\157\144", $v1);
$zD = get_user_meta($v1, "\x6d\157\x32\146\x5f\142\x61\x63\x6b\165\160\x5f\143\x6f\144\145\163", true);
if (is_array($zD)) {
    goto fu;
}
$zD = 0;
goto sK;
fu:
$zD = count($zD);
sK:
require $V0 . "\x76\x69\x65\x77\x73" . DIRECTORY_SEPARATOR . "\x6e\141\166\142\141\162\56\160\150\x70";
