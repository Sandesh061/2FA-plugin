<?php


use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Helper\Mo2f_Common_Helper;
if (defined("\x41\102\x53\120\101\x54\110")) {
    goto V6;
}
exit;
V6:
$SP = apply_filters("\x6d\157\x32\x66\x5f\x69\x73\137\x6c\166\137\156\145\x65\x64\x65\144", false);
$cB = new Mo2f_Common_Helper();
$ad = isset($_GET["\x70\x61\x67\145"]) ? sanitize_text_field(wp_unslash($_GET["\x70\x61\147\145"])) : $cB->mo2f_get_default_page($SP);
if (!(current_user_can("\x6d\141\156\x61\x67\145\137\x6f\160\x74\x69\157\x6e\163") || "\x6d\x6f\137\x32\146\141\137\x6d\x79\x5f\141\x63\x63\x6f\165\156\164" === $ad)) {
    goto H_;
}
echo "\x3c\144\151\x76\x20\151\144\75\42\x6d\x6f\x5f\x73\x63\x61\156\x5f\155\145\163\x73\x61\147\145\x22\x20\x73\164\171\x6c\145\75\42\x70\x61\x64\x64\151\156\147\x2d\164\157\160\72\x38\x70\x78\x22\x3e\74\57\144\x69\x76\x3e\15\xa\15\xa\x9\x9\x3c\x64\x69\166\40\143\154\x61\163\x73\75\42\155\x6f\62\146\x2d\x74\x77\55\146\154\145\170\142\x6f\170\x22\76\xd\12\11\11\11";
$Q_ = $VD->tab_details;
if (!isset($Q_)) {
    goto IM;
}
foreach ($Q_ as $WW) {
    if (!($WW->menu_slug === $ad)) {
        goto E3;
    }
    echo "\74\x64\x69\x76\x20\143\154\x61\x73\x73\x3d\42\x6d\x6f\62\146\x2d\164\x77\55\164\x61\142\154\x65\55\154\x61\x79\157\x75\164\x22\x20\x69\144\75\42" . esc_attr($ad) . "\137\x64\x69\x76\x22\x3e";
    $d1 = $WW->nav_tabs;
    if (in_array("\115\171\40\101\143\x63\x6f\165\156\x74", $d1, true)) {
        goto xj;
    }
    echo "\74\x64\151\166\x20\x63\x6c\x61\x73\x73\75\x22\x6d\157\x32\146\x2d\x74\x77\x2d\x73\x75\x62\164\x61\x62\55\167\162\141\160\x70\145\x72\42\x3e";
    foreach ($d1 as $EN) {
        $Ye = strtolower(str_replace("\x20", '', $EN));
        echo "\x3c\141\x20\150\162\145\146\75\42" . esc_url(admin_url()) . "\x61\x64\155\151\156\56\x70\x68\x70\x3f\160\x61\147\145\x3d" . esc_attr($ad) . "\x26\x73\x75\142\160\x61\x67\x65\x3d" . esc_attr($Ye) . "\x22\40\143\x6c\141\x73\163\x3d\42\155\157\62\x66\55\x74\x77\55\163\x75\142\x74\141\142\x22\x20\x69\x64\x3d\42" . esc_attr($Ye) . "\42\x3e\40" . esc_html(MoWpnsMessages::lang_translate($EN)) . "\74\57\141\76";
        oX:
    }
    PI:
    echo "\74\57\x64\x69\166\x3e";
    echo empty($d1) ? '' : "\x3c\x68\x72\76";
    xj:
    if (isset($_GET["\163\165\142\x70\x61\x67\x65"])) {
        goto Dm;
    }
    require_once $V0 . "\x63\x6f\156\164\162\x6f\154\154\145\162\163" . DIRECTORY_SEPARATOR . $WW->view;
    goto ap;
    Dm:
    $Kv = sanitize_text_field(wp_unslash($_GET["\x73\165\142\x70\141\x67\145"]));
    foreach ($d1 as $EN) {
        $Ye = strtolower(str_replace("\40", '', $EN));
        if (!($Kv === $Ye)) {
            goto Dh;
        }
        require_once $V0 . "\143\x6f\x6e\164\x72\157\x6c\x6c\x65\162\163" . DIRECTORY_SEPARATOR . strtolower(str_replace("\40", '', $WW->page_title)) . DIRECTORY_SEPARATOR . $Ye . "\x2e\160\150\160";
        Dh:
        GL:
    }
    l5:
    ap:
    echo "\x9\x9\x9\11\x9\x9\x3c\x2f\144\151\x76\x3e\15\xa\x9\x9\11\11\x9\x9\11";
    E3:
    Fm:
}
WO:
IM:
echo "\x9\11\74\x2f\x64\x69\166\76\xd\xa\11\11";
H_:
