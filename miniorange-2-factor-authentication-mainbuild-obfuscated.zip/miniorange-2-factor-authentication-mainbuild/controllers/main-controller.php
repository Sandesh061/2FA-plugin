<?php


if (defined("\101\102\x53\x50\x41\124\x48")) {
    goto fV;
}
exit;
fV:
use TwoFA\Objects\Mo2f_TabDetails;
global $uz, $V0;
$B6 = $V0 . "\143\x6f\156\x74\162\157\154\154\x65\x72\163" . DIRECTORY_SEPARATOR;
require_once $B6 . "\156\x61\x76\x62\141\162\x2e\x70\x68\x70";
$VD = Mo2f_TabDetails::instance();
require_once $B6 . "\x6d\x61\151\x6e\55\155\x65\156\165\x2e\x70\x68\160";
$bl = isset($_GET["\160\x61\x67\x65"]) ? sanitize_text_field(wp_unslash($_GET["\x70\141\x67\x65"])) : '';
echo "\74\144\x69\x76\40\151\144\x3d\42\155\157\62\x66\137\62\146\x61\x5f\160\157\160\165\160\x5f\x64\x61\x73\150\142\x6f\141\x72\x64\x22\x20\x63\154\x61\x73\163\75\x22\x6d\157\144\141\154\42\x20\x68\x69\144\x64\145\x6e\x3e\74\x2f\144\151\166\76\xd\12";
require_once $B6 . DIRECTORY_SEPARATOR . "\164\167\157\x2d\146\x61\143\164\x6f\x72\55\160\141\x67\x65\56\160\x68\x70";
if (!current_user_can("\x6d\x61\x6e\141\147\x65\x5f\x6f\x70\164\x69\157\x6e\163")) {
    goto tD;
}
require $B6 . "\143\x6f\156\164\x61\x63\x74\165\163\x2e\160\150\160";
tD:
