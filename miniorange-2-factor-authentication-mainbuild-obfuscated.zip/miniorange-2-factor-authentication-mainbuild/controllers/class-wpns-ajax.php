<?php


use TwoFA\Onprem\Miniorange_Password_2Factor_Login;
use TwoFA\Onprem\Miniorange_Authentication;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Helper\MocURL;
if (defined("\x41\x42\x53\120\101\124\110")) {
    goto fJ;
}
exit;
fJ:
if (class_exists("\x57\160\156\163\x5f\x41\152\x61\170")) {
    goto A_;
}
class Wpns_Ajax
{
    public function __construct()
    {
        add_action("\x61\x64\155\x69\x6e\x5f\151\156\x69\x74", array($this, "\x6d\157\137\154\x6f\147\x69\156\137\163\x65\x63\165\162\151\x74\x79\137\x61\x6a\x61\170"));
        add_action("\x69\x6e\x69\x74", array($this, "\155\157\62\146\x61\x5f\145\154\x65\155\x65\156\x74\157\x72\x5f\x61\x6a\x61\170\137\x66\x75\x6e"));
    }
    public function mo_login_security_ajax()
    {
        add_action("\x77\x70\x5f\x61\x6a\141\x78\x5f\167\x70\156\163\137\154\x6f\x67\x69\156\x5f\163\x65\143\165\162\151\x74\171", array($this, "\x77\160\x6e\163\137\x6c\157\147\151\x6e\x5f\x73\x65\x63\x75\x72\x69\x74\x79"));
        add_action("\167\160\137\x61\152\x61\x78\137\155\x6f\62\146\x5f\x61\x6a\x61\x78", array($this, "\x6d\x6f\62\x66\137\141\x6a\x61\x78"));
        add_action("\x77\x70\x5f\x61\x6a\x61\x78\137\x6e\x6f\160\x72\151\x76\137\x6d\x6f\x32\146\x5f\141\152\x61\x78", array($this, "\x6d\157\62\x66\137\x61\x6a\141\x78"));
    }
    public function mo2f_ajax()
    {
        if (check_ajax_referer("\x6d\151\x6e\151\157\162\x61\156\x67\145\55\62\x2d\x66\141\143\x74\x6f\162\x2d\x6c\157\x67\x69\x6e\x2d\156\157\x6e\x63\x65", "\x6e\x6f\156\x63\145", false)) {
            goto oj;
        }
        wp_send_json_error("\x63\154\x61\163\163\55\x77\x70\156\x73\55\x61\x6a\x61\170");
        oj:
        $GLOBALS["\155\x6f\x32\146\x5f\151\163\x5f\x61\152\141\170\137\x72\x65\161\x75\x65\x73\164"] = true;
        $Xh = isset($_POST["\x6d\157\62\146\137\141\152\x61\170\137\157\160\164\x69\x6f\156"]) ? sanitize_text_field(wp_unslash($_POST["\155\157\62\146\x5f\x61\152\x61\x78\x5f\x6f\160\x74\x69\x6f\x6e"])) : '';
        switch ($Xh) {
            case "\155\157\x32\x66\x5f\x61\152\141\x78\137\x6c\157\x67\151\x6e":
                $this->mo2f_ajax_login();
                goto LI;
        }
        cL:
        LI:
    }
    public function mo2fa_elementor_ajax_fun()
    {
        if (!isset($_POST["\x6d\151\156\x69\157\162\141\x6e\147\145\137\145\154\145\155\x65\x6e\x74\x6f\x72\137\154\x6f\x67\151\x6e\x5f\156\x6f\x6e\143\145"])) {
            goto Be;
        }
        if (check_ajax_referer("\155\151\156\151\x6f\162\x61\x6e\x67\x65\x2d\62\x2d\146\141\143\x74\x6f\x72\x2d\x6c\x6f\x67\x69\x6e\55\156\157\156\x63\145", "\x6d\151\156\x69\x6f\162\141\156\147\x65\x5f\145\x6c\x65\155\x65\156\x74\x6f\162\x5f\x6c\157\x67\151\x6e\137\x6e\x6f\156\x63\x65", false)) {
            goto b8;
        }
        wp_send_json_error("\x63\x6c\x61\163\163\55\167\160\156\x73\55\x61\x6a\x61\x78");
        b8:
        if (!(isset($_POST["\x6d\157\x32\146\141\137\x65\x6c\x65\x6d\145\x6e\164\x6f\162\x5f\165\163\x65\x72\137\160\x61\x73\x73\x77\x6f\162\144"]) && !empty($_POST["\155\x6f\x32\x66\141\137\x65\x6c\x65\155\145\156\164\157\x72\x5f\x75\x73\145\162\x5f\x70\141\163\163\167\157\x72\144"]) && isset($_POST["\x6d\x6f\62\x66\141\137\145\x6c\145\x6d\145\x6e\164\157\x72\137\x75\163\145\x72\137\156\141\x6d\145"]))) {
            goto L3;
        }
        $qS = array();
        $qS["\x75\163\x65\x72\137\154\157\x67\151\156"] = sanitize_user(wp_unslash($_POST["\x6d\x6f\62\146\x61\137\145\154\x65\155\x65\x6e\164\157\162\137\165\x73\x65\162\137\156\x61\x6d\x65"]));
        $qS["\x75\x73\x65\x72\137\x70\141\x73\163\167\x6f\x72\144"] = $_POST["\x6d\157\x32\146\141\x5f\145\x6c\145\155\x65\x6e\164\157\162\x5f\165\163\x65\162\137\160\x61\163\x73\167\x6f\x72\144"];
        $qS["\162\x65\x6d\x65\155\x62\145\x72"] = false;
        $wU = wp_signon($qS, false);
        if (!is_wp_error($wU)) {
            goto JL;
        }
        wp_send_json_error(array("\x6c\x6f\147\x67\x65\x64\151\x6e" => false, "\x6d\145\163\163\x61\147\145" => __("\127\162\157\156\x67\40\165\163\145\162\156\x61\x6d\x65\40\x6f\x72\40\160\141\163\x73\x77\x6f\162\144\x2e")));
        JL:
        L3:
        Be:
    }
    public function wpns_login_security()
    {
        if (!(!check_ajax_referer("\114\x6f\x67\151\x6e\123\145\143\x75\x72\x69\164\x79\x4e\157\156\143\x65", "\x6e\x6f\156\143\x65", false) || !current_user_can("\155\x61\x6e\x61\x67\x65\137\x6f\160\164\x69\x6f\156\163"))) {
            goto Z0;
        }
        wp_send_json_error("\143\154\x61\163\x73\x2d\x77\160\156\x73\x2d\141\x6a\141\170");
        Z0:
        $Xh = isset($_POST["\x77\x70\156\163\x5f\154\x6f\147\x69\x6e\x73\145\143\x75\162\x69\x74\x79\137\141\x6a\x61\x78"]) ? sanitize_text_field(wp_unslash($_POST["\167\x70\156\x73\x5f\x6c\x6f\x67\x69\x6e\163\145\x63\165\x72\151\164\171\137\x61\152\x61\x78"])) : '';
        switch ($Xh) {
            case "\167\x70\156\x73\137\x61\x6c\154\x5f\x70\x6c\141\156\163":
                $this->wpns_all_plans();
                goto cD;
            case "\165\160\144\x61\x74\x65\137\160\154\x61\156":
                $this->update_plan();
                goto cD;
        }
        rC:
        cD:
    }
    public function update_plan()
    {
        if (check_ajax_referer("\114\157\147\x69\x6e\123\145\x63\x75\x72\151\164\171\116\157\156\x63\145", "\156\157\x6e\143\145", false)) {
            goto L6;
        }
        wp_send_json_error("\143\154\x61\163\x73\55\167\160\156\163\55\x61\152\x61\x78");
        L6:
        $Qj = isset($_POST["\x70\x6c\141\x6e\x6e\x61\x6d\x65"]) ? sanitize_text_field(wp_unslash($_POST["\x70\154\141\x6e\x6e\x61\x6d\x65"])) : '';
        $H3 = isset($_POST["\x70\x6c\x61\x6e\124\x79\x70\x65"]) ? sanitize_text_field(wp_unslash($_POST["\160\x6c\x61\156\124\171\160\x65"])) : '';
        update_site_option("\155\157\x32\146\x5f\x70\154\141\x6e\x6e\141\x6d\145", $Qj);
        if ("\141\144\x64\x6f\156\x5f\x70\x6c\141\x6e" === $Qj) {
            goto O7;
        }
        if ("\62\146\141\x5f\x70\154\141\x6e" === $Qj) {
            goto M2;
        }
        goto RA;
        O7:
        update_site_option("\155\157\62\x66\x5f\160\x6c\x61\x6e\x6e\x61\x6d\145", "\x61\x64\x64\157\x6e\137\160\154\141\156");
        update_site_option("\155\157\x5f\x32\146\x61\137\141\144\144\157\156\137\x70\154\x61\x6e\137\164\x79\160\x65", $H3);
        goto RA;
        M2:
        update_site_option("\x6d\x6f\x32\x66\137\x70\154\x61\156\x6e\x61\155\x65", "\x32\x66\x61\137\160\x6c\141\x6e");
        update_site_option("\x6d\157\137\62\146\x61\137\x70\x6c\x61\156\137\x74\x79\160\145", $H3);
        RA:
    }
    public function mo2f_ajax_login()
    {
        if (!check_ajax_referer("\x6d\151\156\x69\157\x72\141\156\147\145\x2d\x32\55\x66\141\143\164\157\162\x2d\154\157\x67\x69\156\x2d\x6e\157\156\x63\x65", "\156\157\156\143\x65", false)) {
            goto i_;
        }
        $Zi = isset($_POST["\165\163\x65\x72\156\x61\155\x65"]) ? sanitize_user(wp_unslash($_POST["\x75\163\145\162\156\x61\x6d\x65"])) : '';
        $uk = isset($_POST["\160\141\x73\x73\167\x6f\162\144"]) ? $_POST["\x70\141\163\x73\167\x6f\162\x64"] : '';
        apply_filters("\x61\165\x74\x68\x65\156\164\x69\143\x61\x74\x65", null, $Zi, $uk);
        goto tM;
        i_:
        wp_send_json_error("\143\x6c\141\163\163\55\167\160\156\x73\x2d\141\x6a\141\170");
        tM:
    }
    public function wpns_all_plans()
    {
        if (check_ajax_referer("\x4c\157\x67\x69\x6e\123\x65\143\165\162\x69\164\171\x4e\x6f\156\143\x65", "\x6e\157\156\143\x65", false)) {
            goto D3;
        }
        wp_send_json_error("\143\x6c\x61\163\163\55\x77\x70\x6e\x73\55\141\x6a\x61\170");
        D3:
        $Qj = isset($_POST["\x70\154\x61\x6e\x6e\x61\x6d\x65"]) ? sanitize_text_field(wp_unslash($_POST["\x70\x6c\141\156\x6e\x61\x6d\145"])) : '';
        $H3 = isset($_POST["\x70\x6c\141\x6e\124\171\x70\x65"]) ? sanitize_text_field(wp_unslash($_POST["\160\x6c\141\x6e\x54\171\160\x65"])) : '';
        update_site_option("\x6d\x6f\x32\146\137\160\x6c\141\x6e\156\x61\155\145", $Qj);
        if ("\x61\x64\x64\157\x6e\137\160\x6c\x61\156" === $Qj) {
            goto Rt;
        }
        if ("\x32\x66\141\137\x70\x6c\x61\156" === $Qj) {
            goto qS;
        }
        goto X9;
        Rt:
        update_site_option("\155\x6f\62\x66\137\160\x6c\141\156\x6e\x61\x6d\x65", "\x61\144\144\157\156\x5f\x70\x6c\x61\x6e");
        update_site_option("\x6d\x6f\137\x32\x66\141\137\141\x64\x64\x6f\156\137\160\x6c\x61\156\x5f\164\x79\x70\145", $H3);
        update_site_option("\155\157\x32\146\x5f\143\165\163\164\x6f\155\x65\162\137\163\145\154\145\143\x74\145\x64\137\160\x6c\x61\x6e", $H3);
        goto X9;
        qS:
        update_site_option("\155\157\x32\x66\137\x70\154\141\156\156\141\155\x65", "\x32\146\x61\x5f\160\x6c\x61\156");
        update_site_option("\x6d\x6f\137\x32\x66\141\137\160\154\x61\x6e\x5f\x74\x79\160\145", $H3);
        update_site_option("\155\x6f\62\146\x5f\x63\x75\x73\x74\157\155\145\162\x5f\x73\x65\x6c\x65\x63\x74\x65\144\137\x70\154\141\x6e", $H3);
        X9:
    }
}
new Wpns_Ajax();
A_:
