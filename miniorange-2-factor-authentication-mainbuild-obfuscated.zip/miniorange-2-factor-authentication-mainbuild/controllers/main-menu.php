<?php


use TwoFA\Objects\Mo2f_TabDetails;
if (defined("\x41\x42\x53\x50\101\124\x48")) {
    goto Xy;
}
exit;
Xy:
use TwoFA\Helper\MoWpnsUtility;
$Ns = isset($_GET["\160\x61\x67\x65"]) ? sanitize_text_field(wp_unslash($_GET["\160\141\x67\145"])) : (current_user_can("\x6d\x61\x6e\141\x67\145\x5f\157\160\x74\151\157\156\x73") ? "\x6d\x6f\x5f\62\x66\141\137\x74\167\x6f\x5f\x66\x61" : "\x6d\157\137\62\x66\x61\137\x6d\x79\x5f\141\143\x63\157\x75\x6e\164");
$I8 = MoWpnsUtility::get_mo2f_db_option("\x6d\157\x5f\167\160\x6e\163\x5f\62\146\141\x5f\167\x69\x74\150\x5f\156\145\164\x77\157\162\153\137\163\x65\x63\165\162\x69\x74\171", "\163\x69\x74\145\137\157\x70\x74\x69\x6f\x6e");
$VD = Mo2f_TabDetails::instance();
require $V0 . "\166\151\x65\x77\x73" . DIRECTORY_SEPARATOR . "\155\x61\151\156\55\155\x65\156\165\x2e\x70\x68\x70";
