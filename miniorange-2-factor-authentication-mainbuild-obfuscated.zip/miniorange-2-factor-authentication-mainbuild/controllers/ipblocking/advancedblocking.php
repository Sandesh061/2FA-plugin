<?php


if (defined("\x41\x42\x53\120\x41\124\110")) {
    goto bm;
}
exit;
bm:
$z0 = is_numeric(get_site_option("\155\157\137\x77\x70\156\x73\137\151\160\x72\x61\x6e\147\145\x5f\143\157\165\x6e\x74")) && intval(get_site_option("\x6d\x6f\137\167\160\156\163\x5f\151\160\x72\141\156\x67\145\x5f\x63\157\165\x6e\164")) !== 0 ? intval(get_site_option("\155\157\137\167\160\x6e\163\x5f\x69\x70\162\141\156\147\145\x5f\x63\157\x75\x6e\164")) : 1;
$ET = 1;
hq:
if (!($ET <= $z0)) {
    goto uG;
}
$H2 = get_site_option("\x6d\x6f\137\167\160\x6e\163\137\x69\x70\x72\x61\x6e\x67\145\x5f\x72\141\x6e\147\x65\137" . $ET);
if (!$H2) {
    goto w0;
}
$Sq = explode("\55", $H2);
$rp[$ET] = $Sq[0];
$xk[$ET] = $Sq[1];
w0:
kF:
$ET++;
goto hq;
uG:
if (isset($rp[1])) {
    goto du;
}
$rp[1] = '';
du:
if (isset($xk[1])) {
    goto pu;
}
$xk[1] = '';
pu:
require_once dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . "\x76\x69\x65\x77\x73" . DIRECTORY_SEPARATOR . "\x74\x77\x6f\x66\x61" . DIRECTORY_SEPARATOR . "\154\x69\156\153\55\164\x72\141\x63\x65\162\56\160\x68\160";
require dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . "\166\151\x65\x77\163" . DIRECTORY_SEPARATOR . "\151\160\x62\x6c\x6f\143\x6b\x69\x6e\147" . DIRECTORY_SEPARATOR . "\x61\144\x76\x61\156\x63\145\x64\142\x6c\x6f\x63\153\x69\x6e\x67\x2e\160\x68\160";
