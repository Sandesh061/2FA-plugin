<?php


if (defined("\x41\x42\x53\x50\x41\124\110")) {
    goto P4;
}
exit;
P4:
require_once dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . "\x76\151\145\167\x73" . DIRECTORY_SEPARATOR . "\164\167\157\x66\x61" . DIRECTORY_SEPARATOR . "\x6c\x69\x6e\153\55\164\x72\141\143\x65\x72\56\x70\x68\160";
require dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . "\166\x69\x65\167\163" . DIRECTORY_SEPARATOR . "\x69\x70\142\x6c\x6f\x63\x6b\x69\156\x67" . DIRECTORY_SEPARATOR . "\x69\x70\142\x6c\x61\143\x6b\154\x69\x73\x74\x2e\x70\x68\160";
