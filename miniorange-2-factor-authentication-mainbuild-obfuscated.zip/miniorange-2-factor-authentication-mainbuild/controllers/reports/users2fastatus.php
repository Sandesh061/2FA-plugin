<?php


use TwoFA\Helper\Mo2f_Common_Helper;
if (defined("\x41\102\123\120\101\124\110")) {
    goto g4;
}
exit;
g4:
$cB = new Mo2f_Common_Helper();
require_once $V0 . "\166\x69\x65\167\x73" . DIRECTORY_SEPARATOR . "\162\x65\x70\157\162\x74\x73" . DIRECTORY_SEPARATOR . "\165\163\x65\x72\x73\62\146\x61\x73\x74\141\x74\165\163\x2e\x70\x68\160";
