<?php


if (defined("\101\x42\x53\x50\101\124\x48")) {
    goto U2;
}
exit;
U2:
use TwoFA\Helper\MoWpnsHandler;
use TwoFA\Helper\Mo2f_Common_Helper;
global $uz, $V0;
$g8 = new MoWpnsHandler();
$np = $g8->get_login_transaction_report();
$cB = new Mo2f_Common_Helper();
require $V0 . "\x76\151\x65\167\163" . DIRECTORY_SEPARATOR . "\x72\145\x70\x6f\x72\x74\x73" . DIRECTORY_SEPARATOR . "\x6c\157\147\151\156\162\x65\x70\x6f\x72\164\x2e\x70\150\160";
