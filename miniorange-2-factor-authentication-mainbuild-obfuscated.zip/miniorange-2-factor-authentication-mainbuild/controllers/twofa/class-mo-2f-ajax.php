<?php


use TwoFA\Onprem\MO2f_Utility;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Onprem\Two_Factor_Setup_Onprem_Cloud;
use TwoFA\Database\Mo2fDB;
use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Helper\MocURL;
use TwoFA\Onprem\MO2f_Cloud_Onprem_Interface;
use TwoFA\Onprem\Miniorange_Password_2Factor_Login;
use TwoFA\Onprem\Google_Auth_Onpremise;
if (defined("\101\102\x53\x50\101\124\x48")) {
    goto uU;
}
exit;
uU:
if (class_exists("\115\157\x5f\x32\146\x5f\x41\152\141\170")) {
    goto y1;
}
class Mo_2f_Ajax
{
    private $mo2f_onprem_cloud_obj;
    public function __construct()
    {
        $this->mo2f_onprem_cloud_obj = MO2f_Cloud_Onprem_Interface::instance();
        add_action("\141\144\x6d\151\x6e\x5f\x69\x6e\151\164", array($this, "\155\x6f\x5f\x32\x66\x5f\164\x77\x6f\137\x66\141\x63\164\x6f\x72"));
    }
    public function mo_2f_two_factor()
    {
        add_action("\x77\160\x5f\141\x6a\141\x78\x5f\155\x6f\x5f\164\x77\x6f\137\x66\x61\x63\164\157\x72\x5f\141\x6a\x61\x78", array($this, "\x6d\157\137\x74\167\x6f\x5f\146\141\143\164\x6f\x72\x5f\141\152\141\x78"));
        add_action("\167\160\x5f\141\x6a\141\x78\x5f\156\157\160\x72\151\x76\137\155\157\x5f\164\x77\157\137\146\141\x63\x74\157\162\137\x61\152\x61\170", array($this, "\x6d\x6f\137\164\x77\x6f\x5f\x66\141\143\164\157\162\137\141\x6a\x61\170"));
    }
    public function mo_two_factor_ajax()
    {
        $GLOBALS["\155\157\62\146\x5f\151\x73\137\141\x6a\141\170\137\162\x65\161\x75\x65\163\x74"] = true;
        if (check_ajax_referer("\155\x6f\x2d\164\167\x6f\x2d\146\141\x63\164\x6f\x72\55\141\x6a\x61\170\x2d\156\157\156\x63\145", "\156\157\x6e\143\x65", false)) {
            goto TQ;
        }
        wp_send_json_error("\x63\x6c\141\163\163\x2d\x6d\x6f\62\x66\x2d\141\x6a\141\170");
        TQ:
        switch (isset($_POST["\155\157\x5f\x32\x66\137\164\x77\157\x5f\146\141\x63\164\x6f\x72\137\141\152\x61\170"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\x6f\x5f\62\146\x5f\x74\x77\157\137\146\141\143\x74\x6f\162\137\141\x6a\x61\x78"])) : '') {
            case "\155\x6f\x32\x66\x5f\141\152\141\x78\137\154\157\x67\x69\156\x5f\162\x65\144\x69\x72\145\143\x74":
                $this->mo2f_ajax_login_redirect();
                goto Oi;
            case "\x6d\x6f\62\x66\137\x73\145\x74\x5f\x6f\x74\160\137\157\166\x65\x72\137\163\x6d\163":
                $this->mo2f_set_otp_over_sms();
                goto Oi;
            case "\155\157\62\146\137\145\x6e\x61\x62\154\145\x5f\x74\x77\157\146\141\143\164\157\162\137\x75\x73\145\162\160\162\x6f\x66\x69\154\x65":
                $this->mo2f_enable_twofactor_userprofile($_POST);
                goto Oi;
            case "\155\157\x32\x66\x5f\163\145\164\137\107\x41":
                $this->mo2f_set_ga();
                goto Oi;
            case "\155\157\62\146\x5f\147\157\157\147\154\x65\137\141\x75\x74\x68\137\x73\145\x74\137\164\162\141\156\163\151\145\x6e\164":
                $this->mo2f_google_auth_set_transient();
                goto Oi;
        }
        DD:
        Oi:
    }
    public function mo2f_google_auth_set_transient()
    {
        if (!check_ajax_referer("\x6d\x6f\55\164\x77\157\x2d\146\141\143\164\x6f\162\55\x61\152\141\x78\55\156\x6f\x6e\143\x65", "\x6e\157\x6e\143\x65", false) || !current_user_can("\x65\144\151\164\x5f\165\163\145\162\x73")) {
            goto Um;
        }
        $GT = isset($_POST["\x61\x75\x74\x68\x5f\156\141\155\145"]) ? sanitize_text_field(wp_unslash($_POST["\141\x75\164\x68\x5f\x6e\141\x6d\145"])) : null;
        $jg = isset($_POST["\x73\145\x73\163\x69\x6f\x6e\137\151\x64"]) ? sanitize_text_field(wp_unslash($_POST["\163\x65\x73\x73\151\x6f\x6e\x5f\151\x64"])) : null;
        if (MoWpnsConstants::MSFT_AUTH === $GT) {
            goto mX;
        }
        $xz = isset($_POST["\x67\x5f\141\x75\x74\x68\137\x75\162\154"]) ? sanitize_text_field(wp_unslash($_POST["\147\x5f\x61\x75\x74\150\x5f\x75\162\x6c"])) : null;
        goto Ty;
        mX:
        $xz = isset($_POST["\155\151\143\x72\x6f\137\163\x6f\x66\164\137\165\162\154"]) ? sanitize_text_field(wp_unslash($_POST["\155\x69\143\162\157\x5f\163\x6f\x66\x74\x5f\x75\x72\154"])) : null;
        Ty:
        MO2f_Utility::mo2f_set_transient($jg, "\x67\x61\x5f\x71\162\103\157\x64\145", $xz);
        wp_send_json_success();
        goto d3;
        Um:
        wp_send_json_error("\155\x6f\62\x66\x2d\x61\152\141\x78");
        d3:
    }
    public function mo2f_validate_google_authenticator()
    {
        if (!check_ajax_referer("\155\x6f\x2d\x74\x77\157\x2d\x66\141\143\x74\x6f\162\55\141\152\x61\x78\x2d\156\157\156\x63\145", "\x6e\x6f\x6e\143\145", false)) {
            goto Jo;
        }
        $li = isset($_POST["\157\x74\160\137\x74\157\153\x65\x6e"]) ? sanitize_text_field(wp_unslash($_POST["\x6f\x74\x70\137\164\157\x6b\x65\156"])) : null;
        $Ty = isset($_POST["\163\x65\163\x73\151\157\x6e\137\x69\x64"]) ? sanitize_text_field(wp_unslash($_POST["\x73\145\x73\163\151\x6f\156\137\151\x64"])) : null;
        $CM = isset($_POST["\x67\141\137\x73\x65\x63\x72\x65\x74"]) ? sanitize_text_field(wp_unslash($_POST["\147\x61\137\x73\145\143\x72\x65\164"])) : (isset($_POST["\163\145\x73\x73\x69\157\x6e\137\151\x64"]) ? MO2f_Utility::mo2f_get_transient($Ty, "\x73\145\x63\x72\x65\x74\137\147\141") : null);
        global $Gw, $user;
        if (MO2f_Utility::mo2f_check_number_length($li)) {
            goto Kz;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::ONLY_DIGITS_ALLOWED));
        goto aG;
        Kz:
        $fK = $Gw->get_user_detail("\x6d\157\62\x66\x5f\x75\x73\x65\x72\x5f\145\x6d\x61\151\x6c", $user->ID);
        $user = wp_get_current_user();
        if ($user->ID) {
            goto sM;
        }
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\x6d\x6f\x32\x66\x5f\x63\165\162\x72\x65\156\x74\x5f\165\163\x65\162\137\151\x64");
        $user = get_user_by("\x69\144", $v1);
        sM:
        $fK = empty($fK) ? $user->user_email : $fK;
        $Zf = new Mo2fDB();
        $VX = $Zf->check_alluser_limit_exceeded($user->ID);
        if (!$VX) {
            goto mZ;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::USER_LIMIT_EXCEEDED));
        mZ:
        $SV = json_decode($this->mo2f_onprem_cloud_obj->mo2f_validate_google_auth($fK, $li, $CM), true);
        if (!(json_last_error() === JSON_ERROR_NONE)) {
            goto eh;
        }
        if (!(MoWpnsConstants::SUCCESS_RESPONSE === $SV["\x73\x74\x61\164\165\x73"])) {
            goto Qh;
        }
        $bC = json_decode($this->mo2f_onprem_cloud_obj->mo2f_update_user_info($user->ID, true, MoWpnsConstants::GOOGLE_AUTHENTICATOR, MoWpnsConstants::SUCCESS_RESPONSE, MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, true, $fK, null), true);
        if (!(json_last_error() === JSON_ERROR_NONE)) {
            goto A5;
        }
        if (!(MoWpnsConstants::SUCCESS_RESPONSE === $bC["\163\x74\x61\164\x75\163"])) {
            goto Yd;
        }
        delete_user_meta($user->ID, "\155\x6f\x32\146\137\62\106\101\137\155\145\x74\150\x6f\x64\x5f\164\x6f\137\143\x6f\x6e\x66\x69\x67\165\162\x65");
        delete_user_meta($user->ID, "\x6d\x6f\x32\x66\x5f\143\x6f\156\146\x69\147\165\162\x65\137\x32\x46\101");
        delete_user_meta($user->ID, "\x6d\157\62\x66\137\x67\x6f\x6f\x67\x6c\x65\137\x61\x75\164\x68");
        $jS = MoWpnsConstants::GOOGLE_AUTHENTICATOR;
        if (!MO2F_IS_ONPREM) {
            goto nC;
        }
        update_user_meta($user->ID, "\155\157\x32\146\x5f\x32\x46\x41\x5f\155\x65\x74\x68\157\x64\x5f\x74\x6f\x5f\143\157\x6e\x66\x69\147\165\162\x65", $jS);
        $Ts = new Google_Auth_Onpremise();
        $Ts->mo_g_auth_set_secret($user->ID, $CM);
        nC:
        update_user_meta($user->ID, "\x6d\x6f\62\146\137\145\170\x74\x65\x72\x6e\x61\x6c\137\141\x70\x70\137\x74\171\160\x65", $jS);
        delete_user_meta($user->ID, "\x6d\x6f\62\146\137\x75\x73\x65\x72\137\160\x72\x6f\146\x69\x6c\x65\x5f\x73\x65\164");
        wp_send_json_success($jS . "\x20\x68\x61\163\40\142\145\x65\156\x20\143\157\156\x66\151\x67\165\x72\x65\144\x20\163\165\143\143\x65\163\163\x66\165\x6c\154\171\56");
        Yd:
        A5:
        Qh:
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_OTP));
        eh:
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_WHILE_VALIDATING_OTP));
        aG:
        goto nr;
        Jo:
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_WHILE_VALIDATING_OTP));
        nr:
    }
    public function mo2f_enable_twofactor_userprofile($post)
    {
        $AE = isset($post["\x69\x73\137\145\x6e\141\x62\x6c\145\x64"]) && "\164\162\165\x65" === sanitize_text_field(wp_unslash($post["\x69\163\x5f\x65\156\141\142\x6c\145\x64"]));
        wp_send_json($AE);
    }
    public function mo2f_set_otp_over_sms()
    {
        if (check_ajax_referer("\x6d\157\55\x74\167\157\x2d\x66\141\x63\164\x6f\162\55\x61\152\x61\170\x2d\156\157\x6e\143\x65", "\x6e\x6f\156\x63\x65", false)) {
            goto wM;
        }
        $jY = new WP_Error();
        $jY->add("\x65\x6d\x70\x74\x79\137\x75\163\x65\x72\x6e\x61\155\145", "\74\163\164\x72\157\156\147\76" . esc_html__("\105\x52\122\x4f\122", "\x6d\151\156\151\157\x72\x61\x6e\x67\145\x2d\62\x2d\x66\x61\143\164\x6f\x72\55\141\x75\164\x68\145\x6e\x74\x69\143\141\x74\151\157\x6e") . "\74\x2f\163\x74\162\x6f\156\x67\76\x3a\x20" . esc_html__("\x49\x6e\x76\141\x6c\x69\x64\x20\x52\x65\161\x75\145\163\x74\56", "\x6d\x69\x6e\151\157\x72\x61\x6e\x67\145\x2d\x32\x2d\146\141\x63\164\x6f\162\55\x61\x75\164\150\145\x6e\164\151\143\141\164\151\x6f\156"));
        wp_send_json_error("\x6d\x6f\x32\x66\x2d\141\x6a\x61\x78");
        exit;
        wM:
        $yu = isset($_POST["\151\163\137\62\146\x61\x5f\145\156\x61\x62\x6c\x65\144"]) ? sanitize_text_field(wp_unslash($_POST["\x69\x73\137\x32\x66\x61\x5f\145\x6e\141\x62\154\x65\x64"])) : null;
        if (!("\164\162\x75\145" !== $yu)) {
            goto Q4;
        }
        wp_send_json("\62\x66\x61\144\x69\x73\141\142\x6c\145\144");
        Q4:
        global $Gw;
        $p9 = isset($_POST["\164\x72\141\156\x73\x69\x65\156\x74\137\x69\x64"]) ? sanitize_text_field(wp_unslash($_POST["\164\x72\141\x6e\163\151\145\x6e\x74\137\151\x64"])) : null;
        $v1 = MO2f_Utility::mo2f_get_transient($p9, "\x6d\x6f\x32\146\x5f\x75\x73\x65\162\x5f\151\x64");
        if (!empty($v1)) {
            goto cf;
        }
        wp_send_json_error("\x55\x73\145\x72\111\144\x4e\x6f\164\x46\x6f\x75\156\144");
        cf:
        $iD = isset($_POST["\x70\150\x6f\x6e\145"]) ? sanitize_text_field(wp_unslash($_POST["\x70\x68\157\156\x65"])) : null;
        $iD = str_replace("\x20", '', $iD);
        $Gw->update_user_details($v1, array("\x6d\157\x32\146\x5f\x75\x73\x65\162\137\x70\x68\x6f\x6e\x65" => $iD));
        $RN = $Gw->get_user_detail("\x6d\x6f\62\x66\137\x75\x73\x65\162\137\x70\x68\x6f\x6e\x65", $v1);
        wp_send_json_success($RN);
    }
    public function mo2f_set_ga()
    {
        if (check_ajax_referer("\x6d\157\x2d\164\x77\x6f\x2d\x66\141\x63\164\x6f\x72\55\141\152\141\170\55\156\157\156\143\x65", "\x6e\x6f\156\x63\145", false)) {
            goto OP;
        }
        $jY = new WP_Error();
        $jY->add("\145\x6d\160\164\171\137\165\163\145\162\156\141\x6d\x65", "\x3c\163\x74\162\x6f\x6e\147\76" . esc_html__("\x45\x52\122\117\122", "\x6d\x69\156\x69\x6f\x72\141\156\x67\x65\55\62\55\146\141\x63\x74\x6f\x72\x2d\141\x75\164\x68\x65\x6e\164\x69\143\141\x74\x69\157\x6e") . "\x3c\57\x73\164\x72\157\x6e\147\x3e\72\40" . esc_html__("\111\x6e\x76\141\x6c\x69\144\x20\x52\x65\x71\165\145\x73\x74\x2e", "\155\151\156\x69\x6f\162\141\156\x67\x65\55\x32\55\146\141\x63\x74\x6f\162\55\x61\x75\164\150\x65\156\x74\x69\x63\141\x74\151\x6f\156"));
        wp_send_json_error("\155\x6f\x32\x66\55\141\152\141\170");
        OP:
        $yu = isset($_POST["\151\x73\x5f\62\146\x61\x5f\145\x6e\141\x62\154\145\x64"]) ? sanitize_text_field(wp_unslash($_POST["\151\163\137\x32\146\141\x5f\x65\x6e\x61\142\154\145\x64"])) : null;
        if (!("\x74\x72\165\145" !== $yu)) {
            goto L5;
        }
        wp_send_json("\x32\146\x61\144\151\x73\141\x62\154\x65\x64");
        L5:
        include_once dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . "\x68\141\x6e\144\x6c\145\x72" . DIRECTORY_SEPARATOR . "\164\167\x6f\x66\x61" . DIRECTORY_SEPARATOR . "\x63\154\141\x73\163\x2d\147\x6f\157\147\154\x65\55\141\x75\164\150\x2d\x6f\x6e\160\162\x65\x6d\151\x73\145\56\x70\150\x70";
        global $Gw, $Xw;
        $p9 = isset($_POST["\x74\162\141\156\163\x69\x65\156\x74\137\x69\x64"]) ? sanitize_text_field(wp_unslash($_POST["\164\162\x61\x6e\x73\151\145\156\x74\137\151\144"])) : null;
        $v1 = MO2f_Utility::mo2f_get_transient($p9, "\155\157\62\x66\137\165\x73\x65\162\137\151\144");
        if (!empty($v1)) {
            goto YO;
        }
        wp_send_json_error("\x55\x73\145\x72\111\144\116\x6f\164\x46\x6f\x75\156\x64");
        YO:
        $user = get_user_by("\x69\x64", $v1);
        $fK = !empty($Gw->get_user_detail("\x6d\x6f\x32\146\137\165\163\145\x72\x5f\145\155\x61\151\154", $v1)) ? $Gw->get_user_detail("\x6d\x6f\x32\146\137\165\x73\145\162\x5f\x65\155\141\x69\x6c", $v1) : $user->user_email;
        $li = isset($_POST["\143\x6f\x64\x65"]) ? sanitize_text_field(wp_unslash($_POST["\143\157\144\x65"])) : null;
        $CM = isset($_POST["\147\x61\137\163\x65\x63\x72\145\x74"]) ? sanitize_text_field(wp_unslash($_POST["\147\x61\137\163\x65\143\x72\x65\164"])) : null;
        $Xw->mo2f_set_gauth_secret($v1, $fK, $CM);
        $SV = json_decode($Xw->mo2f_validate_google_auth($fK, $li, $CM), true);
        wp_send_json_success($SV["\x73\x74\141\164\x75\163"]);
    }
    public function mo2f_ajax_login_redirect()
    {
        if (check_ajax_referer("\x6d\157\x2d\164\167\157\x2d\146\x61\x63\164\x6f\x72\x2d\141\x6a\141\x78\55\156\x6f\x6e\x63\145", "\x6e\x6f\156\143\145", false)) {
            goto H8;
        }
        wp_send_json_error("\155\x6f\x32\x66\55\x61\152\x61\170");
        H8:
        $Zi = isset($_POST["\x75\x73\145\162\x6e\141\x6d\x65"]) ? sanitize_user(wp_unslash($_POST["\x75\x73\x65\162\x6e\141\155\x65"])) : null;
        $uk = isset($_POST["\160\x61\x73\x73\x77\x6f\162\144"]) ? $_POST["\160\141\x73\163\167\x6f\162\x64"] : null;
        apply_filters("\141\165\164\150\145\x6e\164\x69\x63\x61\164\145", null, $Zi, $uk);
    }
}
new Mo_2f_Ajax();
y1:
