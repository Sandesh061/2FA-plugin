<?php


if (defined("\101\102\123\x50\101\x54\x48")) {
    goto K9;
}
exit;
K9:
global $uz, $V0;
require $V0 . "\x76\x69\145\167\x73" . DIRECTORY_SEPARATOR . "\164\x72\x6f\x75\142\x6c\145\x73\x68\157\x6f\x74\151\x6e\x67\56\x70\x68\x70";
