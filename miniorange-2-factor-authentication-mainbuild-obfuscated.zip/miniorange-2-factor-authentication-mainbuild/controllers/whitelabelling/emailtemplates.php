<?php


if (defined("\101\x42\x53\120\101\124\110")) {
    goto FE;
}
exit;
FE:
require dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . "\166\151\145\x77\x73" . DIRECTORY_SEPARATOR . "\x77\x68\x69\164\145\x6c\141\x62\145\154\x6c\151\156\x67" . DIRECTORY_SEPARATOR . "\145\x6d\141\x69\154\x74\145\155\x70\154\141\164\x65\x73\56\x70\x68\160";
