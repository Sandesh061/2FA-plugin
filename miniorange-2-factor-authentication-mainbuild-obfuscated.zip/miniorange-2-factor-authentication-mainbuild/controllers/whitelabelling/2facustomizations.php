<?php


if (defined("\101\x42\123\120\101\124\x48")) {
    goto FC;
}
exit;
FC:
$qc = get_site_option("\155\x6f\x32\x66\137\x64\x65\146\141\x75\x6c\x74\x5f\x6b\x62\141\161\165\145\163\164\x69\x6f\156\163\x5f\x75\163\145\162\x73", 2);
$QD = get_site_option("\x6d\x6f\x32\146\x5f\143\165\163\x74\x6f\x6d\x5f\153\x62\x61\x71\165\x65\163\164\151\x6f\x6e\x73\x5f\165\x73\145\162\163", 1);
$aw = get_site_option("\155\157\62\x66\137\143\x75\163\x74\157\x6d\137\163\145\143\165\x72\x69\164\171\x5f\x71\x75\145\x73\x74\151\157\x6e\x73", array());
require dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . "\x76\x69\145\167\163" . DIRECTORY_SEPARATOR . "\x77\x68\151\164\145\x6c\141\142\x65\154\x6c\151\156\x67" . DIRECTORY_SEPARATOR . "\x32\x66\141\143\x75\163\x74\157\155\x69\172\141\x74\151\x6f\156\163\x2e\160\x68\x70";
