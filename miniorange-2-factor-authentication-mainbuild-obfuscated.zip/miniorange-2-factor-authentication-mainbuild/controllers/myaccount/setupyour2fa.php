<?php


use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Onprem\Miniorange_Authentication;
use TwoFA\Helper\Mo2f_Common_Helper;
if (defined("\101\102\x53\120\101\x54\x48")) {
    goto G0;
}
exit;
G0:
global $Gw, $Xw;
$user = wp_get_current_user();
$v1 = $user->ID;
$YE = $Gw->get_user_detail("\155\157\62\146\137\x63\x6f\156\x66\x69\147\x75\162\x65\144\x5f\62\x46\x41\137\155\145\x74\150\x6f\144", $v1);
$DL = get_site_option("\155\x6f\x5f\x32\x66\x61\x63\164\x6f\162\x5f\x61\144\155\x69\156\x5f\x72\x65\x67\151\163\x74\162\141\164\151\x6f\x6e\137\163\x74\141\164\165\x73");
update_site_option("\x6d\157\62\x66\x5f\x73\150\157\x77\x5f\163\155\x73\137\164\x72\x61\156\163\x61\x63\164\x69\x6f\x6e\137\155\x65\x73\163\141\147\145", MoWpnsConstants::OTP_OVER_SMS === $YE);
$PH = current_user_can("\155\x61\156\141\147\145\x5f\157\160\164\151\157\156\x73");
$xu = $Xw->mo2f_plan_methods();
$Vq = array_keys($xu);
if (!(!$PH && !Miniorange_Authentication::mo2f_is_customer_registered())) {
    goto CX;
}
$Vq = array_filter($Vq, function ($la) {
    return MoWpnsConstants::OTP_OVER_SMS !== $la;
});
CX:
if (!MO2F_IS_ONPREM) {
    goto u3;
}
$YE = !empty($Gw->get_user_detail("\155\x6f\x32\146\x5f\x63\x6f\x6e\x66\151\x67\165\x72\145\x64\137\62\106\x41\137\x6d\x65\x74\150\x6f\x64", $v1)) ? $Gw->get_user_detail("\155\157\x32\x66\137\x63\x6f\x6e\146\151\147\165\x72\145\x64\x5f\x32\x46\101\137\155\145\x74\x68\157\144", $v1) : "\x4e\x4f\x4e\x45";
u3:
$cB = new Mo2f_Common_Helper();
$cB->mo2f_echo_js_css_files();
require dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . "\166\151\145\x77\163" . DIRECTORY_SEPARATOR . "\155\171\141\x63\x63\x6f\165\156\164" . DIRECTORY_SEPARATOR . "\163\145\164\165\x70\x79\157\165\x72\x32\146\141\x2e\x70\x68\160";
