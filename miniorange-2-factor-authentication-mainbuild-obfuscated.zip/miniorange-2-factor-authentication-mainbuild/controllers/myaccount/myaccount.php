<?php


use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Helper\Mo2f_Common_Helper;
if (defined("\x41\x42\123\x50\101\124\110")) {
    goto N9;
}
exit;
N9:
$user = wp_get_current_user();
$rM = get_site_option("\155\x6f\137\62\x66\x61\143\164\x6f\x72\137\141\x64\155\151\156\x5f\x72\145\x67\x69\x73\164\x72\141\x74\151\x6f\x6e\137\x73\x74\141\164\x75\163");
$fK = get_site_option("\x6d\157\62\146\x5f\x65\x6d\x61\151\x6c");
$t8 = get_site_option("\x6d\x6f\x32\146\137\143\165\163\164\x6f\x6d\x65\162\x4b\145\171");
$ER = get_site_option("\x6d\157\62\x66\x5f\141\160\x69\137\153\145\x79");
$CS = get_site_option("\x6d\x6f\x32\x66\137\x63\165\163\164\x6f\155\145\x72\x5f\x74\x6f\x6b\145\156");
$i9 = get_site_option("\155\157\62\146\141\x5f\x6c\153") ? "\x55\x6e\x6c\x69\155\151\164\145\144" : MoWpnsUtility::get_mo2f_db_option("\x63\x6d\x56\164\131\x57\x6c\x75\x61\127\x35\156\124\61\x52\x51", "\x73\151\x74\x65\137\x6f\160\x74\x69\x6f\x6e");
$i9 = $i9 ? $i9 : 0;
$BZ = get_site_option("\x63\155\x56\164\x59\x57\x6c\165\141\x57\x35\156\x54\x31\122\121\x56\110\112\150\142\156\x4e\x68\131\63\122\160\x62\62\x35\x7a") ? get_site_option("\x63\155\126\164\x59\x57\x6c\x75\x61\x57\65\x6e\124\61\x52\121\126\110\112\x68\142\156\116\x68\x59\x33\x52\160\x62\62\65\172") : 0;
if (!$t8) {
    goto vN;
}
do_action("\155\157\62\146\x5f\x67\x65\x74\x5f\154\x69\143\145\156\163\x65\137\x76\141\x72\151\146\151\143\x61\x74\151\x6f\156\137\x73\143\162\x65\145\156");
require_once dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . "\166\x69\145\x77\x73" . DIRECTORY_SEPARATOR . "\155\171\x61\x63\143\157\165\x6e\x74" . DIRECTORY_SEPARATOR . "\x61\143\x63\x6f\165\x6e\x74\56\160\150\160";
goto Ct;
vN:
$FT = array("\43\x23\143\162\157\163\163\x62\165\x74\x74\157\156\43\43" => '', "\x23\x23\155\151\x6e\151\x6f\x72\141\156\147\x65\x6c\x6f\x67\157\43\43" => '', "\x23\x23\x70\x61\147\x65\x74\151\164\154\145\x23\x23" => "\74\x68\x33\76" . __("\114\157\147\151\x6e\x2f\x52\145\147\151\163\164\x65\x72\40\167\x69\164\150\x20\x6d\x69\156\151\x4f\162\x61\x6e\147\x65", "\x6d\151\x6e\x69\x6f\x72\141\x6e\x67\145\55\62\x2d\x66\x61\x63\x74\x6f\x72\x2d\x61\165\164\x68\145\156\164\151\143\141\x74\151\157\x6e") . "\x3c\x2f\150\x33\76");
$cB = new Mo2f_Common_Helper();
$XZ = $cB->mo2f_get_miniorange_user_registration_prompt('', null, null, "\155\x79\141\x63\143\157\x75\156\164", $FT);
require_once dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . "\x76\151\x65\x77\163" . DIRECTORY_SEPARATOR . "\155\x79\x61\x63\x63\157\165\x6e\164" . DIRECTORY_SEPARATOR . "\154\157\147\x69\x6e\x2e\160\150\160";
Ct:
