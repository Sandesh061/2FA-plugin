<?php


use TwoFA\Helper\MoWpnsConstants;
if (defined("\x41\102\x53\120\101\124\x48")) {
    goto rz;
}
exit;
rz:
global $wp_roles, $Xw;
if (!is_multisite()) {
    goto Ai;
}
$f4 = array("\163\x75\x70\x65\x72\x61\144\155\151\x6e" => "\x53\x75\160\x65\162\x61\144\x6d\151\x6e");
$wp_roles->role_names = array_merge($f4, $wp_roles->role_names);
Ai:
$xu = $Xw->mo2f_plan_methods();
$Vq = array_keys($xu);
$Vq = array_filter($Vq, function ($la) {
    return MoWpnsConstants::OTP_OVER_WHATSAPP !== $la;
});
$ao = MoWpnsConstants::$mo2f_cap_to_small;
$WX = get_site_option("\155\x6f\62\x66\x5f\163\x65\154\145\x63\164\x5f\x6d\x65\164\x68\157\144\163\x5f\x66\157\162\137\x75\x73\x65\162\163", 1);
$qu = (array) get_site_option("\x6d\x6f\x32\146\x5f\x61\x75\164\x68\x5f\155\145\x74\150\x6f\144\163\137\x66\x6f\x72\x5f\165\163\x65\162\x73", array(MoWpnsConstants::GOOGLE_AUTHENTICATOR, MoWpnsConstants::OTP_OVER_SMS, MoWpnsConstants::OTP_OVER_TELEGRAM, MoWpnsConstants::OTP_OVER_EMAIL, MoWpnsConstants::OUT_OF_BAND_EMAIL, MoWpnsConstants::SECURITY_QUESTIONS));
$Ve = (array) get_site_option("\155\157\62\x66\x5f\141\165\164\x68\x5f\155\x65\x74\x68\x6f\144\x73\137\x72\157\154\145\x73");
$Zw = get_site_option("\155\x6f\62\146\137\x61\x6c\154\137\165\163\x65\x72\163\137\155\145\164\x68\x6f\144");
require dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . "\166\x69\145\x77\163" . DIRECTORY_SEPARATOR . "\62\x66\141\143\x6f\x6e\146\x69\x67\x75\162\141\164\x69\x6f\156\x73" . DIRECTORY_SEPARATOR . "\x71\165\151\x63\153\x73\145\x74\x75\x70\x2e\160\150\x70";
