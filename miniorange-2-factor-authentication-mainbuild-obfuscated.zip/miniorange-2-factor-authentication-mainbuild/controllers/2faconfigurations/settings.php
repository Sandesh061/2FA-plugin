<?php


if (defined("\101\102\x53\120\x41\124\x48")) {
    goto AA;
}
exit;
AA:
global $wp_roles;
$Tk = get_site_option("\x6d\x6f\62\x66\137\145\156\x61\x62\154\145\137\143\x75\x73\164\x6f\155\x5f\x72\x65\x64\151\162\x65\x63\x74");
$xj = (array) get_option("\x6d\x6f\62\x66\137\143\165\x73\x74\157\x6d\x5f\x6c\x6f\147\151\156\x5f\x75\x72\154\163", array(wp_get_current_user()->roles[0] => home_url()));
require_once $V0 . "\166\151\x65\167\x73" . DIRECTORY_SEPARATOR . "\62\x66\x61\143\x6f\x6e\x66\x69\x67\x75\162\x61\164\x69\x6f\156\x73" . DIRECTORY_SEPARATOR . "\163\145\164\164\151\x6e\x67\163\x2e\x70\150\160";
