<?php


use TwoFA\Helper\MocURL;
use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Helper\MoWpnsUtility;
if (defined("\x41\102\123\120\x41\x54\x48")) {
    goto lM;
}
exit;
lM:
global $V0;
$em = wp_get_current_user();
$fK = get_site_option("\155\x6f\x32\x66\137\x65\155\141\x69\154");
$T7 = get_site_option("\x6d\157\137\x77\160\x6e\x73\137\x61\144\x6d\x69\x6e\137\x70\150\x6f\x6e\x65");
if (!empty($fK)) {
    goto Hq;
}
$fK = $em->user_email;
Hq:
$jj = wp_create_nonce("\x6d\157\x32\146\55\163\165\160\x70\x6f\162\x74\55\146\x6f\x72\x6d\x2d\x6e\x6f\x6e\143\145");
$Ht = get_transient("\x6d\x6f\62\x66\137\x71\165\145\x72\x79\137\x73\145\156\x74") ? "\x74\x72\165\x65" : "\146\x61\154\x73\x65";
require dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . "\166\x69\145\167\x73" . DIRECTORY_SEPARATOR . "\x63\157\156\164\x61\143\x74\165\163\x2e\160\x68\160";
