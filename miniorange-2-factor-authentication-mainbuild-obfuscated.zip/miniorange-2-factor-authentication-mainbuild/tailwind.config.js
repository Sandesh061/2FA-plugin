0/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    //views
    "./views/class-mo2f-setup-wizard.php",
    "./views/upgrade.php",
    "./views/troubleshooting.php",
    "./views/main-menu.php",
    "./views/myaccount/account.php",
    "./views/class-mo2f-setup-wizard.php",
    "./views/2faconfigurations/quicksetup.php",
    "./views/2faconfigurations/2faforme.php",
    "./views/2faconfigurations/formintegration.php",
    "./views/navbar.php",
    "./views/reports/loginreports.php",
    "./views/ipblocking/advancedblocking.php",
    "./views/ipblocking/ipblacklist.php",
    "./views/2faconfigurations/advancedfeatures/sessionmanagement.php",
    "./views/2faconfigurations/advancedfeatures/rememberdevice.php",
    "./views/2faconfigurations/advancedfeatures/passwordlesslogin.php",
    "./views/whitelabelling/loginpopup.php",
    "./views/whitelabelling/emailtemplates.php",
    "./views/whitelabelling/2facustomizations.php",
    //helper
    "./helper/class-mo2f-common-helper.php",
    "./helper/class-mo2f-inline-popup.php",
    "./helper/class-mo2f-login-popup.php",
    "./helper/class-mo2f-setupwizard.php",
    "./helper/class-mowpnsmessages.php",
    "./helper/class-mo2f-login-popup.php",
    //twofactor
    "./twofactor/addons/views/addons-custom-login.php",
    "./twofactor/addons/views/addons-rba.php",
    "./twofactor/addons/views/addons-session-management.php",
    "./twofactor/addons/views/addons-shortcode.php",
    "./twofactor/2-factorAuthentication/customloginforms/views/custom-login-forms.php",
    //controllers
    "./controllers/two-factor-page.php",

    //database
    "./database/mo2f-db-options.php",
  ],
  theme: {
    spacing: {
        "mo-0": "0",
        "mo-0.5": "0.125rem",
        "mo-1": "0.25rem",
        "mo-1.5": "0.375rem",
        "mo-1.75": "0.4rem",
        "mo-2": "0.5rem",
        "mo-2.5": "0.625rem",
        "mo-3": "0.75rem",
        "mo-3.5": "0.875rem",
        "mo-4": "1rem",
        "mo-5": "1.25rem",
        "mo-6": "1.5rem",
        "mo-7": "1.75rem",
        "mo-8": "2rem",
        "mo-9": "2.25rem",
        "mo-10": "2.5rem",
        "mo-11": "2.75rem",
        "mo-12": "3rem",
        "mo-14": "3.5rem",
        "mo-16": "4rem",
        "mo-20": "5rem",
        "mo-22": "5.5rem",
        "mo-24": "6rem",
        "mo-28": "7rem",
        "mo-29": "7.5rem",
        "mo-30": "8rem",
        "mo-36": "9rem",
        "mo-38": "9.5rem",
        "mo-40": "10rem",
        "mo-44": "11rem",
        "mo-48": "12rem",
        "mo-52": "13rem",
        "mo-56": "14rem",
        "mo-60": "15rem",
        "mo-64": "16rem",
        "mo-72": "18rem",
        "mo-80": "20rem",
        "mo-96": "24rem",
        "mo-32" : "32%",
        "mo-10p": "10px",
        "mo-h10": "10%",
        "mo-100": "100%",
        "mo-48": "48%",
        "mo-h190": "190px",
    },

    // Extended Theme Properties
    extend: {
        /*
        -----------------------------------------------
        Color Palette
        -----------------------------------------------
        */
        colors: {
            // App
            "mo-app-primary": "#2563EB",

            // Background
            "mo-primary-bg": "#FFFFFF",
            "mo-secondary-bg": "#F8FAFC",

            // Border
            "mo-primary-br": "#E2E8F0",
            "mo-active-br": "#2563EB",

            // Icon
            "mo-active-ic": "#334155",
            "mo-inactive-ic": "#94A3B8",
            "mo-light-ic": "#FFFFFF",

            // Text
            "mo-primary-txt": "#334155",
            "mo-secondary-txt": "#64748B",
            "mo-tertiary-txt": "#FF0000",
            "mo-blue-txt": "#0000ff",

            //button
            "mo-primary-btn-bg": "#2271b1",
            "mo-primary-hover-bg": "#649fcf",

            //overlay
            "mo-settings" : "#ffffff82",
        },
        fontFamily: {
            poppins: ['Poppins', 'sans-serif'],
          },

        /*
        -----------------------------------------------
        Spacings values for Margins & Paddings
        -----------------------------------------------
        */
        spacing: {
            // Base Spacing units
            "mo-tiny": "4px",
            "mo-xs": "8px",
            "mo-sm": "12px",
            "mo-rg": "16px",
            "mo-md": "20px",
            "mo-lg": "24px",
            "mo-xl": "28px",
            "mo-2xl": "38px",

            // Button Height
            "mo2f-button": "36px",

            // Input Height
            "mo-input": "36px",

            // Icon Size
            "mo-icon": "24px",

            // Sidenav
            "mo-sidenav": "14rem",

            // Subtabs Container
            "mo-subtabs-container": "56px",
        },

        /*
        -----------------------------------------------
        Border Radius
        -----------------------------------------------
        */
        borderRadius: {
            "mo-smooth": "4px",
            "mo-rounded": "1000px",
        },

        borderWidth: {
            "mo-tab": "3px",
        },

        /*
        -----------------------------------------------
        Font Sizes
        -----------------------------------------------
        */
        fontSize: {
            "mo-heading": "16px",
            "mo-title": "13px",
            "mo-caption": "12px",
            "mo-hover-button" : "14px",
            "mo-setting-font" : "10px",
        },

        /*
        -----------------------------------------------
        Grid Auto Columns
        -----------------------------------------------
        */
        gridTemplateColumns: {
            "mo-tabs": "repeat(auto-fit,minmax(168px,168px))",
        },
    },
  },
  plugins: [],
}