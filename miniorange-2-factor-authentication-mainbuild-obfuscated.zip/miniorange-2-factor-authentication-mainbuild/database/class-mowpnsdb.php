<?php


namespace TwoFA\Database;

use TwoFA\Helper\MoWpnsConstants;
if (defined("\x41\102\x53\120\101\x54\x48")) {
    goto TT;
}
exit;
TT:
require_once ABSPATH . "\167\x70\x2d\141\144\x6d\151\x6e\x2f\151\156\x63\154\x75\x64\145\x73\x2f\165\x70\147\162\141\144\145\56\160\150\160";
if (class_exists("\115\x6f\x57\160\156\163\104\102")) {
    goto A4;
}
class MoWpnsDB
{
    private $transaction_table;
    private $blocked_ips_table;
    private $whitelist_ips_table;
    private $email_audit_table;
    private $attack_list;
    private $filescan;
    public function __construct()
    {
        global $wpdb;
        $this->transaction_table = $wpdb->base_prefix . "\x6d\x6f\62\x66\x5f\156\x65\x74\x77\x6f\162\153\137\164\162\x61\x6e\x73\141\143\164\151\x6f\x6e\163";
        $this->blocked_ips_table = $wpdb->base_prefix . "\x6d\157\62\146\x5f\156\x65\164\167\157\x72\x6b\137\x62\x6c\x6f\143\153\x65\x64\137\151\x70\x73";
        $this->attack_list = $wpdb->base_prefix . "\167\160\156\x73\x5f\141\x74\x74\x61\143\x6b\137\x6c\x6f\147\x73";
        $this->whitelist_ips_table = $wpdb->base_prefix . "\155\157\x32\x66\137\x6e\145\x74\x77\x6f\162\153\137\x77\150\x69\x74\145\154\151\163\164\145\x64\x5f\151\x70\x73";
        $this->email_audit_table = $wpdb->base_prefix . "\155\x6f\x32\x66\137\156\x65\x74\167\157\162\x6b\x5f\x65\x6d\x61\151\x6c\137\163\x65\156\x74\137\141\165\x64\x69\164";
    }
    public function mo_plugin_activate()
    {
        if (!get_site_option("\155\157\x5f\x77\160\156\x73\x5f\x64\142\x76\x65\162\163\151\157\156") || get_site_option("\x6d\x6f\x5f\167\x70\x6e\163\x5f\x64\142\x76\x65\x72\163\151\157\x6e") < MoWpnsConstants::DB_VERSION) {
            goto lq;
        }
        $sh = get_site_option("\155\157\137\x77\x70\x6e\163\x5f\x64\x62\166\145\x72\x73\x69\157\x6e");
        if (!($sh < MoWpnsConstants::DB_VERSION)) {
            goto Us;
        }
        update_site_option("\155\157\x5f\x77\x70\156\163\137\x64\142\x76\145\162\163\151\157\156", MoWpnsConstants::DB_VERSION);
        Us:
        goto gy;
        lq:
        update_site_option("\x6d\157\x5f\167\x70\x6e\163\x5f\144\x62\x76\145\x72\163\x69\x6f\x6e", MoWpnsConstants::DB_VERSION);
        $this->generate_tables();
        gy:
    }
    public function generate_tables()
    {
        global $wpdb;
        $cc = $this->transaction_table;
        if (!($wpdb->get_var($wpdb->prepare("\x73\150\x6f\167\40\x74\141\x62\154\145\x73\40\x6c\x69\153\x65\x20\45\x73", array($cc))) !== $cc)) {
            goto xz;
        }
        $ns = "\x43\122\x45\x41\124\x45\40\124\x41\x42\114\x45\40" . $cc . "\40\x28\x20\x60\151\x64\x60\x20\142\151\x67\151\156\164\x20\x4e\117\x54\x20\116\x55\x4c\114\x20\x41\125\124\117\137\x49\x4e\103\x52\x45\x4d\x45\x4e\x54\54\40\x60\x69\x70\x5f\x61\x64\x64\162\145\163\163\140\40\x6d\x65\x64\x69\165\155\x74\145\170\x74\40\116\x4f\x54\x20\116\125\x4c\114\40\54\40\40\x60\x75\163\x65\x72\x6e\141\x6d\145\x60\x20\155\145\x64\151\165\x6d\x74\145\x78\164\40\x4e\117\124\40\x4e\x55\x4c\114\40\54\40\140\x74\171\160\145\140\x20\155\x65\x64\151\x75\155\164\145\170\164\40\116\x4f\124\40\x4e\x55\114\x4c\x20\54\40\x60\165\162\x6c\140\x20\x6d\x65\x64\x69\165\155\x74\x65\x78\164\40\116\x4f\124\x20\116\125\114\x4c\40\54\x20\140\x73\164\141\164\165\163\140\x20\155\x65\144\x69\x75\155\x74\x65\x78\x74\40\x4e\117\124\x20\x4e\125\114\114\40\x2c\40\140\143\162\145\141\x74\145\x64\x5f\164\x69\x6d\x65\163\164\x61\155\160\x60\40\x69\156\x74\x2c\x20\125\x4e\x49\121\125\x45\x20\113\x45\131\x20\x69\144\x20\x28\x69\x64\51\x20\51\x3b";
        dbDelta($ns);
        xz:
        $cc = $this->blocked_ips_table;
        if (!($wpdb->get_var($wpdb->prepare("\x73\150\157\x77\40\164\x61\x62\x6c\145\163\40\x6c\151\153\x65\x20\x25\x73", array($cc))) !== $cc)) {
            goto xY;
        }
        $ns = "\103\x52\x45\101\x54\105\40\124\101\102\114\x45\x20" . $cc . "\40\x28\40\140\x69\x64\140\40\x69\156\x74\x20\x4e\x4f\124\40\x4e\x55\114\x4c\40\x41\x55\124\117\137\111\x4e\x43\122\x45\x4d\x45\x4e\x54\x2c\40\x60\151\x70\137\x61\144\x64\162\x65\163\x73\140\40\x6d\145\x64\x69\165\x6d\x74\x65\x78\x74\40\x4e\x4f\124\40\x4e\125\114\114\x20\x2c\x20\x60\162\145\x61\x73\157\x6e\x60\40\x6d\x65\144\x69\165\x6d\164\145\x78\x74\x2c\40\x60\x62\x6c\157\x63\153\145\x64\137\146\157\x72\137\x74\x69\155\x65\140\x20\x69\x6e\164\x2c\x20\x60\143\x72\145\x61\x74\x65\144\x5f\x74\x69\155\145\x73\164\x61\x6d\160\x60\x20\151\x6e\164\x2c\x20\125\116\111\x51\x55\105\x20\113\105\x59\40\151\x64\40\x28\151\x64\51\x20\51\x3b";
        dbDelta($ns);
        xY:
        $cc = $this->whitelist_ips_table;
        if (!($wpdb->get_var($wpdb->prepare("\x73\x68\157\x77\x20\x74\x61\x62\x6c\x65\x73\x20\x6c\151\x6b\145\40\45\163", array($cc))) !== $cc)) {
            goto il;
        }
        $ns = "\x43\122\x45\x41\x54\105\40\124\101\x42\x4c\x45\x20" . $cc . "\40\50\x20\x60\x69\x64\140\x20\x69\x6e\164\40\116\x4f\x54\x20\x4e\125\x4c\x4c\x20\101\125\124\117\137\x49\x4e\x43\x52\x45\x4d\105\116\x54\54\x20\x60\151\x70\x5f\x61\x64\x64\162\x65\163\163\140\x20\155\x65\144\x69\165\x6d\164\x65\x78\x74\x20\116\x4f\x54\40\116\125\114\114\x20\x2c\x20\x60\143\x72\145\141\x74\145\144\137\x74\x69\x6d\x65\x73\164\141\155\x70\x60\40\x69\156\164\54\x20\x55\116\x49\x51\x55\x45\x20\x4b\x45\131\x20\x69\144\x20\50\151\144\x29\x20\51\73";
        dbDelta($ns);
        il:
        $vv = $wpdb->get_var($wpdb->prepare("\40\x53\x48\x4f\127\x20\x43\117\x4c\125\x4d\116\x53\40\x46\122\117\x4d\40\x25\x31\x73\x20\114\111\x4b\x45\x20\x25\x73\x20", array($cc, "\160\x6c\x75\x67\x69\x6e\x5f\x70\x61\x74\x68")));
        if (!is_null($vv)) {
            goto sr;
        }
        $ns = "\x41\x4c\124\x45\122\x20\124\101\102\114\x45\40\40\140{$cc}\140\x20\101\x44\104\40\40\x60\x70\x6c\165\x67\151\156\137\x70\x61\x74\150\140\40\155\145\144\151\165\155\x74\x65\x78\164\40\x41\x46\x54\105\x52\x20\40\x60\143\162\x65\x61\x74\x65\x64\x5f\x74\x69\x6d\145\163\164\x61\155\160\140\x20\x3b";
        $ab = $wpdb->query($wpdb->prepare("\101\114\124\105\122\40\x54\x41\x42\114\105\x20\45\61\163\x20\x41\104\x44\40\x20\x25\x31\x73\40\155\145\144\x69\165\155\164\x65\x78\164\40\101\106\x54\x45\x52\x20\40\x25\61\x73\x20", array($cc, "\x70\x6c\165\147\151\156\x5f\160\x61\x74\150", "\x63\162\x65\141\x74\x65\144\x5f\x74\151\x6d\145\163\164\141\x6d\160")));
        sr:
        $cc = $this->email_audit_table;
        if (!($wpdb->get_var($wpdb->prepare("\x73\150\x6f\167\x20\x74\x61\142\154\x65\163\x20\x6c\151\x6b\145\40\x25\x73", array($cc))) !== $cc)) {
            goto es;
        }
        $ns = "\x43\x52\x45\x41\124\x45\40\124\x41\102\x4c\x45\x20" . $cc . "\x20\x28\x20\140\151\144\x60\40\x69\156\164\40\x4e\x4f\124\40\x4e\x55\114\114\40\101\x55\124\x4f\x5f\x49\x4e\103\x52\x45\x4d\x45\x4e\124\54\x20\140\151\x70\x5f\141\144\x64\162\x65\x73\x73\x60\x20\x6d\145\144\x69\165\155\x74\x65\x78\164\40\116\117\x54\x20\116\125\x4c\x4c\x20\54\x20\140\165\x73\x65\162\x6e\141\155\145\140\x20\155\x65\144\x69\x75\155\x74\x65\x78\164\40\116\117\x54\x20\x4e\125\x4c\x4c\x2c\40\140\x72\x65\x61\163\157\156\x60\x20\155\145\x64\151\x75\155\x74\145\170\x74\x2c\x20\140\143\162\x65\x61\x74\145\144\x5f\164\151\155\x65\x73\164\141\x6d\x70\140\x20\x69\156\x74\54\40\x55\x4e\x49\121\125\x45\x20\x4b\x45\x59\x20\x69\x64\40\x28\x69\144\51\40\x29\x3b";
        dbDelta($ns);
        es:
        $cc = $this->attack_list;
        if (!($wpdb->get_var($wpdb->prepare("\163\x68\157\x77\40\x74\x61\x62\154\145\163\x20\x6c\151\153\145\x20\x25\x73", array($cc))) !== $cc)) {
            goto ko;
        }
        $u8 = $wpdb->query($wpdb->prepare("\x63\162\145\x61\164\x65\x20\164\141\142\x6c\145\40\45\x31\163\x28\x20\151\160\40\x76\141\x72\143\150\141\162\50\x32\60\x29\x2c\40\164\x79\160\145\40\166\141\x72\143\150\141\x72\50\x32\60\x29\54\40\164\151\x6d\x65\40\x62\151\147\151\x6e\164\54\x20\151\156\160\165\164\40\155\x65\x64\x69\165\155\x74\x65\170\164\40\51\73", array($cc)));
        ko:
    }
    public function get_ip_blocked_count($nb)
    {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare("\x53\x45\114\x45\x43\x54\x20\x43\117\125\116\124\50\x2a\51\x20\106\x52\x4f\115\40\45\61\x73\40\127\110\x45\122\105\40\x69\x70\x5f\x61\144\144\162\145\x73\163\x20\75\x20\45\163", array($this->blocked_ips_table, $nb)));
    }
    public function get_total_blocked_ips()
    {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare("\x53\x45\x4c\105\x43\x54\40\x43\x4f\x55\x4e\x54\50\52\51\x20\x46\x52\117\x4d\x20\45\61\163", array($this->blocked_ips_table)));
    }
    public function get_total_manual_blocked_ips()
    {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare("\123\x45\114\x45\103\x54\40\103\117\125\116\124\x28\x2a\51\40\106\x52\x4f\x4d\40\x25\61\x73\x20\x57\x48\105\x52\105\x20\162\x65\x61\163\157\156\40\75\40\47\x42\x6c\157\143\x6b\x65\x64\x20\x62\x79\40\101\x64\155\151\x6e\x27\x20", array($this->blocked_ips_table)));
    }
    public function get_total_blocked_ips_waf()
    {
        global $wpdb;
        $F0 = $wpdb->get_var($wpdb->prepare("\123\x45\x4c\105\103\124\40\x43\x4f\x55\116\124\50\52\51\x20\x46\x52\117\x4d\x20\45\x31\163", array($this->blocked_ips_table)));
        return $F0 - $wpdb->get_var($wpdb->prepare("\x53\105\114\105\x43\x54\40\103\117\x55\116\x54\50\x2a\x29\x20\x46\x52\117\x4d\x20\x25\61\x73\x20\x57\x48\x45\x52\105\40\162\x65\141\x73\157\156\40\75\40\x27\x42\154\157\143\153\x65\x64\x20\x62\x79\x20\x41\x64\x6d\x69\x6e\47", array($this->blocked_ips_table)));
    }
    public function get_blocked_attack_count($iR)
    {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare("\123\105\x4c\105\103\124\40\103\x4f\x55\116\x54\50\x2a\x29\x20\x46\x52\117\x4d\x20\45\x31\163\40\127\x48\105\x52\105\40\164\x79\x70\145\x20\75\40\x25\163", array($this->attack_list, $iR)));
    }
    public function get_count_of_blocked_ips()
    {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare("\x53\105\114\x45\x43\124\40\x43\117\x55\x4e\x54\50\x2a\x29\40\x46\122\117\x4d\x20\45\x31\163", array($this->blocked_ips_table)));
    }
    public function mo_wpns_clear_login_report()
    {
        global $wpdb;
        $wpdb->query("\104\105\114\105\124\x45\x20\x46\122\117\115\40" . $wpdb->base_prefix . "\155\157\62\146\x5f\x6e\145\164\167\x6f\x72\153\x5f\164\162\x61\156\x73\141\x63\164\151\157\156\163\40\127\110\x45\x52\105\40\x53\164\141\164\165\x73\75\x27\x73\165\x63\143\145\x73\163\47\x20\x6f\x72\x20\123\164\x61\x74\x75\163\75\x20\47\160\x61\x73\164\146\x61\151\154\145\x64\x27\x20\157\x72\40\x53\164\141\164\165\163\75\47\x66\141\151\154\145\144\47\40");
    }
    public function get_blocked_ip($Of)
    {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare("\x53\105\x4c\x45\x43\124\x20\151\160\137\x61\144\x64\x72\x65\x73\163\40\106\122\x4f\115\40\45\61\x73\x20\x57\110\105\122\x45\40\151\144\x3d\40\45\x64", array($this->blocked_ips_table, $Of)));
    }
    public function get_blocked_ip_list()
    {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare("\123\105\x4c\105\x43\124\x20\x69\144\54\x20\x72\145\x61\163\x6f\156\54\40\151\160\x5f\141\x64\x64\162\145\163\163\54\40\x63\162\145\141\x74\145\144\x5f\x74\151\155\x65\x73\164\x61\x6d\x70\x20\x46\x52\117\x4d\40\x25\61\163", array($this->blocked_ips_table)));
    }
    public function get_blocked_attack_list()
    {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare("\123\x45\114\x45\x43\x54\40\x69\160\54\x20\x74\x79\x70\x65\54\x20\x74\151\x6d\145\54\40\151\156\160\165\x74\40\x46\122\117\115\x20\x25\x31\163", array($this->attack_list)));
    }
    public function insert_blocked_ip($nb, $e3, $R9)
    {
        global $wpdb;
        $wpdb->insert($this->blocked_ips_table, array("\151\160\x5f\141\144\x64\x72\x65\163\x73" => $nb, "\162\145\x61\x73\x6f\156" => $e3, "\x62\154\x6f\143\x6b\x65\144\x5f\x66\157\162\137\164\151\x6d\145" => $R9, "\143\x72\x65\x61\164\145\x64\x5f\164\x69\155\x65\x73\x74\141\155\160" => current_time("\x74\151\155\145\x73\164\141\155\160")), array("\x25\163", "\x25\163", "\x25\x64", "\x25\144"));
    }
    public function delete_blocked_ip($Of)
    {
        global $wpdb;
        $wpdb->query($wpdb->prepare("\x44\x45\114\x45\x54\x45\40\106\x52\x4f\115\40\45\x31\163\x20\127\110\x45\122\105\40\x69\144\40\x3d\x20\45\144", array($this->blocked_ips_table, $Of)));
    }
    public function get_whitelisted_ip_count($nb)
    {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare("\x53\x45\114\105\103\x54\40\x43\117\125\x4e\124\x28\52\x29\40\x46\122\117\115\x20\x25\x31\163\40\127\x48\105\x52\x45\x20\x69\160\137\141\x64\x64\162\145\163\x73\x20\75\40\x25\163", array($this->whitelist_ips_table, $nb)));
    }
    public function insert_whitelisted_ip($nb)
    {
        global $wpdb;
        $wpdb->insert($this->whitelist_ips_table, array("\x69\160\x5f\141\x64\144\162\x65\x73\x73" => $nb, "\x63\162\145\x61\x74\x65\x64\137\x74\151\155\x65\163\164\141\x6d\160" => current_time("\x74\151\x6d\x65\163\x74\x61\155\160")), array("\x25\163", "\x25\144"));
    }
    public function get_number_of_whitelisted_ips()
    {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare("\x53\x45\114\105\103\x54\x20\103\117\125\x4e\124\50\x2a\51\x20\x46\122\117\115\x20\x25\61\x73", array($this->whitelist_ips_table)));
    }
    public function delete_whitelisted_ip($Of)
    {
        global $wpdb;
        $wpdb->query($wpdb->prepare("\104\x45\114\x45\x54\x45\40\106\122\x4f\x4d\x20\45\x31\163\40\127\110\x45\x52\105\40\x69\x64\40\75\x20\45\x64", array($this->whitelist_ips_table, $Of)));
    }
    public function get_whitelisted_ips_list()
    {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare("\x53\x45\114\x45\103\124\x20\151\x64\x2c\x20\151\x70\137\x61\144\144\162\x65\x73\163\54\x20\x63\x72\145\x61\x74\145\144\x5f\164\151\x6d\145\x73\164\141\155\x70\40\x46\122\117\x4d\x20\x25\x31\163", array($this->whitelist_ips_table)));
    }
    public function get_email_audit_count($nb, $Zi)
    {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare("\x53\105\x4c\x45\x43\124\x20\103\x4f\125\x4e\124\50\52\51\40\x46\122\117\115\40\45\x31\x73\40\127\110\105\x52\105\x20\x69\160\x5f\x61\x64\x64\x72\x65\x73\x73\x20\75\40\x25\163\40\101\116\x44\x20\165\163\145\162\x6e\141\155\145\x3d\40\45\x73", array($this->email_audit_table, $nb, $Zi)));
    }
    public function insert_email_audit($nb, $Zi, $e3)
    {
        global $wpdb;
        $wpdb->insert($this->email_audit_table, array("\x69\x70\x5f\141\x64\144\162\145\163\x73" => $nb, "\x75\163\x65\162\x6e\141\x6d\x65" => $Zi, "\162\x65\141\163\x6f\156" => $e3, "\x63\162\145\x61\x74\x65\x64\x5f\164\x69\x6d\x65\163\164\141\x6d\x70" => current_time("\x74\x69\x6d\145\163\164\x61\155\x70")), array("\45\x73", "\45\x73", "\x25\x73", "\45\144"));
    }
    public function insert_transaction_audit($nb, $Zi, $qJ, $yY, $xz = null)
    {
        global $wpdb;
        $mC = array("\x69\x70\137\x61\144\144\162\x65\x73\x73" => $nb, "\165\x73\145\x72\156\141\x6d\145" => $Zi, "\164\x79\160\x65" => $qJ, "\x73\164\141\164\165\x73" => $yY, "\x63\x72\x65\141\x74\145\144\x5f\164\151\155\x65\163\164\x61\155\160" => current_time("\x74\151\x6d\145\x73\x74\x61\x6d\160"));
        $Eu = array("\x25\x73", "\45\x73", "\x25\x73", "\x25\163", "\x25\144");
        $mC["\x75\162\154"] = is_null($xz) ? '' : $xz;
        $xz = esc_url_raw($xz);
        $wpdb->insert($this->transaction_table, $mC, $Eu);
    }
    public function get_transasction_list()
    {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare("\x53\105\114\x45\103\x54\x20\151\x70\x5f\141\144\144\x72\145\163\163\54\40\x75\x73\145\x72\156\x61\x6d\145\54\40\164\171\x70\145\x2c\x20\163\x74\141\x74\165\x73\54\40\143\x72\145\141\x74\145\144\137\x74\151\155\x65\163\164\x61\x6d\x70\40\106\122\x4f\115\x20\45\x31\x73\40\x6f\162\x64\x65\x72\x20\x62\x79\x20\151\144\40\144\x65\163\x63\x20\154\x69\x6d\x69\x74\x20\x35\60\x30\60", array($this->transaction_table)));
    }
    public function get_login_transaction_report()
    {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare("\x53\x45\114\105\103\124\40\x69\160\x5f\x61\144\x64\162\x65\x73\163\x2c\40\x75\x73\x65\x72\156\141\x6d\x65\54\x20\x73\164\x61\164\x75\x73\x2c\x20\x63\162\145\141\x74\x65\144\x5f\x74\x69\x6d\145\163\164\x61\x6d\160\40\x46\x52\117\115\x20\x25\61\163\x20\127\110\105\x52\105\x20\x74\171\x70\x65\75\x27\125\163\x65\162\40\114\157\147\x69\x6e\x27\x20\157\x72\x64\x65\162\x20\142\x79\x20\151\144\x20\144\x65\163\143\x20\x6c\x69\x6d\151\164\40\x35\60\x30\60", array($this->transaction_table)));
    }
    public function update_transaction_table($Rv, $pU)
    {
        global $wpdb;
        $ns = "\x55\x50\104\101\x54\105\x20" . $this->transaction_table . "\40\x53\x45\x54\40";
        $ET = 0;
        foreach ($pU as $t8 => $iY) {
            if (!(0 !== $ET % 2)) {
                goto Of;
            }
            $ns .= "\40\54\40";
            Of:
            if ("\x63\x72\145\x61\164\145\144\137\164\x69\155\145\163\164\141\155\160" === $t8 || "\x69\144" === $t8) {
                goto gb;
            }
            $ns .= $wpdb->prepare("\45\x31\163\40\x3d\x20\x25\163", array($t8, $iY));
            goto VD;
            gb:
            $ns .= $wpdb->prepare("\x25\x31\x73\40\75\40\45\x64", array($t8, $iY));
            VD:
            $ET++;
            v4:
        }
        O0:
        $ns .= "\x20\127\110\x45\122\x45\40";
        $ET = 0;
        foreach ($Rv as $t8 => $iY) {
            if (!(0 !== $ET % 2)) {
                goto aN;
            }
            $ns .= "\40\x41\x4e\104\x20";
            aN:
            if ("\143\x72\145\141\x74\145\144\137\164\x69\155\145\163\164\141\155\x70" === $t8 || "\151\144" === $t8) {
                goto sh;
            }
            $ns .= $wpdb->prepare("\x20\x25\x31\163\40\75\x20\45\x73\x20", array($t8, $iY));
            goto J4;
            sh:
            $ns .= $wpdb->prepare("\40\45\61\x73\40\x3d\40\x25\x64\x20", array($t8, $iY));
            J4:
            $ET++;
            iP:
        }
        Cz:
        $wpdb->query($ns);
    }
    public function get_count_of_attacks_blocked()
    {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare("\x53\x45\x4c\x45\x43\x54\40\103\x4f\x55\x4e\x54\50\52\x29\40\106\122\x4f\x4d\40\x25\61\x73\x20\x57\x48\105\122\105\x20\163\x74\x61\164\x75\x73\x20\x3d\x20\45\x73\x20\x4f\x52\x20\163\164\x61\x74\165\x73\x20\x3d\40\45\163", array($this->transaction_table, MoWpnsConstants::FAILED, MoWpnsConstants::PAST_FAILED)));
    }
    public function get_failed_transaction_count($nb)
    {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare("\123\x45\114\105\x43\x54\40\103\x4f\x55\116\x54\50\x2a\x29\40\106\122\117\115\40\45\61\163\x20\x57\110\105\122\x45\x20\x69\160\137\x61\x64\x64\x72\x65\163\163\x20\x3d\40\45\x73\40\x41\x4e\x44\40\x73\x74\141\x74\165\163\x20\75\x20\45\x73", array($this->transaction_table, $nb, MoWpnsConstants::FAILED)));
    }
    public function delete_transaction($nb)
    {
        global $wpdb;
        $wpdb->query($wpdb->prepare("\x44\105\x4c\x45\124\x45\40\x46\x52\117\115\40\45\x31\163\x20\127\110\105\x52\105\x20\151\x70\x5f\141\x64\x64\162\x65\x73\x73\x20\75\x20\x25\x73\x20\x41\x4e\x44\x20\x73\x74\141\x74\x75\x73\x3d\x20\x25\x73\x20", array($this->transaction_table, $nb, MoWpnsConstants::FAILED)));
    }
}
A4:
