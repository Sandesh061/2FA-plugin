<?php


namespace TwoFA\Onprem;

use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Helper\TwoFAMoSessions;
use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Helper\MoWpnsMessages;
if (class_exists("\115\x6f\x32\146\x5f\117\156\120\x72\145\x6d\122\145\144\151\x72\145\143\164")) {
    goto Nzk;
}
class Mo2f_OnPremRedirect
{
    public function on_prem_validate_redirect($dX, $li, $bO, $current_user = null)
    {
        switch ($dX) {
            case MoWpnsConstants::GOOGLE_AUTHENTICATOR:
                $hP = $this->mo2f_google_authenticator_onpremise($li, $current_user);
                return $hP;
            case MoWpnsConstants::SECURITY_QUESTIONS:
                $hP = $this->mo2f_kba_onpremise($current_user);
                return $hP;
            case MoWpnsConstants::OTP_OVER_EMAIL:
                return $this->mo2f_otp_email_verify($li, $bO);
        }
        DMQ:
        WM3:
    }
    private function mo2f_kba_onpremise($current_user)
    {
        if (check_ajax_referer("\x6d\157\55\164\167\157\x2d\x66\141\x63\x74\x6f\x72\55\x61\152\141\170\x2d\156\157\x6e\143\x65", "\156\x6f\x6e\143\x65", false)) {
            goto l7H;
        }
        wp_send_json_error("\x63\x6c\x61\163\163\55\x6d\x6f\x32\x66\x2d\141\152\141\170");
        l7H:
        $v1 = $current_user->ID;
        $Ku = isset($_POST["\x6d\157\x32\x66\137\x61\156\163\167\145\162\x5f\61"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\x6f\62\146\137\x61\x6e\163\x77\x65\162\x5f\x31"])) : '';
        $J6 = isset($_POST["\x6d\x6f\x32\x66\x5f\141\156\x73\167\145\162\x5f\62"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\157\x32\x66\x5f\141\156\x73\x77\145\162\137\62"])) : '';
        $GG = TwoFAMoSessions::get_session_var("\x6d\157\x5f\62\137\x66\x61\x63\x74\157\162\x5f\x6b\142\141\137\x71\165\145\x73\164\151\x6f\x6e\x73");
        $Q9 = get_user_meta($v1, "\155\x6f\62\x66\x5f\153\142\x61\137\x63\150\x61\x6c\x6c\x65\x6e\147\145");
        $Q9 = $Q9[0];
        $q5 = $Q9[$GG[0]];
        $X7 = $Q9[$GG[1]];
        if (!strcmp(md5(strtolower($Ku)), $q5) && !strcmp(md5(strtolower($J6)), $X7)) {
            goto qsF;
        }
        $g4 = array("\163\x74\x61\x74\165\163" => "\106\x41\x49\x4c\x45\104", "\x6d\145\x73\163\x61\147\145" => "\x54\x45\x53\124\x20\x46\101\x49\114\105\x44\56");
        $hP = wp_json_encode($g4);
        return $hP;
        goto AAx;
        qsF:
        $g4 = array("\163\x74\141\164\165\x73" => "\123\x55\x43\103\105\123\x53", "\155\x65\163\x73\141\147\145" => "\x53\x75\x63\143\x65\163\x73\146\x75\154\x6c\171\40\x76\x61\154\x69\x64\x61\164\145\x64\x2e");
        $hP = wp_json_encode($g4);
        return $hP;
        AAx:
    }
    public function on_prem_send_redirect($Ww, $dX, $cs)
    {
        switch ($dX) {
            case MoWpnsConstants::OTP_OVER_EMAIL:
                $hP = $this->on_prem_otp_over_email($cs, $Ww);
                return $hP;
            case MoWpnsConstants::SECURITY_QUESTIONS:
                $hP = $this->on_prem_security_questions($cs);
                return $hP;
        }
        yus:
        u1b:
    }
    private function on_prem_security_questions($user)
    {
        $o_ = get_user_meta($user->ID, "\155\157\x32\146\x5f\153\x62\x61\137\143\150\141\x6c\154\x65\156\147\x65");
        $Jl = array_keys($o_[0]);
        $S7 = array_rand($Jl, 2);
        $jn = array("\161\x75\145\163\164\151\x6f\156" => $Jl[$S7[0]]);
        $wo = array("\161\165\x65\x73\164\x69\157\156" => $Jl[$S7[1]]);
        $yp = array($jn, $wo);
        update_user_meta($user->ID, "\x6b\142\x61\x5f\161\x75\145\163\x74\151\x6f\x6e\163\137\x75\163\145\162", $yp);
        $bC = wp_json_encode(array("\x74\170\x49\x64" => wp_rand(100, 10000000), "\x73\164\141\164\x75\163" => "\x53\125\103\x43\105\123\x53", "\x6d\x65\x73\x73\x61\x67\x65" => "\120\x6c\x65\x61\163\x65\x20\x61\156\163\167\145\x72\x20\x74\x68\145\40\x66\157\x6c\x6c\x6f\167\x69\156\x67\x20\163\145\x63\165\162\x69\164\x79\40\x71\165\x65\x73\164\151\157\x6e\x73\x2e", "\x71\x75\x65\x73\164\x69\x6f\156\x73" => $yp));
        return $bC;
    }
    private function mo2f_google_authenticator_onpremise($li, $current_user = null)
    {
        include_once dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . "\150\x61\156\x64\x6c\x65\x72" . DIRECTORY_SEPARATOR . "\164\167\x6f\146\x61" . DIRECTORY_SEPARATOR . "\x63\x6c\141\x73\x73\55\147\157\x6f\x67\x6c\x65\x2d\141\x75\x74\x68\x2d\157\x6e\160\162\145\x6d\x69\163\x65\56\x70\x68\x70";
        $Ts = new Google_auth_onpremise();
        $Ty = isset($_POST["\x73\145\x73\163\151\x6f\x6e\x5f\x69\x64"]) ? sanitize_text_field(wp_unslash($_POST["\x73\x65\163\163\151\x6f\156\137\151\144"])) : null;
        if (is_user_logged_in()) {
            goto mC0;
        }
        if (isset($current_user) && !empty($current_user->ID)) {
            goto qE1;
        }
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\155\157\x32\x66\137\143\165\x72\162\145\x6e\164\137\165\163\x65\162\x5f\x69\144");
        goto puF;
        mC0:
        $user = wp_get_current_user();
        $v1 = $user->ID;
        goto puF;
        qE1:
        $v1 = $current_user->ID;
        puF:
        $wG = $Ts->mo_a_auth_get_secret($v1);
        $hP = $Ts->mo2f_verify_code($wG, $li);
        return $hP;
    }
    private function on_prem_otp_over_email($current_user, $UG)
    {
        if ($this->mo2f_check_if_email_transactions_exists()) {
            goto ykN;
        }
        return wp_json_encode(array("\163\164\141\x74\165\x73" => "\105\122\x52\x4f\122", "\155\x65\163\x73\141\x67\145" => MoWpnsMessages::ERROR_IN_SENDING_OTP));
        ykN:
        return $this->on_prem_send_otp_email($current_user, $UG);
    }
    public function mo2f_check_if_email_transactions_exists()
    {
        if ((int) MoWpnsUtility::get_mo2f_db_option("\143\x6d\126\x74\x59\x57\x6c\165\x61\x57\65\x6e\x54\x31\x52\121", "\x73\x69\x74\145\137\157\160\x74\x69\x6f\x6e") <= 0 && !get_site_option("\155\x6f\x32\x66\141\x5f\x6c\153")) {
            goto xqp;
        }
        return true;
        goto Y3D;
        xqp:
        return false;
        Y3D:
    }
    private function on_prem_send_otp_email($current_user, $fK)
    {
        global $ai;
        $a3 = MoWpnsUtility::get_mo2f_db_option("\155\157\62\146\137\x65\155\x61\151\x6c\137\x73\x75\142\x6a\145\143\x74", "\x73\x69\x74\x65\x5f\157\160\x74\151\x6f\x6e");
        $Tp = array("\x43\157\x6e\164\x65\156\164\x2d\x54\171\x70\x65\72\x20\164\145\x78\x74\x2f\x68\x74\x6d\x6c\x3b\x20\143\x68\x61\x72\163\145\x74\x3d\125\x54\106\x2d\x38");
        $li = '';
        $ET = 1;
        und:
        if (!($ET < 7)) {
            goto vqH;
        }
        $li .= wp_rand(0, 9);
        VkE:
        $ET++;
        goto und;
        vqH:
        $bO = MoWpnsUtility::rand();
        TwoFAMoSessions::add_session_var("\155\x6f\x32\x66\137\157\x74\160\x5f\x65\155\141\151\154\137\143\157\144\145", $bO . $li);
        TwoFAMoSessions::add_session_var("\155\x6f\x32\x66\x5f\157\164\x70\x5f\145\155\141\151\x6c\137\164\151\x6d\145", time());
        TwoFAMoSessions::add_session_var("\x74\x65\x6d\160\122\145\147\x45\x6d\x61\151\154", $fK);
        $jD = MoWpnsUtility::get_mo2f_db_option("\x6d\157\x32\146\x5f\x6f\164\x70\x5f\157\x76\145\162\137\x65\155\141\151\154\137\x74\145\155\160\154\x61\x74\x65", "\163\x69\164\145\x5f\x6f\x70\164\151\157\x6e");
        $jD = str_replace("\x23\43\151\x6d\141\147\x65\x5f\x70\141\x74\150\x23\x23", $ai, $jD);
        $jD = str_replace("\x23\x23\157\x74\160\x5f\164\x6f\153\145\156\43\43", $li, $jD);
        $vv = wp_mail($fK, $a3, $jD, $Tp);
        if ($vv) {
            goto t9p;
        }
        $g4 = array("\x73\164\141\x74\165\x73" => "\x46\101\111\x4c\x45\x44", "\155\x65\x73\163\x61\x67\x65" => "\124\105\123\124\x20\x46\x41\111\x4c\105\104\x2e");
        goto oNJ;
        t9p:
        $Bj = get_site_option("\143\x6d\x56\164\131\x57\154\x75\141\127\x35\x6e\x54\61\x52\121");
        update_site_option("\x63\x6d\126\164\131\x57\x6c\x75\141\127\x35\x6e\x54\61\122\121", $Bj - 1);
        if (!("\65" === $Bj)) {
            goto ibf;
        }
        Miniorange_Authentication::mo2f_low_otp_alert("\145\155\141\151\154");
        ibf:
        $g4 = array("\163\164\x61\164\x75\x73" => "\x53\x55\103\x43\105\123\123", "\x6d\145\163\x73\x61\x67\145" => "\101\x6e\x20\x4f\124\120\40\x63\157\144\145\x20\150\x61\163\x20\x62\x65\x65\x6e\x20\x73\x65\x6e\x74\40\164\x6f\x20\171\157\165\x20\x6f\156\x20\171\157\x75\x72\x20\x65\x6d\x61\151\154\x2e", "\x74\x78\111\144" => $bO, "\x65\155\x61\x69\154" => $fK);
        oNJ:
        $hP = wp_json_encode($g4);
        return $hP;
    }
    private function mo2f_otp_email_verify($li, $bO)
    {
        global $Gw;
        if (!(isset($li) && !empty($li))) {
            goto pUJ;
        }
        $Ov = TwoFAMoSessions::get_session_var("\x6d\x6f\x32\146\137\x6f\164\160\137\145\155\x61\x69\x6c\x5f\x63\x6f\x64\x65");
        $rs = TwoFAMoSessions::get_session_var("\x6d\x6f\x32\146\137\157\164\160\137\x65\155\x61\x69\x6c\137\x74\151\x6d\x65");
        $j9 = time() - 300;
        if ($j9 > $rs) {
            goto rHH;
        }
        if (strtolower((string) ($bO . $li)) === strtolower((string) $Ov)) {
            goto vCK;
        }
        $g4 = array("\163\x74\x61\164\165\x73" => "\105\122\122\x4f\122", "\155\145\163\x73\x61\x67\x65" => MoWpnsMessages::INVALID_OTP);
        goto bSy;
        rHH:
        $g4 = array("\163\164\141\164\x75\x73" => "\x45\122\x52\117\122", "\x6d\145\163\163\x61\x67\x65" => "\x54\150\145\x20\117\156\145\x20\164\151\155\145\40\x70\x61\x73\163\x63\157\144\145\x20\150\141\x73\x20\142\x65\145\156\x20\145\x78\160\151\x72\145\144\56\x20\x50\154\145\x61\163\145\40\162\x65\x73\145\x6e\x64\40\164\x68\x65\40\x63\157\144\145\x2e");
        goto bSy;
        vCK:
        $g4 = array("\x73\x74\x61\164\165\163" => "\123\125\x43\103\105\x53\123", "\155\x65\163\163\x61\147\x65" => "\x53\165\143\x63\145\163\163\x66\165\154\154\171\40\x76\x61\154\151\x64\x61\164\145\x64\56");
        TwoFAMoSessions::unset_session("\x6d\x6f\x32\x66\x5f\x6f\164\x70\137\145\155\141\x69\x6c\x5f\x63\157\144\145");
        TwoFAMoSessions::unset_session("\x6d\157\62\x66\137\157\164\160\x5f\x65\x6d\141\151\154\x5f\x74\151\155\145");
        TwoFAMoSessions::unset_session("\164\145\155\x70\x52\x65\x67\105\155\x61\x69\154");
        bSy:
        $hP = wp_json_encode($g4);
        return $hP;
        pUJ:
    }
    public function mo2f_pass2login_push_email_onpremise($current_user, $fK, $tG = false)
    {
        global $Gw;
        if (!empty($fK)) {
            goto yLV;
        }
        $fK = $Gw->get_user_detail("\155\x6f\62\x66\x5f\x75\163\145\x72\x5f\145\x6d\141\151\x6c", $current_user->ID);
        yLV:
        $a3 = MoWpnsUtility::get_mo2f_db_option("\x6d\157\x32\146\137\x65\155\141\151\x6c\137\166\145\162\137\163\x75\142\152\145\143\x74", "\163\151\x74\145\x5f\157\x70\x74\x69\157\156");
        $Tp = array("\x43\x6f\156\x74\145\156\x74\55\124\x79\160\x65\72\x20\x74\x65\x78\x74\x2f\x68\164\x6d\154\x3b\x20\143\150\x61\162\x73\x65\164\x3d\125\x54\x46\x2d\70");
        $e9 = '';
        $li = '';
        $e2 = '';
        $ET = 1;
        q6v:
        if (!($ET < 7)) {
            goto k18;
        }
        $li .= wp_rand(0, 9);
        $e9 .= wp_rand(100, 999);
        $e2 .= wp_rand(0, 9);
        Z81:
        $ET++;
        goto q6v;
        k18:
        $CZ = hash("\163\150\141\65\x31\62", $li);
        $Ha = hash("\163\150\141\x35\61\62", $e2);
        TwoFAMoSessions::add_session_var("\x6d\157\62\x66\x5f\164\162\141\x6e\x73\141\143\164\x69\157\x6e\111\144", $e9);
        TwoFAMoSessions::add_session_var($e9, array("\165\x73\x65\162\x5f\x69\x64" => $current_user->ID, "\x75\x73\145\162\137\x65\155\x61\x69\154" => $fK));
        $v1 = hash("\x73\150\141\65\61\x32", $current_user->ID . $e9);
        update_site_option($v1, $CZ);
        update_site_option($e9, 3);
        $zm = $v1 . "\104";
        update_site_option($zm, $Ha);
        $jD = $this->getemailtemplate($v1, $CZ, $Ha, $e9, $fK);
        $R7 = MoWpnsUtility::get_mo2f_db_option("\143\155\126\164\x59\127\x6c\165\x61\127\x35\x6e\x54\x31\x52\x51", "\163\x69\164\x65\x5f\x6f\x70\164\151\157\156");
        $vv = wp_mail($fK, $a3, $jD, $Tp);
        $bC = array("\x74\x78\x49\x64" => $e9);
        if ($vv) {
            goto Quq;
        }
        $bC["\x73\x74\x61\x74\165\163"] = "\x45\x52\x52\x4f\122";
        $bC["\155\x65\163\163\x61\147\145"] = MoWpnsMessages::ERROR_DURING_PROCESS_EMAIL;
        goto Gi8;
        Quq:
        if (!(get_site_option("\x63\x6d\126\164\131\127\154\x75\141\x57\x35\x6e\124\61\x52\x51") === 5)) {
            goto fBA;
        }
        Miniorange_Authentication::mo2f_low_otp_alert("\x65\155\141\151\x6c");
        fBA:
        update_site_option("\x63\155\x56\x74\131\x57\154\x75\141\x57\x35\156\124\x31\122\x51", $R7 - 1);
        $bC["\163\164\141\x74\x75\163"] = "\123\125\x43\x43\x45\x53\123";
        $rs = "\x74\x69\155\145" . $e9;
        $E6 = round(microtime(true) * 1000);
        update_site_option($rs, $E6);
        Gi8:
        return wp_json_encode($bC);
    }
    public function getemailtemplate($v1, $CZ, $Ha, $e9, $fK)
    {
        global $ai;
        $xz = get_site_option("\163\x69\164\x65\165\x72\154") . "\x2f\167\160\55\x6c\157\147\151\x6e\56\160\150\x70\x3f";
        $jD = MoWpnsUtility::get_mo2f_db_option("\x6d\157\62\146\x5f\x6f\x75\164\137\157\146\x5f\x62\141\x6e\144\x5f\145\x6d\141\x69\154\x5f\x74\x65\155\160\x6c\x61\x74\x65", "\163\151\164\x65\x5f\157\160\x74\x69\157\156");
        $jD = str_replace("\43\43\151\x6d\x61\147\145\137\160\141\x74\150\43\x23", $ai, $jD);
        $jD = str_replace("\x23\x23\165\163\145\x72\x5f\151\x64\x23\x23", $v1, $jD);
        $jD = str_replace("\x23\43\x75\162\x6c\x23\x23", $xz, $jD);
        $jD = str_replace("\x23\43\141\143\x63\145\x70\x74\137\x74\x6f\x6b\x65\156\x23\43", $CZ, $jD);
        $jD = str_replace("\43\x23\x64\x65\156\x69\x65\x5f\x74\x6f\153\145\156\x23\x23", $Ha, $jD);
        $jD = str_replace("\43\43\164\170\151\x64\43\43", $e9, $jD);
        $jD = str_replace("\x23\x23\145\x6d\141\x69\154\43\43", $fK, $jD);
        return $jD;
    }
}
Nzk:
