<?php


use TwoFA\Helper\MoWpnsHandler;
use TwoFA\Helper\MoWpnsConstants;
if (defined("\x41\102\x53\120\x41\x54\x48")) {
    goto NA;
}
exit;
NA:
if (class_exists("\x4d\x6f\62\x66\x5f\x4c\157\147\x67\145\x72")) {
    goto xi;
}
class Mo2f_Logger
{
    public function __construct()
    {
        add_action("\154\157\x67\x5f\64\60\63", array($this, "\154\157\147\x5f\64\x30\63"));
        add_action("\164\x65\155\x70\x6c\141\x74\145\x5f\162\145\x64\151\162\x65\143\164", array($this, "\154\x6f\x67\x5f\64\60\64"));
    }
    public function log_403()
    {
        global $uz;
        $wB = new MoWpnsHandler();
        $Px = $uz->get_client_ip();
        $Px = sanitize_text_field($Px);
        $xz = $uz->get_current_url();
        $user = wp_get_current_user();
        $Zi = is_user_logged_in() ? $user->user_login : "\x47\x55\105\123\124";
        if (!("\x74\162\165\x65" === get_site_option("\x6d\157\62\146\x5f\x65\156\x61\x62\154\x65\x5f\154\157\147\151\156\137\162\145\160\x6f\x72\164"))) {
            goto iS;
        }
        $wB->add_transactions($Px, $Zi, MoWpnsConstants::ERR_403, MoWpnsConstants::ACCESS_DENIED, $xz);
        iS:
    }
    public function log_404()
    {
        global $uz;
        if (is_404()) {
            goto J8;
        }
        return;
        J8:
        $wB = new MoWpnsHandler();
        $Px = $uz->get_client_ip();
        $Px = sanitize_text_field($Px);
        $xz = $uz->get_current_url();
        $user = wp_get_current_user();
        $Zi = is_user_logged_in() ? $user->user_login : "\x47\x55\x45\123\124";
        if (!("\164\x72\165\145" === get_site_option("\155\157\x32\x66\x5f\145\x6e\141\x62\x6c\x65\x5f\154\x6f\x67\x69\156\137\x72\145\x70\157\x72\164"))) {
            goto Ma;
        }
        $wB->add_transactions($Px, $Zi, MoWpnsConstants::ERR_404, MoWpnsConstants::ACCESS_DENIED, $xz);
        Ma:
    }
}
new Mo2f_Logger();
xi:
