<?php


namespace TwoFA\Onprem;

use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Helper\Mo2f_Common_Helper;
use TwoFA\Helper\MocURL;
if (defined("\101\x42\x53\120\101\124\110")) {
    goto wz;
}
exit;
wz:
if (class_exists("\x4d\x6f\x32\x66\x5f\x56\x4c\x53")) {
    goto fq;
}
class Mo2f_VLS
{
    public function __construct()
    {
        add_action("\167\x70\x5f\x61\x6a\x61\x78\137\x6d\x6f\x32\146\137\164\167\157\137\146\x61\143\164\157\162\x5f\141\x6a\141\170", array($this, "\155\157\x32\146\137\x74\x77\157\x5f\146\x61\x63\x74\x6f\162\137\x61\152\x61\170"));
        add_action("\x77\x70\x5f\x61\152\x61\x78\137\156\x6f\x70\x72\151\x76\137\x6d\x6f\x32\146\137\x74\x77\x6f\x5f\146\141\143\164\157\x72\137\x61\x6a\x61\x78", array($this, "\155\x6f\x32\146\x5f\164\x77\157\x5f\x66\141\x63\x74\157\x72\137\x61\152\x61\x78"));
        add_action("\x6d\157\62\x66\137\162\x6c\x64", array($this, "\x6d\157\x32\x66\137\x72\154\144"));
        add_action("\141\144\155\x69\156\x5f\x69\x6e\151\x74", array($this, "\155\157\x32\146\x5f\x70\x6c\143"));
        add_filter("\155\157\62\146\137\x69\163\x5f\x6c\x76\137\156\x65\x65\144\145\144", array($this, "\155\x6f\x32\x66\x5f\151\x73\x5f\154\x76\137\156\x65\x65\144\145\144"));
    }
    public function mo2f_two_factor_ajax()
    {
        $GLOBALS["\x6d\157\x32\146\x5f\151\x73\137\141\152\x61\170\137\x72\145\x71\x75\145\163\x74"] = true;
        if (check_ajax_referer("\x6d\x6f\55\164\167\157\55\x66\x61\143\x74\x6f\162\x2d\x61\x6a\x61\x78\55\156\x6f\156\x63\x65", "\156\x6f\x6e\143\x65", false)) {
            goto eG;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG));
        eG:
        $Xh = isset($_POST["\157\160\x74\x69\x6f\156"]) ? sanitize_text_field(wp_unslash($_POST["\x6f\x70\x74\151\x6f\x6e"])) : '';
        switch ($Xh) {
            case "\155\x6f\x32\x66\137\166\x65\x72\x69\x66\x79\x5f\154\x69\x63\x65\156\163\145":
                $this->mo2f_verify_license($_POST);
                goto mb;
            case "\155\x6f\137\x32\146\x61\137\x62\141\x63\x6b\137\x61\x63\x63\x6f\165\156\x74":
                $this->mo2f_go_back_account($_POST);
                goto mb;
        }
        K6:
        mb:
    }
    public function mo2f_is_lv_needed()
    {
        return true;
    }
    public function mo2f_verify_license($post)
    {
        global $Gw, $iZ;
        $j8 = isset($post["\154\x69\x63\145\x6e\x73\x65\x5f\143\x6f\156\163\145\156\164"]) ? "\164\162\165\x65" === sanitize_text_field(wp_unslash($post["\154\151\143\145\156\x73\x65\137\x63\x6f\x6e\163\x65\156\x74"])) : false;
        $hW = isset($post["\155\157\x32\x66\141\137\154\151\x63\x65\x6e\143\145\x5f\x6b\x65\171"]) ? wp_unslash($post["\155\157\62\146\x61\x5f\x6c\x69\143\x65\156\x63\x65\x5f\x6b\x65\171"]) : '';
        $w9 = htmlspecialchars(trim($hW));
        if ($j8) {
            goto Sg;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate("\x50\x6c\145\141\x73\x65\x20\143\x68\x65\143\x6b\40\x74\150\145\x20\142\157\x78\40\x74\157\40\143\x6f\156\146\151\x72\x6d\40\171\x6f\165\40\150\141\x76\145\x20\162\145\141\x64\x20\164\150\145\40\x6c\151\x63\x65\x6e\163\145\40\144\145\x74\141\151\154\163\x2e"));
        Sg:
        if (empty($w9)) {
            goto a8;
        }
        $Gi = new MocURL();
        $hP = $Gi->get_customer_transactions("\167\x70\137\163\x65\143\165\162\x69\x74\x79\x5f\x74\167\x6f\x5f\146\x61\143\164\157\162\x5f\142\141\163\x69\143\137\160\x6c\141\x6e", "\120\x52\105\x4d\x49\125\115");
        if ($hP) {
            goto vH;
        }
        return;
        vH:
        $hP = json_decode($hP, true);
        $f5 = false;
        if (!isset($hP["\x6c\151\143\x65\x6e\163\x65\x45\x78\x70\151\x72\x79"])) {
            goto Xo;
        }
        $bq = $hP["\x6c\151\x63\145\x6e\x73\x65\105\170\x70\x69\162\x79"];
        $k4 = strtotime($bq);
        $bf = time();
        if (!($k4 < $bf)) {
            goto gq;
        }
        $f5 = true;
        gq:
        Xo:
        if (strcasecmp($hP["\163\x74\141\164\165\163"], "\x53\x55\103\x43\105\x53\123") === 0) {
            goto Vk;
        }
        $xz = esc_url(add_query_arg(array("\160\141\x67\x65" => "\155\157\137\x32\146\141\x5f\x75\x70\147\x72\x61\x64\145"), isset($_SERVER["\122\105\121\125\105\123\124\137\x55\122\111"]) ? esc_url_raw(wp_unslash($_SERVER["\x52\105\121\125\x45\123\x54\x5f\125\x52\111"])) : ''));
        $jD = "\131\x6f\x75\40\150\141\x76\145\x20\156\x6f\164\x20\x75\160\147\x72\141\144\145\x64\40\x79\x65\x74\56\x20\x3c\141\x20\150\162\x65\146\75" . $xz . "\x3e\x43\154\151\143\153\x20\150\x65\162\145\40\74\57\141\x3e\x20\164\x6f\40\x75\x70\x67\x72\x61\x64\145\x20\164\157\x20\x70\162\x65\x6d\151\x75\155\x20\166\x65\x72\163\x69\157\x6e\56";
        wp_send_json_error(MoWpnsMessages::lang_translate($jD));
        goto Jy;
        Vk:
        update_site_option("\143\x6d\126\164\131\x57\x6c\x75\x61\x57\65\156\124\x31\x52\121\126\x48\112\150\x62\x6e\x4e\150\131\63\x52\160\142\x32\x35\172", $hP["\163\155\x73\122\x65\x6d\x61\151\x6e\x69\156\x67"]);
        $bC = json_decode($this->mo2fa_vl($w9), true);
        if (!$f5) {
            goto Ax;
        }
        $bC = $this->mo_2fa_update_status($w9);
        $xz = MoWpnsConstants::PORTAL_LINK . "\x69\x6e\x69\164\x69\141\x6c\x69\172\145\x70\141\x79\x6d\x65\x6e\164\77\162\145\x71\165\x65\x73\164\x4f\162\x69\x67\x69\x6e\x3d" . $hP["\x6c\151\x63\145\156\x73\145\x50\154\x61\156"];
        $jD = "\131\157\x75\x72\40\x50\154\141\156\40\150\141\x73\x20\142\x65\145\156\x20\x65\170\x70\151\x72\145\144\40\x70\154\145\x61\x73\145\x20\x72\145\x6e\x65\167\40\171\x6f\x75\x72\40\x70\154\141\x6e\x2e\74\x61\x20\150\162\145\x66\x3d" . $xz . "\x20\164\x61\162\147\145\164\75\42\137\x62\x6c\141\x6e\153\42\76\x43\x6c\151\143\x6b\x20\150\x65\162\x65\40\x3c\x2f\x61\x3e\x74\x6f\40\x72\145\x6e\x65\167\x20\171\157\x75\x72\x20\160\x6c\141\x6e\56";
        wp_send_json_error(MoWpnsMessages::lang_translate($jD));
        goto gu;
        Ax:
        if (isset($bC) && strcasecmp($bC["\163\164\x61\164\165\163"], "\123\x55\x43\x43\x45\x53\x53") === 0) {
            goto EJ;
        }
        if (isset($hP) && strcasecmp($bC["\x73\x74\141\164\165\x73"], "\106\101\111\114\105\x44") === 0) {
            goto CN;
        }
        $jD = "\101\x6e\40\x65\x72\162\x6f\x72\40\157\143\143\165\x72\x65\x64\x20\x77\x68\x69\154\145\40\160\162\157\x63\145\x73\163\x69\x6e\147\40\171\157\165\162\x20\162\x65\x71\165\x65\x73\x74\56\40\x50\154\145\x61\x73\145\40\x54\x72\171\40\141\x67\x61\151\156\x2e";
        wp_send_json_error(MoWpnsMessages::lang_translate($jD));
        goto kl;
        EJ:
        update_site_option("\x76\x6c\x5f\x63\x68\x65\143\153\137\164", time());
        $t8 = get_site_option("\155\157\62\x66\137\143\x75\163\x74\x6f\x6d\x65\x72\x5f\164\157\x6b\145\x6e");
        $wT = get_site_option("\163\x69\164\x65\x75\x72\x6c");
        update_site_option("\x6d\157\62\146\x61\x5f\x6c\x6b", MO2f_Utility::encrypt_data($w9, $t8));
        $current_user = wp_get_current_user();
        update_site_option("\x6d\x6f\62\146\137\x6d\151\x6e\x69\x6f\162\x61\x6e\x67\x65\x5f\141\x64\155\x69\156", $current_user->ID);
        $Gw->update_user_details($current_user->ID, array("\x6d\157\62\146\x5f\x75\163\x65\162\137\145\x6d\141\151\x6c" => $current_user->user_email, "\165\163\145\162\x5f\162\145\x67\151\163\x74\162\x61\164\x69\157\x6e\137\167\151\164\150\x5f\x6d\151\156\x69\157\162\141\x6e\147\x65" => "\123\x55\103\103\105\123\123", "\155\157\62\x66\137\x32\146\141\143\x74\157\162\137\x65\x6e\141\x62\x6c\145\137\62\x66\x61\x5f\x62\171\165\x73\145\x72\x73" => 1, "\x6d\x6f\x5f\62\146\x61\143\164\157\x72\x5f\165\163\145\162\x5f\162\145\147\x69\x73\164\162\x61\164\151\157\156\x5f\163\x74\x61\x74\165\x73" => "\115\117\x5f\x32\137\106\x41\x43\124\x4f\x52\x5f\111\116\x49\124\111\x41\114\x49\x5a\x45\x5f\x54\127\x4f\x5f\106\x41\x43\x54\117\x52"));
        update_site_option("\x63\62\154\60\x5a\126\x39\x31\x63\155\x77\75", MO2f_Utility::encrypt_data($wT, $t8));
        update_site_option("\155\157\137\x32\x66\x61\143\164\x6f\x72\137\x61\144\x6d\151\156\x5f\x72\145\147\x69\x73\164\x72\x61\x74\151\157\x6e\x5f\163\x74\141\x74\165\x73", "\x4d\x4f\137\62\x5f\106\101\103\124\x4f\x52\137\x43\x55\123\124\117\x4d\x45\122\137\x52\105\107\111\x53\124\x45\x52\x45\104\x5f\x53\x55\103\103\x45\123\123");
        wp_send_json_success(MoWpnsMessages::lang_translate("\131\157\x75\x20\x6c\151\x63\x65\x6e\x73\145\x20\150\141\163\40\x62\x65\x65\156\40\166\x65\162\151\146\151\145\x64\40\163\165\x63\143\x65\163\163\146\165\154\154\x79\x2e\40\x59\x6f\165\x20\143\141\156\40\x6e\157\x77\40\x73\145\x74\x75\x70\40\x74\150\145\x20\x70\x6c\x75\147\151\x6e\56"));
        goto kl;
        CN:
        if (strcasecmp($bC["\155\145\163\163\x61\147\x65"], "\x43\x6f\x64\x65\x20\x68\141\x73\40\x45\170\x70\x69\x72\x65\x64") === 0) {
            goto qX;
        }
        $jD = "\x59\x6f\165\x20\150\x61\x76\145\40\145\156\x74\x65\x72\145\144\40\141\156\x20\x69\x6e\x76\141\x6c\x69\x64\x20\x6c\151\x63\145\x6e\163\x65\x20\153\x65\171\x2e\x20\x50\x6c\145\x61\163\x65\40\x65\x6e\x74\x65\162\40\141\40\x76\x61\154\151\x64\x20\x6c\x69\x63\x65\156\163\145\x20\153\x65\171\x2e";
        wp_send_json_error(MoWpnsMessages::lang_translate($jD));
        goto T9;
        qX:
        $jD = "\114\151\143\x65\x6e\163\x65\40\x6b\145\x79\40\171\157\165\40\150\141\166\145\x20\x65\156\x74\145\162\145\144\40\150\141\163\x20\x61\x6c\x72\145\141\x64\171\40\x62\x65\145\156\40\x75\x73\x65\144\x2e\x20\120\154\x65\141\163\x65\40\145\x6e\x74\x65\162\x20\141\40\40\74\141\x20\x20\x6f\x6e\143\154\151\x63\x6b\x3d\42\x67\145\164\154\x69\x63\145\156\x73\x65\x6b\x65\x79\x73\x66\157\x72\x6d\50\51\42\x20\x3e\74\165\x3e\x3c\151\x3e\x75\x6e\x75\163\x65\144\x20\x6c\151\x63\x65\156\163\145\x20\153\x65\171\74\57\x69\x3e\x3c\x2f\165\76\x3c\x2f\141\x3e\x20\x6f\x72\40\74\x61\x20\x68\x72\145\146\75" . esc_url($iZ["\x4c\x69\x63\145\x6e\x73\x65\40\x54\x72\x61\156\x73\x66\x65\x72"]) . "\40\x74\141\x72\x67\145\x74\75\x22\142\154\x61\x6e\x6b\x22\76\x3c\x69\76\164\x72\x61\156\163\x66\x65\162\x20\x74\x68\145\40\154\x69\x63\145\156\163\x65\40\x6b\145\171\74\x2f\x69\x3e\74\57\141\76";
        wp_send_json_error(MoWpnsMessages::lang_translate($jD));
        T9:
        kl:
        gu:
        Jy:
        a8:
    }
    public function mo2f_go_back_account()
    {
        $cB = new Mo2f_Common_Helper();
        $cB->mo2f_remove_account_details();
        wp_send_json_success();
    }
    public function mo2fa_vl($w9)
    {
        $xz = MO_HOST_NAME . "\57\x6d\157\141\163\x2f\141\160\151\57\142\x61\143\153\165\x70\x63\157\144\145\57\x76\145\x72\x69\x66\x79";
        $hS = get_site_option("\x6d\157\x32\x66\137\x63\165\x73\164\x6f\x6d\145\x72\x4b\x65\x79");
        $it = new Mo2f_Api();
        $Tp = $it->get_http_header_array();
        $aV = array("\143\x6f\144\145" => $w9, "\x63\165\163\164\x6f\155\x65\162\x4b\145\171" => $hS, "\141\144\144\151\164\151\157\156\x61\154\x46\151\145\154\144\x73" => array("\146\151\x65\x6c\144\61" => home_url()));
        $e5 = wp_json_encode($aV);
        $hP = $it->mo2f_http_request($xz, $e5, $Tp);
        return $hP;
    }
    public function mo_2fa_update_status()
    {
        $xz = MO_HOST_NAME . "\x2f\x6d\157\141\163\57\x61\160\x69\57\142\141\143\x6b\165\160\x63\x6f\144\145\57\x75\x70\144\141\164\x65\x73\x74\141\164\x75\163";
        $hS = get_site_option("\155\157\x32\146\137\143\165\x73\x74\x6f\155\145\x72\x4b\x65\171");
        $it = new Mo2f_Api();
        $Tp = $it->get_http_header_array();
        $t8 = get_site_option("\155\x6f\x32\146\137\x63\x75\x73\164\157\x6d\145\162\137\164\157\x6b\x65\x6e");
        $w9 = MO2f_Utility::decrypt_data(get_site_option("\155\x6f\62\146\141\137\154\x6b"), $t8);
        $aV = array("\x63\157\x64\x65" => $w9, "\143\165\163\164\x6f\155\145\x72\x4b\145\171" => $hS, "\x61\x64\x64\151\164\151\157\156\x61\x6c\106\x69\x65\154\x64\x73" => array("\x66\x69\x65\x6c\144\x31" => home_url()));
        $e5 = wp_json_encode($aV);
        $hP = $it->mo2f_http_request($xz, $e5, $Tp);
        return $hP;
    }
    public function mo2f_rld()
    {
        global $Gw;
        $hP = $this->mo_2fa_update_status();
        $hP = json_decode($hP);
        if (strcasecmp($hP->status, "\x53\x55\103\x43\105\x53\x53") === 0) {
            goto mJ;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate("\x54\x68\145\x72\x65\40\167\145\x72\145\x20\163\157\155\145\40\151\x73\163\x75\x65\40\167\150\151\154\x65\40\x72\x65\x6d\157\166\x69\x6e\x67\x20\171\157\x75\162\x20\x61\143\x63\x6f\165\156\x74\x2e"));
        goto ev;
        mJ:
        $Gw->update_user_details(wp_get_current_user()->ID, array("\x6d\157\x32\146\x5f\165\163\145\162\x5f\145\x6d\x61\151\x6c" => '', "\165\x73\145\162\x5f\162\x65\x67\151\163\x74\162\141\164\x69\157\x6e\137\167\x69\164\150\x5f\155\151\x6e\x69\x6f\162\141\x6e\x67\145" => '', "\155\157\x32\146\137\62\146\141\x63\164\x6f\162\137\x65\x6e\141\x62\x6c\145\137\x32\x66\x61\x5f\x62\171\165\163\145\x72\x73" => 0, "\155\x6f\x5f\x32\146\x61\143\x74\157\162\x5f\165\163\145\x72\137\162\x65\x67\151\163\164\x72\141\164\x69\x6f\x6e\137\163\164\x61\164\165\163" => "\115\117\137\62\x5f\106\101\103\x54\x4f\x52\x5f\x56\105\122\x49\106\x59\137\x43\125\x53\x54\x4f\x4d\x45\122"));
        delete_site_option("\x6d\x6f\62\x66\x61\x5f\x6c\x6b");
        delete_site_option("\x6d\157\x32\x66\137\154\x69\x63\145\156\163\145\x5f\x70\x6c\141\x6e\137\x6e\141\155\x65");
        ev:
    }
    public function mo2f_plc()
    {
        if (get_site_option("\155\x6f\62\146\141\x5f\x6c\153")) {
            goto Bp;
        }
        return;
        Bp:
        if (get_site_option("\142\127\x38\171\x5a\x6c\71\x68\x5a\x47\61\160\x62\154\71\x70\142\x6d\154\x30\130\x32\x78\160\131\x32\126\x75\143\62\x56\x66\x59\62\x68\154\131\62\163\75")) {
            goto f7;
        }
        update_site_option("\x62\127\x38\171\x5a\x6c\71\150\x5a\107\x31\160\142\154\x39\x70\142\155\x6c\x30\130\62\170\x70\131\x32\126\165\143\62\126\146\x59\62\x68\154\131\62\x73\75", time() + 345600);
        f7:
        $uI = time();
        $nd = get_site_option("\x62\127\x38\171\132\154\71\150\x5a\107\x31\160\x62\154\x39\x70\142\x6d\x6c\x30\x58\x32\170\160\x59\62\x56\165\x63\62\x56\146\131\62\150\154\131\62\163\x3d");
        if (!($uI > $nd)) {
            goto uI;
        }
        $Gi = new MocURL();
        $hP = $Gi->get_customer_transactions("\x77\x70\x5f\163\x65\x63\165\x72\151\164\171\137\x74\167\157\x5f\146\141\143\164\x6f\x72\x5f\x62\141\163\151\143\137\x70\x6c\141\156", "\x50\122\x45\115\x49\125\x4d");
        $hP = json_decode($hP, true);
        $ls = 0;
        if (!isset($hP["\x6c\x69\143\x65\x6e\163\145\105\x78\160\151\162\171"])) {
            goto LK;
        }
        $bq = $hP["\154\x69\x63\145\156\x73\145\105\x78\x70\x69\162\x79"];
        $k4 = strtotime($bq);
        $bf = time();
        if (!($k4 < $bf)) {
            goto lC;
        }
        $this->mo_2fa_update_status();
        $ls = 1;
        lC:
        LK:
        if (strcasecmp($hP["\163\164\x61\x74\x75\x73"], "\123\125\x43\x43\105\123\x53") !== 0 || $ls) {
            goto cT;
        }
        update_site_option("\x62\127\70\171\132\154\x39\150\x5a\x47\61\x70\x62\x6c\71\160\142\x6d\154\x30\x58\62\x78\160\x59\x32\x56\165\x63\x32\x56\x66\131\x32\150\154\x59\x32\163\75", $uI + 345600);
        goto KM;
        cT:
        MO2f_Utility::mo2f_debug_file("\x69\x6e\40\40\x73\x74\x72\x63\141\x73\145\x63\155\160\x28\x20\x24\143\x6f\156\164\145\156\x74\133\42\163\x74\x61\164\x75\x73\x22\135\54\x20\x22\x53\125\103\103\105\123\x53\42\x20\51\40\x21\x3d\x20\x30\x20\x6f\x72\40\x24\x64\x6e\153\144\x6e\153");
        $cB = new Mo2f_Common_Helper();
        $cB->mo2f_remove_account_details();
        delete_site_option("\x6d\x6f\62\146\x61\137\x6c\153");
        delete_site_option("\x6d\x6f\62\146\137\154\x69\143\x65\x6e\163\145\137\160\x6c\x61\x6e\137\156\141\155\x65");
        KM:
        uI:
    }
}
new Mo2f_VLS();
fq:
