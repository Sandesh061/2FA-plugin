<?php


namespace TwoFA\Onprem;

use TwoFA\Onprem\MO2f_Utility;
use TwoFA\Helper\Mo2f_Login_Popup;
use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Helper\Mo2f_Common_Helper;
use WP_REST_Request;
use TwoFA\Helper\MocURL;
if (defined("\x41\x42\x53\120\x41\x54\110")) {
    goto Zv;
}
exit;
Zv:
if (class_exists("\115\x6f\x32\146\137\101\x64\x6d\x69\156\x5f\x41\143\164\151\x6f\156\137\x48\141\x6e\x64\x6c\x65\x72")) {
    goto WV;
}
class Mo2f_Admin_Action_Handler
{
    public function __construct()
    {
        add_action("\x77\160\137\141\x6a\x61\170\x5f\x6d\157\137\x74\167\x6f\x5f\146\x61\x63\164\157\162\x5f\141\x6a\141\x78", array($this, "\155\x6f\x5f\164\x77\x6f\x5f\x66\141\143\164\157\162\x5f\x61\152\141\170"));
        add_action("\167\x70\x5f\141\x6a\141\x78\137\156\157\160\162\x69\x76\x5f\x6d\157\x5f\x74\167\157\137\146\x61\x63\x74\157\x72\x5f\x61\x6a\141\170", array($this, "\155\157\x5f\x74\167\x6f\x5f\x66\141\x63\164\x6f\x72\x5f\x61\152\x61\170"));
    }
    public function mo_two_factor_ajax()
    {
        $GLOBALS["\x6d\157\62\x66\x5f\x69\x73\x5f\141\x6a\141\x78\x5f\x72\x65\161\165\x65\163\x74"] = true;
        if (check_ajax_referer("\155\157\55\164\x77\157\55\146\x61\143\x74\157\162\x2d\141\x6a\x61\x78\x2d\156\x6f\156\143\145", "\156\157\x6e\x63\x65", false)) {
            goto XY;
        }
        wp_send_json_error("\143\154\141\163\x73\x2d\x6d\x6f\62\x66\55\x61\152\141\170");
        XY:
        $Xh = isset($_POST["\x6d\157\x5f\x32\146\137\x74\x77\157\x5f\146\141\143\164\x6f\162\x5f\141\152\141\x78"]) ? sanitize_text_field(wp_unslash($_POST["\155\157\137\62\146\x5f\x74\x77\x6f\137\146\141\143\164\x6f\162\x5f\141\152\141\x78"])) : '';
        switch ($Xh) {
            case "\155\157\62\146\x5f\x6d\x69\x6e\x69\157\x72\x61\x6e\x67\x65\137\x73\151\x67\156\137\151\156":
                $this->mo2f_miniorange_sign_in($_POST);
                goto Qy;
            case "\155\157\62\x66\x5f\155\151\156\x69\x6f\x72\x61\x6e\x67\x65\x5f\x73\x69\x67\156\137\x75\160":
                $this->mo2f_miniorange_sign_up($_POST);
                goto Qy;
            case "\x6d\x6f\x32\x66\137\x72\x65\155\157\x76\x65\x5f\155\151\156\x69\157\x72\141\156\147\145\x5f\141\x63\x63\x6f\165\156\164":
                $this->mo2f_remove_miniorange_account();
                goto Qy;
            case "\155\157\62\146\137\x63\x68\x65\143\x6b\137\x74\162\141\x6e\163\x61\143\x74\151\157\156\163":
                $this->mo2f_check_transactions();
                goto Qy;
            case "\155\x6f\62\146\137\150\141\x6e\144\x6c\x65\x5f\x73\165\160\x70\x6f\x72\164\137\146\157\162\155":
                $this->mo2f_handle_support_form($_POST);
                goto Qy;
        }
        BH:
        Qy:
    }
    public function mo2f_miniorange_sign_in($post)
    {
        global $uz;
        $fK = isset($post["\x65\x6d\141\x69\x6c"]) ? sanitize_email(wp_unslash($post["\x65\x6d\141\151\x6c"])) : '';
        $uk = isset($post["\160\x61\163\x73\x77\x6f\162\x64"]) ? wp_unslash($post["\x70\141\x73\x73\x77\157\x72\144"]) : '';
        if (!($uz->check_empty_or_null($fK) || $uz->check_empty_or_null($uk))) {
            goto QY;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::REQUIRED_FIELDS));
        QY:
        $cB = new Mo2f_Common_Helper();
        $cB->mo2f_get_miniorange_customer($fK, $uk);
    }
    public function mo2f_miniorange_sign_up($post)
    {
        $fK = isset($post["\x65\155\x61\151\154"]) ? sanitize_email(wp_unslash($post["\x65\155\x61\x69\x6c"])) : '';
        $ke = isset($_SERVER["\123\105\x52\126\105\x52\x5f\116\101\x4d\x45"]) ? sanitize_text_field(wp_unslash($_SERVER["\123\x45\122\x56\x45\122\137\116\101\115\x45"])) : '';
        $uk = isset($post["\160\141\163\x73\x77\x6f\162\x64"]) ? wp_unslash($post["\x70\141\x73\163\x77\x6f\162\144"]) : '';
        $mJ = isset($post["\143\x6f\156\146\151\162\155\x50\x61\x73\x73\x77\157\162\144"]) ? wp_unslash($post["\143\157\156\x66\x69\162\x6d\120\141\163\163\167\x6f\x72\144"]) : '';
        if (!(strlen($uk) < 6 || strlen($mJ) < 6)) {
            goto NN;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::PASS_LENGTH));
        NN:
        if (!($uk !== $mJ)) {
            goto HX;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::PASS_MISMATCH));
        HX:
        if (!(MoWpnsUtility::check_empty_or_null($fK) || MoWpnsUtility::check_empty_or_null($uk) || MoWpnsUtility::check_empty_or_null($mJ))) {
            goto fO;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::REQUIRED_FIELDS));
        fO:
        update_site_option("\x6d\157\x32\146\137\x65\x6d\141\x69\x6c", $fK);
        update_site_option("\x6d\157\x5f\167\160\x6e\163\x5f\143\x6f\155\x70\x61\156\x79", $ke);
        update_site_option("\155\x6f\x5f\x77\160\156\163\137\160\141\x73\163\167\x6f\162\x64", $uk);
        $uU = new MocURL();
        $hP = json_decode($uU->check_customer($fK), true);
        $cB = new Mo2f_Common_Helper();
        switch ($hP["\163\x74\141\164\x75\x73"]) {
            case "\x43\125\x53\x54\x4f\115\105\x52\x5f\x4e\117\x54\x5f\x46\x4f\125\116\104":
                $hS = json_decode($uU->create_customer($fK, $ke, $uk), true);
                $ga = isset($hS["\x6d\145\x73\163\x61\147\x65"]) ? $hS["\x6d\x65\163\163\141\x67\x65"] : __("\x45\162\x72\157\x72\x20\x6f\x63\x63\x75\162\x65\144\40\x77\x68\151\x6c\145\x20\x63\162\145\x61\x74\x69\x6e\147\x20\141\156\40\141\x63\x63\x6f\x75\156\x74\56", "\155\151\156\x69\157\162\141\x6e\147\145\x2d\x32\x2d\146\x61\x63\164\x6f\x72\55\141\165\x74\x68\145\156\164\x69\x63\x61\164\151\x6f\x6e");
                if (strcasecmp($hS["\163\x74\x61\164\165\163"], "\123\125\x43\x43\105\x53\x53") === 0) {
                    goto y2;
                }
                wp_send_json_error(MoWpnsMessages::lang_translate($ga));
                goto Wp;
                y2:
                $cB->mo2f_get_miniorange_customer($fK, $uk);
                Wp:
                goto jg;
            case "\x53\125\103\x43\105\123\123":
                wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::ALREADY_ACCOUNT_EXISTS));
                goto jg;
            case "\x45\x52\x52\117\122":
                wp_send_json_error(MoWpnsMessages::lang_translate($hP["\x6d\145\x73\163\141\147\x65"]));
                goto jg;
            default:
                $cB->mo2f_get_miniorange_customer($fK, $uk);
                return;
        }
        Dy:
        jg:
        wp_send_json_error(MoWpnsMessages::lang_translate("\x45\162\x72\x6f\x72\40\117\x63\143\165\x72\145\x64\x20\167\x68\151\154\145\40\162\145\147\x69\x73\164\162\x61\x74\x69\157\156\56\40\120\154\145\141\163\x65\x20\164\162\171\x20\141\x67\x61\151\156\x2e"));
    }
    public function mo2f_remove_miniorange_account()
    {
        global $uz, $Gw;
        if ($uz->check_empty_or_null(get_site_option("\155\x6f\x5f\167\x70\x6e\x73\x5f\162\145\147\151\x73\164\162\141\x74\x69\157\156\x5f\x73\164\141\164\x75\x73"))) {
            goto eb;
        }
        delete_site_option("\x6d\x6f\x32\x66\137\x65\155\141\x69\x6c");
        eb:
        do_action("\155\157\62\x66\x5f\162\154\144");
        $cB = new Mo2f_Common_Helper();
        $cB->mo2f_remove_account_details();
        if (MO2F_IS_ONPREM) {
            goto XG;
        }
        $Gw->mo2f_delete_cloud_meta_on_account_remove();
        XG:
        $yP = new Miniorange_Authentication();
        $yP->mo2f_auth_deactivate();
        wp_send_json_success(MoWpnsMessages::lang_translate("\101\x63\x63\157\x75\156\164\40\x72\x65\x6d\157\166\x65\x64\40\163\x75\x63\143\145\163\x73\146\165\154\154\x79\x2e"));
    }
    public function mo2f_check_transactions()
    {
        $Ip = new MocURL();
        $hP = json_decode($Ip->get_customer_transactions("\x6f\x74\160\137\162\145\x63\150\141\x72\x67\145\x5f\x70\x6c\x61\156", "\127\x50\137\117\x54\x50\137\126\105\122\x49\x46\111\x43\101\x54\x49\117\116\x5f\x50\114\125\107\x49\x4e"), true);
        if ("\123\125\x43\103\105\123\123" === $hP["\163\x74\141\x74\165\x73"]) {
            goto El;
        }
        update_site_option("\x6d\157\62\146\137\x6c\x69\x63\145\x6e\163\x65\x5f\164\x79\x70\145", "\x44\105\x4d\117");
        $hP = json_decode($Ip->get_customer_transactions("\x2d\x31", "\x44\105\x4d\117"), true);
        goto vq;
        El:
        update_site_option("\x6d\x6f\x32\x66\137\154\151\x63\x65\x6e\163\x65\x5f\164\x79\x70\x65", "\x50\x52\x45\115\x49\x55\115");
        vq:
        if (isset($hP["\163\x6d\x73\x52\145\155\141\x69\156\151\x6e\x67"])) {
            goto H7;
        }
        if ("\123\x55\x43\103\x45\x53\123" === $hP["\163\164\x61\x74\165\x73"]) {
            goto ci;
        }
        goto sk;
        H7:
        update_site_option("\x63\x6d\126\x74\x59\127\x6c\x75\x61\x57\x35\156\124\61\122\121\126\110\112\x68\142\156\116\150\131\63\122\x70\142\x32\x35\x7a", $hP["\163\x6d\163\x52\145\x6d\141\151\x6e\151\156\147"]);
        goto sk;
        ci:
        update_site_option("\x63\155\x56\164\131\127\154\x75\x61\127\65\156\124\x31\122\121\126\x48\112\x68\x62\x6e\116\x68\x59\x33\122\160\142\62\65\x7a", 0);
        sk:
        if (!isset($hP["\145\x6d\x61\151\x6c\122\x65\155\141\151\x6e\x69\156\x67"])) {
            goto QR;
        }
        if (MO2F_IS_ONPREM) {
            goto IX;
        }
        update_site_option("\143\x6d\x56\x74\x59\x57\x6c\x75\141\127\x35\x6e\124\61\x52\121", $hP["\x65\155\x61\151\154\x52\145\x6d\x61\151\x6e\151\156\147"]);
        if (!($hP["\x65\155\141\151\x6c\122\145\155\141\151\156\151\x6e\x67"] > 0)) {
            goto zt;
        }
        update_site_option("\142\x47\154\164\x61\x58\x52\123\x5a\x57\106\x6a\141\x47\x56\x6b", 0);
        zt:
        goto lf;
        IX:
        $hh = get_site_option("\x45\x6d\141\151\154\124\x72\x61\156\163\x61\143\x74\x69\157\x6e\103\165\x72\162\145\156\164", 30);
        if (!($hP["\145\x6d\141\x69\x6c\x52\x65\x6d\141\151\x6e\x69\x6e\147"] > $hh && $hP["\145\155\x61\151\x6c\122\145\155\141\151\156\x69\156\147"] > 10)) {
            goto KD;
        }
        $zX = $hP["\x65\155\141\151\154\x52\145\155\141\151\156\x69\x6e\147"] + get_site_option("\x63\x6d\126\x74\131\x57\154\x75\x61\127\65\x6e\x54\61\x52\121");
        update_site_option("\x62\x47\x6c\x74\x61\130\x52\x53\132\127\106\152\x61\107\126\x6b", 0);
        if (!($hh > 30)) {
            goto qr;
        }
        $zX = $zX - $hh;
        qr:
        update_site_option("\143\155\126\164\131\x57\x6c\x75\141\x57\65\156\x54\x31\122\121", $zX);
        update_site_option("\x45\155\x61\x69\154\124\x72\141\x6e\x73\141\x63\164\x69\157\x6e\x43\x75\162\x72\145\x6e\x74", $hP["\145\x6d\141\x69\x6c\x52\145\x6d\x61\151\x6e\151\x6e\x67"]);
        KD:
        lf:
        QR:
        wp_send_json_success(MoWpnsMessages::lang_translate("\124\162\x61\x6e\163\141\x63\164\x69\157\x6e\x73\40\x75\x70\x64\x61\x74\145\x64\40\163\x75\x63\143\145\x73\x73\146\x75\154\154\x79\56"));
    }
    public function mo2f_handle_support_form($post)
    {
        $wJ = isset($post["\155\157\62\x66\x5f\161\165\145\162\171"]) ? sanitize_text_field(wp_unslash($post["\x6d\x6f\x32\146\137\161\165\x65\162\x79"])) : '';
        $T7 = isset($post["\155\x6f\62\x66\137\161\x75\145\162\171\137\160\150\157\156\x65"]) ? sanitize_text_field(wp_unslash($post["\155\x6f\62\x66\x5f\x71\x75\145\162\171\x5f\160\150\x6f\x6e\x65"])) : '';
        $fK = isset($post["\x6d\x6f\x32\146\x5f\x71\165\145\162\x79\137\145\155\141\151\154"]) ? sanitize_text_field(wp_unslash($post["\x6d\x6f\62\146\x5f\161\165\145\162\171\137\x65\155\141\x69\x6c"])) : '';
        $bg = isset($post["\155\157\62\x66\137\x73\x65\x6e\144\x5f\143\x6f\x6e\x66\151\147\x75\x72\x61\164\x69\157\156"]) ? sanitize_text_field(wp_unslash($post["\155\x6f\x32\146\137\163\x65\156\x64\x5f\x63\157\156\146\x69\147\165\x72\x61\164\x69\x6f\x6e"])) : 0;
        $Xx = array();
        if (!(empty($fK) || empty($wJ))) {
            goto RV;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::SUPPORT_FORM_VALUES));
        RV:
        $Lk = new MocURL();
        if (!$bg) {
            goto oa;
        }
        $wJ = $wJ . MoWpnsUtility::mo_2fa_send_configuration(true);
        oa:
        if (!filter_var($fK, FILTER_VALIDATE_EMAIL)) {
            goto cM;
        }
        if (get_transient("\155\x6f\x32\146\x5f\x71\x75\145\x72\x79\137\x73\x65\156\164")) {
            goto kc;
        }
        $Xx = json_decode($Lk->submit_contact_us($fK, $T7, $wJ), true);
        goto Ea;
        cM:
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::SUPPORT_FORM_ERROR));
        goto Ea;
        kc:
        wp_send_json_success(MoWpnsMessages::lang_translate(MoWpnsMessages::QUERY_SUBMITTED));
        Ea:
        if (json_last_error() === JSON_ERROR_NONE && $Xx) {
            goto L2;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::SUPPORT_FORM_ERROR));
        goto ds;
        L2:
        wp_send_json_success(MoWpnsMessages::lang_translate(MoWpnsMessages::SUPPORT_FORM_SENT));
        ds:
    }
}
new Mo2f_Admin_Action_Handler();
WV:
