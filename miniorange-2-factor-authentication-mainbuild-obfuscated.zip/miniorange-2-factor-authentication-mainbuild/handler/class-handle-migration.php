<?php


if (defined("\101\102\x53\x50\x41\x54\110")) {
    goto rK;
}
exit;
rK:
if (class_exists("\x48\141\x6e\144\x6c\x65\137\x4d\x69\147\162\141\164\x69\x6f\x6e")) {
    goto mU;
}
class Handle_Migration
{
    public function __construct()
    {
        add_action("\x61\x64\x6d\151\156\x5f\x69\x6e\x69\164", array($this, "\155\x6f\x32\x66\x5f\150\x61\156\144\x6c\145\x5f\x6d\x69\x67\162\x61\164\151\157\x6e"), 10);
    }
    public function mo2f_handle_migration()
    {
        if (get_site_option("\x6d\157\x32\146\x5f\x68\141\x6e\144\154\x65\137\155\151\x67\x72\x61\x74\151\x6f\x6e\x5f\163\164\x61\164\165\163")) {
            goto vl;
        }
        update_site_option("\x6d\157\x32\146\x5f\150\x61\x6e\144\154\145\137\x6d\151\x67\162\141\164\x69\157\x6e\137\x73\164\141\x74\x75\x73", 1);
        $this->mo2f_handle_enable_2fa_migration();
        $this->mo2f_handle_grace_period_migration();
        $this->mo2f_handle_mfa_migration();
        $this->mo2f_handle_new_release_email_migration();
        $this->mo2f_handle_backup_code_enable();
        vl:
    }
    public function mo2f_handle_enable_2fa_migration()
    {
        if (!(get_site_option("\x6d\157\x32\x66\137\141\143\164\x69\166\141\x74\x65\x5f\x70\154\x75\x67\151\156") === false)) {
            goto aX;
        }
        update_site_option("\x6d\x6f\x32\x66\137\141\x63\164\151\x76\141\164\145\x5f\x70\154\x75\147\x69\x6e", 1);
        aX:
    }
    public function mo2f_handle_grace_period_migration()
    {
        $SI = get_site_option("\155\157\62\x66\137\147\x72\141\x63\x65\137\160\x65\x72\151\x6f\x64");
        update_site_option("\155\157\x32\x66\137\x67\x72\x61\143\x65\x5f\160\x65\162\x69\x6f\144", "\x6f\156" === $SI ? 1 : null);
        update_site_option("\x6d\x6f\x32\146\137\x67\162\141\143\x65\x70\x65\x72\x69\157\x64\x5f\141\143\x74\x69\157\x6e", "\x65\156\146\x6f\x72\143\x65\x5f\62\146\x61");
    }
    public function mo2f_handle_mfa_migration()
    {
        $WF = get_site_option("\x6d\x6f\62\146\137\x6e\x6f\156\143\x65\137\x65\156\x61\142\154\x65\137\x63\x6f\156\x66\151\147\165\162\145\x64\x5f\155\x65\164\150\157\x64\x73");
        update_site_option("\155\157\62\x66\x5f\155\165\x6c\x74\151\137\146\x61\143\x74\x6f\x72\x5f\x61\x75\164\x68\x65\156\164\151\143\141\164\x69\157\x6e", $WF);
    }
    public function mo2f_handle_new_release_email_migration()
    {
        $kj = get_site_option("\155\x6f\62\x66\x5f\155\141\x69\x6c\137\156\x6f\x74\151\146\x79\x5f\x6e\145\167\x5f\x72\x65\x6c\x65\x61\163\145");
        update_site_option("\x6d\x6f\62\x66\137\x6d\x61\x69\x6c\x5f\156\157\164\151\x66\171\x5f\156\x65\167\137\x72\x65\x6c\x65\141\x73\x65", "\x6f\x6e" === $kj ? 1 : null);
    }
    public function mo2f_handle_backup_code_enable()
    {
        add_option("\x6d\x6f\x32\x66\x5f\145\156\x61\x62\154\145\x5f\x62\141\x63\153\165\x70\137\x6d\x65\x74\x68\157\144\163", true);
        add_option("\155\157\62\x66\137\x65\x6e\141\142\154\145\144\x5f\x62\141\143\x6b\165\x70\137\x6d\x65\164\x68\157\144\x73", array("\155\157\x32\146\x5f\162\145\x63\157\156\146\x69\x67\x5f\154\x69\x6e\153\137\163\x68\x6f\167", "\155\x6f\62\x66\x5f\142\141\143\153\x5f\165\x70\137\143\x6f\x64\145\x73"));
    }
}
new Handle_Migration();
mU:
