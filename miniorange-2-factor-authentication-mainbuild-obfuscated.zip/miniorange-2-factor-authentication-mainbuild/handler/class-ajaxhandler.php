<?php


use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Helper\MoWpnsHandler;
if (defined("\x41\x42\123\120\101\x54\110")) {
    goto GF;
}
exit;
GF:
if (class_exists("\x41\x6a\141\170\110\x61\156\x64\x6c\145\x72")) {
    goto cU;
}
class AjaxHandler
{
    public function __construct()
    {
        add_action("\x61\x64\155\x69\x6e\x5f\151\x6e\x69\x74", array($this, "\155\x6f\137\x77\x70\156\163\x5f\x32\146\x61\137\x61\143\164\151\x6f\156\163"));
    }
    public function mo_wpns_2fa_actions()
    {
        $dk = isset($_GET["\156\157\x6e\x63\145"]) ? sanitize_text_field(wp_unslash($_GET["\156\x6f\x6e\143\145"])) : '';
        if (!wp_verify_nonce($dk, "\155\157\62\x66\137\x73\145\164\164\151\x6e\x67\x73\137\x6e\157\156\x63\145")) {
            goto ey;
        }
        if (current_user_can("\155\141\156\141\147\x65\x5f\x6f\160\x74\x69\x6f\x6e\163") && isset($_REQUEST["\157\160\x74\x69\157\156"])) {
            goto F4;
        }
        goto Cw;
        ey:
        $jY = new WP_Error();
        $jY->add("\x65\155\x70\x74\x79\x5f\165\163\145\x72\156\141\155\145\137\110\145\154\154\x6f", "\x3c\163\164\x72\x6f\156\147\76" . __("\x45\x52\122\x4f\x52", "\155\x69\156\x69\157\x72\x61\x6e\x67\x65\x2d\x32\55\146\141\x63\x74\157\x72\55\x61\165\x74\150\145\x6e\164\x69\143\x61\164\x69\x6f\x6e") . "\x3c\57\x73\x74\162\x6f\156\x67\76\72\40" . __("\111\x6e\x76\141\154\x69\x64\40\122\x65\161\x75\145\x73\x74\56", "\x6d\151\x6e\151\157\162\x61\156\x67\x65\x2d\62\55\146\141\x63\164\157\162\x2d\141\x75\164\x68\x65\156\164\151\143\x61\164\x69\x6f\x6e"));
        return $jY;
        goto Cw;
        F4:
        $Xh = sanitize_text_field(wp_unslash($_REQUEST["\x6f\160\x74\x69\157\156"]));
        $CG = isset($_GET["\x69\160"]) ? filter_var(wp_unslash($_GET["\151\160"]), FILTER_VALIDATE_IP) : null;
        switch ($Xh) {
            case "\151\x70\x6c\x6f\x6f\153\x75\x70":
                $this->lookup_i_p($CG);
                goto Va;
            case "\167\150\151\164\x65\154\x69\x73\164\163\145\154\146":
                $this->whitelist_self();
                goto Va;
            case "\x64\151\163\x6d\x69\x73\x73\160\154\x75\147\151\156":
                $this->wpns_plugin_notice();
                goto Va;
            case "\160\x6c\165\147\151\x6e\137\167\x61\162\156\151\156\147\x5f\156\x65\x76\x65\x72\x5f\163\150\157\167\137\141\147\x61\151\x6e":
                $this->wpns_plugin_warning_never_show_again();
                goto Va;
            case "\x6d\157\62\146\137\x62\141\x6e\x6e\145\162\137\156\x65\x76\145\162\137\163\150\157\x77\x5f\141\x67\x61\151\x6e":
                $this->wpns_mo2f_banner_never_show_again();
                goto Va;
            case "\144\151\163\x6d\151\163\163\123\x6d\163":
                $this->wpns_sms_notice();
                goto Va;
            case "\x64\151\163\x6d\x69\163\163\x45\x6d\141\x69\x6c":
                $this->wpns_email_notice();
                goto Va;
            case "\144\x69\163\155\151\163\163\123\x6d\163\x5f\x61\154\167\141\171\x73":
                $this->wpns_sms_notice_always();
                goto Va;
            case "\144\x69\x73\155\x69\163\x73\105\155\x61\x69\154\137\x61\154\x77\141\x79\163":
                $this->wpns_email_notice_always();
                goto Va;
            case "\x64\151\163\155\x69\x73\x73\x63\157\144\x65\163\x77\x61\x72\156\151\x6e\147":
                $this->mo2f_backup_codes_dismiss();
                goto Va;
        }
        go:
        Va:
        Cw:
    }
    private function lookup_i_p($CG)
    {
        $vv = wp_remote_get("\x68\164\x74\160\72\57\57\167\x77\167\56\x67\x65\x6f\160\154\165\147\x69\156\x2e\x6e\145\x74\x2f\152\x73\157\x6e\56\147\x70\x3f\x69\160\x3d" . $CG);
        if (is_wp_error($vv)) {
            goto IB;
        }
        $vv = wp_remote_retrieve_body($vv);
        IB:
        $F_ = gethostbyaddr($vv["\x67\145\157\x70\x6c\165\x67\x69\x6e\137\162\145\x71\165\x65\x73\x74"]);
        try {
            $u3 = timezone_offset_get(new DateTimeZone($vv["\x67\x65\x6f\x70\154\x75\x67\151\x6e\x5f\164\151\155\145\172\157\156\145"]), new DateTime("\x6e\157\x77"));
            $u3 = $u3 / 3600;
        } catch (Exception $vA) {
            $vv["\147\145\157\x70\154\x75\147\x69\x6e\137\x74\151\x6d\x65\172\x6f\x6e\145"] = '';
            $u3 = '';
        }
        $kz = MoWpnsConstants::IP_LOOKUP_TEMPLATE;
        if ($vv["\x67\145\x6f\x70\x6c\165\147\x69\x6e\137\x72\x65\161\x75\145\x73\x74"] === $CG) {
            goto hO;
        }
        $vv["\151\x70\x44\145\x74\x61\x69\x6c\x73"]["\x73\x74\141\x74\165\163"] = "\105\x52\x52\117\x52";
        goto ti;
        hO:
        $kz = str_replace("\173\173\163\x74\141\x74\x75\163\x7d\x7d", $vv["\147\x65\x6f\x70\x6c\x75\x67\151\156\x5f\163\164\x61\164\165\x73"], $kz);
        $kz = str_replace("\x7b\173\x69\160\x7d\175", $vv["\x67\x65\x6f\160\x6c\165\x67\x69\x6e\137\162\145\161\x75\x65\x73\x74"], $kz);
        $kz = str_replace("\x7b\x7b\x72\145\x67\x69\x6f\156\175\175", $vv["\x67\145\157\x70\154\x75\147\151\x6e\x5f\162\145\x67\x69\x6f\x6e"], $kz);
        $kz = str_replace("\x7b\x7b\143\x6f\x75\x6e\164\x72\171\x7d\175", $vv["\147\145\157\x70\154\x75\147\x69\x6e\137\143\x6f\x75\x6e\164\x72\x79\116\141\x6d\145"], $kz);
        $kz = str_replace("\x7b\173\143\x69\x74\x79\x7d\175", $vv["\147\145\x6f\160\x6c\165\x67\151\x6e\137\143\x69\164\x79"], $kz);
        $kz = str_replace("\173\x7b\143\157\x6e\164\151\156\x65\156\x74\x7d\x7d", $vv["\147\x65\157\x70\x6c\165\147\151\x6e\x5f\x63\x6f\156\x74\x69\156\x65\156\164\116\x61\x6d\145"], $kz);
        $kz = str_replace("\173\x7b\x6c\x61\164\x69\164\165\x64\x65\175\175", $vv["\x67\x65\157\x70\x6c\x75\x67\151\x6e\137\154\x61\164\151\164\x75\x64\145"], $kz);
        $kz = str_replace("\173\x7b\154\157\x6e\147\x69\164\165\x64\145\x7d\175", $vv["\x67\145\157\x70\154\165\147\x69\x6e\137\x6c\157\x6e\147\151\164\x75\144\145"], $kz);
        $kz = str_replace("\173\x7b\x74\x69\155\145\172\x6f\156\x65\175\x7d", $vv["\x67\x65\157\x70\154\165\x67\x69\156\137\164\x69\155\145\x7a\x6f\x6e\145"], $kz);
        $kz = str_replace("\x7b\x7b\x63\165\x72\162\x65\156\x79\x5f\x63\x6f\x64\145\175\x7d", $vv["\x67\x65\157\x70\154\165\147\151\x6e\137\143\165\x72\x72\145\156\x63\x79\103\x6f\x64\x65"], $kz);
        $kz = str_replace("\x7b\x7b\143\x75\x72\x72\145\156\171\137\x73\x79\x6d\142\157\x6c\x7d\x7d", $vv["\x67\x65\157\x70\154\165\x67\151\156\137\x63\x75\x72\x72\x65\156\143\x79\x53\171\155\x62\157\x6c"], $kz);
        $kz = str_replace("\173\173\x70\145\x72\x5f\144\157\x6c\x6c\x61\162\137\x76\x61\x6c\x75\145\175\x7d", $vv["\x67\x65\x6f\x70\x6c\x75\147\x69\156\x5f\x63\165\162\x72\145\x6e\x63\x79\103\x6f\156\166\145\162\x74\145\x72"], $kz);
        $kz = str_replace("\x7b\173\150\157\x73\164\156\x61\x6d\x65\175\175", $F_, $kz);
        $kz = str_replace("\x7b\x7b\157\146\146\x73\x65\164\x7d\175", $u3, $kz);
        $vv["\151\160\x44\x65\x74\x61\151\154\x73"] = $kz;
        ti:
        wp_send_json($vv);
    }
    private function whitelist_self()
    {
        global $uz;
        $LQ = new MoWpnsHandler();
        $LQ->whitelist_ip($uz->get_client_ip());
        wp_send_json_success();
    }
    private function wpns_plugin_notice()
    {
        update_site_option("\155\x61\x6c\167\141\162\x65\137\156\x6f\164\x69\x66\151\x63\x61\x74\151\x6f\x6e\x5f\x6f\x70\164\151\157\156", 1);
        update_site_option("\x6e\157\x74\x69\x63\x65\x5f\144\151\163\x6d\151\163\x73\137\164\x69\x6d\145", time());
        wp_send_json_success();
    }
    public function wpns_plugin_warning_never_show_again()
    {
        update_site_option("\x70\154\x75\147\x69\x6e\x5f\167\141\x72\156\151\x6e\147\137\x6e\145\166\145\x72\x5f\x73\x68\157\x77\137\141\x67\141\x69\x6e", 1);
        wp_send_json_success();
    }
    public function wpns_mo2f_banner_never_show_again()
    {
        update_site_option("\x6d\157\x32\146\x5f\142\x61\x6e\x6e\x65\x72\137\x6e\x65\166\x65\x72\137\x73\150\157\x77\x5f\141\147\141\x69\x6e", 1);
        wp_send_json_success();
    }
    private function wpns_sms_notice()
    {
        update_site_option("\155\157\62\146\137\167\160\156\x73\137\x73\x6d\x73\137\x64\x69\163\155\x69\163\163", time());
        wp_send_json_success();
    }
    private function wpns_email_notice()
    {
        update_site_option("\155\157\x32\146\137\167\x70\156\x73\x5f\145\155\141\x69\154\x5f\144\151\163\x6d\151\163\163", time());
        wp_send_json_success();
    }
    private function wpns_sms_notice_always()
    {
        update_site_option("\155\157\62\x66\137\x77\160\156\x73\x5f\x64\157\156\x6f\164\x5f\x73\150\x6f\167\137\154\x6f\167\x5f\163\x6d\x73\x5f\x6e\x6f\164\151\143\145", 1);
        wp_send_json_success();
    }
    private function wpns_email_notice_always()
    {
        update_site_option("\x6d\157\x32\x66\137\x77\160\x6e\x73\137\x64\x6f\156\x6f\164\137\163\150\157\167\137\x6c\157\167\x5f\x65\155\x61\x69\154\x5f\x6e\x6f\x74\151\x63\x65", 1);
        wp_send_json_success();
    }
    private function mo2f_backup_codes_dismiss()
    {
        $v1 = get_current_user_id();
        update_user_meta($v1, "\x64\x6f\x6e\157\164\137\x73\x68\157\167\x5f\142\x61\x63\x6b\x75\x70\x5f\x63\x6f\144\145\137\x6e\x6f\164\151\143\x65", 1);
        wp_send_json_success();
    }
}
new AjaxHandler();
cU:
