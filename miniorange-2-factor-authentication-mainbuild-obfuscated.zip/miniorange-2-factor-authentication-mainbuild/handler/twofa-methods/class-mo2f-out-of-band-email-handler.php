<?php


if (defined("\101\102\123\x50\x41\x54\x48")) {
    goto W0t;
}
exit;
W0t:
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Onprem\Mo2f_Inline_Popup;
use TwoFA\Onprem\MO2f_Utility;
use TwoFA\Helper\Mo2f_Login_Popup;
use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Onprem\Mo2f_Main_Handler;
use TwoFA\Helper\Mo2f_Common_Helper;
use TwoFA\Helper\TwoFAMoSessions;
use TwoFA\Helper\MocURL;
if (class_exists("\x4d\x6f\62\x66\x5f\117\125\x54\117\106\102\x41\116\104\105\115\x41\111\114\x5f\x48\x61\x6e\x64\x6c\x65\162")) {
    goto NKU;
}
class Mo2f_OUTOFBANDEMAIL_Handler
{
    private $mo2f_current_method;
    private $mo2f_transactionid;
    public function __construct()
    {
        $this->mo2f_current_method = MoWpnsConstants::OUT_OF_BAND_EMAIL;
    }
    public function mo2f_prompt_2fa_setup_inline($jg, $ok, $YP, $we)
    {
        global $Xw;
        $current_user = get_user_by("\151\x64", $YP);
        $cB = new Mo2f_Common_Helper();
        if (!MoWpnsUtility::get_mo2f_db_option("\x6d\157\x32\x66\137\x65\x6e\141\x62\x6c\145\x5f\x65\x6d\x61\151\x6c\x5f\x63\x68\141\x6e\x67\145", "\163\151\x74\x65\x5f\x6f\160\x74\x69\x6f\156")) {
            goto Qwi;
        }
        $hP = $Xw->mo2f_set_user_two_fa($current_user, $this->mo2f_current_method);
        $Kl = new Mo2f_Inline_Popup();
        $cB = new Mo2f_Common_Helper();
        $cB->mo2f_inline_css_and_js();
        $iE = $cB->mo2f_get_previous_screen_for_inline($current_user->ID);
        $FT = $cB->mo2f_email_common_skeleton($YP);
        $XZ = "\74\x64\151\166\x20\143\x6c\x61\x73\163\x3d\42\x6d\157\x32\x66\x5f\155\x6f\144\141\154\42\x20\164\x61\x62\151\x6e\x64\x65\170\x3d\x22\x2d\x31\42\40\x72\x6f\x6c\145\75\x22\144\151\x61\154\x6f\147\42\x3e\xd\xa\11\x9\11\x9\74\x64\x69\166\40\x63\x6c\141\163\x73\75\x22\155\157\x32\146\55\155\157\x64\141\154\55\x62\x61\143\153\144\162\x6f\x70\x22\76\x3c\57\144\x69\x76\76\xd\12\11\x9\x9\11\74\144\x69\166\40\x63\154\x61\163\163\75\42\155\157\x5f\x63\x75\x73\x74\x6f\155\x65\162\137\x76\x61\x6c\x69\x64\141\x74\x69\157\x6e\x2d\x6d\157\x64\141\x6c\55\144\x69\141\154\157\x67\40\x6d\x6f\x5f\143\165\x73\164\157\x6d\x65\162\137\166\x61\154\151\x64\141\x74\x69\x6f\x6e\55\155\157\x64\x61\154\x2d\155\144\42\x3e";
        $XZ .= $cB->mo2f_otp_based_methods_configuration_screen($FT, $this->mo2f_current_method, $hP["\155\157\x32\x66\141\x5f\154\157\147\151\156\137\x6d\145\163\x73\141\147\x65"], $YP, $ok, $jg, $iE);
        $XZ .= "\74\57\144\151\166\x3e\x3c\57\x64\151\x76\x3e";
        $XZ .= $Kl->mo2f_get_inline_hidden_forms($ok, $jg, $current_user->ID);
        $XZ .= $cB->mo2f_get_script_for_otp_based_methods("\x69\x6e\154\151\156\x65");
        $XZ .= $Xw->mo2f_oobe_get_login_script("\111\x6e\x6c\x69\x6e\x65", $bO);
        $XZ .= $cB->mo2f_get_hidden_forms_for_ooba($ok, $jg, $current_user->ID);
        echo $XZ;
        goto y3A;
        Qwi:
        $this->mo2f_prompt_2fa_inline($current_user, $jg, $ok);
        y3A:
        exit;
    }
    public function mo2f_prompt_2fa_setup_dashboard()
    {
        global $Gw, $Xw;
        $current_user = wp_get_current_user();
        $fK = $current_user->user_email;
        $Gw->insert_user($current_user->ID);
        $Wu = stripslashes($Xw->mo2f_send_link($current_user, $this->mo2f_current_method, $fK));
        $hP = json_decode($Wu, true);
        if (!(json_last_error() === JSON_ERROR_NONE)) {
            goto qX3;
        }
        if (!("\x53\x55\x43\103\x45\123\x53" === $hP["\163\164\141\x74\x75\x73"])) {
            goto v3m;
        }
        $this->mo2f_handle_success_dashboard($fK, $current_user->ID, $hP, "\143\x6f\x6e\x66\151\147\165\x72\145\x5f\62\x66\x61");
        v3m:
        qX3:
        $this->mo2f_handle_error_dashboard(MoWpnsMessages::ERROR_DURING_PROCESS_EMAIL);
    }
    public function mo2f_prompt_2fa_test_dashboard()
    {
        global $Gw, $Xw;
        $current_user = wp_get_current_user();
        $y2 = $Gw->get_user_detail("\155\x6f\x32\x66\x5f\x75\163\145\x72\137\145\155\141\x69\154", $current_user->ID);
        $bC = json_decode($Xw->mo2f_send_link($current_user, $this->mo2f_current_method, $y2), true);
        if (json_last_error() === JSON_ERROR_NONE) {
            goto qIU;
        }
        $this->mo2f_handle_error_dashboard(MoWpnsMessages::ERROR_DURING_PROCESS_EMAIL);
        goto Tft;
        qIU:
        if (!("\123\x55\103\x43\105\123\x53" === $bC["\163\164\141\x74\165\163"])) {
            goto Q6e;
        }
        $this->mo2f_handle_success_dashboard($y2, $current_user->ID, $bC, "\x74\x65\x73\164\137\62\146\141");
        Q6e:
        Tft:
    }
    public function mo2f_prompt_2fa_login($cs, $Ty, $ok)
    {
        global $Gw, $Xw;
        $y2 = $Gw->get_user_detail("\x6d\x6f\x32\x66\x5f\x75\x73\x65\x72\137\x65\155\x61\x69\x6c", $cs->ID);
        $bC = json_decode($Xw->mo2f_send_link($cs, $this->mo2f_current_method, $y2), true);
        $bO = isset($bC["\x74\170\111\144"]) ? $bC["\164\x78\x49\x64"] : '';
        if (json_last_error() === JSON_ERROR_NONE && MoWpnsConstants::SUCCESS_RESPONSE === $bC["\x73\164\141\164\x75\163"]) {
            goto kpR;
        }
        $AP = MoWpnsConstants::MO2F_ERROR_MESSAGE_PROMPT;
        $we = $this->mo2f_get_error_message($cs);
        goto HW8;
        kpR:
        $hP = $this->mo2f_handle_success_login($y2, $cs, $bC);
        $we = $hP["\154\x6f\147\x69\x6e\137\x6d\x65\x73\163\x61\147\x65"];
        $AP = $hP["\154\157\x67\x69\156\x5f\163\x74\x61\x74\x75\x73"];
        HW8:
        $this->mo2f_show_login_prompt($we, $AP, $cs, $ok, $Ty, $bO);
        exit;
    }
    public function mo2f_prompt_2fa_inline($cs, $Ty, $ok)
    {
        global $Xw;
        $y2 = $cs->user_email;
        $bC = json_decode($Xw->mo2f_send_link($cs, $this->mo2f_current_method, $y2), true);
        if (json_last_error() === JSON_ERROR_NONE && MoWpnsConstants::SUCCESS_RESPONSE === $bC["\163\x74\141\x74\x75\x73"]) {
            goto I46;
        }
        $we = MoWpnsMessages::ERROR_DURING_PROCESS_EMAIL;
        $AP = MoWpnsConstants::MO2F_ERROR_MESSAGE_PROMPT;
        goto oL9;
        I46:
        $hP = $this->mo2f_handle_success_login($y2, $cs, $bC);
        $we = $hP["\154\157\x67\x69\x6e\137\x6d\x65\163\x73\x61\x67\145"];
        $AP = $hP["\154\157\x67\x69\156\x5f\163\x74\141\x74\x75\163"];
        oL9:
        $this->mo2f_show_login_prompt($we, $AP, $cs, $ok, $Ty);
        exit;
    }
    public function mo2f_send_otp($fK, $jg, $current_user)
    {
        global $Xw, $uz;
        $hP = json_decode($Xw->mo2f_send_link($current_user, $this->mo2f_current_method, $fK), true);
        if (json_last_error() === JSON_ERROR_NONE) {
            goto Ouy;
        }
        $we = user_can($current_user->ID, "\155\141\156\141\147\x65\x5f\157\160\x74\x69\x6f\156\163") ? MoWpnsMessages::ERROR_DURING_PROCESS_EMAIL : MoWpnsMessages::ERROR_DURING_PROCESS;
        wp_send_json_error($we);
        goto W6p;
        Ouy:
        if ("\105\x52\x52\117\x52" === $hP["\x73\164\x61\x74\165\163"]) {
            goto aot;
        }
        if (MoWpnsConstants::SUCCESS_RESPONSE === $hP["\x73\164\141\x74\x75\163"]) {
            goto zJ2;
        }
        goto Asa;
        aot:
        wp_send_json_error($hP["\155\x65\163\x73\141\147\145"]);
        goto Asa;
        zJ2:
        MO2f_Utility::mo2f_debug_file("\105\x6d\x61\x69\154\40\x76\145\162\x69\x66\x69\x63\141\x74\151\x6f\x6e\40\x6c\x69\156\153\x20\150\141\163\40\142\x65\x65\x6e\x20\163\x65\x6e\x74\40\x73\165\143\143\145\163\163\146\165\154\154\171\40\x66\x6f\162\40" . $this->mo2f_current_method . "\x20\125\163\145\162\x5f\x49\x50\55" . $uz->get_client_ip() . "\x20\x55\163\145\162\x5f\111\144\x2d" . $current_user->ID . "\40\x45\x6d\141\151\154\55" . $current_user->user_email);
        $we = "\x41\x6e\x20\145\x6d\141\x69\x6c\40\166\145\162\x69\x66\x69\143\x61\x74\x69\x6f\x6e\x20\x6c\x69\156\x6b\x20\x68\141\163\40\x62\x65\145\x6e\x20\x73\x65\x6e\x74\40\164\x6f\x20" . $fK . "\x2e";
        wp_send_json_success($we);
        Asa:
        W6p:
    }
    public function mo2f_handle_success_login($y2, $current_user, $hP)
    {
        global $uz;
        $q4 = MO2f_Utility::mo2f_get_hidden_email($y2);
        $we = "\101\x6e\40\x65\x6d\141\151\154\x20\166\x65\x72\x69\x66\151\x63\x61\x74\151\x6f\x6e\x20\154\151\x6e\x6b\x20\x68\141\163\40\x62\145\x65\x6e\x20\163\x65\x6e\x74\x20\164\157\x20" . $q4 . "\x2e";
        TwoFAMoSessions::add_session_var("\x6d\x6f\x32\146\x5f\x74\162\141\x6e\x73\x61\x63\164\151\x6f\156\111\144", $hP["\x74\170\x49\x64"]);
        $AP = MoWpnsConstants::MO_2_FACTOR_CHALLENGE_OOB_EMAIL;
        MO2f_Utility::mo2f_debug_file("\105\155\141\151\x6c\x20\166\x65\x72\x69\146\151\x63\141\164\x69\157\x6e\40\154\151\x6e\x6b\x20\x68\141\163\40\x62\145\x65\x6e\x20\x73\x65\x6e\164\x20\x73\165\x63\x63\x65\x73\163\146\x75\x6c\154\x79\40\146\x6f\x72\x20" . $this->mo2f_current_method . "\40\x55\163\145\x72\137\x49\x50\55" . $uz->get_client_ip() . "\x20\125\x73\x65\x72\137\111\x64\55" . $current_user->ID . "\x20\105\155\x61\151\x6c\x2d" . $current_user->user_email);
        return array("\154\157\147\x69\156\x5f\163\164\x61\164\165\163" => $AP, "\154\x6f\147\x69\156\137\x6d\145\x73\163\141\x67\145" => $we);
    }
    public function mo2f_handle_error_dashboard($jD)
    {
        wp_send_json_error($jD);
    }
    public function mo2f_handle_error_login($L4, $y2, $jg, $ok)
    {
        $Aw = new Mo2f_Inline_Popup();
        MO2f_Utility::mo2f_debug_file("\101\x6e\x20\145\162\162\157\x72\40\157\x63\x63\165\162\145\x64\40\167\150\x69\x6c\145\40\x73\x65\156\x64\x69\x6e\x67\40\164\x68\145\x20\x6c\x69\x6e\x6b\x20\55\x20\x45\155\141\x69\154\40\x2d\40" . $y2);
        $we = user_can($L4, "\141\x64\x6d\x69\x6e\x69\163\164\162\x61\164\157\x72") ? MoWpnsMessages::ERROR_DURING_PROCESS_EMAIL : MoWpnsMessages::ERROR_DURING_PROCESS;
        $Aw->prompt_user_to_select_2factor_mthod_inline($L4, $we, $ok, $jg);
    }
    public function mo2f_handle_success_dashboard($y2, $v1, $bC, $Sl)
    {
        global $uz, $Xw;
        MO2f_Utility::mo2f_debug_file("\x45\x6d\141\151\x6c\40\x76\x65\x72\x69\x66\x69\143\x61\164\x69\x6f\x6e\40\154\x69\156\153\40\150\x61\x73\40\142\145\x65\x6e\x20\x73\145\156\x74\x20\x73\165\x63\x63\145\163\163\146\x75\154\x6c\x79\x20\x66\x6f\x72\40" . $this->mo2f_current_method . "\x20\x55\x73\x65\162\x5f\x49\x50\40\x2d\x20" . $uz->get_client_ip() . "\40\x55\163\x65\x72\x5f\111\x64\x20\55\x20" . $v1 . "\40\x45\155\141\151\154\x20\x2d\x20" . $y2);
        $q4 = MO2f_Utility::mo2f_get_hidden_email($y2);
        $we = "\x41\156\40\x65\x6d\x61\x69\154\40\166\x65\162\151\146\x69\143\x61\x74\151\157\x6e\40\x6c\x69\x6e\x6b\40\150\x61\x73\x20\142\x65\145\x6e\40\163\x65\156\x74\x20\x74\157\x20" . $q4 . "\40\x2e\x20";
        TwoFAMoSessions::add_session_var("\x6d\157\x32\x66\x5f\x74\x72\141\x6e\163\x61\143\x74\151\157\156\x49\144", $bC["\x74\x78\111\144"]);
        $AP = MoWpnsConstants::MO_2_FACTOR_CHALLENGE_OOB_EMAIL;
        $yV = new Mo2f_Login_Popup();
        $cB = new Mo2f_Common_Helper();
        $gH = $yV->mo2f_twofa_login_prompt_skeleton_values($we, $AP, null, null, $v1, "\x74\x65\x73\164\137\x32\146\141", '');
        $XZ = $yV->mo2f_get_twofa_skeleton_html($AP, $we, '', '', $gH, $this->mo2f_current_method, "\164\x65\163\164\x5f\x32\146\141");
        $XZ .= $yV->mo2f_get_validation_popup_script("\164\145\163\x74\137\x32\146\141", $this->mo2f_current_method, '', '');
        $XZ .= $Xw->mo2f_oobe_get_dashboard_script($Sl, $bC["\164\x78\111\144"]);
        $XZ .= "\74\x73\x63\162\x69\160\164\x3e\145\155\141\x69\x6c\126\x65\x72\x69\146\x69\x63\x61\164\x69\x6f\x6e\120\157\154\154\x28\51\74\x2f\163\x63\x72\151\160\x74\x3e";
        $XZ .= $cB->mo2f_get_dashboard_hidden_forms();
        wp_send_json_success($XZ);
    }
    public function mo2f_show_login_prompt($we, $AP, $current_user, $ok, $Ty, $bO = '')
    {
        global $Xw;
        $yV = new Mo2f_Login_Popup();
        $cB = new Mo2f_Common_Helper();
        $gH = $yV->mo2f_twofa_login_prompt_skeleton_values($we, $AP, null, null, $current_user->ID, "\x6c\157\x67\151\156\137\62\x66\x61", '');
        $XZ = $yV->mo2f_twofa_authentication_login_prompt($AP, $we, $ok, $Ty, $gH, $this->mo2f_current_method);
        $XZ .= $cB->mo2f_get_hidden_forms_login($ok, $Ty, $AP, $we, $this->mo2f_current_method, $current_user->ID);
        if (!(MoWpnsConstants::MO2F_ERROR_MESSAGE_PROMPT !== $AP)) {
            goto kNn;
        }
        $XZ .= $Xw->mo2f_oobe_get_login_script("\x64\151\x72\x65\143\164\137\x6c\x6f\147\x69\x6e", $bO);
        kNn:
        $XZ .= $cB->mo2f_get_hidden_script_login();
        $XZ .= $cB->mo2f_get_hidden_forms_for_ooba($ok, $Ty, $current_user->ID);
        echo $XZ;
        exit;
    }
    public function mo2f_process_link_validation($I1, $mb, $sp)
    {
        $li = get_site_option($I1);
        $F4 = get_site_option($mb);
        $C1 = $I1 . "\104";
        $QO = get_site_option($C1);
        $V0 = dirname(__FILE__);
        $V0 = explode("\167\160\55\143\157\x6e\164\145\x6e\x74", $V0);
        $V0 = explode("\150\141\156\144\x6c\x65\x72", $V0[1]);
        $bC = $this->mo2f_validate_link($F4, $mb, $li, $QO, $sp, $I1, $C1);
        $W8 = array("\x68\x65\141\x64" => $bC["\150\x65\x61\144"], "\142\157\x64\x79" => $bC["\x62\x6f\x64\x79"], "\143\157\154\x6f\x72" => $bC["\143\x6f\x6c\157\x72"], "\142\x67\137\143\157\x6c\x6f\x72" => "\43\x46\106\106\106\106\106", "\x62\x72\x61\x6e\x64\x69\156\x67\x5f\x69\x6d\x67" => "\x62\x61\x63\153\147\x72\x6f\165\156\x64\x2d\x63\x6f\154\157\x72\x3a\40\43\144\x35\145\x33\x64\x39\x3b", "\x6c\x6f\x67\157\x5f\165\x72\x6c" => esc_url($yv . "\151\156\143\154\165\144\145\x73\x2f\x69\155\141\147\145\163\x2f\155\151\x6e\x69\117\162\141\x6e\147\x65\62\x2e\160\x6e\147"));
        $W8 = apply_filters("\155\x6f\62\x66\137\x65\x6e\x74\x65\162\160\x72\x69\x73\145\137\160\154\x61\x6e\x5f\163\145\x74\164\151\x6e\147\x73\137\x66\151\x6c\x74\145\162", $W8, "\x6d\x6f\62\146\137\143\x75\x73\x74\x6f\x6d\x5f\x65\x6d\x61\151\154\x5f\x76\x65\x72\151\146\x69\x63\x61\x74\x69\x6f\x6e\x5f\x70\x6f\160\165\x70\137\141\162\147\x73", $W8);
        $bc = new Mo2f_Login_Popup();
        $bc->mo2f_display_email_verification($W8);
        exit;
    }
    public function mo2f_validate_link($F4, $mb, $li, $QO, $sp, $I1, $C1)
    {
        $rP = __("\131\x6f\165\x20\x61\162\145\40\156\157\x74\40\141\x75\164\x68\157\162\151\x7a\x65\x64\x20\x74\157\40\x70\x65\162\x66\157\x72\155\40\x74\150\151\163\40\141\x63\164\x69\157\x6e", "\x6d\x69\156\x69\157\162\x61\x6e\x67\145\55\62\55\146\x61\x63\164\x6f\162\x2d\x61\x75\164\150\145\156\x74\x69\x63\141\x74\x69\x6f\x6e");
        $zI = __("\120\x6c\x65\x61\163\x65\x20\143\x6f\x6e\x74\x61\x63\x74\x20\164\157\x20\x79\157\x75\x72\40\141\x64\155\x69\156", "\x6d\151\x6e\151\157\x72\x61\156\147\x65\55\62\55\x66\x61\143\164\x6f\x72\55\x61\165\x74\150\x65\x6e\x74\151\143\141\164\151\157\156");
        $eM = "\x72\145\144";
        if (!(3 === (int) $F4)) {
            goto BeU;
        }
        $rs = "\164\151\155\x65" . $mb;
        $E6 = round(microtime(true) * 1000);
        $Lx = get_site_option($rs);
        $WU = ($E6 - $Lx) / 1000;
        if ($WU <= 300) {
            goto LW1;
        }
        update_site_option($mb, 0);
        goto oEg;
        LW1:
        if ($sp === $li) {
            goto DG4;
        }
        if ($sp === $QO) {
            goto oDt;
        }
        goto aQF;
        DG4:
        update_site_option($mb, 1);
        $zI = __("\x54\x72\141\x6e\x73\x61\143\164\x69\x6f\x6e\40\150\x61\163\40\x62\145\x65\156\x20\x73\x75\x63\x63\145\163\163\x66\165\154\x6c\171\x20\166\141\154\151\x64\141\164\145\x64\40\x2e\x20\120\154\145\x61\163\x65\40\143\x6f\156\164\x69\156\x75\x65\x20\x77\x69\x74\x68\x20\164\x68\x65\40\x74\162\141\x6e\163\141\143\x74\x69\x6f\156\x2e", "\155\x69\156\151\157\x72\141\156\147\145\55\x32\55\x66\141\x63\x74\157\162\x2d\141\x75\x74\150\145\156\x74\151\x63\141\164\151\x6f\x6e");
        $rP = __("\x54\122\101\x4e\x53\101\x43\124\x49\117\116\x20\x53\x55\103\x43\x45\123\x53\106\125\x4c", "\155\151\156\151\157\x72\x61\156\x67\x65\x2d\x32\x2d\x66\x61\143\164\157\162\55\141\165\164\150\x65\x6e\x74\151\143\x61\x74\x69\157\x6e");
        $eM = "\x67\162\x65\145\x6e";
        goto aQF;
        oDt:
        update_site_option($mb, 0);
        $zI = __("\x54\162\141\x6e\x73\141\143\164\151\x6f\156\x20\150\141\163\40\142\x65\145\156\40\103\x61\156\x63\145\154\x65\144\x20\x2e\40\x50\x6c\x65\x61\163\145\40\164\162\x79\x20\x41\147\x61\151\x6e\40\x2e\x20", "\x6d\151\x6e\x69\x6f\162\141\156\147\145\55\x32\x2d\146\141\143\x74\157\x72\55\141\165\164\150\x65\x6e\x74\x69\143\x61\164\151\157\x6e");
        $rP = __("\124\122\x41\x4e\x53\x41\x43\124\x49\x4f\x4e\40\x44\x45\x4e\111\x45\x44", "\x6d\151\x6e\151\157\162\141\156\x67\145\55\x32\55\146\x61\x63\164\157\x72\55\141\165\164\150\x65\156\164\x69\143\x61\x74\151\157\x6e");
        aQF:
        oEg:
        delete_site_option($I1);
        delete_site_option($C1);
        delete_site_option($rs);
        BeU:
        $hP = array("\142\x6f\144\171" => $zI, "\x68\145\141\144" => $rP, "\x63\x6f\x6c\157\x72" => $eM);
        return $hP;
    }
    public function mo2f_update_user_details($cs, $y2)
    {
        global $Xw;
        $Ip = new MocURL();
        $Ip->mo_create_user($cs, $y2);
        delete_user_meta($cs->ID, "\x6d\x6f\x32\146\137\165\x73\x65\x72\x5f\x70\x72\x6f\x66\x69\154\145\137\x73\145\x74");
        $Xw->mo2f_update_user_info($cs->ID, true, MoWpnsConstants::OUT_OF_BAND_EMAIL, null, MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, true, $y2, null);
    }
    public function mo2f_handle_polling($ed)
    {
        global $Gw;
        $yY = get_site_option($ed);
        if (!("\x31" === $yY || "\x30" === $yY)) {
            goto wig;
        }
        $oP = TwoFAMoSessions::get_session_var($ed);
        if (!("\x31" === $yY && !$Gw->get_user_detail("\x6d\157\62\x66\137\105\x6d\141\151\x6c\126\x65\x72\151\x66\x69\x63\141\x74\x69\157\156\137\x63\x6f\156\146\x69\x67\x5f\163\x74\x61\164\165\163", $oP["\x75\x73\x65\162\x5f\x69\144"]))) {
            goto OPl;
        }
        $this->mo2f_update_user_details(get_user_by("\151\x64", $oP["\x75\x73\x65\162\x5f\151\144"]), $oP["\165\163\145\162\x5f\145\155\141\151\154"]);
        OPl:
        delete_site_option($ed);
        wig:
        wp_send_json($yY);
    }
    public function mo2f_get_error_message($cs)
    {
        $we = user_can($cs->ID, "\141\x64\x6d\151\x6e\151\163\164\x72\141\164\157\162") ? MoWpnsMessages::ERROR_DURING_PROCESS_EMAIL : MoWpnsMessages::ERROR_DURING_PROCESS;
        return $we;
    }
}
new Mo2f_OUTOFBANDEMAIL_Handler();
NKU:
