<?php


if (defined("\x41\102\123\x50\x41\x54\110")) {
    goto fiv;
}
exit;
fiv:
use TwoFA\Onprem\MO2f_Cloud_Onprem_Interface;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Onprem\Mo2f_Inline_Popup;
use TwoFA\Onprem\MO2f_Utility;
use TwoFA\Helper\Mo2f_Login_Popup;
use TwoFA\Helper\Mo2f_Common_Helper;
use TwoFA\Onprem\Mo2f_Main_Handler;
use TwoFA\Helper\TwoFAMoSessions;
if (class_exists("\115\157\62\146\137\113\x42\x41\137\x48\x61\156\x64\154\145\x72")) {
    goto GEQ;
}
class Mo2f_KBA_Handler
{
    private $mo2f_current_method;
    private $kba_login_questions;
    public function __construct()
    {
        $this->mo2f_current_method = MoWpnsConstants::SECURITY_QUESTIONS;
    }
    public function mo2f_prompt_2fa_setup_inline($jg, $ok, $YP, $we)
    {
        global $Xw;
        $Kl = new Mo2f_Inline_Popup();
        $current_user = get_userdata($YP);
        $hP = $Xw->mo2f_set_user_two_fa($current_user, $this->mo2f_current_method);
        $cB = new Mo2f_Common_Helper();
        $cB->mo2f_inline_css_and_js();
        $XZ = "\74\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\42\155\157\62\146\x5f\155\157\x64\141\x6c\x22\x20\x74\141\x62\151\156\x64\145\x78\x3d\42\x2d\61\x22\40\162\x6f\154\145\x3d\x22\x64\151\141\x6c\157\x67\42\x3e\15\xa\11\x9\x9\74\144\151\166\x20\x63\x6c\x61\x73\163\x3d\42\155\x6f\x32\x66\x2d\x6d\157\144\141\154\55\142\x61\x63\x6b\x64\162\x6f\160\42\76\x3c\57\x64\x69\x76\x3e\xd\xa\11\x9\11\74\x64\x69\166\40\x63\x6c\x61\163\163\x3d\x22\155\157\137\x63\165\163\164\157\155\145\x72\x5f\x76\141\154\x69\x64\141\164\x69\157\x6e\55\x6d\157\x64\x61\154\x2d\144\x69\x61\x6c\x6f\x67\40\x6d\x6f\x5f\143\165\x73\164\x6f\x6d\145\x72\x5f\166\141\154\151\x64\x61\164\151\157\x6e\55\x6d\x6f\144\x61\154\55\155\144\x22\x3e";
        $iE = $cB->mo2f_get_previous_screen_for_inline($current_user->ID);
        $XZ .= $cB->prompt_user_for_kba_setup($YP, $we, $ok, $jg, $iE);
        $XZ .= "\74\57\x64\x69\x76\76\x3c\x2f\144\x69\x76\76";
        $XZ .= $Kl->mo2f_get_inline_hidden_forms($ok, $jg, $current_user->ID);
        $XZ .= $this->mo2f_get_script($YP, "\151\x6e\154\151\156\x65");
        echo $XZ;
        exit;
    }
    public function mo2f_get_script($v1, $z7)
    {
        $cB = new Mo2f_Common_Helper();
        $y0 = array($cB, "\x6d\x6f\62\x66\137\147\145\164\x5f\x76\141\x6c\151\144\x61\x74\145\137\163\x75\143\143\145\x73\x73\x5f\162\x65\163\160\x6f\x6e\x73\145\x5f" . $z7 . "\x5f\x73\x63\x72\151\160\164");
        $lW = "\74\x73\x63\x72\151\160\x74\76\15\xa\11\11\x9\x6a\121\x75\x65\162\171\50\x64\x6f\143\x75\155\145\156\164\51\x2e\x72\145\x61\144\x79\x28\146\165\156\x63\164\151\157\156\x28\x24\51\x7b\15\12\x9\11\x9\x9\152\x51\x75\145\x72\171\50\x66\x75\x6e\x63\164\151\157\156\50\x29\x7b\11\xd\12\x9\11\x9\x9\152\x51\x75\x65\162\x79\50\42\141\133\x68\x72\145\x66\75\47\x23\x6d\157\62\146\x5f\x6c\157\x67\151\156\x5f\x66\157\x72\155\47\x5d\x22\x29\x2e\x63\154\x69\143\x6b\50\146\165\156\143\164\x69\x6f\x6e\x28\x29\x20\173\15\12\x9\11\11\x9\x9\152\x51\x75\x65\162\x79\x28\x22\43\155\157\x32\x66\137\142\x61\143\153\164\157\137\x6d\x6f\137\154\157\x67\x69\x6e\x66\157\x72\155\x22\x29\x2e\163\x75\142\155\151\x74\50\51\x3b\xd\xa\11\11\x9\x9\x7d\51\x3b\xd\12\11\x9\x9\11\x6a\x51\165\x65\162\171\50\42\141\x5b\150\162\145\146\75\x27\43\155\x6f\62\x66\x5f\x69\x6e\154\x69\156\145\x5f\146\x6f\162\x6d\47\135\x22\51\x2e\x63\154\x69\x63\153\50\x66\x75\x6e\x63\164\151\x6f\156\50\51\x20\173\15\12\x9\x9\11\11\x9\x6a\x51\165\145\162\x79\50\42\x23\155\157\62\x66\137\x62\x61\143\x6b\x74\157\137\x69\156\154\151\x6e\x65\x5f\x72\145\x67\x69\163\164\x72\x61\164\x69\157\x6e\42\51\56\163\165\x62\155\151\x74\50\x29\73\xd\12\11\x9\11\11\175\51\73\15\xa\11\11\11\11\152\121\165\x65\x72\x79\x28\x27\43\x6d\x6f\x32\x66\x5f\x6e\145\170\164\x5f\x73\164\x65\160\x33\x27\x29\56\x63\163\x73\50\x27\144\x69\x73\x70\154\x61\x79\x27\x2c\47\x6e\x6f\x6e\x65\x27\51\73\15\xa\x9\11\11\x9\166\x61\162\x20\x61\152\141\170\165\x72\x6c\x20\x3d\40\42" . esc_js(admin_url("\x61\144\x6d\x69\x6e\x2d\141\152\x61\x78\x2e\160\150\x70")) . "\42\x3b\xd\12\11\x9\11\11\166\141\162\40\165\x73\145\x72\x49\144\40\x3d\40\x22" . esc_js($v1) . "\42\73\15\xa\11\x9\x9\x9\152\x51\x75\x65\162\171\x28\x22\x23\155\157\x32\x66\x5f\x73\141\x76\145\x5f\x6b\x62\x61\x22\51\x2e\143\x6c\x69\x63\153\x28\x66\x75\156\143\164\x69\157\156\x28\51\40\173\15\xa\x9\x9\x9\x9\11" . $cB->mo2f_show_loader() . "\15\xa\x9\x9\11\x9\11\166\x61\x72\x20\156\157\156\x63\x65\x20\x3d\40\42" . esc_js(wp_create_nonce("\155\x6f\55\164\x77\157\x2d\x66\141\x63\x74\157\x72\55\141\152\141\170\x2d\x6e\157\x6e\x63\145")) . "\42\73\xd\12\x20\x20\x20\40\40\40\40\x20\x20\x20\40\x20\40\x20\x20\40\x20\x20\x20\40" . $this->mo2f_get_jquery_data() . "\15\12\11\11\x9\x9\x9\x6a\121\165\145\x72\x79\56\x70\x6f\x73\x74\x28\141\152\141\170\165\162\154\x2c\40\144\141\x74\141\54\40\x66\165\x6e\x63\x74\151\x6f\156\50\x72\x65\x73\x70\157\x6e\x73\145\51\40\173\15\xa\x9\x9\11\x9\x9\x20\x20\40\40" . $cB->mo2f_hide_loader() . "\xd\xa\x9\x9\11\11\11\x9\151\x66\40\50\162\145\x73\160\157\x6e\163\145\x2e\x73\165\143\x63\x65\163\x73\x29\x20\x7b\15\12\x9\11\11\11\x9\x9\x9\152\121\165\145\162\171\x28\42\x23\155\157\62\146\137\151\x6e\154\151\x6e\x65\x5f\x6f\x74\160\137\166\141\x6c\151\144\x61\x74\x65\144\x5f\146\x6f\x72\x6d\x22\x29\x2e\x73\165\142\x6d\151\164\50\x29\x3b\xd\12\11\11\x9\x9\11\11\x9" . call_user_func($y0) . "\15\xa\x9\11\x9\11\x9\x9\x7d\40\x65\154\x73\145\x20\151\x66\x20\50\x21\x72\x65\163\160\157\x6e\163\x65\56\163\165\x63\143\145\x73\163\51\40\173\xd\xa\11\x9\x9\x9\x9\11\x9\155\x6f\62\x66\137\x73\150\157\167\137\155\x65\x73\x73\141\147\x65\50\x72\145\163\x70\157\156\x73\145\x2e\x64\x61\x74\141\51\x3b\15\xa\11\x9\11\11\11\11\x7d\40\145\x6c\163\x65\x20\173\15\xa\11\x9\x9\11\11\x9\x9\x6d\x6f\62\x66\x5f\163\x68\x6f\x77\x5f\x6d\x65\x73\x73\x61\x67\x65\50\x22\125\156\153\156\x6f\167\156\x20\145\162\162\x6f\162\x20\x6f\x63\143\x75\x72\162\145\144\56\40\x50\x6c\145\x61\163\x65\40\164\x72\x79\x20\x61\x67\x61\151\x6e\x2e\42\x29\x3b\xd\xa\11\11\x9\x9\x9\x9\175\15\12\11\x9\11\x9\x9\175\51\15\xa\x9\x9\x9\x9\175\x29\73\15\12\x9\11\x9\x7d\51\x3b\xd\12\x9\x9\175\x29\x3b";
        $lW .= "\x3c\x2f\163\143\x72\151\x70\164\76";
        return $lW;
    }
    public function mo2f_get_jquery_data()
    {
        $qc = get_site_option("\155\x6f\x32\146\x5f\x64\x65\146\x61\165\154\x74\x5f\x6b\x62\141\161\165\145\163\x74\151\157\x6e\x73\x5f\x75\x73\x65\x72\163", 2);
        $QD = get_site_option("\x6d\x6f\62\x66\x5f\x63\x75\x73\164\x6f\x6d\137\153\x62\x61\161\165\145\x73\164\x69\x6f\x6e\163\137\165\x73\145\162\x73", 1);
        $A_ = $qc + $QD;
        $mC = "\166\x61\x72\x20\144\141\x74\x61\x20\75\40\x7b\xd\12\x9\x9\11\11\x61\143\x74\151\x6f\x6e\72\40\42\x6d\157\137\x74\x77\x6f\x5f\146\141\x63\x74\x6f\162\137\141\x6a\x61\x78\x22\x2c\xd\12\x9\x9\x9\x9\x6d\x6f\x5f\x32\x66\137\164\x77\157\137\x66\141\x63\x74\157\162\137\x61\x6a\141\170\x3a\x20\x22\x6d\x6f\62\x66\x5f\x73\145\164\137\x6b\x62\141\42\54\xd\12\11\x9\11\11\x75\163\x65\162\x5f\x69\144\72\40\165\163\145\162\111\144\54\xd\12\x9\11\11\11\x6e\x6f\x6e\x63\x65\x3a\x20\156\157\x6e\143\x65\x2c\xd\xa\11\11\11\x7d\73";
        $ET = 1;
        HsN:
        if (!($ET <= $A_)) {
            goto c3X;
        }
        $mC .= "\xd\12\11\11\x9\11\x64\x61\164\141\133\42\x6d\x6f\x32\146\137\153\x62\x61\161\165\x65\163\x74\151\157\x6e\137" . $ET . "\42\135\40\x3d\40\152\x51\x75\x65\162\x79\x28\42\43\155\x6f\62\x66\137\153\142\141\161\165\145\x73\164\151\157\x6e\137" . $ET . "\42\x29\x2e\166\141\x6c\x28\51\x3b\xd\xa\11\x9\11\11\144\x61\x74\x61\133\42\155\157\62\146\x5f\153\x62\141\137\141\156\163" . $ET . "\42\x5d\x20\x3d\x20\152\x51\x75\x65\x72\171\x28\42\43\x6d\x6f\x32\x66\x5f\x6b\x62\141\x5f\141\156\x73" . $ET . "\42\x29\x2e\x76\141\154\50\51\x3b";
        lUn:
        $ET++;
        goto HsN;
        c3X:
        $mC .= "\15\xa\x9\11\x9\x64\x61\x74\141\133\x22\x72\x65\144\151\x72\145\x63\x74\137\x74\157\42\x5d\x20\75\x20\x6a\x51\165\x65\162\171\x28\x22\x69\x6e\x70\x75\164\133\156\141\x6d\x65\x3d\47\x72\x65\144\151\162\x65\x63\164\137\164\x6f\x27\x5d\x22\51\x2e\166\x61\154\x28\x29\x3b\xd\xa\11\11\x9\144\141\x74\x61\x5b\x22\163\145\x73\x73\x69\157\x6e\137\x69\x64\42\135\40\x3d\40\152\121\165\145\x72\171\50\x22\151\x6e\x70\165\164\133\156\x61\x6d\145\x3d\47\163\x65\163\163\151\157\156\137\151\x64\x27\x5d\42\x29\x2e\166\x61\x6c\x28\51\73";
        return $mC;
    }
    public function mo2f_prompt_2fa_setup_dashboard()
    {
        global $Gw;
        $current_user = wp_get_current_user();
        $Gw->insert_user($current_user->ID);
        $cB = new Mo2f_Common_Helper();
        $XZ = $cB->prompt_user_for_kba_setup($current_user->ID, '', '', '', "\144\x61\163\150\x62\x6f\x61\x72\x64");
        $XZ .= $cB->mo2f_get_dashboard_hidden_forms();
        $XZ .= $this->mo2f_get_script($current_user->ID, "\x64\141\163\x68\142\157\141\x72\144");
        wp_send_json_success($XZ);
    }
    public function mo2f_prompt_2fa_test_dashboard()
    {
        global $Xw;
        $current_user = wp_get_current_user();
        $we = "\120\154\x65\x61\x73\x65\40\x61\x6e\163\167\145\162\x20\164\150\x65\x20\146\157\154\x6c\157\167\x69\x6e\147\x20\161\x75\145\163\x74\151\x6f\x6e\x73\x3a";
        $AP = MoWpnsConstants::MO_2_FACTOR_CHALLENGE_KBA_AUTHENTICATION;
        $g7 = $Xw->mo2f_pass2login_kba_verification($current_user, $this->mo2f_current_method, '', '');
        $yV = new Mo2f_Login_Popup();
        $cB = new Mo2f_Common_Helper();
        $gH = $yV->mo2f_twofa_login_prompt_skeleton_values($we, $AP, $g7[0], $g7[1], $current_user->ID, "\164\145\x73\164\137\x32\x66\x61", '');
        $XZ = $yV->mo2f_get_twofa_skeleton_html($AP, $we, '', '', $gH, $this->mo2f_current_method, "\x74\x65\x73\164\x5f\x32\146\x61");
        $XZ .= $yV->mo2f_get_validation_popup_script("\x74\145\x73\x74\x5f\x32\x66\x61", $this->mo2f_current_method, '', '');
        $XZ .= $cB->mo2f_get_test_script();
        wp_send_json_success($XZ);
    }
    public function mo2f_set_kba($post)
    {
        global $Gw;
        $Ty = isset($post["\163\x65\163\163\x69\157\156\x5f\151\x64"]) ? sanitize_text_field(wp_unslash($post["\163\145\x73\163\151\x6f\x6e\137\151\144"])) : null;
        $ok = isset($post["\x72\x65\144\x69\x72\145\x63\x74\137\x74\157"]) ? esc_url_raw(wp_unslash($post["\x72\x65\144\151\x72\x65\143\x74\137\164\x6f"])) : null;
        $v1 = isset($post["\165\163\145\x72\x5f\x69\x64"]) ? sanitize_text_field(wp_unslash($post["\x75\x73\145\x72\x5f\x69\x64"])) : null;
        $current_user = get_user_by("\151\144", $v1);
        $MX = $this->mo2f_get_ques_ans($post);
        $g7 = $this->mo2f_validate_questions($MX, $Ty, $ok, $v1);
        $mL = $this->mo2f_validate_answers($MX, $Ty, $ok, $v1);
        $tW = $this->mo2f_encode_question_answer($g7, $mL);
        update_user_meta($current_user->ID, "\x6d\157\x32\146\137\153\x62\141\x5f\143\150\x61\154\x6c\x65\x6e\x67\x65", $tW);
        if (TwoFAMoSessions::get_session_var("\x6d\x6f\62\146\x5f\x69\x73\x5f\153\x62\x61\137\142\x61\x63\x6b\x75\x70\137\143\157\x6e\x66\151\x67\x75\162\145\x64" . $v1)) {
            goto Vd1;
        }
        $this->mo2f_update_user_details($post, $current_user->ID, $current_user->user_email);
        goto Q0V;
        Vd1:
        update_user_meta($v1, "\x6d\157\x32\146\x5f\142\141\143\153\165\160\x5f\x6d\145\164\x68\x6f\144\137\x73\x65\x74", 1);
        $Gw->update_user_details($v1, array("\155\157\62\146\137\x53\x65\x63\x75\x72\x69\164\x79\121\165\x65\163\x74\151\x6f\x6e\x73\137\x63\x6f\x6e\x66\x69\x67\137\163\164\x61\x74\x75\x73" => true));
        Q0V:
        wp_send_json_success();
    }
    public function mo2f_get_ques_ans($post)
    {
        $qc = get_site_option("\x6d\157\62\x66\x5f\144\x65\146\141\x75\154\x74\x5f\x6b\142\141\x71\x75\x65\x73\x74\x69\x6f\x6e\163\x5f\165\x73\x65\x72\163", 2);
        $QD = get_site_option("\155\157\62\x66\137\143\165\163\164\x6f\155\x5f\153\x62\x61\x71\165\x65\x73\x74\151\x6f\x6e\x73\x5f\165\163\145\162\x73", 1);
        $A_ = $qc + $QD;
        $MX = array();
        $ET = 1;
        UYt:
        if (!($ET <= $A_)) {
            goto ka1;
        }
        $MX["\153\x62\141\137\x71" . $ET] = isset($post["\155\x6f\x32\x66\x5f\153\x62\x61\161\x75\145\163\164\x69\157\156\137" . $ET]) ? sanitize_text_field(wp_unslash($post["\155\157\62\x66\137\153\142\141\x71\x75\145\x73\164\x69\x6f\156\x5f" . $ET])) : '';
        $MX["\x6b\x62\141\x5f\x61" . $ET] = isset($post["\155\x6f\62\x66\137\153\142\x61\x5f\x61\x6e\163" . $ET]) ? sanitize_text_field(wp_unslash($post["\155\157\62\x66\137\x6b\142\141\137\x61\156\163" . $ET])) : '';
        Z6K:
        $ET++;
        goto UYt;
        ka1:
        return $MX;
    }
    public function mo2f_validate_questions($MX, $Ty, $ok, $v1)
    {
        $g7 = array();
        foreach ($MX as $t8 => $ZB) {
            if (!(strpos($t8, "\x6b\x62\x61\x5f\x71") === 0)) {
                goto PEK;
            }
            if (MO2f_Utility::mo2f_check_empty_or_null($ZB)) {
                goto r3D;
            }
            $aJ = sanitize_text_field($ZB);
            $aJ = addcslashes(stripslashes($aJ), "\42\x5c");
            array_push($g7, $aJ);
            goto z6V;
            r3D:
            $we = __("\101\154\154\40\164\x68\x65\x20\146\151\145\x6c\x64\163\40\141\x72\x65\40\162\145\161\x75\x69\162\x65\144\x2e\x20\x50\x6c\x65\141\x73\145\40\x65\156\164\x65\162\x20\166\141\x6c\151\x64\40\145\x6e\164\162\x69\x65\x73\56", "\x6d\x69\156\x69\x6f\162\141\x6e\x67\145\x2d\62\55\146\141\x63\x74\157\162\55\x61\165\164\150\x65\x6e\x74\151\143\141\x74\151\157\156");
            wp_send_json_error($we);
            z6V:
            PEK:
            q7D:
        }
        S31:
        if (!(count($g7) !== count(array_unique($g7)))) {
            goto oBm;
        }
        $we = __("\124\150\145\x20\x71\165\145\x73\164\x69\157\156\x73\40\x79\157\x75\x20\163\145\x6c\145\143\164\x20\155\165\163\164\x20\142\x65\40\x75\156\151\x71\165\145\56", "\x6d\151\156\x69\157\162\141\156\147\x65\x2d\x32\55\x66\x61\x63\x74\x6f\162\x2d\141\165\x74\x68\145\x6e\164\151\143\141\x74\x69\x6f\156");
        wp_send_json_error($we);
        oBm:
        return $g7;
    }
    public function mo2f_validate_answers($MX, $Ty, $ok, $v1)
    {
        $mL = array();
        foreach ($MX as $t8 => $Bw) {
            if (!(strpos($t8, "\153\142\141\x5f\141") === 0)) {
                goto aux;
            }
            if (MO2f_Utility::mo2f_check_empty_or_null($Bw)) {
                goto MbO;
            }
            $aq = sanitize_text_field($Bw);
            $jC = strtolower($aq);
            array_push($mL, $jC);
            goto xIo;
            MbO:
            $we = __("\101\154\154\x20\x74\150\x65\40\x66\x69\x65\154\x64\163\x20\x61\162\x65\40\162\x65\161\165\x69\162\145\x64\56\40\120\154\x65\x61\163\x65\x20\145\x6e\x74\x65\x72\40\x76\141\x6c\x69\x64\40\x65\x6e\x74\162\151\x65\163\56", "\x6d\151\156\x69\157\162\141\x6e\x67\145\x2d\62\55\x66\141\x63\164\157\x72\x2d\x61\x75\164\x68\x65\156\x74\x69\x63\141\164\x69\x6f\156");
            wp_send_json_error($we);
            xIo:
            aux:
            sHM:
        }
        vze:
        return $mL;
    }
    public function mo2f_encode_question_answer($g7, $mL)
    {
        $Z8 = count($g7);
        $qI = array();
        $eA = 0;
        Cq2:
        if (!($eA < $Z8)) {
            goto sx1;
        }
        $ZB = $g7[$eA];
        $Bw = md5($mL[$eA]);
        $qI[$ZB] = $Bw;
        Cw6:
        $eA++;
        goto Cq2;
        sx1:
        return $qI;
    }
    public function mo2f_update_user_details($post, $v1, $fK)
    {
        global $Xw;
        $MX = $this->mo2f_get_ques_ans($post);
        $w1 = json_decode($Xw->mo2f_register_kba_details($fK, $MX, $v1), true);
        if (!(json_last_error() === JSON_ERROR_NONE)) {
            goto HjZ;
        }
        if (!("\123\125\103\x43\105\123\123" === $w1["\x73\x74\x61\x74\x75\x73"])) {
            goto h2a;
        }
        delete_user_meta($v1, "\x6d\x6f\x32\146\x5f\x75\x73\x65\x72\x5f\x70\x72\x6f\x66\151\154\145\137\x73\145\x74");
        $bC = json_decode($Xw->mo2f_update_user_info($v1, true, MoWpnsConstants::SECURITY_QUESTIONS, MoWpnsConstants::SUCCESS_RESPONSE, MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, true, $fK), true);
        h2a:
        HjZ:
        return $bC;
    }
    public function mo2f_prompt_2fa_login($cs, $Ty, $ok)
    {
        global $Xw;
        $we = "\120\154\x65\141\163\145\x20\x61\x6e\x73\167\145\x72\40\x74\x68\x65\x20\x66\157\154\x6c\x6f\x77\151\x6e\147\40\x71\165\x65\x73\x74\151\157\x6e\163\x3a";
        $AP = MoWpnsConstants::MO_2_FACTOR_CHALLENGE_KBA_AUTHENTICATION;
        $g7 = $Xw->mo2f_pass2login_kba_verification($cs, $this->mo2f_current_method, $ok, $Ty);
        $this->mo2f_show_login_prompt($we, $AP, $cs, $ok, $Ty, $g7);
        exit;
    }
    public function mo2f_show_login_prompt($we, $AP, $current_user, $ok, $Ty, $g7 = null)
    {
        $yV = new Mo2f_Login_Popup();
        if (!is_null($g7)) {
            goto OaB;
        }
        $g7 = TwoFAMoSessions::get_session_var("\155\157\x5f\x32\x5f\x66\x61\x63\x74\x6f\x72\137\153\x62\x61\137\x71\x75\145\x73\x74\151\157\156\x73");
        OaB:
        $yV->mo2f_show_login_prompt_for_otp_based_methods($we, $AP, $current_user, $ok, $Ty, $this->mo2f_current_method, $g7);
        exit;
    }
    public function mo2f_login_validate($li, $ok, $Ty)
    {
        global $Xw;
        if (check_ajax_referer("\x6d\x6f\55\164\167\157\55\146\x61\143\x74\x6f\x72\x2d\x61\x6a\141\x78\55\156\x6f\x6e\143\145", "\x6e\x6f\x6e\143\x65", false)) {
            goto q1I;
        }
        wp_send_json_error("\143\x6c\x61\163\163\x2d\x6d\157\x32\146\55\x61\x6a\x61\170");
        q1I:
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\x6d\x6f\62\x66\137\143\x75\x72\x72\x65\156\164\137\165\163\145\162\x5f\151\144");
        if (!(!$v1 && is_user_logged_in())) {
            goto Bxe;
        }
        $user = wp_get_current_user();
        $v1 = $user->ID;
        Bxe:
        $current_user = get_user_by("\151\x64", $v1);
        $MX = array();
        $g7 = TwoFAMoSessions::get_session_var("\155\x6f\x5f\62\x5f\x66\141\143\x74\157\162\x5f\153\x62\x61\x5f\161\165\145\163\x74\x69\x6f\156\x73");
        $MX[0] = $g7[0];
        $MX[1] = isset($_POST["\155\157\x32\x66\137\141\x6e\163\167\x65\162\x5f\61"]) ? sanitize_text_field(wp_unslash($_POST["\155\157\x32\146\x5f\141\x6e\x73\167\x65\162\137\x31"])) : '';
        $MX[2] = $g7[1];
        $MX[3] = isset($_POST["\155\x6f\x32\146\137\x61\156\x73\x77\x65\x72\137\x32"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\157\x32\x66\137\x61\156\163\167\x65\162\137\62"])) : '';
        $hP = json_decode($Xw->validate_otp_token($this->mo2f_current_method, $current_user->user_email, '', $MX, $current_user), true);
        if (0 === strcasecmp($hP["\x73\164\x61\164\165\x73"], "\123\125\x43\x43\105\123\123")) {
            goto WmI;
        }
        wp_send_json_error("\x49\116\126\x41\114\111\x44\x5f\101\116\x53\127\105\x52\123");
        goto I6z;
        WmI:
        wp_send_json_success("\x56\x41\x4c\111\104\x41\x54\105\x44\x5f\123\x55\x43\103\105\123\123");
        I6z:
    }
}
new Mo2f_KBA_Handler();
GEQ:
