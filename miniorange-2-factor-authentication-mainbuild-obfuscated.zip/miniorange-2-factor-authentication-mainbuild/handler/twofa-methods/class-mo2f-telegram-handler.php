<?php


if (defined("\101\102\x53\120\x41\124\110")) {
    goto jwF;
}
exit;
jwF:
use TwoFA\Onprem\MO2f_Cloud_Onprem_Interface;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Onprem\Mo2f_Inline_Popup;
use TwoFA\Onprem\MO2f_Utility;
use TwoFA\Onprem\Miniorange_Password_2Factor_Login;
use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Helper\Mo2f_Login_Popup;
use TwoFA\Helper\Mo2f_Common_Helper;
use TwoFA\Onprem\Mo2f_Main_Handler;
use TwoFA\Helper\TwoFAMoSessions;
use TwoFA\Helper\MocURL;
if (class_exists("\115\x6f\62\x66\x5f\124\x45\x4c\x45\x47\122\101\x4d\137\x48\141\156\x64\x6c\145\x72")) {
    goto Hsu;
}
class Mo2f_TELEGRAM_Handler
{
    private $mo2f_current_method;
    public function __construct()
    {
        $this->mo2f_current_method = MoWpnsConstants::OTP_OVER_TELEGRAM;
    }
    public function mo2f_prompt_2fa_setup_inline($jg, $ok, $YP, $we)
    {
        $oG = new MO2f_Cloud_Onprem_Interface();
        $current_user = get_user_by("\x69\144", $YP);
        $hP = $oG->mo2f_set_user_two_fa($current_user, $this->mo2f_current_method);
        $Kl = new Mo2f_Inline_Popup();
        $cB = new Mo2f_Common_Helper();
        $cB->mo2f_inline_css_and_js();
        $iE = $cB->mo2f_get_previous_screen_for_inline($YP);
        $FT = $cB->mo2f_telegram_common_skeleton($YP);
        $XZ = "\74\x64\151\x76\x20\x63\154\x61\x73\163\75\x22\155\x6f\x32\x66\x5f\x6d\x6f\x64\141\x6c\x22\40\164\x61\142\151\x6e\x64\145\170\x3d\x22\x2d\x31\42\x20\162\x6f\154\x65\x3d\x22\144\x69\141\154\157\x67\42\x3e\15\xa\11\11\11\74\x64\151\166\x20\x63\x6c\x61\x73\163\75\x22\x6d\x6f\62\146\x2d\155\x6f\144\x61\x6c\55\142\x61\143\x6b\x64\x72\x6f\160\42\76\74\57\x64\151\166\x3e\15\12\x9\x9\x9\x3c\x64\x69\166\x20\143\x6c\x61\x73\163\x3d\42\155\157\x5f\143\165\163\164\x6f\x6d\x65\x72\137\166\141\154\151\x64\141\x74\151\157\x6e\x2d\x6d\157\144\x61\154\55\x64\x69\141\x6c\x6f\147\x20\x6d\157\x5f\x63\x75\x73\164\157\x6d\x65\162\137\166\x61\x6c\x69\144\141\x74\151\157\156\x2d\x6d\157\x64\x61\x6c\55\155\x64\x22\76";
        $XZ .= $cB->mo2f_otp_based_methods_configuration_screen($FT, $this->mo2f_current_method, $hP["\x6d\157\x32\146\141\x5f\x6c\x6f\x67\x69\156\x5f\x6d\145\163\x73\141\147\x65"], $YP, $ok, $jg, $iE);
        $XZ .= "\x3c\x2f\144\151\166\x3e\x3c\x2f\144\151\x76\x3e";
        $XZ .= $Kl->mo2f_get_inline_hidden_forms($ok, $jg, $current_user->ID);
        $XZ .= $cB->mo2f_get_script_for_otp_based_methods("\x69\x6e\x6c\151\x6e\145");
        echo $XZ;
        exit;
    }
    public function mo2f_send_otp($yo, $Ty, $user, $jD)
    {
        $Ip = new MocURL();
        $yo = $yo ?? get_user_meta($user->ID, "\x6d\157\62\x66\137\143\x68\x61\164\x5f\x69\x64", true);
        TwoFAMoSessions::add_session_var("\x6d\x6f\62\x66\137\x74\x65\155\160\x5f\x63\150\141\x74\111\x44", $yo);
        $hP = $Ip->mo2f_send_telegram_otp($yo);
        $this->mo2f_process_inline_send_otp($hP, $user, $Ty, $jD);
    }
    public function mo2f_process_inline_send_otp($hP, $user, $Ty, $jD)
    {
        global $Gw;
        if (json_last_error() === JSON_ERROR_NONE) {
            goto mRS;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_REQ));
        goto MUU;
        mRS:
        if ("\105\122\122\x4f\122" === $hP["\163\164\x61\x74\x75\163"]) {
            goto veF;
        }
        if (MoWpnsConstants::SUCCESS_RESPONSE === $hP["\x73\164\x61\164\x75\163"]) {
            goto FKk;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_REQ));
        goto sJJ;
        veF:
        wp_send_json_error($hP["\155\145\x73\163\141\147\x65"]);
        goto sJJ;
        FKk:
        TwoFAMoSessions::add_session_var("\155\157\x32\x66\137\x74\x72\141\156\x73\141\143\x74\151\x6f\x6e\x49\144", $hP["\x74\x78\111\x64"]);
        TwoFAMoSessions::add_session_var("\155\x6f\x32\x66\x5f\x6f\164\160\137\x73\145\156\x64\137\164\162\165\x65", true);
        wp_send_json_success($jD . "\171\157\165\x72\x20\x74\145\x6c\145\147\x72\141\155\x20\x6e\165\155\142\145\x72\56\x20" . MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_OTP) . MoWpnsMessages::lang_translate(MoWpnsMessages::VERIFY_YOURSELF));
        sJJ:
        MUU:
    }
    public function mo2f_validate_otp($li, $Ty, $user, $lZ, $post)
    {
        global $Gw;
        $sC = TwoFAMoSessions::get_session_var("\155\x6f\x32\146\137\164\145\x6d\160\137\x63\150\x61\164\111\x44");
        $this->mo2f_mismatch_input_check($sC, $lZ);
        $G5 = TwoFAMoSessions::get_session_var("\x6d\x6f\62\x66\137\x74\x72\141\x6e\163\141\x63\x74\x69\157\156\x49\144");
        $Ip = new MocURL();
        $hP = $Ip->mo2f_validate_telegram_code($li, $G5);
        $this->mo2f_process_inline_validate_otp($hP, $user);
    }
    public function mo2f_mismatch_input_check($sC, $lZ)
    {
        if (!($sC !== $lZ)) {
            goto a8h;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate("\x54\150\x65\40\x63\x75\x72\x72\145\x6e\164\40\x63\x68\x61\164\40\x49\x44\40\x64\157\x65\x73\x6e\47\x74\40\x6d\141\164\143\150\40\164\150\145\40\x6f\156\145\x20\165\163\145\144\x20\164\157\x20\163\x65\x6e\144\40\x74\150\x65\x20\117\x54\x50\56"));
        a8h:
    }
    public function mo2f_process_inline_validate_otp($hP, $user)
    {
        if ("\x45\x52\x52\x4f\x52" === $hP["\x73\x74\x61\164\x75\163"]) {
            goto dC9;
        }
        if (strcasecmp($hP["\163\x74\141\164\x75\x73"], "\x53\x55\x43\x43\105\x53\x53") === 0) {
            goto zAK;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_OTP));
        goto ZoR;
        dC9:
        wp_send_json_error(MoWpnsMessages::lang_translate($hP["\155\145\163\x73\x61\147\x65"]));
        goto ZoR;
        zAK:
        if (!isset($user->ID)) {
            goto KJO;
        }
        $Mc = new Miniorange_Password_2Factor_Login();
        $Mc->mo2fa_update_user_details($user->ID, true, $this->mo2f_current_method, MoWpnsConstants::SUCCESS_RESPONSE, MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, true, $user->user_email, null);
        KJO:
        update_user_meta($user->ID, "\155\157\x32\x66\x5f\143\x68\141\164\x5f\151\144", TwoFAMoSessions::get_session_var("\155\157\62\x66\137\164\x65\x6d\160\x5f\x63\150\141\164\111\104"));
        TwoFAMoSessions::unset_session("\x6d\x6f\x32\146\x5f\164\x65\x6d\x70\137\x63\150\141\164\111\104");
        TwoFAMoSessions::unset_session("\155\157\x32\146\x5f\157\164\160\x5f\x74\157\153\x65\x6e");
        TwoFAMoSessions::unset_session("\155\157\62\146\137\x74\x65\x6c\145\147\162\141\155\x5f\164\151\x6d\145");
        TwoFAMoSessions::unset_session("\155\x6f\x32\x66\x5f\157\x74\x70\137\x73\145\x6e\144\137\x74\162\165\x65");
        wp_send_json_success("\131\157\165\162\x20\x32\x46\101\40\x6d\145\x74\x68\157\144\40\x68\x61\163\40\x62\145\x65\x6e\x20\163\x65\x74\40\163\165\x63\143\145\x73\163\146\x75\x6c\154\x79\56");
        ZoR:
    }
    public function mo2f_prompt_2fa_login($cs, $Ty, $ok)
    {
        global $uz;
        $yo = get_user_meta($cs->ID, "\x6d\x6f\x32\x66\137\143\150\x61\164\x5f\x69\x64", true);
        $Ip = new MocURL();
        $hP = $Ip->mo2f_send_telegram_otp($yo);
        if (json_last_error() === JSON_ERROR_NONE && MoWpnsConstants::SUCCESS_RESPONSE === $hP["\163\x74\x61\164\165\163"]) {
            goto w34;
        }
        $AP = MoWpnsConstants::MO2F_ERROR_MESSAGE_PROMPT;
        $we = $this->mo2f_get_error_message();
        goto Nje;
        w34:
        $we = MoWpnsMessages::lang_translate(MoWpnsMessages::OTP_SENT) . "\x79\x6f\165\x72\40\164\x65\154\x65\x67\162\x61\x6d\x20\156\x75\155\142\x65\x72\x2e\40" . MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_OTP) . MoWpnsMessages::lang_translate(MoWpnsMessages::VERIFY_YOURSELF);
        $AP = MoWpnsConstants::MO_2_FACTOR_CHALLENGE_OTP_OVER_TELEGRAM;
        TwoFAMoSessions::add_session_var("\155\157\62\x66\x5f\x74\162\x61\156\163\x61\143\164\x69\157\156\111\144", $hP["\x74\170\111\x64"]);
        MO2f_Utility::mo2f_debug_file($AP . "\x20\x55\163\x65\x72\137\x49\x50\55" . $uz->get_client_ip() . "\40\125\x73\145\x72\x5f\111\x64\x2d" . $cs->ID . "\x20\105\x6d\x61\151\x6c\x2d" . $cs->user_email);
        Nje:
        $this->mo2f_show_login_prompt($we, $AP, $cs, $ok, $Ty);
        exit;
    }
    public function mo2f_show_login_prompt($we, $AP, $current_user, $ok, $Ty)
    {
        $yV = new Mo2f_Login_Popup();
        $yV->mo2f_show_login_prompt_for_otp_based_methods($we, $AP, $current_user, $ok, $Ty, $this->mo2f_current_method);
        exit;
    }
    public function mo2f_get_error_message()
    {
        return MoWpnsMessages::ERROR_DURING_PROCESS;
    }
    public function mo2f_login_validate($li, $ok, $Ty)
    {
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\x6d\157\x32\146\x5f\143\165\x72\x72\145\x6e\x74\137\x75\163\x65\x72\137\151\144");
        if (!(!$v1 && is_user_logged_in())) {
            goto VjD;
        }
        $user = wp_get_current_user();
        $v1 = $user->ID;
        VjD:
        $G5 = TwoFAMoSessions::get_session_var("\155\x6f\62\x66\137\x74\x72\x61\156\x73\141\143\164\x69\157\156\111\144");
        $b9 = TwoFAMoSessions::get_session_var("\x6d\x6f\x32\x66\x5f\141\164\164\145\x6d\160\x74\163\137\142\145\x66\157\x72\x65\137\x72\x65\144\x69\x72\x65\x63\x74");
        $Ip = new MocURL();
        $hP = $Ip->mo2f_validate_telegram_code($li, $G5);
        if (0 === strcasecmp($hP["\163\164\x61\x74\165\x73"], "\x53\x55\x43\103\105\123\123")) {
            goto axq;
        }
        if ($b9 > 1 || "\x64\x69\x73\141\142\x6c\x65\144" === $b9) {
            goto kAk;
        }
        TwoFAMoSessions::unset_session("\155\x6f\x32\x66\137\x61\164\164\x65\x6d\160\x74\x73\x5f\x62\145\x66\157\x72\x65\x5f\x72\x65\x64\151\162\x65\x63\x74");
        wp_send_json_error("\x4c\x49\115\x49\124\x5f\105\x58\103\105\x45\x44\105\x44");
        goto ca0;
        kAk:
        TwoFAMoSessions::add_session_var("\x6d\157\62\x66\x5f\x61\x74\164\x65\155\x70\164\x73\x5f\142\145\146\157\x72\x65\137\x72\145\x64\151\162\145\x63\x74", $b9 - 1);
        wp_send_json_error("\x49\116\126\x41\x4c\x49\104\137\117\124\x50");
        ca0:
        goto cJZ;
        axq:
        TwoFAMoSessions::add_session_var("\155\157\x32\146\137\x61\164\x74\145\x6d\x70\x74\163\137\x62\145\146\157\x72\x65\x5f\162\145\x64\151\x72\145\x63\164", 3);
        wp_send_json_success("\x56\101\114\x49\x44\101\124\x45\x44\x5f\x53\125\103\103\105\123\123");
        cJZ:
    }
    public function mo2f_prompt_2fa_setup_dashboard()
    {
        global $Gw;
        $current_user = wp_get_current_user();
        $Gw->insert_user($current_user->ID);
        $cB = new Mo2f_Common_Helper();
        $FT = $cB->mo2f_telegram_common_skeleton($current_user->ID);
        $XZ = $cB->mo2f_otp_based_methods_configuration_screen($FT, $this->mo2f_current_method, '', $current_user->ID, '', '', "\144\141\163\150\x62\x6f\x61\x72\x64");
        $XZ .= $this->mo2f_get_hidden_forms_dashboard($cB);
        $XZ .= $cB->mo2f_get_script_for_otp_based_methods("\144\x61\x73\150\142\157\141\162\x64");
        wp_send_json_success($XZ);
    }
    public function mo2f_prompt_2fa_test_dashboard()
    {
        global $uz;
        $cs = wp_get_current_user();
        $yo = get_user_meta($cs->ID, "\155\157\x32\146\x5f\x63\150\141\164\x5f\x69\144", true);
        $Ip = new MocURL();
        $hP = $Ip->mo2f_send_telegram_otp($yo);
        if (!(json_last_error() === JSON_ERROR_NONE)) {
            goto A2L;
        }
        if (!(MoWpnsConstants::SUCCESS_RESPONSE === $hP["\163\164\x61\x74\165\x73"])) {
            goto WJm;
        }
        $we = "\120\x6c\145\141\x73\145\x20\145\x6e\x74\145\x72\x20\x74\150\145\x20\x6f\x6e\x65\x20\x74\x69\x6d\145\x20\160\141\x73\163\x63\157\x64\145\40\x73\145\156\x74\x20\157\x6e\40\x79\x6f\165\162\x3c\142\x3e\x20\x54\x65\x6c\x65\147\x72\x61\155\x3c\x2f\x62\x3e\40\x61\x70\x70\56";
        $AP = MoWpnsConstants::MO_2_FACTOR_CHALLENGE_OTP_OVER_TELEGRAM;
        TwoFAMoSessions::add_session_var("\155\157\x32\x66\137\164\x72\x61\x6e\x73\141\x63\x74\x69\x6f\156\x49\x64", $hP["\x74\170\111\144"]);
        MO2f_Utility::mo2f_debug_file($AP . "\x20\125\163\145\162\137\111\120\55" . $uz->get_client_ip() . "\x20\x55\x73\x65\x72\137\x49\144\55" . $cs->ID . "\40\x45\155\x61\151\154\55" . $cs->user_email);
        $yV = new Mo2f_Login_Popup();
        $cB = new Mo2f_Common_Helper();
        $gH = $yV->mo2f_twofa_login_prompt_skeleton_values($we, $AP, null, null, $cs->ID, "\x74\145\163\x74\137\x32\x66\x61", '');
        $XZ = $yV->mo2f_get_twofa_skeleton_html($AP, $we, '', '', $gH, $this->mo2f_current_method, "\164\145\x73\x74\x5f\x32\x66\141");
        $XZ .= $yV->mo2f_get_validation_popup_script("\x74\145\x73\x74\137\62\x66\x61", $this->mo2f_current_method, '', '');
        $XZ .= $cB->mo2f_get_test_script();
        wp_send_json_success($XZ);
        WJm:
        A2L:
        $we = $this->mo2f_get_error_message();
        wp_send_json_error($we);
    }
    public function mo2f_get_hidden_forms_dashboard($cB)
    {
        return $cB->mo2f_get_dashboard_hidden_forms();
    }
}
new Mo2f_TELEGRAM_Handler();
Hsu:
