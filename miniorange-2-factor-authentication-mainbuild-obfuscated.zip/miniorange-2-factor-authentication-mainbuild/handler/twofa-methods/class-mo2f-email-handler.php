<?php


if (defined("\x41\x42\x53\120\101\x54\x48")) {
    goto KR;
}
exit;
KR:
use TwoFA\Onprem\MO2f_Cloud_Onprem_Interface;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Onprem\Mo2f_Inline_Popup;
use TwoFA\Onprem\MO2f_Utility;
use TwoFA\Helper\Mo2f_Login_Popup;
use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Onprem\Mo2f_Main_Handler;
use TwoFA\Helper\Mo2f_Common_Helper;
use TwoFA\Helper\TwoFAMoSessions;
if (class_exists("\115\x6f\62\146\x5f\x45\x4d\101\x49\114\x5f\110\x61\156\x64\154\x65\162")) {
    goto aF;
}
class Mo2f_EMAIL_Handler
{
    private $mo2f_current_method;
    public function __construct()
    {
        $this->mo2f_current_method = MoWpnsConstants::OTP_OVER_EMAIL;
    }
    public function mo2f_prompt_2fa_setup_inline($jg, $ok, $YP, $we)
    {
        global $Xw;
        $current_user = get_user_by("\151\144", $YP);
        if (!MoWpnsUtility::get_mo2f_db_option("\x6d\x6f\62\146\137\145\156\x61\142\154\x65\137\145\x6d\x61\x69\154\137\143\x68\141\156\147\x65", "\x73\151\164\x65\x5f\157\x70\164\x69\157\x6e")) {
            goto Uu;
        }
        $hP = $Xw->mo2f_set_user_two_fa($current_user, $this->mo2f_current_method);
        $Kl = new Mo2f_Inline_Popup();
        $cB = new Mo2f_Common_Helper();
        $cB->mo2f_inline_css_and_js();
        $iE = $cB->mo2f_get_previous_screen_for_inline($current_user->ID);
        $FT = $cB->mo2f_email_common_skeleton($YP);
        $XZ = "\74\x64\151\x76\40\143\154\141\163\163\75\x22\x6d\157\x32\x66\x5f\x6d\157\x64\x61\154\x22\x20\x74\141\x62\151\x6e\144\x65\x78\x3d\42\x2d\61\42\40\x72\x6f\x6c\145\75\42\144\x69\x61\x6c\x6f\147\42\76\15\12\11\11\x9\x9\x3c\144\151\x76\40\x63\x6c\141\x73\x73\75\42\155\x6f\62\146\x2d\155\157\144\141\x6c\55\142\141\x63\153\144\x72\157\x70\42\76\x3c\57\x64\x69\x76\76\xd\xa\11\11\11\11\74\x64\x69\x76\40\143\154\141\x73\x73\75\42\x6d\x6f\137\143\165\163\164\157\x6d\x65\x72\137\x76\x61\x6c\151\x64\141\x74\x69\x6f\x6e\55\x6d\x6f\144\x61\x6c\55\x64\x69\x61\154\x6f\x67\x20\x6d\x6f\137\143\x75\163\x74\x6f\155\145\162\x5f\166\141\154\x69\x64\141\164\x69\x6f\156\x2d\x6d\x6f\144\141\x6c\55\155\144\42\x3e";
        $XZ .= $cB->mo2f_otp_based_methods_configuration_screen($FT, $this->mo2f_current_method, $hP["\x6d\x6f\62\x66\141\137\x6c\x6f\x67\x69\156\x5f\155\x65\x73\163\x61\147\145"], $YP, $ok, $jg, $iE);
        $XZ .= "\74\x2f\x64\151\166\76\x3c\57\x64\151\x76\76";
        $XZ .= $Kl->mo2f_get_inline_hidden_forms($ok, $jg, $current_user->ID);
        $XZ .= $cB->mo2f_get_script_for_otp_based_methods("\151\156\154\151\x6e\145");
        echo $XZ;
        goto IP;
        Uu:
        $this->mo2f_prompt_2fa_inline($current_user, $jg, $ok);
        IP:
        exit;
    }
    public function mo2f_prompt_2fa_test_dashboard()
    {
        global $Gw, $Xw, $uz;
        $current_user = wp_get_current_user();
        $y2 = $Gw->get_user_detail("\155\x6f\62\x66\137\x75\x73\x65\162\137\x65\x6d\x61\x69\x6c", $current_user->ID);
        $bC = json_decode($Xw->send_otp_token(null, $y2, $this->mo2f_current_method, $current_user), true);
        if (!(json_last_error() === JSON_ERROR_NONE)) {
            goto YR;
        }
        if (!("\x53\x55\x43\103\105\x53\x53" === $bC["\163\164\x61\164\x75\163"])) {
            goto o0;
        }
        MO2f_Utility::mo2f_debug_file("\40\x4f\124\x50\x20\150\141\x73\x20\142\x65\145\x6e\40\163\x65\x6e\x74\x20\163\165\x63\x63\x65\163\x73\x66\x75\x6c\x6c\171\40\157\x76\x65\162\40\x65\155\141\x69\x6c\56\x20\x55\x73\x65\x72\137\111\120\55" . $uz->get_client_ip() . "\40\125\x73\x65\162\x5f\111\x64\x2d" . $current_user->ID . "\40\105\155\141\151\x6c\x2d" . $current_user->user_email);
        $q4 = MO2f_Utility::mo2f_get_hidden_email($y2);
        $we = MoWpnsMessages::lang_translate(MoWpnsMessages::OTP_SENT) . "\x20" . $q4 . "\x2e\40" . MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_OTP) . MoWpnsMessages::lang_translate(MoWpnsMessages::VERIFY_YOURSELF);
        TwoFAMoSessions::add_session_var("\155\157\62\x66\137\164\162\141\x6e\x73\141\143\x74\151\157\156\x49\x64", $bC["\x74\170\x49\144"]);
        $AP = MoWpnsConstants::MO_2_FACTOR_CHALLENGE_OTP_OVER_EMAIL;
        $yV = new Mo2f_Login_Popup();
        $cB = new Mo2f_Common_Helper();
        $gH = $yV->mo2f_twofa_login_prompt_skeleton_values($we, $AP, null, null, $current_user->ID, "\164\x65\163\164\x5f\62\x66\141", '');
        $XZ = $yV->mo2f_get_twofa_skeleton_html($AP, $we, '', '', $gH, $this->mo2f_current_method, "\164\x65\x73\x74\137\x32\146\141");
        $XZ .= $yV->mo2f_get_validation_popup_script("\164\x65\163\164\137\x32\x66\x61", $this->mo2f_current_method, '', '');
        $XZ .= $cB->mo2f_get_test_script();
        wp_send_json_success($XZ);
        o0:
        YR:
        $we = $this->mo2f_get_error_message($current_user);
        wp_send_json_error($we);
    }
    public function mo2f_prompt_2fa_login($cs, $Ty, $ok)
    {
        global $Gw, $Xw;
        $y2 = $Gw->get_user_detail("\x6d\x6f\x32\x66\x5f\x75\163\145\x72\137\145\155\141\151\154", $cs->ID);
        $hP = json_decode($Xw->send_otp_token(null, $y2, $this->mo2f_current_method, $cs), true);
        if (json_last_error() === JSON_ERROR_NONE && MoWpnsConstants::SUCCESS_RESPONSE === $hP["\x73\x74\x61\164\x75\x73"]) {
            goto ec;
        }
        $AP = MoWpnsConstants::MO2F_ERROR_MESSAGE_PROMPT;
        $we = $this->mo2f_get_error_message($cs);
        goto DJ;
        ec:
        $hP = $this->mo2f_handle_success_login($y2, $cs, $hP);
        $we = $hP["\154\x6f\x67\151\x6e\137\155\145\x73\x73\x61\x67\145"];
        $AP = $hP["\154\x6f\x67\151\156\x5f\163\164\141\164\165\x73"];
        DJ:
        $this->mo2f_show_login_prompt($we, $AP, $cs, $ok, $Ty);
        exit;
    }
    public function mo2f_prompt_2fa_inline($cs, $Ty, $ok)
    {
        global $Xw;
        $y2 = $cs->user_email;
        $hP = json_decode($Xw->send_otp_token(null, $y2, $this->mo2f_current_method, $cs), true);
        if (json_last_error() === JSON_ERROR_NONE && MoWpnsConstants::SUCCESS_RESPONSE === $hP["\x73\x74\x61\x74\165\163"]) {
            goto Uk;
        }
        $we = MoWpnsMessages::ERROR_DURING_PROCESS_EMAIL;
        $AP = MoWpnsConstants::MO2F_ERROR_MESSAGE_PROMPT;
        goto dx;
        Uk:
        $hP = $this->mo2f_handle_success_login($y2, $cs, $hP);
        $we = $hP["\154\x6f\x67\151\156\x5f\x6d\x65\163\x73\141\147\x65"];
        $AP = $hP["\154\x6f\x67\151\156\x5f\163\x74\141\x74\x75\x73"];
        dx:
        $this->mo2f_show_login_prompt($we, $AP, $cs, $ok, $Ty);
        exit;
    }
    public function mo2f_handle_success_login($y2, $current_user, $hP)
    {
        global $uz;
        $q4 = MO2f_Utility::mo2f_get_hidden_email($y2);
        $we = MoWpnsMessages::lang_translate(MoWpnsMessages::OTP_SENT) . "\40" . $q4 . "\x2e\40" . MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_OTP) . MoWpnsMessages::lang_translate(MoWpnsMessages::VERIFY_YOURSELF);
        TwoFAMoSessions::add_session_var("\155\x6f\62\146\137\x74\162\x61\x6e\x73\x61\x63\164\151\157\156\x49\x64", $hP["\164\x78\x49\144"]);
        $AP = MoWpnsConstants::MO_2_FACTOR_CHALLENGE_OTP_OVER_EMAIL;
        MO2f_Utility::mo2f_debug_file($AP . "\x20\x55\163\145\x72\x5f\111\x50\55" . $uz->get_client_ip() . "\x20\x55\163\x65\x72\x5f\111\x64\x2d" . $current_user->ID . "\40\105\x6d\141\151\154\55" . $current_user->user_email);
        return array("\154\157\147\x69\156\x5f\163\164\141\x74\165\163" => $AP, "\154\157\147\x69\x6e\x5f\155\145\163\163\x61\147\145" => $we);
    }
    public function mo2f_handle_error_login($L4, $y2, $jg, $ok)
    {
        $Aw = new Mo2f_Inline_Popup();
        MO2f_Utility::mo2f_debug_file("\101\156\40\x65\x72\x72\x6f\x72\x20\157\x63\143\x75\162\145\x64\x20\167\150\151\154\145\x20\163\x65\x6e\144\151\156\x67\x20\x74\x68\145\x20\x4f\124\x50\x2d\x20\x45\155\141\151\154\x2d" . $y2);
        $we = user_can($L4, "\x61\x64\155\x69\x6e\x69\x73\x74\x72\x61\164\157\162") ? MoWpnsMessages::ERROR_DURING_PROCESS_EMAIL : MoWpnsMessages::ERROR_DURING_PROCESS;
        $Aw->prompt_user_to_select_2factor_mthod_inline($L4, $we, $ok, $jg);
    }
    public function mo2f_login_validate($li, $ok, $Ty)
    {
        global $Xw;
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\155\157\62\146\x5f\143\165\162\162\145\x6e\164\137\165\x73\145\x72\137\151\144");
        if (!(!$v1 && is_user_logged_in())) {
            goto Xr;
        }
        $user = wp_get_current_user();
        $v1 = $user->ID;
        Xr:
        $current_user = get_user_by("\x69\x64", $v1);
        $G5 = TwoFAMoSessions::get_session_var("\x6d\x6f\62\x66\137\164\x72\141\x6e\x73\x61\143\x74\x69\x6f\156\111\144");
        $b9 = TwoFAMoSessions::get_session_var("\x6d\x6f\62\146\x5f\141\x74\164\145\x6d\x70\164\x73\137\x62\145\146\x6f\162\145\137\x72\x65\144\x69\x72\145\143\164");
        $hP = json_decode($Xw->validate_otp_token($this->mo2f_current_method, null, $G5, $li, $current_user), true);
        if (0 === strcasecmp($hP["\163\164\x61\x74\165\x73"], "\123\125\x43\x43\x45\x53\x53")) {
            goto C0;
        }
        if ($b9 > 1 || "\x64\151\163\141\x62\x6c\145\144" === $b9) {
            goto ff;
        }
        TwoFAMoSessions::unset_session("\x6d\x6f\x32\146\137\x61\164\164\145\x6d\160\164\x73\x5f\x62\x65\146\x6f\162\145\x5f\x72\x65\144\x69\162\145\x63\164");
        wp_send_json_error("\114\x49\x4d\111\124\x5f\x45\x58\103\x45\105\x44\x45\x44");
        goto j7;
        ff:
        TwoFAMoSessions::add_session_var("\155\157\x32\146\137\x61\164\164\145\155\160\x74\x73\x5f\x62\145\x66\x6f\x72\145\x5f\162\145\144\151\x72\145\x63\x74", $b9 - 1);
        wp_send_json_error("\111\116\126\x41\x4c\111\104\x5f\117\x54\120");
        j7:
        goto T_;
        C0:
        TwoFAMoSessions::add_session_var("\x6d\x6f\62\146\x5f\x61\164\164\x65\x6d\x70\164\163\x5f\x62\145\x66\157\x72\145\137\162\x65\144\x69\162\x65\x63\164", 3);
        $cB = new Mo2f_Common_Helper();
        if ($cB->mo2f_is_2fa_set($current_user->ID)) {
            goto tq;
        }
        $this->mo2f_update_user_details($current_user, $current_user->user_email);
        tq:
        wp_send_json_success("\x56\101\114\111\104\101\124\105\x44\137\123\x55\103\103\x45\123\123");
        T_:
    }
    public function mo2f_get_error_message($cs)
    {
        if (user_can($cs->ID, "\141\x64\155\151\x6e\x69\x73\164\x72\x61\x74\157\162")) {
            goto sb;
        }
        return MoWpnsMessages::ERROR_DURING_PROCESS;
        goto bN;
        sb:
        return MoWpnsMessages::ERROR_DURING_PROCESS_EMAIL;
        bN:
    }
    public function mo2f_send_otp($fK, $jg, $current_user, $jD)
    {
        global $Xw, $Gw;
        $fK = $fK ?? $Gw->get_user_detail("\155\157\x32\146\x5f\x75\x73\145\162\x5f\x65\155\141\151\154", $current_user->ID);
        $hP = json_decode($Xw->send_otp_token(null, $fK, $this->mo2f_current_method, $current_user), true);
        $this->mo2f_process_send_otp_content($hP, $current_user, $jD, $fK);
    }
    public function mo2f_process_send_otp_content($hP, $current_user, $jD, $fK)
    {
        if (!(json_last_error() === JSON_ERROR_NONE)) {
            goto oE;
        }
        if (!(MoWpnsConstants::SUCCESS_RESPONSE === $hP["\x73\164\x61\164\x75\163"])) {
            goto nj;
        }
        MO2f_Utility::mo2f_debug_file("\x4f\x54\x50\x20\x68\141\163\40\142\145\145\x6e\x20\x73\x65\156\164\x20\x73\x75\x63\x63\x65\x73\x73\x66\165\154\x6c\171\40\x6f\166\x65\162\x20\x45\155\x61\151\154");
        TwoFAMoSessions::add_session_var("\x6d\157\62\146\x5f\x74\162\x61\x6e\x73\141\x63\164\151\157\156\x49\x64", $hP["\x74\170\x49\144"]);
        TwoFAMoSessions::add_session_var("\155\x6f\62\146\137\157\x74\160\137\163\145\156\x64\137\164\x72\165\x65", true);
        wp_send_json_success($jD . "\40" . MO2f_Utility::mo2f_get_hidden_email($fK) . "\x2e\40" . MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_OTP) . MoWpnsMessages::lang_translate(MoWpnsMessages::VERIFY_YOURSELF));
        nj:
        oE:
        $we = user_can($current_user->ID, "\155\x61\x6e\141\147\145\137\x6f\160\x74\x69\x6f\x6e\163") ? MoWpnsMessages::ERROR_DURING_PROCESS_EMAIL : MoWpnsMessages::ERROR_DURING_PROCESS;
        wp_send_json_error($we);
    }
    public function mo2f_validate_otp($li, $jg, $user, $P3, $post)
    {
        global $Xw;
        $oJ = TwoFAMoSessions::get_session_var("\x74\x65\155\160\x52\x65\147\105\x6d\x61\151\154");
        $this->mo2f_mismatch_input_check($oJ, $P3);
        $G5 = TwoFAMoSessions::get_session_var("\x6d\157\x32\x66\x5f\x74\x72\141\x6e\163\x61\x63\x74\x69\x6f\156\111\x64");
        $hP = json_decode($Xw->validate_otp_token($this->mo2f_current_method, null, $G5, $li, $user), true);
        $this->mo2f_process_validate_otp($hP, $user, $oJ);
    }
    public function mo2f_process_validate_otp($hP, $user, $oJ)
    {
        if ("\105\122\x52\117\122" === $hP["\163\164\x61\164\x75\x73"]) {
            goto Ca;
        }
        if (strcasecmp($hP["\x73\x74\141\x74\x75\x73"], "\123\125\x43\103\x45\x53\123") === 0) {
            goto aT;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_OTP));
        goto oG;
        Ca:
        wp_send_json_error(MoWpnsMessages::lang_translate($hP["\155\145\163\163\141\x67\x65"]));
        goto oG;
        aT:
        $bC = $this->mo2f_update_user_details($user, $oJ);
        $this->mo2f_process_update_details_response($bC, $user);
        oG:
    }
    public function mo2f_process_update_details_response($bC, $user)
    {
        if (json_last_error() === JSON_ERROR_NONE) {
            goto Ot;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_REQ));
        goto uT;
        Ot:
        if ("\105\x52\x52\x4f\122" === $bC["\163\164\141\x74\x75\163"]) {
            goto ft;
        }
        if (MoWpnsConstants::SUCCESS_RESPONSE === $bC["\163\x74\x61\164\x75\x73"]) {
            goto Sz;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_DURING_PROCESS));
        goto DI;
        ft:
        wp_send_json_error(MoWpnsMessages::lang_translate($bC["\155\145\x73\x73\x61\x67\x65"]));
        goto DI;
        Sz:
        TwoFAMoSessions::unset_session("\155\157\62\146\137\x6f\x74\160\x5f\163\x65\x6e\x64\x5f\164\x72\165\145");
        wp_send_json_success("\x59\157\165\162\x20\62\x46\x41\40\x6d\145\164\150\157\x64\40\x68\141\163\40\142\145\x65\156\x20\x73\145\164\40\x73\x75\143\x63\145\x73\x73\x66\x75\x6c\x6c\x79\56");
        DI:
        uT:
    }
    public function mo2f_mismatch_input_check($IR, $P3)
    {
        if (!($IR !== $P3)) {
            goto fU;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate("\124\150\145\40\143\x75\162\x72\x65\156\x74\40\145\155\141\151\x6c\40\x49\x44\x20\144\x6f\x65\x73\156\47\164\x20\x6d\x61\164\x63\x68\x20\164\x68\145\x20\x6f\x6e\145\40\165\163\145\144\x20\x74\157\x20\x73\x65\x6e\144\x20\x74\x68\x65\40\x4f\124\120\56"));
        fU:
    }
    public function mo2f_process_inline_send_otp($bC, $current_user, $jg, $ok)
    {
        if (!(json_last_error() === JSON_ERROR_NONE)) {
            goto lp;
        }
        if ("\x53\x55\x43\x43\105\123\123" === $bC["\x73\164\141\x74\x75\x73"]) {
            goto Rs;
        }
        $we = user_can($current_user->ID, "\x61\x64\x6d\x69\x6e\x69\163\164\162\x61\164\x6f\x72") ? MoWpnsMessages::ERROR_DURING_PROCESS_EMAIL : MoWpnsMessages::ERROR_DURING_PROCESS;
        $Aw = new Mo2f_Inline_Popup();
        $Aw->prompt_user_to_select_2factor_mthod_inline($current_user->ID, $we, $ok, $jg);
        goto dI;
        Rs:
        $we = MoWpnsMessages::lang_translate(MoWpnsMessages::OTP_SENT) . "\x20" . MO2f_Utility::mo2f_get_hidden_email($current_user->user_email) . "\56\x20" . MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_OTP) . MoWpnsMessages::lang_translate(MoWpnsMessages::SET_THE_2FA);
        $AP = MoWpnsConstants::MO_2_FACTOR_CHALLENGE_OTP_OVER_EMAIL;
        TwoFAMoSessions::add_session_var("\155\x6f\x32\x66\x5f\164\162\141\156\163\x61\143\x74\151\x6f\x6e\x49\x64", $bC["\x74\170\111\144"]);
        $this->mo2f_show_login_prompt($we, $AP, $current_user, $ok, $jg);
        dI:
        lp:
    }
    public function mo2f_show_login_prompt($we, $AP, $current_user, $ok, $Ty)
    {
        $yV = new Mo2f_Login_Popup();
        $yV->mo2f_show_login_prompt_for_otp_based_methods($we, $AP, $current_user, $ok, $Ty, $this->mo2f_current_method);
        exit;
    }
    public function mo2f_update_user_details($user, $fK)
    {
        global $Xw;
        delete_user_meta($user->ID, "\x6d\157\x32\146\x5f\x75\163\145\162\x5f\160\162\x6f\x66\x69\x6c\x65\137\x73\x65\x74");
        return json_decode($Xw->mo2f_update_user_info($user->ID, true, $this->mo2f_current_method, MoWpnsConstants::SUCCESS_RESPONSE, MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, true, $fK, null), true);
    }
    public function mo2f_prompt_2fa_setup_dashboard()
    {
        global $Gw;
        $current_user = wp_get_current_user();
        $Gw->insert_user($current_user->ID);
        $cB = new Mo2f_Common_Helper();
        $FT = $cB->mo2f_email_common_skeleton($current_user->ID);
        $XZ = $cB->mo2f_otp_based_methods_configuration_screen($FT, $this->mo2f_current_method, '', $current_user->ID, '', '', "\144\141\163\x68\x62\157\x61\x72\144");
        $XZ .= $this->mo2f_get_hidden_forms_dashboard($cB);
        $XZ .= $cB->mo2f_get_script_for_otp_based_methods("\x64\141\x73\150\142\x6f\x61\x72\144");
        wp_send_json_success($XZ);
    }
    public function mo2f_get_hidden_forms_dashboard($cB)
    {
        return $cB->mo2f_get_dashboard_hidden_forms();
    }
}
new Mo2f_EMAIL_Handler();
aF:
