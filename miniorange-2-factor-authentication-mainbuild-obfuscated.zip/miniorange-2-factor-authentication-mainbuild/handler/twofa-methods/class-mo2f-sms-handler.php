<?php


if (defined("\x41\x42\x53\120\x41\124\x48")) {
    goto FFv;
}
exit;
FFv:
use TwoFA\Onprem\MO2f_Cloud_Onprem_Interface;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Onprem\Mo2f_Inline_Popup;
use TwoFA\Onprem\MO2f_Utility;
use TwoFA\Helper\Mo2f_Login_Popup;
use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Onprem\Mo2f_Main_Handler;
use TwoFA\Helper\Mo2f_Common_Helper;
use TwoFA\Helper\TwoFAMoSessions;
if (class_exists("\115\x6f\x32\146\x5f\123\x4d\x53\137\110\141\x6e\x64\x6c\x65\162")) {
    goto R4K;
}
class Mo2f_SMS_Handler
{
    private $mo2f_current_method;
    public function __construct()
    {
        $this->mo2f_current_method = MoWpnsConstants::OTP_OVER_SMS;
    }
    public function mo2f_prompt_2fa_setup_inline($jg, $ok, $YP, $we)
    {
        global $Xw;
        $current_user = get_user_by("\x69\144", $YP);
        $hP = $Xw->mo2f_set_user_two_fa($current_user, $this->mo2f_current_method);
        $Kl = new Mo2f_Inline_Popup();
        $cB = new Mo2f_Common_Helper();
        $cB->mo2f_inline_css_and_js();
        $iE = $cB->mo2f_get_previous_screen_for_inline($YP);
        $FT = $cB->mo2f_sms_common_skeleton($YP);
        $XZ = "\x3c\144\151\166\40\143\x6c\x61\163\163\75\42\x6d\x6f\62\x66\x5f\x6d\157\144\x61\154\42\x20\164\141\x62\151\x6e\x64\145\170\x3d\42\55\61\42\40\162\x6f\x6c\145\x3d\x22\x64\151\141\154\157\x67\42\x3e\15\12\x9\x9\x9\74\144\x69\x76\x20\143\x6c\x61\163\163\75\x22\155\157\62\146\x2d\x6d\x6f\144\141\154\x2d\142\x61\x63\x6b\x64\x72\157\x70\x22\x3e\x3c\x2f\144\151\x76\x3e\xd\12\x9\11\x9\74\x64\x69\166\x20\143\x6c\x61\x73\x73\75\42\x6d\157\137\x63\x75\163\164\x6f\x6d\145\x72\137\166\x61\154\x69\144\141\164\x69\x6f\x6e\x2d\x6d\x6f\x64\141\154\x2d\144\x69\x61\154\x6f\147\40\x6d\157\x5f\143\165\x73\x74\157\155\145\162\137\x76\x61\x6c\x69\144\141\164\151\x6f\156\x2d\155\157\144\x61\x6c\55\155\x64\x22\76";
        $XZ .= $cB->mo2f_otp_based_methods_configuration_screen($FT, $this->mo2f_current_method, $hP["\x6d\x6f\x32\146\x61\x5f\154\157\147\x69\156\137\x6d\145\163\163\x61\x67\145"], $YP, $ok, $jg, $iE);
        $XZ .= "\x3c\x2f\144\x69\x76\76\x3c\x2f\144\151\x76\76";
        $XZ .= $Kl->mo2f_get_inline_hidden_forms($ok, $jg, $current_user->ID);
        $XZ .= $cB->mo2f_get_script_for_otp_based_methods("\x69\x6e\x6c\151\156\145");
        echo $XZ;
        exit;
    }
    public function mo2f_send_otp($T7, $Ty, $user, $jD)
    {
        global $Xw, $Gw;
        $T7 = $T7 ?? $Gw->get_user_detail("\x6d\157\62\x66\x5f\x75\163\x65\x72\x5f\x70\150\x6f\x6e\x65", $user->ID);
        TwoFAMoSessions::add_session_var("\165\163\x65\x72\x5f\x70\x68\157\x6e\145\137\x74\x65\155\160", $T7);
        $hP = json_decode($Xw->send_otp_token($T7, null, $this->mo2f_current_method, $user), true);
        $this->mo2f_process_send_otp_content($hP, $Ty, $user, $T7, $jD);
    }
    public function mo2f_process_send_otp_content($hP, $Ty, $user, $T7, $jD)
    {
        if (json_last_error() === JSON_ERROR_NONE) {
            goto t1a;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_REQ));
        goto Wru;
        t1a:
        if ("\105\122\122\x4f\122" === $hP["\163\x74\141\x74\x75\163"]) {
            goto R8g;
        }
        if (MoWpnsConstants::SUCCESS_RESPONSE === $hP["\x73\164\141\x74\x75\x73"]) {
            goto nUN;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::GET_FREE_TRANSACTIONS));
        goto Na2;
        R8g:
        wp_send_json_error($hP["\155\145\x73\163\x61\147\x65"]);
        goto Na2;
        nUN:
        MO2f_Utility::mo2f_set_transient($Ty, "\x6d\x6f\62\146\x5f\164\162\141\x6e\163\141\x63\x74\151\157\x6e\111\144", $hP["\164\x78\x49\144"]);
        TwoFAMoSessions::add_session_var("\x6d\x6f\62\146\137\164\x72\141\156\x73\141\143\164\x69\x6f\156\111\x64", $hP["\x74\x78\x49\144"]);
        TwoFAMoSessions::add_session_var("\155\157\62\x66\x5f\x6f\x74\160\x5f\163\145\x6e\x64\x5f\164\x72\165\x65", true);
        $ra = get_site_option("\x63\155\x56\164\131\127\154\x75\x61\x57\65\156\124\x31\122\x51\126\110\112\150\142\x6e\x4e\150\x59\x33\x52\160\x62\x32\65\172");
        if (!($ra > 0)) {
            goto Orl;
        }
        update_site_option("\143\155\126\164\131\127\x6c\x75\141\127\x35\x6e\x54\x31\x52\x51\126\x48\112\x68\x62\156\116\x68\131\63\122\160\x62\x32\x35\172", $ra - 1);
        Orl:
        wp_send_json_success($jD . "\x20" . $T7 . "\x2e\40" . MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_OTP) . MoWpnsMessages::lang_translate(MoWpnsMessages::VERIFY_YOURSELF));
        Na2:
        Wru:
    }
    public function mo2f_validate_otp($li, $Ty, $user, $P3, $post)
    {
        global $Xw;
        $RN = TwoFAMoSessions::get_session_var("\165\163\145\162\x5f\x70\x68\x6f\156\145\137\164\145\155\x70");
        $this->mo2f_mismatch_input_check($RN, $P3);
        $G5 = MO2f_Utility::mo2f_get_transient($Ty, "\155\157\62\146\137\164\162\x61\156\x73\x61\x63\164\x69\x6f\156\111\144");
        $hP = json_decode($Xw->validate_otp_token($this->mo2f_current_method, null, $G5, $li, $user), true);
        $this->mo2f_process_validate_otp_content($hP, $user, $RN);
    }
    public function mo2f_process_validate_otp_content($hP, $user, $RN)
    {
        if ("\105\122\x52\x4f\122" === $hP["\163\164\x61\164\x75\x73"]) {
            goto pU1;
        }
        if (strcasecmp($hP["\x73\x74\x61\164\165\x73"], "\123\125\x43\103\105\123\x53") === 0) {
            goto Zzj;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_OTP));
        goto upM;
        pU1:
        wp_send_json_error(MoWpnsMessages::lang_translate($hP["\x6d\x65\x73\163\141\x67\145"]));
        goto upM;
        Zzj:
        $fK = get_user_by("\x69\144", $user->ID)->user_email;
        $bC = $this->mo2f_update_user_details($user, $fK, $RN);
        TwoFAMoSessions::unset_session("\x75\x73\x65\x72\x5f\x70\150\157\156\145\x5f\164\x65\155\160");
        TwoFAMoSessions::unset_session("\155\x6f\x32\x66\x5f\x6f\x74\160\137\x73\x65\156\144\137\164\x72\165\145");
        $this->mo2f_process_update_details_response($bC, $user);
        upM:
    }
    public function mo2f_process_update_details_response($bC, $user)
    {
        if (json_last_error() === JSON_ERROR_NONE) {
            goto Vh0;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_REQ));
        goto iBn;
        Vh0:
        if (MoWpnsConstants::SUCCESS_RESPONSE === $bC["\163\164\141\164\165\x73"]) {
            goto gv2;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_DURING_PROCESS));
        goto z_r;
        gv2:
        wp_send_json_success("\131\x6f\x75\162\40\62\106\101\x20\x6d\145\164\x68\157\144\40\150\x61\x73\x20\x62\x65\145\x6e\x20\163\145\164\40\163\x75\143\x63\145\x73\x73\146\165\x6c\154\171\56");
        z_r:
        iBn:
    }
    public function mo2f_mismatch_input_check($ki, $P3)
    {
        if (!($ki !== $P3)) {
            goto T18;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::PHONE_NUMBER_MISMATCH));
        T18:
    }
    public function mo2f_update_user_details($user, $fK, $RN)
    {
        global $Xw;
        delete_user_meta($user->ID, "\x6d\157\x32\146\x5f\x75\163\145\x72\137\160\x72\157\x66\151\x6c\145\137\163\x65\164");
        return json_decode($Xw->mo2f_update_user_info($user->ID, true, $this->mo2f_current_method, MoWpnsConstants::SUCCESS_RESPONSE, MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, true, $fK, $RN, "\x41\120\x49\x5f\x32\x46\101", true), true);
    }
    public function mo2f_get_error_message($cs)
    {
        if (user_can($cs->ID, "\141\x64\x6d\151\x6e\151\x73\164\x72\x61\x74\x6f\162")) {
            goto QoN;
        }
        return MoWpnsMessages::ERROR_DURING_PROCESS;
        goto nnx;
        QoN:
        return MoWpnsMessages::GET_FREE_TRANSACTIONS;
        nnx:
    }
    public function mo2f_prompt_2fa_setup_dashboard()
    {
        global $Gw;
        $current_user = wp_get_current_user();
        $Gw->insert_user($current_user->ID);
        $cB = new Mo2f_Common_Helper();
        if (get_site_option("\x6d\x6f\x5f\62\146\x61\143\x74\x6f\162\137\x61\144\x6d\x69\x6e\137\162\145\x67\151\x73\x74\x72\x61\164\151\157\156\137\x73\x74\141\164\165\163") === "\115\117\x5f\62\x5f\106\x41\103\x54\117\122\x5f\x43\125\123\124\117\115\x45\122\x5f\122\105\x47\x49\123\x54\105\x52\105\104\137\123\125\x43\103\x45\x53\123") {
            goto cpw;
        }
        $FT = array("\x23\x23\x63\162\157\x73\163\142\165\164\164\157\156\43\x23" => "\11\x3c\x62\165\164\x74\157\156\40\x74\171\160\145\75\x22\x62\x75\164\164\x6f\x6e\42\40\x63\x6c\x61\x73\163\75\x22\x6d\x6f\62\146\x5f\x63\x6c\157\163\x65\x22\x20\144\x61\x74\x61\55\x64\x69\163\155\x69\x73\163\75\x22\155\157\144\x61\154\x22\x20\141\162\151\141\55\x6c\141\x62\x65\x6c\x3d\x22\103\154\157\163\145\42\x20\164\x69\x74\154\x65\75\42" . esc_attr__("\102\x61\143\153\x20\164\x6f\40\x6c\157\x67\151\x6e", "\155\x69\x6e\151\157\x72\x61\x6e\x67\145\x2d\x32\55\x66\141\x63\x74\157\x72\x2d\141\165\164\x68\x65\156\x74\x69\x63\141\164\x69\157\x6e") . "\42\40\x6f\156\143\154\151\x63\x6b\75\x22\155\x6f\x6c\157\x67\x69\156\x62\141\x63\x6b\x28\x29\73\x22\76\xd\xa\x9\11\x9\x9\x9\x3c\x73\x70\141\x6e\x20\141\x72\151\x61\55\150\x69\x64\144\x65\156\75\42\x74\162\165\x65\42\76\x26\x74\x69\155\x65\x73\73\x3c\x2f\163\x70\x61\x6e\x3e\xd\12\11\11\11\x9\x3c\57\142\x75\164\x74\157\x6e\x3e", "\43\43\155\x69\x6e\x69\x6f\x72\x61\x6e\147\x65\154\x6f\147\x6f\x23\x23" => $cB->mo2f_customize_logo(), "\43\43\x70\x61\147\x65\164\151\164\154\145\43\43" => "\x3c\x62\x3e" . __("\114\157\x67\x69\156\57\122\145\147\151\163\164\145\162\40\x77\151\x74\x68\x20\155\151\x6e\151\117\162\141\156\x67\145", "\155\x69\156\x69\x6f\162\x61\156\147\x65\x2d\x32\x2d\x66\141\x63\x74\157\162\x2d\x61\165\x74\150\x65\156\x74\x69\143\x61\x74\x69\x6f\x6e") . "\74\x2f\x62\76");
        $XZ = "\74\144\151\x76\x20\x63\x6c\x61\x73\x73\75\x22\155\x6f\x32\x66\x5f\x6c\x6f\x67\x69\x6e\137\162\145\x67\x69\x73\164\x65\162\137\160\x6f\160\x75\160\x22\76";
        $XZ .= $cB->mo2f_get_miniorange_user_registration_prompt('', null, null, "\144\141\x73\x68\142\157\141\x72\x64", $FT);
        $XZ .= "\x3c\x2f\144\151\x76\x3e";
        goto yjk;
        cpw:
        $FT = $cB->mo2f_sms_common_skeleton($current_user->ID);
        $XZ = $cB->mo2f_otp_based_methods_configuration_screen($FT, $this->mo2f_current_method, '', $current_user->ID, '', '', "\144\141\x73\x68\x62\157\141\162\144");
        $XZ .= $this->mo2f_get_hidden_forms_dashboard($cB);
        $XZ .= $cB->mo2f_get_script_for_otp_based_methods("\x64\x61\163\150\142\x6f\141\x72\x64");
        yjk:
        wp_send_json_success($XZ);
    }
    public function mo2f_prompt_2fa_test_dashboard()
    {
        global $Gw, $Xw, $uz;
        $current_user = wp_get_current_user();
        $Ez = $Gw->get_user_detail("\x6d\x6f\x32\146\x5f\x75\163\x65\x72\x5f\160\x68\157\156\145", $current_user->ID);
        $bC = json_decode($Xw->send_otp_token($Ez, null, $this->mo2f_current_method, $current_user), true);
        if (!(json_last_error() === JSON_ERROR_NONE)) {
            goto QA2;
        }
        if (!("\x53\x55\x43\x43\x45\x53\123" === $bC["\x73\x74\x61\164\165\x73"])) {
            goto ke9;
        }
        MO2f_Utility::mo2f_debug_file("\x4f\124\x50\x20\150\141\x73\40\142\145\145\x6e\x20\x73\x65\156\x74\x20\163\165\143\143\x65\x73\x73\x66\x75\154\154\171\40\157\166\x65\162\x20\160\x68\x6f\156\145\56\40\x55\x73\x65\162\x5f\111\x50\x2d" . $uz->get_client_ip() . "\40\125\163\145\162\137\x49\x64\55" . $current_user->ID . "\x20\x45\155\x61\x69\154\x2d" . $current_user->user_email);
        $UZ = MO2f_Utility::get_hidden_phone($Ez);
        $we = MoWpnsMessages::lang_translate(MoWpnsMessages::OTP_SENT) . "\x20" . $UZ . "\x2e\40" . MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_OTP) . MoWpnsMessages::lang_translate(MoWpnsMessages::VERIFY_YOURSELF);
        $AP = MoWpnsConstants::MO_2_FACTOR_CHALLENGE_OTP_OVER_SMS;
        $cB = new Mo2f_Common_Helper();
        TwoFAMoSessions::add_session_var("\155\157\62\146\x5f\x74\x72\x61\156\163\x61\143\164\x69\x6f\x6e\x49\144", $bC["\164\170\x49\144"]);
        $yV = new Mo2f_Login_Popup();
        $gH = $yV->mo2f_twofa_login_prompt_skeleton_values($we, $AP, null, null, $current_user->ID, "\x74\x65\163\x74\137\62\146\x61", '');
        $XZ = $yV->mo2f_twofa_authentication_login_prompt($AP, $we, '', '', $gH, $this->mo2f_current_method, "\x74\x65\x73\x74\137\62\146\141");
        $XZ .= $cB->mo2f_get_test_script();
        wp_send_json_success($XZ);
        ke9:
        QA2:
        $we = $this->mo2f_get_error_message($current_user);
        wp_send_json_error($we);
    }
    public function mo2f_prompt_2fa_login($cs, $Ty, $ok)
    {
        global $Gw, $Xw, $uz;
        $Ez = $Gw->get_user_detail("\x6d\x6f\x32\146\x5f\x75\x73\145\162\137\160\x68\x6f\x6e\x65", $cs->ID);
        $hP = json_decode($Xw->send_otp_token($Ez, null, $this->mo2f_current_method, $cs), true);
        if (json_last_error() === JSON_ERROR_NONE && MoWpnsConstants::SUCCESS_RESPONSE === $hP["\163\x74\141\x74\165\163"]) {
            goto Q6Y;
        }
        $AP = MoWpnsConstants::MO2F_ERROR_MESSAGE_PROMPT;
        $we = $this->mo2f_get_error_message($cs);
        goto OHW;
        Q6Y:
        $UZ = MO2f_Utility::get_hidden_phone($Ez);
        $we = MoWpnsMessages::lang_translate(MoWpnsMessages::OTP_SENT) . "\x20" . $UZ . "\x2e\x20" . MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_OTP) . MoWpnsMessages::lang_translate(MoWpnsMessages::VERIFY_YOURSELF);
        $AP = MoWpnsConstants::MO_2_FACTOR_CHALLENGE_OTP_OVER_SMS;
        TwoFAMoSessions::add_session_var("\x6d\157\62\x66\137\164\162\141\x6e\x73\141\143\x74\151\157\x6e\x49\x64", $hP["\164\x78\x49\x64"]);
        MO2f_Utility::mo2f_debug_file($AP . "\40\x55\x73\x65\x72\x5f\111\x50\x2d" . $uz->get_client_ip() . "\x20\x55\x73\x65\x72\137\111\144\55" . $cs->ID . "\x20\x45\155\141\151\154\55" . $cs->user_email);
        OHW:
        $this->mo2f_show_login_prompt($we, $AP, $cs, $ok, $Ty);
        exit;
    }
    public function mo2f_show_login_prompt($we, $AP, $current_user, $ok, $Ty)
    {
        $yV = new Mo2f_Login_Popup();
        $yV->mo2f_show_login_prompt_for_otp_based_methods($we, $AP, $current_user, $ok, $Ty, $this->mo2f_current_method);
        exit;
    }
    public function mo2f_login_validate($li, $ok, $Ty)
    {
        global $Xw, $Gw;
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\x6d\157\62\146\x5f\143\165\162\162\x65\x6e\x74\x5f\165\x73\x65\x72\x5f\x69\144");
        if (!(!$v1 && is_user_logged_in())) {
            goto c0b;
        }
        $user = wp_get_current_user();
        $v1 = $user->ID;
        c0b:
        $current_user = get_user_by("\x69\144", $v1);
        $G5 = TwoFAMoSessions::get_session_var("\x6d\x6f\x32\x66\x5f\x74\x72\141\156\163\141\143\164\151\x6f\x6e\x49\144");
        $b9 = TwoFAMoSessions::get_session_var("\155\157\x32\146\x5f\x61\164\x74\x65\155\x70\x74\163\137\142\x65\146\157\162\x65\x5f\x72\x65\144\x69\162\145\x63\164");
        $hP = json_decode($Xw->validate_otp_token($this->mo2f_current_method, null, $G5, $li, $current_user), true);
        if (0 === strcasecmp($hP["\163\x74\x61\x74\165\x73"], "\x53\x55\103\103\105\x53\123")) {
            goto OGo;
        }
        if ($b9 > 1 || "\x64\151\x73\x61\142\x6c\x65\144" === $b9) {
            goto wXh;
        }
        TwoFAMoSessions::unset_session("\155\x6f\x32\x66\x5f\x61\164\164\145\155\160\x74\x73\x5f\142\x65\146\157\x72\x65\137\x72\145\144\151\162\x65\143\164");
        wp_send_json_error("\x4c\111\115\x49\124\137\x45\x58\103\105\105\x44\x45\104");
        goto eto;
        wXh:
        TwoFAMoSessions::add_session_var("\155\x6f\x32\146\x5f\141\x74\164\x65\155\160\164\x73\x5f\142\x65\x66\x6f\x72\145\137\162\x65\144\x69\x72\145\x63\x74", $b9 - 1);
        $we = MoWpnsMessages::INVALID_OTP;
        wp_send_json_error("\x49\116\126\x41\114\111\x44\137\x4f\x54\120");
        eto:
        goto A1r;
        OGo:
        TwoFAMoSessions::add_session_var("\x6d\157\x32\146\x5f\141\164\x74\x65\x6d\160\x74\163\137\x62\145\x66\x6f\162\x65\x5f\x72\145\144\x69\x72\145\143\x74", 3);
        wp_send_json_success("\126\x41\x4c\x49\104\101\x54\105\104\137\123\x55\x43\103\x45\123\123");
        A1r:
    }
    public function mo2f_get_hidden_forms_dashboard($cB)
    {
        return $cB->mo2f_get_dashboard_hidden_forms();
    }
}
new Mo2f_SMS_Handler();
R4K:
