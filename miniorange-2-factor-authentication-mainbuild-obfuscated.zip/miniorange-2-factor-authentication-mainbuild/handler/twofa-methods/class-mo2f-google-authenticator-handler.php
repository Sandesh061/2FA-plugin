<?php


if (defined("\x41\x42\123\120\101\124\x48")) {
    goto r7;
}
exit;
r7:
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Onprem\Mo2f_Inline_Popup;
use TwoFA\Onprem\MO2f_Utility;
use TwoFA\Helper\Mo2f_Login_Popup;
use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Onprem\Google_Auth_Onpremise;
use TwoFA\Helper\Mo2f_Inline_Common;
use TwoFA\Helper\Mo2f_Common_Helper;
use TwoFA\Helper\TwoFAMoSessions;
require_once dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . "\x68\x61\156\x64\x6c\x65\162" . DIRECTORY_SEPARATOR . "\x74\x77\x6f\146\141" . DIRECTORY_SEPARATOR . "\x63\154\141\x73\x73\x2d\x67\157\157\147\154\145\55\141\x75\164\x68\x2d\157\156\x70\x72\145\x6d\151\x73\x65\56\160\150\160";
if (class_exists("\x4d\x6f\x32\146\137\x47\x4f\117\x47\x4c\x45\101\x55\124\110\x45\x4e\x54\x49\103\x41\x54\x4f\122\x5f\x48\141\156\x64\154\145\x72")) {
    goto f2e;
}
class Mo2f_GOOGLEAUTHENTICATOR_Handler
{
    private $mo2f_current_method;
    public function __construct()
    {
        $this->mo2f_current_method = MoWpnsConstants::GOOGLE_AUTHENTICATOR;
    }
    public function mo2f_prompt_2fa_setup_inline($jg, $ok, $YP, $we)
    {
        global $Xw;
        $ic = get_option("\x6d\157\62\x66\137\x67\157\157\147\x6c\x65\x5f\141\160\160\156\141\x6d\145", DEFAULT_GOOGLE_APPNAME);
        $ic = preg_replace("\43\136\x68\164\164\160\163\x3f\x3a\57\x2f\x23\151", '', $ic);
        $user = get_user_by("\111\x44", $YP);
        $Xw->mo2f_set_google_authenticator($user, $this->mo2f_current_method, $ic, $jg);
        $CM = MO2f_Utility::mo2f_get_transient($jg, "\x73\145\143\162\x65\164\137\147\141");
        $mC = MO2f_Utility::mo2f_get_transient($jg, "\147\x61\x5f\x71\162\x43\x6f\144\x65");
        if ($CM) {
            goto Jn;
        }
        $CM = $this->mo2f_create_secret();
        MO2f_Utility::mo2f_set_transient($jg, "\x73\145\x63\162\x65\x74\x5f\147\141", $CM);
        Jn:
        global $Gw;
        if (!(empty($mC) || !MO2F_IS_ONPREM)) {
            goto YX;
        }
        $fK = $Gw->get_user_detail("\x6d\x6f\62\x66\137\x75\163\145\162\137\x65\155\x61\x69\154", $user->ID);
        $CM = $this->mo2f_create_secret();
        $mC = $this->mo2f_geturl($CM, $ic, $fK);
        MO2f_Utility::mo2f_set_transient($jg, "\x67\x61\x5f\x71\162\x43\157\x64\145", $mC);
        YX:
        $EY = $this->mo2f_geturl($CM, $ic, '');
        MO2f_Utility::mo2f_set_transient($jg, "\x73\x65\143\x72\x65\x74\137\x67\x61", $CM);
        wp_register_script("\155\157\62\146\x5f\x71\x72\x5f\143\x6f\144\145\137\155\x69\156\152\x73", plugins_url("\x2f\x69\156\143\x6c\165\144\x65\163\x2f\x6a\x71\165\145\x72\x79\55\161\x72\143\x6f\144\145\x2f\x6a\161\165\x65\162\x79\55\161\162\x63\x6f\144\145\x2e\x6d\x69\156\56\x6a\x73", dirname(dirname(__FILE__))), array(), MO2F_VERSION, false);
        $cB = new Mo2f_Common_Helper();
        $Kl = new Mo2f_Inline_Popup();
        $iE = $cB->mo2f_get_previous_screen_for_inline($user->ID);
        $cB->mo2f_inline_css_and_js();
        wp_print_scripts("\155\x6f\62\x66\x5f\x71\x72\137\x63\157\144\145\137\155\151\x6e\152\163");
        $XZ = "\74\150\164\155\154\76\xd\12\x9\x9\x9\x3c\150\145\x61\x64\x3e\40\x20\x3c\x6d\x65\164\141\40\143\x68\x61\162\x73\x65\x74\75\42\165\164\146\x2d\70\42\x2f\76\15\xa\x9\11\x9\11\x3c\155\145\x74\x61\40\x68\164\164\x70\x2d\145\161\165\x69\166\75\x22\x58\x2d\x55\x41\55\103\157\155\x70\141\x74\151\142\x6c\145\x22\40\143\157\x6e\x74\x65\156\x74\75\x22\x49\x45\75\x65\144\x67\145\42\76\15\12\11\x9\11\x9\x3c\155\x65\x74\x61\40\156\141\155\x65\75\42\x76\x69\x65\167\x70\x6f\x72\164\x22\x20\x63\157\x6e\x74\x65\156\164\75\42\167\151\x64\164\150\75\144\145\166\151\143\145\55\x77\151\144\x74\150\54\x20\151\156\151\x74\x69\x61\x6c\55\x73\x63\x61\x6c\145\x3d\61\42\76\15\xa\x9\x9\x9\74\x2f\150\145\x61\x64\76\xd\xa\11\x9\x9\x3c\x62\157\x64\x79\76";
        $XZ .= $cB->mo2f_google_authenticator_popup_common_html($ic, $mC, $EY, $CM, $iE, $ok, $jg);
        $XZ .= $Kl->mo2f_get_inline_hidden_forms($ok, $jg, $user->ID);
        $XZ .= $this->mo2f_get_script("\x69\156\x6c\151\x6e\145", $jg, $ok);
        echo $XZ;
        exit;
    }
    public function mo2f_prompt_2fa_setup_dashboard()
    {
        global $Gw;
        $current_user = wp_get_current_user();
        $Gw->insert_user($current_user->ID);
        $cB = new Mo2f_Common_Helper();
        $ic = get_option("\x6d\x6f\62\x66\137\x67\157\x6f\x67\x6c\145\x5f\x61\160\160\156\141\x6d\x65", DEFAULT_GOOGLE_APPNAME);
        $Ts = new Google_auth_onpremise();
        $wG = $this->mo2f_create_secret();
        $G1 = get_option("\x6d\x6f\62\146\x5f\147\x6f\157\x67\154\145\x5f\141\160\160\156\x61\155\145", DEFAULT_GOOGLE_APPNAME);
        $fK = $current_user->user_email;
        $iG = $this->mo2f_geturl($wG, $G1, $fK);
        $EY = $Ts->mo2f_geturl($wG, $ic, '');
        $XZ = $cB->mo2f_google_authenticator_popup_common_html($ic, $iG, $EY, $wG, "\x64\141\x73\x68\142\157\x61\x72\144", null, null);
        $XZ .= $cB->mo2f_get_dashboard_hidden_forms();
        $XZ .= $this->mo2f_get_script("\144\141\x73\x68\142\157\x61\162\x64", '', '');
        wp_send_json_success($XZ);
    }
    public function mo2f_prompt_2fa_test_dashboard()
    {
        $current_user = wp_get_current_user();
        $we = MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_OTP) . MoWpnsMessages::lang_translate(MoWpnsMessages::VERIFY_YOURSELF);
        $AP = "\x4d\117\x5f\62\137\x46\101\x43\124\117\x52\137\x43\110\101\114\x4c\105\x4e\107\105\x5f\107\117\x4f\107\x4c\105\x5f\x41\x55\x54\x48\105\x4e\124\x49\103\x41\x54\111\117\x4e";
        $yV = new Mo2f_Login_Popup();
        $cB = new Mo2f_Common_Helper();
        $gH = $yV->mo2f_twofa_login_prompt_skeleton_values($we, $AP, null, null, $current_user->ID, "\164\145\163\x74\x5f\62\146\x61", '');
        $XZ = $yV->mo2f_get_twofa_skeleton_html($AP, $we, '', '', $gH, $this->mo2f_current_method, "\x74\x65\x73\x74\x5f\x32\x66\141");
        $XZ .= $yV->mo2f_get_validation_popup_script("\164\145\x73\x74\x5f\x32\x66\141", $this->mo2f_current_method, '', '');
        $XZ .= $cB->mo2f_get_test_script();
        wp_send_json_success($XZ);
    }
    public function mo2f_get_script($z7, $jg, $ok)
    {
        $cB = new Mo2f_Common_Helper();
        $y0 = array($cB, "\x6d\157\x32\146\137\147\x65\x74\x5f\x76\x61\154\151\x64\x61\164\145\137\163\165\143\143\145\x73\x73\137\x72\x65\163\160\x6f\156\163\145\x5f" . $z7 . "\137\x73\x63\x72\151\x70\164");
        $lW = "\74\163\143\x72\151\x70\164\76\xd\12\11\11\11\x6a\x51\x75\x65\x72\x79\50\42\x61\133\150\x72\145\x66\x3d\47\x23\x6d\x6f\x32\146\137\x69\x6e\x6c\151\156\x65\137\146\x6f\162\155\x27\x5d\x22\51\56\x63\x6c\x69\x63\x6b\x28\x66\165\x6e\143\164\151\x6f\156\50\51\x20\173\xd\xa\11\11\x9\11\x6a\x51\x75\145\162\x79\50\42\43\x6d\157\x32\x66\137\x62\x61\x63\153\x74\157\x5f\151\156\x6c\x69\156\145\137\162\145\147\x69\163\164\x72\141\164\151\157\x6e\42\51\56\x73\165\x62\155\151\164\x28\x29\x3b\15\12\11\11\11\175\x29\x3b\xd\12\11\11\11\x76\141\162\40\141\x6a\141\x78\165\162\154\x20\x3d\40\42" . esc_js(admin_url("\x61\x64\155\151\x6e\55\141\x6a\x61\170\x2e\160\150\160")) . "\42\73\xd\12\11\11\x9\146\x75\156\x63\x74\x69\x6f\156\x20\155\157\62\146\x5f\x76\141\154\x69\x64\141\164\145\x5f\x67\141\165\x74\150\50\156\157\x6e\143\x65\x2c\x20\x67\141\137\163\145\143\162\x65\164\x29\173\xd\xa\11\11\40\x20\x20\x20\40" . $cB->mo2f_show_loader() . "\xd\12\11\x9\x9\11\x76\141\x72\x20\x64\141\164\x61\40\x3d\x20\x7b\15\12\11\x9\x9\x9\11\42\x61\x63\164\151\157\156\42\x20\x20\40\40\40\x20\x20\x20\40\x20\40\40\x20\x20\x20\40\40\72\x20\x22\155\x6f\x5f\164\x77\x6f\x5f\x66\141\143\x74\157\x72\x5f\x61\x6a\x61\170\42\x2c\xd\xa\11\x9\x9\x9\11\42\x6d\x6f\x5f\62\146\137\x74\x77\157\137\146\x61\x63\164\157\x72\137\x61\x6a\141\x78\x22\x20\40\72\x20\x22\x6d\x6f\x32\x66\137\166\141\154\151\144\141\x74\x65\137\157\164\x70\137\x66\157\x72\x5f\x63\157\x6e\x66\x69\147\x75\x72\x61\x74\x69\x6f\156\42\x2c\15\12\x9\x9\x9\x9\11\42\156\x6f\x6e\x63\x65\42\40\x20\40\40\x20\x20\40\40\40\x20\x20\40\40\x20\x20\x20\x20\40\x3a\40\x6e\x6f\156\x63\145\54\11\xd\12\11\x9\x9\x9\x9\x22\157\164\160\x5f\164\157\x6b\x65\x6e\x22\x20\x20\40\40\40\40\x20\x20\x20\40\x20\40\40\40\x3a\40\x6a\x51\x75\x65\162\171\50\x22\x23\x67\x6f\x6f\147\154\x65\x5f\141\165\164\150\137\x63\x6f\x64\x65\x22\x29\x2e\166\x61\x6c\x28\x29\54\15\12\11\x9\x9\x9\x9\x22\147\141\x5f\163\145\143\x72\x65\x74\42\40\x20\x20\x20\x20\x20\40\x20\x20\x20\40\x20\40\40\x3a\x20\147\141\x5f\163\x65\143\162\145\x74\54\xd\12\x9\x9\x9\11\x9\42\x6d\x6f\62\146\137\x73\x65\x73\163\151\157\156\137\151\144\42\40\40\40\40\40\40\40\40\x3a\x20\42" . esc_js($jg) . "\x22\x2c\15\12\11\x9\11\11\x9\42\x72\x65\144\151\162\145\x63\x74\x5f\164\157\x22\40\x20\x20\x20\x20\40\x20\x20\x20\40\x20\x20\x3a\40\x22" . esc_js($ok) . "\x22\x2c\xd\12\x9\11\11\x9\11\42\x6d\157\x32\146\x5f\157\x74\x70\x5f\x62\141\x73\x65\144\x5f\x6d\x65\164\x68\157\144\x22\x20\40\72\40\42" . esc_js($this->mo2f_current_method) . "\42\x2c\15\12\11\x9\11\11\175\x3b\15\xa\x9\11\x9\11\152\x51\165\145\162\171\56\141\152\x61\x78\x28\173\15\12\x9\11\11\x9\x9\165\162\x6c\x3a\x20\x61\x6a\141\170\165\162\154\54\15\12\11\x9\x9\11\11\164\171\160\x65\x3a\40\x22\120\117\x53\x54\x22\x2c\15\xa\x9\x9\11\x9\x9\x64\x61\164\x61\124\171\x70\x65\x3a\x20\x22\x6a\x73\157\156\x22\54\15\12\11\x9\11\11\x9\144\141\x74\x61\x3a\x20\144\141\x74\141\54\15\12\11\x9\x9\11\11\163\165\143\143\x65\163\x73\x3a\x20\146\165\156\x63\164\x69\x6f\x6e\40\x28\x72\145\x73\160\x6f\x6e\x73\x65\51\40\173\xd\12\11\x9\11\11\x9\x20\40\x20\40" . $cB->mo2f_hide_loader() . "\15\xa\x9\x9\x9\11\x9\x9\x69\x66\40\x28\x72\x65\x73\160\x6f\x6e\x73\x65\56\x73\x75\x63\x63\x65\x73\x73\x29\x20\x7b\xd\xa\11\x9\x9\x9\11\x9\11" . call_user_func($y0) . "\xd\12\11\11\x9\x9\x9\x9\175\x20\145\154\163\145\x20\173\15\12\11\x9\x9\11\11\x9\11\152\x51\x75\145\162\x79\50\x22\x23\x6f\x74\160\115\x65\x73\163\141\x67\x65\42\x29\56\143\x73\x73\50\x22\x64\x69\163\160\x6c\x61\171\42\54\42\x62\x6c\x6f\x63\153\x22\x29\x3b\xd\12\11\x9\11\x9\11\11\11\x6a\121\x75\x65\x72\171\50\x22\43\155\157\62\146\137\x67\141\165\x74\x68\137\151\x6e\x6c\x69\156\x65\137\x6d\145\x73\x73\141\147\145\42\x29\x2e\164\x65\170\x74\50\162\x65\x73\160\157\156\x73\145\56\x64\x61\x74\x61\x29\x3b\15\12\11\x9\x9\11\x9\11\175\15\xa\11\x9\x9\x9\11\175\15\xa\11\x9\11\11\x7d\x29\x3b\15\xa\11\11\11\175\15\12\x9\11\x9\x3c\x2f\x73\x63\162\151\160\164\76";
        return $lW;
    }
    public function mo2f_create_secret($tY = 16)
    {
        $R4 = $this->mo2f_get_base32_lookup_table();
        if (!($tY < 16 || $tY > 128)) {
            goto yz;
        }
        throw new Exception("\102\141\144\40\163\145\x63\162\x65\164\40\154\x65\x6e\147\164\150");
        yz:
        $wG = '';
        $Wz = false;
        if (!function_exists("\157\160\145\156\163\x73\x6c\x5f\x72\x61\156\144\x6f\x6d\x5f\x70\163\x65\165\x64\x6f\137\142\x79\164\x65\163")) {
            goto el;
        }
        $Wz = openssl_random_pseudo_bytes($tY, $pv);
        if ($pv) {
            goto Hl;
        }
        $Wz = false;
        Hl:
        el:
        if (false !== $Wz) {
            goto WZ;
        }
        throw new Exception("\116\157\x20\x73\x6f\x75\162\x63\x65\x20\157\x66\x20\163\x65\143\165\x72\145\x20\162\141\x6e\144\x6f\x6d");
        goto BO;
        WZ:
        $ET = 0;
        zB:
        if (!($ET < $tY)) {
            goto Mp;
        }
        $wG .= $R4[ord($Wz[$ET]) & 31];
        yg:
        ++$ET;
        goto zB;
        Mp:
        BO:
        return $wG;
    }
    public function mo2f_get_base32_lookup_table()
    {
        return array("\x41", "\x42", "\x43", "\104", "\x45", "\x46", "\107", "\x48", "\111", "\112", "\x4b", "\114", "\115", "\x4e", "\x4f", "\120", "\x51", "\x52", "\123", "\x54", "\x55", "\126", "\x57", "\x58", "\x59", "\132", "\62", "\x33", "\64", "\x35", "\x36", "\x37", "\75");
    }
    public function mo2f_geturl($wG, $G1, $fK)
    {
        $xz = "\157\164\160\141\165\x74\150\72\57\x2f\x74\x6f\x74\160\x2f";
        $xz .= $fK . "\x3f\x73\x65\143\162\145\164\x3d" . $wG . "\46\x69\x73\x73\x75\145\162\75" . $G1;
        return $xz;
    }
    public function mo2f_validate_otp($li, $Ty, $user, $P3, $post)
    {
        global $Gw, $Xw;
        $CM = isset($post["\147\x61\x5f\x73\x65\x63\x72\145\164"]) ? sanitize_text_field(wp_unslash($post["\x67\141\137\163\x65\143\162\145\x74"])) : (isset($post["\163\145\163\163\x69\x6f\x6e\137\x69\x64"]) ? MO2f_Utility::mo2f_get_transient($Ty, "\x73\145\143\x72\145\164\x5f\x67\x61") : null);
        if (MO2f_Utility::mo2f_check_number_length($li)) {
            goto K_;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::ONLY_DIGITS_ALLOWED));
        goto nAQ;
        K_:
        $fK = $Gw->get_user_detail("\x6d\x6f\62\x66\x5f\165\163\145\162\137\x65\155\141\151\x6c", $user->ID);
        $fK = empty($fK) ? $user->user_email : $fK;
        $SV = json_decode($Xw->mo2f_validate_google_auth($fK, $li, $CM), true);
        $this->mo2f_process_inline_ga_validate($SV, $user, $fK, $CM);
        nAQ:
    }
    public function mo2f_process_inline_ga_validate($SV, $user, $fK, $CM)
    {
        if (!(json_last_error() === JSON_ERROR_NONE)) {
            goto Agj;
        }
        if (!(MoWpnsConstants::SUCCESS_RESPONSE === $SV["\163\x74\x61\x74\x75\x73"])) {
            goto UmK;
        }
        $bC = $this->mo2f_update_user_details($user, $fK);
        $this->mo2f_process_update_details_response($bC, $user, $CM);
        UmK:
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_OTP));
        Agj:
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_WHILE_VALIDATING_OTP));
    }
    public function mo2f_process_update_details_response($bC, $user, $CM)
    {
        if (!(json_last_error() === JSON_ERROR_NONE)) {
            goto ZC6;
        }
        if (!(MoWpnsConstants::SUCCESS_RESPONSE === $bC["\x73\164\x61\x74\165\163"])) {
            goto kH2;
        }
        delete_user_meta($user->ID, "\155\x6f\62\x66\x5f\x32\x46\x41\137\x6d\x65\164\150\157\x64\x5f\164\x6f\x5f\143\157\x6e\x66\151\147\x75\x72\x65");
        delete_user_meta($user->ID, "\x6d\157\62\x66\x5f\143\x6f\x6e\x66\x69\x67\x75\162\145\137\62\106\x41");
        delete_user_meta($user->ID, "\x6d\157\62\146\x5f\147\157\x6f\x67\x6c\x65\137\x61\165\164\150");
        $jS = MoWpnsConstants::GOOGLE_AUTHENTICATOR;
        if (!MO2F_IS_ONPREM) {
            goto Bbu;
        }
        update_user_meta($user->ID, "\155\x6f\x32\146\137\62\106\x41\137\155\145\x74\x68\x6f\144\x5f\164\x6f\x5f\x63\x6f\x6e\146\151\x67\x75\x72\x65", $jS);
        $Ts = new Google_Auth_Onpremise();
        $Ts->mo_g_auth_set_secret($user->ID, $CM);
        Bbu:
        update_user_meta($user->ID, "\x6d\157\62\x66\137\x65\x78\164\x65\x72\x6e\141\x6c\137\141\160\x70\137\x74\171\x70\x65", $jS);
        wp_send_json_success($jS . "\x20\x68\141\163\40\142\145\145\x6e\x20\143\x6f\x6e\x66\151\x67\165\162\145\x64\x20\x73\x75\143\143\145\163\163\146\165\x6c\x6c\x79\x2e");
        kH2:
        ZC6:
    }
    public function mo2f_update_user_details($user, $fK)
    {
        global $Xw;
        delete_user_meta($user->ID, "\x6d\157\62\146\x5f\165\163\145\x72\137\x70\x72\157\x66\x69\154\x65\137\163\x65\x74");
        return json_decode($Xw->mo2f_update_user_info($user->ID, true, MoWpnsConstants::GOOGLE_AUTHENTICATOR, MoWpnsConstants::SUCCESS_RESPONSE, MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, true, $fK, null), true);
    }
    public function mo2f_prompt_2fa_login($cs, $Ty, $ok)
    {
        global $uz;
        $we = "\120\x6c\x65\x61\x73\145\x20\145\156\164\x65\162\40\x74\x68\145\x20\157\x6e\145\40\x74\x69\x6d\145\40\160\141\x73\x73\143\157\144\x65\40\163\150\157\167\156\40\151\156\40\x74\150\x65\x20\x3c\x62\76\40\101\165\164\x68\145\156\164\x69\x63\x61\164\x6f\x72\74\57\x62\x3e\40\141\x70\x70\x2e";
        $AP = "\115\117\137\62\x5f\106\101\x43\x54\x4f\122\137\103\110\x41\x4c\114\x45\x4e\x47\105\137\107\x4f\x4f\x47\114\105\x5f\x41\125\124\110\x45\116\124\x49\103\101\x54\111\x4f\116";
        MO2f_Utility::mo2f_debug_file($AP . "\x20\125\163\x65\162\137\x49\x50\55" . $uz->get_client_ip() . "\x20\125\163\145\162\x5f\x49\144\x2d" . $cs->ID . "\x20\x45\x6d\141\x69\154\x2d" . $cs->user_email);
        $this->mo2f_show_login_prompt($we, $AP, $cs, $ok, $Ty);
        exit;
    }
    public function mo2f_show_login_prompt($we, $AP, $cs, $ok, $jg)
    {
        $yV = new Mo2f_Login_Popup();
        $yV->mo2f_show_login_prompt_for_otp_based_methods($we, $AP, $cs, $ok, $jg, $this->mo2f_current_method);
        exit;
    }
    public function mo2f_login_validate($li, $ok, $Ty)
    {
        global $Xw, $Gw;
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\x6d\157\62\x66\137\143\x75\x72\x72\145\x6e\164\x5f\165\x73\145\162\x5f\151\144");
        if (!(!$v1 && is_user_logged_in())) {
            goto na0;
        }
        $v1 = wp_get_current_user()->ID;
        na0:
        $b9 = TwoFAMoSessions::get_session_var("\155\x6f\62\146\x5f\x61\164\x74\x65\x6d\x70\164\163\137\x62\145\146\x6f\162\x65\137\162\145\x64\x69\162\145\143\164");
        $user = get_user_by("\151\x64", $v1);
        $fK = $Gw->get_user_detail("\x6d\157\62\x66\x5f\x75\163\145\x72\137\145\155\141\x69\x6c", $v1);
        $hP = json_decode($Xw->validate_otp_token($this->mo2f_current_method, $fK, null, $li, $user), true);
        if (0 === strcasecmp($hP["\x73\x74\141\164\165\163"], "\x53\x55\x43\x43\x45\123\x53")) {
            goto XnD;
        }
        if ($b9 > 1 || "\144\151\x73\141\x62\154\145\x64" === $b9) {
            goto L39;
        }
        TwoFAMoSessions::unset_session("\155\157\x32\x66\x5f\141\164\x74\145\x6d\x70\164\x73\x5f\x62\x65\146\157\x72\145\x5f\162\145\144\x69\x72\x65\143\164");
        wp_send_json_error("\x4c\111\115\x49\124\137\x45\x58\x43\105\105\x44\x45\x44");
        goto TAM;
        L39:
        TwoFAMoSessions::add_session_var("\x6d\x6f\62\x66\x5f\x61\164\164\x65\155\160\x74\163\137\x62\145\x66\157\x72\145\x5f\x72\x65\144\151\x72\x65\x63\x74", $b9 - 1);
        wp_send_json_error("\x49\x4e\x56\101\x4c\111\104\x5f\x4f\124\x50");
        TAM:
        goto Xsr;
        XnD:
        TwoFAMoSessions::add_session_var("\155\x6f\x32\x66\x5f\141\x74\164\x65\x6d\160\x74\x73\137\142\145\146\157\162\x65\137\x72\x65\x64\x69\162\x65\143\x74", 3);
        wp_send_json_success("\126\101\x4c\111\104\101\x54\105\x44\137\123\125\103\x43\105\123\x53");
        Xsr:
        return $hP;
    }
}
new Mo2f_GOOGLEAUTHENTICATOR_Handler();
f2e:
