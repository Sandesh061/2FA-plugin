<?php


use TwoFA\Helper\MocURL;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Onprem\MO2f_Utility;
use TwoFA\Onprem\MO2f_Cloud_Onprem_Interface;
use TwoFA\Onprem\Miniorange_Authentication;
use TwoFA\Onprem\Miniorange_Password_2Factor_Login;
use TwoFA\Helper\MoWpnsMessages;
if (defined("\x41\x42\123\120\x41\x54\110")) {
    goto Sk3;
}
exit;
Sk3:
$s5 = isset($_POST["\x6d\x6f\x32\x66\x5f\x65\x6e\x61\142\x6c\x65\x5f\165\163\145\162\160\x72\157\x66\151\154\x65\137\62\x66\141"]) ? sanitize_key(wp_unslash($_POST["\x6d\x6f\x32\146\x5f\x65\156\x61\x62\154\145\x5f\x75\x73\x65\x72\x70\162\x6f\x66\x69\x6c\x65\x5f\62\146\141"])) : false;
if ($s5) {
    goto lyv;
}
return;
lyv:
$dk = isset($_POST["\x6d\x6f\62\x66\55\165\x70\x64\141\164\145\55\155\157\x62\151\154\x65\x2d\x6e\x6f\x6e\143\x65"]) ? sanitize_key(wp_unslash($_POST["\x6d\x6f\62\146\x2d\165\160\144\141\x74\145\x2d\x6d\157\x62\151\154\x65\55\156\157\156\143\145"])) : '';
if (!wp_verify_nonce($dk, "\155\157\x32\x66\x2d\165\160\144\141\164\145\55\155\157\142\x69\154\x65\x2d\x6e\x6f\156\x63\145") || !current_user_can("\155\141\x6e\141\147\145\x5f\x6f\x70\x74\151\x6f\156\x73")) {
    goto BTc;
}
if (isset($_POST["\x6d\145\x74\x68\157\144"])) {
    goto pux;
}
return;
goto ObF;
pux:
$la = sanitize_text_field(wp_unslash($_POST["\155\145\164\150\157\x64"]));
ObF:
global $Gw;
$fK = $Gw->get_user_detail("\155\157\62\146\x5f\165\163\145\162\x5f\x65\155\141\x69\x6c", $v1);
$fK = sanitize_email($fK);
$VN = new MocURL();
if (isset($_POST["\166\145\162\151\x66\x79\x5f\160\150\x6f\x6e\x65"])) {
    goto WJ0;
}
$T7 = null;
goto zQB;
WJ0:
$T7 = strlen($_POST["\x76\x65\x72\151\146\x79\x5f\x70\150\x6f\156\145"] > 4) ? sanitize_text_field(wp_unslash($_POST["\166\145\x72\x69\x66\171\x5f\x70\x68\157\156\x65"])) : null;
zQB:
$Q8 = new Miniorange_Password_2Factor_Login();
$cs = get_user_by("\x69\144", $v1);
if (MO2F_IS_ONPREM) {
    goto m4e;
}
$Ip = new MocURL();
$hP = json_decode($Ip->mo_create_user($cs, $fK), true);
$bC = json_decode($Ip->mo2f_update_user_info($fK, $la, $T7, null, null), true);
if (!("\123\125\103\103\x45\123\x53" !== $bC["\163\164\141\164\165\x73"])) {
    goto NP2;
}
return;
NP2:
m4e:
$qP = get_current_user_id();
$KW = $qP === $v1 ? MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS : MoWpnsConstants::MO_2_FACTOR_INITIALIZE_TWO_FACTOR;
switch ($la) {
    case MoWpnsConstants::GOOGLE_AUTHENTICATOR:
        if ($qP === $v1) {
            goto iN3;
        }
        $hP = mo2f_send_twofa_setup_link_on_email($fK, $v1, $la);
        goto yM4;
        iN3:
        if (!(isset($_POST["\155\x6f\62\146\x5f\x63\x6f\156\x66\x69\x67\x75\x72\141\x74\x69\157\x6e\x5f\163\x74\x61\164\x75\163"]) && sanitize_text_field(wp_unslash($_POST["\x6d\157\62\146\x5f\143\157\156\x66\151\x67\x75\162\141\x74\151\x6f\x6e\x5f\x73\164\141\164\165\x73"])) === "\x53\125\103\103\105\x53\123")) {
            goto u7u;
        }
        $hP = array("\163\164\x61\164\x75\163" => "\x53\125\x43\x43\x45\x53\123");
        u7u:
        yM4:
        if ("\x53\x55\x43\103\105\x53\x53" === $hP["\163\164\141\164\165\x73"]) {
            goto JDs;
        }
        update_user_meta($v1, "\x6d\x6f\62\x66\x5f\x75\163\x65\x72\x70\162\157\146\151\x6c\145\137\x65\x72\x72\157\x72\137\155\145\163\163\x61\147\x65", MoWpnsMessages::lang_translate(MoWpnsMessages::USER_PROFILE_SETUP_SMTP));
        goto FJ1;
        JDs:
        $Q8->mo2fa_update_user_details($v1, true, $la, MoWpnsConstants::SUCCESS_RESPONSE, $KW, 1, $fK);
        if (MO2F_IS_ONPREM) {
            goto Fxl;
        }
        update_user_meta($v1, "\x6d\157\62\146\x5f\145\170\x74\x65\162\156\141\154\137\141\x70\x70\x5f\164\171\160\145", MoWpnsConstants::GOOGLE_AUTHENTICATOR);
        Fxl:
        FJ1:
        goto taq;
    case MoWpnsConstants::OTP_OVER_SMS:
        if (get_site_option("\x6d\x6f\62\x66\x5f\x63\165\163\x74\x6f\x6d\145\x72\x4b\145\171")) {
            goto Dud;
        }
        update_user_meta($v1, "\x6d\157\x32\x66\x5f\x75\x73\145\x72\x70\x72\157\146\151\x6c\145\137\145\x72\x72\157\x72\137\155\x65\x73\x73\x61\x67\x65", MoWpnsMessages::lang_translate("\x50\154\145\141\163\145\x20\162\145\147\151\163\x74\145\x72\40\x77\x69\x74\x68\x20\x6d\151\x6e\x69\117\x72\x61\156\x67\x65\x20\164\x6f\x20\x73\145\164\x20\x74\x68\x65\x20\x4f\x54\x50\40\x4f\x76\x65\162\x20\x53\x4d\x53\x20\x6d\145\164\x68\x6f\144\56"));
        return;
        Dud:
        if ($qP === $v1) {
            goto Vg9;
        }
        $hP = mo2f_send_twofa_setup_link_on_email($fK, $v1, $la);
        if ("\123\x55\x43\x43\x45\x53\123" === $hP["\163\x74\141\164\x75\x73"]) {
            goto aKc;
        }
        update_user_meta($v1, "\x6d\x6f\x32\x66\x5f\165\163\x65\x72\x70\162\157\x66\151\x6c\145\x5f\x65\x72\162\157\162\137\x6d\145\163\x73\x61\x67\x65", MoWpnsMessages::lang_translate(MoWpnsMessages::USER_PROFILE_SETUP_SMTP));
        goto Tgz;
        aKc:
        $Q8->mo2fa_update_user_details($v1, true, $la, MoWpnsConstants::SUCCESS_RESPONSE, MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, 1, $fK);
        Tgz:
        goto j7d;
        Vg9:
        $Q8->mo2fa_update_user_details($v1, true, $la, MoWpnsConstants::SUCCESS_RESPONSE, MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, 1, $fK);
        j7d:
        goto taq;
    case MoWpnsConstants::SECURITY_QUESTIONS:
        if ($qP === $v1) {
            goto X0Z;
        }
        $hP = mo2f_send_twofa_setup_link_on_email($fK, $v1, $la);
        goto MnB;
        X0Z:
        $lc = new Miniorange_Authentication();
        $cE = new Mo2f_KBA_Handler();
        $MX = $cE->mo2f_get_kba_details($_POST);
        if (!(MO2f_Utility::mo2f_check_empty_or_null($MX["\153\142\141\137\x71\61"]) || MO2f_Utility::mo2f_check_empty_or_null($MX["\153\x62\141\x5f\141\x31"]) || MO2f_Utility::mo2f_check_empty_or_null($MX["\153\x62\x61\137\x71\x32"]) || MO2f_Utility::mo2f_check_empty_or_null($MX["\x6b\x62\141\x5f\x61\x32"]) || MO2f_Utility::mo2f_check_empty_or_null($MX["\153\x62\x61\x5f\161\x33"]) || MO2f_Utility::mo2f_check_empty_or_null($MX["\153\142\x61\137\x61\x33"]))) {
            goto CEx;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_ENTRY), "\105\122\x52\x4f\x52");
        return;
        CEx:
        if (!(0 === strcasecmp($MX["\x6b\142\x61\137\161\61"], $MX["\x6b\x62\x61\x5f\x71\x32"]) || 0 === strcasecmp($MX["\153\142\141\137\161\x32"], $MX["\153\x62\x61\x5f\161\x33"]) || 0 === strcasecmp($MX["\153\142\x61\x5f\161\63"], $MX["\x6b\142\141\x5f\161\x31"]))) {
            goto Kb_;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::UNIQUE_QUESTION), "\105\x52\122\117\122");
        return;
        Kb_:
        $fI = new MO2f_Cloud_Onprem_Interface();
        $hP = json_decode($fI->mo2f_register_kba_details($fK, $MX["\x6b\x62\141\137\x71\61"], $MX["\153\142\141\137\x61\x31"], $MX["\x6b\x62\x61\137\161\x32"], $MX["\153\142\141\x5f\141\62"], $MX["\153\x62\141\137\161\63"], $MX["\x6b\x62\x61\137\x61\63"], $v1), true);
        MnB:
        if (!(json_last_error() === JSON_ERROR_NONE)) {
            goto OVB;
        }
        if ("\123\x55\103\x43\x45\x53\123" === $hP["\163\x74\x61\164\x75\163"]) {
            goto eFl;
        }
        update_user_meta($v1, "\x6d\157\x32\146\x5f\x75\163\x65\x72\160\162\x6f\146\x69\154\145\x5f\x65\162\162\157\x72\137\155\x65\163\x73\x61\147\145", MoWpnsMessages::lang_translate(MoWpnsMessages::USER_PROFILE_SETUP_SMTP));
        goto mtX;
        eFl:
        $Q8->mo2fa_update_user_details($v1, true, $la, MoWpnsConstants::SUCCESS_RESPONSE, $KW, 1, $fK);
        mtX:
        OVB:
        goto taq;
    case MoWpnsConstants::OTP_OVER_EMAIL:
        $hP = mo2f_send_twofa_setup_link_on_email($fK, $v1, $la);
        if ("\123\125\103\x43\105\x53\x53" === $hP["\163\164\141\x74\x75\x73"]) {
            goto pMY;
        }
        update_user_meta($v1, "\155\x6f\62\146\137\x75\x73\145\162\160\162\x6f\x66\x69\x6c\145\x5f\x65\162\162\x6f\162\x5f\x6d\x65\x73\x73\141\147\145", MoWpnsMessages::lang_translate(MoWpnsMessages::USER_PROFILE_SETUP_SMTP));
        goto QrY;
        pMY:
        $Q8->mo2fa_update_user_details($v1, true, $la, MoWpnsConstants::SUCCESS_RESPONSE, MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, 1, $fK);
        delete_user_meta($v1, "\x6d\x6f\x32\x66\137\143\x6f\156\146\x69\147\165\x72\145\137\62\x46\101");
        delete_user_meta($v1, "\x74\145\163\x74\137\62\106\101");
        QrY:
        goto taq;
    case MoWpnsConstants::OUT_OF_BAND_EMAIL:
        $hP = mo2f_send_twofa_setup_link_on_email($fK, $v1, $la);
        if ("\x53\125\x43\x43\x45\x53\x53" === $hP["\163\x74\141\164\165\163"]) {
            goto Ir1;
        }
        update_user_meta($v1, "\x6d\157\x32\x66\x5f\165\163\145\162\x70\162\x6f\x66\151\x6c\x65\137\145\162\162\157\x72\x5f\155\x65\x73\x73\141\x67\x65", MoWpnsMessages::lang_translate(MoWpnsMessages::USER_PROFILE_SETUP_SMTP));
        goto gvK;
        Ir1:
        $Q8->mo2fa_update_user_details($v1, true, $la, MoWpnsConstants::SUCCESS_RESPONSE, MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, 1, $fK);
        gvK:
        goto taq;
}
BfY:
taq:
goto UX1;
BTc:
$s0 = new WP_Error();
$s0->add("\x65\x6d\x70\164\x79\137\x75\x73\145\162\156\x61\x6d\x65", "\x3c\163\x74\x72\x6f\156\147\x3e" . __("\x45\x52\x52\x4f\122", "\155\151\156\151\x6f\162\141\x6e\x67\145\55\62\x2d\x66\x61\143\164\157\x72\x2d\x61\165\x74\x68\145\x6e\164\151\x63\141\164\x69\157\156") . "\x3c\57\163\164\x72\x6f\x6e\x67\x3e\x3a\40" . __("\111\156\166\x61\154\151\x64\40\x52\x65\x71\x75\x65\x73\164\x2e", "\x6d\x69\x6e\x69\x6f\x72\141\156\x67\x65\x2d\x32\55\146\141\143\164\x6f\162\x2d\141\165\164\x68\x65\156\164\x69\x63\141\x74\151\x6f\x6e"));
return $s0;
UX1:
function mo2f_send_twofa_setup_link_on_email($fK, $v1, $kJ)
{
    global $Gw, $ai;
    $N7 = array(MoWpnsConstants::GOOGLE_AUTHENTICATOR => "\x63\x6f\x6e\146\151\x67\165\x72\x65\40\164\150\x65\40\x32\156\x64\40\146\x61\x63\164\157\x72", MoWpnsConstants::SECURITY_QUESTIONS => "\x63\x6f\x6e\x66\151\147\x75\x72\x65\x20\x74\150\x65\x20\x32\x6e\x64\40\146\x61\143\x74\157\x72", MoWpnsConstants::OTP_OVER_SMS => "\114\157\x67\151\156\x20\x74\157\40\x74\150\145\x20\x73\151\164\x65", MoWpnsConstants::OTP_OVER_EMAIL => "\x4c\157\x67\151\156\x20\x74\157\x20\164\150\145\40\163\x69\164\145", MoWpnsConstants::OUT_OF_BAND_EMAIL => "\x4c\157\147\x69\156\40\x74\157\x20\x74\150\x65\40\x73\x69\164\x65");
    $la = strval($kJ);
    $ii = hash("\163\x68\x61\x35\61\x32", $la);
    update_site_option($ii, $la);
    $e9 = bin2hex(openssl_random_pseudo_bytes(32));
    update_site_option($e9, get_current_user_id());
    update_user_meta($v1, "\155\x6f\62\146\137\x74\x72\141\156\x73\x61\x63\164\151\157\156\111\x64", $e9);
    update_user_meta($v1, "\x6d\157\x32\146\x5f\x75\163\145\x72\137\x70\162\x6f\x66\x69\154\145\137\x73\x65\164", true);
    $a3 = "\x32\x46\101\55\x43\x6f\156\146\x69\147\165\162\141\164\x69\157\156";
    $Tp = array("\103\x6f\156\x74\145\156\164\55\124\171\x70\x65\72\40\x74\x65\170\164\x2f\x68\x74\x6d\x6c\73\x20\143\x68\141\x72\x73\x65\x74\75\125\124\x46\55\70");
    $z_ = plugins_url(DIRECTORY_SEPARATOR . "\166\x69\x65\x77\163" . DIRECTORY_SEPARATOR . "\161\x72\x5f\157\x76\x65\162\x5f\x65\155\141\151\154\x2e\x70\x68\x70", dirname(__FILE__)) . "\x3f\145\155\141\x69\154\75" . $fK . "\46\x61\155\x70\73\x75\163\x65\x72\x5f\151\x64\75" . $v1;
    $xz = get_site_option("\163\x69\x74\x65\165\x72\x6c") . "\57\x77\x70\x2d\154\x6f\147\x69\x6e\x2e\x70\x68\x70\77";
    $z_ = $xz . "\x26\x61\155\160\x3b\162\145\x63\157\156\146\x69\147\165\162\x65\x4d\145\x74\150\x6f\x64\75" . $ii . "\x26\141\155\x70\x3b\x74\162\x61\156\x73\141\x63\x74\151\157\x6e\111\144\75" . $e9;
    $jD = "\15\12\40\x20\40\x20\x3c\164\x61\142\x6c\x65\x3e\15\xa\x20\x20\40\40\x3c\x74\x62\x6f\x64\171\76\15\xa\x20\x20\x20\40\x3c\x74\x72\x3e\15\xa\40\40\40\40\x3c\164\x64\76\xd\xa\x20\x20\40\x20\74\164\141\142\154\x65\40\143\145\154\154\x70\141\144\144\x69\156\147\75\42\x32\64\42\x20\167\151\144\x74\150\x3d\42\65\x38\64\x70\x78\x22\40\x73\164\x79\x6c\145\75\42\x6d\141\162\x67\x69\x6e\72\x30\40\141\165\x74\157\73\x6d\141\170\55\x77\x69\144\x74\x68\72\65\70\64\x70\x78\73\142\x61\143\153\147\x72\x6f\165\156\x64\x2d\x63\x6f\x6c\157\x72\72\43\146\66\x66\x34\146\x34\x3b\142\x6f\162\144\145\x72\x3a\x31\x70\x78\40\x73\157\x6c\151\144\x20\x23\141\x38\141\x64\x61\x64\x22\76\xd\xa\40\40\40\40\x3c\x74\142\x6f\x64\171\x3e\15\xa\x20\40\40\40\74\x74\162\x3e\xd\xa\40\40\40\40\x3c\164\144\76\x3c\151\x6d\147\x20\x73\162\143\x3d\x22" . $ai . "\x69\x6e\x63\x6c\165\x64\145\x73\57\x69\155\141\147\145\163\x2f\x78\x65\143\x75\162\x69\146\171\55\x6c\157\147\157\x2e\160\156\x67\x22\40\141\154\x74\x3d\x22\x58\x65\x63\165\162\151\146\x79\42\x20\163\164\171\x6c\145\75\42\143\x6f\x6c\157\162\72\43\x35\146\x62\x33\63\66\x3b\164\x65\x78\164\55\144\145\x63\157\162\141\164\x69\x6f\156\72\156\157\156\x65\x3b\x64\x69\x73\x70\154\141\171\x3a\x62\154\x6f\x63\153\73\167\151\144\164\x68\x3a\141\165\164\x6f\x3b\x68\145\151\x67\x68\164\x3a\x61\x75\164\157\73\x6d\x61\170\55\x68\145\x69\x67\150\164\x3a\x33\65\x70\170\42\40\143\154\141\163\163\x3d\42\103\x54\157\127\x55\144\42\76\74\57\164\144\76\xd\12\x20\40\40\x20\74\x2f\x74\x72\76\15\12\40\x20\x20\x20\x3c\x2f\x74\142\x6f\144\171\x3e\15\12\x20\x20\x20\x20\x3c\57\164\x61\x62\154\145\76\xd\xa\40\x20\40\40\x3c\164\141\142\x6c\145\x20\x63\x65\154\154\160\x61\x64\x64\151\x6e\147\x3d\42\62\64\x22\x20\x73\x74\x79\x6c\145\75\42\142\141\x63\153\x67\162\157\165\156\x64\x3a\43\x66\x66\146\73\x62\157\x72\144\145\x72\72\61\x70\x78\40\163\x6f\154\151\144\40\x23\141\x38\141\x64\141\x64\x3b\x77\x69\144\x74\150\x3a\x35\x38\x34\x70\x78\x3b\x62\157\162\144\x65\162\x2d\x74\157\160\x3a\156\x6f\x6e\145\x3b\143\x6f\154\x6f\162\x3a\x23\64\x64\x34\x62\64\x38\73\146\x6f\156\164\x2d\x66\x61\155\x69\x6c\x79\x3a\x41\x72\x69\x61\154\x2c\110\x65\154\x76\x65\164\x69\143\141\x2c\163\x61\x6e\163\55\163\145\x72\151\x66\73\146\x6f\x6e\x74\x2d\x73\151\x7a\x65\72\x31\63\160\x78\73\154\151\156\145\55\150\x65\x69\x67\150\164\72\61\x38\160\170\42\76\xd\12\x20\x20\x20\40\x3c\x74\x62\x6f\144\x79\x3e\xd\12\x20\40\x20\x20\74\164\x72\76\xd\xa\40\40\40\x20\x3c\x74\144\76\15\12\x20\40\40\40\74\x69\x6e\x70\x75\x74\40\164\x79\x70\x65\75\x22\x68\151\144\144\145\x6e\x22\40\x6e\141\155\x65\x3d\42\165\x73\x65\162\137\151\144\x22\x20\151\144\75\42\165\x73\x65\162\137\x69\144\42\40\166\x61\x6c\165\145\x3d\42" . esc_attr($v1) . "\x22\76\xd\12\x20\x20\40\x20\x3c\151\156\x70\x75\x74\40\x74\x79\160\145\75\42\150\x69\144\144\x65\156\42\x20\156\x61\155\145\x3d\x22\145\x6d\x61\151\154\42\x20\x69\x64\75\42\145\x6d\x61\x69\154\42\x20\166\x61\154\165\x65\x3d\42" . esc_attr($fK) . "\x22\x3e\15\12\x20\x20\x20\x20\x3c\160\40\163\x74\171\154\x65\75\42\155\x61\162\147\x69\156\x2d\164\x6f\x70\72\x30\73\x6d\141\162\x67\x69\156\55\x62\x6f\164\x74\157\x6d\x3a\62\60\x70\x78\x22\76\x44\145\141\x72\x20" . get_user_by("\151\x64", $v1)->user_login . "\54\x3c\x2f\160\x3e\15\xa\x20\40\40\40\x3c\x70\x20\x73\164\171\x6c\x65\x3d\42\155\141\x72\147\151\x6e\x2d\x74\x6f\160\72\x30\x3b\155\x61\x72\147\x69\156\55\142\x6f\164\164\157\155\72\x31\x30\160\x78\42\76\x59\x6f\x75\162\x20\x32\106\x41\40\x6d\145\164\150\x6f\144\x20\x28" . esc_attr(MoWpnsConstants::mo2f_convert_method_name($kJ, "\143\141\160\x5f\x74\157\x5f\163\x6d\x61\154\154")) . "\x29\40\x68\x61\163\40\142\x65\145\156\x20\x73\x65\x74\40\x62\171\x20\x73\x69\164\145\40\x61\144\155\x69\156\x2e\x3c\x2f\x70\76\15\xa\40\x20\x20\40\x3c\160\76\x3c\x61\x20\150\x72\x65\x66\75\x22" . esc_url($z_) . "\x22\x20\76\40\x43\154\x69\143\x6b\40\164\x6f\40" . $N7[$kJ] . "\x3c\x2f\141\76\74\x2f\160\x3e\xd\12\40\40\x20\40\74\x70\40\163\164\171\x6c\145\x3d\42\x6d\x61\x72\147\x69\x6e\x2d\164\157\160\x3a\60\73\155\141\162\147\151\156\x2d\x62\157\164\x74\157\155\x3a\61\65\160\x78\x22\76\x54\150\141\x6e\x6b\x20\171\157\165\x2c\x3c\x62\x72\x3e\155\x69\x6e\x69\117\x72\x61\156\147\145\40\x54\145\141\155\74\x2f\160\x3e\xd\xa\40\40\40\x20\x3c\160\x20\x73\164\x79\154\x65\75\42\x6d\x61\162\147\151\x6e\55\x74\157\x70\72\60\73\155\x61\x72\x67\151\156\x2d\142\157\x74\x74\x6f\x6d\72\x30\160\x78\73\x66\x6f\x6e\x74\55\163\151\172\x65\x3a\x31\61\160\170\x22\76\104\x69\x73\x63\x6c\x61\151\155\145\162\x3a\x20\124\150\x69\163\40\145\x6d\141\151\x6c\x20\141\x6e\x64\40\x61\x6e\x79\x20\x66\x69\x6c\145\x73\x20\x74\162\141\156\x73\155\x69\x74\164\x65\144\x20\167\151\164\x68\x20\151\164\x20\x61\162\145\x20\143\157\x6e\146\151\x64\x65\156\x74\x69\141\x6c\40\141\x6e\144\x20\151\x6e\164\x65\156\144\145\144\40\x73\157\x6c\145\x6c\x79\40\x66\157\x72\x20\x74\x68\145\x20\x75\163\145\x20\157\x66\40\164\150\145\x20\151\x6e\x64\x69\166\151\144\x75\141\x6c\x20\x6f\x72\40\x65\x6e\164\151\164\x79\x20\x74\157\40\x77\x68\157\155\40\x74\x68\x65\x79\x20\141\x72\x65\40\x61\x64\x64\x72\x65\x73\163\145\144\x2e\74\x2f\x70\x3e\15\xa\40\x20\x20\40\74\x2f\x64\x69\166\76\74\x2f\x64\151\x76\x3e\x3c\x2f\x74\x64\x3e\15\xa\x20\x20\x20\40\74\57\164\x72\76\xd\xa\x20\x20\40\x20\x3c\x2f\x74\142\x6f\144\171\x3e\15\12\x20\40\x20\40\74\x2f\164\141\x62\x6c\145\76\xd\12\x20\x20\40\x20\74\57\164\144\x3e\15\xa\40\40\40\x20\x3c\x2f\164\x72\76\xd\12\40\40\40\x20\74\x2f\x74\142\157\x64\171\76\xd\xa\x20\40\40\x20\74\x2f\164\x61\142\x6c\x65\x3e";
    $vv = wp_mail($fK, $a3, $jD, $Tp);
    if ($vv) {
        goto Joj;
    }
    $g4 = array("\163\x74\x61\164\x75\163" => "\106\x41\111\x4c\x45\x44", "\x6d\x65\x73\163\141\147\145" => "\x54\x45\x53\x54\40\106\101\111\114\105\104\x2e");
    goto a6i;
    Joj:
    $g4 = array("\x73\164\x61\x74\165\x73" => "\123\125\x43\103\x45\x53\123", "\155\x65\x73\163\x61\x67\145" => "\x53\165\x63\143\x65\163\163\146\x75\154\154\171\40\166\141\x6c\x69\x64\x61\164\145\x64\56", "\164\170\151\x64" => '');
    $Gw->update_user_details($v1, array("\x6d\157\62\146\137\101\165\164\x68\x79\x41\x75\164\x68\x65\x6e\x74\151\143\x61\x74\x6f\162\x5f\x63\157\156\x66\x69\147\137\163\164\141\x74\x75\163" => false, "\155\157\62\x66\137\x45\155\x61\151\154\x56\x65\x72\151\x66\151\x63\x61\164\x69\157\x6e\x5f\x63\157\156\x66\151\147\137\163\x74\x61\x74\x75\163" => false, "\x6d\x6f\62\146\x5f\123\145\143\x75\x72\x69\164\x79\121\x75\x65\x73\x74\151\x6f\x6e\163\x5f\143\x6f\156\x66\x69\147\x5f\x73\164\x61\164\165\x73" => false, "\155\x6f\x32\146\137\107\x6f\x6f\147\x6c\x65\101\165\164\x68\x65\x6e\x74\151\x63\x61\x74\x6f\x72\x5f\x63\x6f\156\146\151\147\x5f\x73\164\x61\x74\x75\x73" => false, "\155\157\x32\x66\x5f\x4f\x54\120\x4f\x76\x65\x72\x54\145\x6c\x65\147\162\141\155\137\x63\157\156\x66\151\x67\x5f\x73\164\141\164\165\163" => false, "\x6d\157\x32\x66\137\117\124\x50\117\x76\x65\162\x53\115\123\137\143\157\x6e\146\151\x67\x5f\163\164\141\164\165\x73" => false, "\155\157\x32\x66\137\117\124\120\117\166\145\x72\105\155\x61\x69\154\137\143\157\x6e\x66\151\147\137\x73\164\141\x74\165\163" => false));
    a6i:
    return $g4;
}
