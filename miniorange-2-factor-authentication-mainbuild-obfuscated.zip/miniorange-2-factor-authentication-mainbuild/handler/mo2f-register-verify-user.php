<?php


if (defined("\x41\102\x53\120\101\x54\x48")) {
    goto qQ;
}
exit;
qQ:
use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Helper\MocURL;
require_once dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . "\x68\x65\154\160\145\162" . DIRECTORY_SEPARATOR . "\155\x6f\x32\146\x2d\x72\145\147\x69\x73\164\145\162\55\166\145\162\x69\x66\x79\55\x75\x73\145\x72\x2e\160\150\x70";
global $uz, $V0, $Gw;
$dk = isset($_POST["\x6d\157\62\x66\x5f\x67\x65\x6e\145\x72\141\154\137\x6e\157\x6e\x63\145"]) ? sanitize_key(wp_unslash($_POST["\155\x6f\x32\x66\x5f\x67\x65\x6e\145\162\141\x6c\137\x6e\157\x6e\143\145"])) : '';
if (!wp_verify_nonce($dk, "\x6d\x69\x6e\151\x4f\162\141\x6e\x67\145\x5f\x32\146\141\x5f\156\157\156\143\145")) {
    goto mp;
}
if (!isset($_POST["\x6f\x70\x74\x69\157\x6e"])) {
    goto s_;
}
$Xh = trim(isset($_POST["\157\160\164\x69\157\156"]) ? sanitize_text_field(wp_unslash($_POST["\157\x70\164\x69\x6f\x6e"])) : null);
switch ($Xh) {
    case "\x6d\157\137\x77\160\156\163\x5f\162\145\147\x69\163\164\145\162\x5f\x63\x75\163\164\x6f\155\x65\162":
        mo2fa_register_customer($_POST);
        goto tx;
    case "\x6d\x6f\137\167\x70\x6e\163\x5f\166\x65\x72\151\x66\x79\x5f\x63\165\x73\164\157\x6d\x65\x72":
        mo2fa_verify_customer($_POST);
        goto tx;
    case "\x6d\157\137\167\x70\x6e\x73\x5f\143\x61\156\x63\145\x6c":
        mo2f_revert_back_registration();
        goto tx;
    case "\155\x6f\137\x77\160\156\x73\x5f\162\x65\x73\145\x74\x5f\160\x61\163\x73\167\157\162\144":
        mo2f_reset_password();
        goto tx;
    case "\x6d\x6f\62\x66\137\x67\x6f\x74\157\137\x76\145\162\x69\x66\171\x63\x75\163\164\157\155\145\162":
        mo2f_goto_sign_in_page();
        goto tx;
}
OL:
tx:
s_:
mp:
function mo2fa_register_customer($post)
{
    global $Gw;
    $user = wp_get_current_user();
    $fK = sanitize_email($post["\x65\155\x61\151\x6c"]);
    $ke = isset($_SERVER["\123\x45\122\x56\x45\122\137\116\101\115\105"]) ? esc_url_raw(wp_unslash($_SERVER["\123\105\122\126\105\122\137\x4e\101\115\x45"])) : null;
    $pd = new MoWpnsMessages();
    $uk = $post["\x70\141\x73\163\167\x6f\x72\x64"];
    $mJ = $post["\x63\157\x6e\x66\151\162\x6d\120\x61\163\163\x77\x6f\162\144"];
    if (!(strlen($uk) < 6 || strlen($mJ) < 6)) {
        goto C2;
    }
    $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::PASS_LENGTH), "\x45\x52\122\117\x52");
    return;
    C2:
    if (!($uk !== $mJ)) {
        goto lJ;
    }
    $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::PASS_MISMATCH), "\105\x52\122\117\122");
    return;
    lJ:
    if (!(MoWpnsUtility::check_empty_or_null($fK) || MoWpnsUtility::check_empty_or_null($uk) || MoWpnsUtility::check_empty_or_null($mJ))) {
        goto ZF;
    }
    $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::REQUIRED_FIELDS), "\105\122\122\x4f\122");
    return;
    ZF:
    update_option("\155\157\x32\146\137\x65\x6d\141\x69\x6c", $fK);
    update_option("\x6d\157\137\x77\160\x6e\x73\x5f\143\x6f\155\160\x61\156\x79", $ke);
    update_option("\155\x6f\x5f\167\160\156\x73\137\160\x61\x73\163\167\157\162\144", $uk);
    $uU = new MocURL();
    $hP = json_decode($uU->check_customer($fK), true);
    $Gw->insert_user($user->ID);
    switch ($hP["\x73\x74\141\164\165\x73"]) {
        case "\x43\125\x53\124\x4f\115\x45\122\x5f\116\117\x54\x5f\x46\117\x55\x4e\104":
            $hS = json_decode($uU->create_customer($fK, $ke, $uk), true);
            $Oc = isset($hS["\155\x65\163\x73\x61\147\x65"]) ? $hS["\x6d\145\163\x73\141\147\x65"] : __("\105\x72\162\157\x72\40\x6f\143\x63\x75\162\x65\144\40\x77\150\151\154\x65\x20\143\x72\x65\141\x74\x69\156\147\40\141\156\x20\141\x63\143\x6f\165\x6e\x74\56", "\155\x69\x6e\151\157\x72\141\156\x67\145\55\62\x2d\146\141\143\164\x6f\x72\55\141\x75\x74\150\x65\156\x74\x69\x63\141\x74\151\157\156");
            if (strcasecmp($hS["\163\164\141\x74\x75\163"], "\x53\x55\103\x43\105\123\x53") === 0) {
                goto t0;
            }
            $pd->mo2f_show_message(MoWpnsMessages::lang_translate($Oc), "\x45\x52\122\x4f\122");
            return;
            goto oJ;
            t0:
            update_site_option(base64_encode("\x74\x6f\x74\x61\154\125\163\x65\x72\x73\103\x6c\157\165\x64"), get_site_option(base64_encode("\x74\157\164\x61\x6c\x55\163\x65\x72\x73\103\x6c\157\165\x64")) + 1);
            update_option("\155\157\62\146\x5f\x65\x6d\x61\151\x6c", $fK);
            $L4 = isset($hS["\151\x64"]) ? $hS["\151\144"] : '';
            $Yl = isset($hS["\x61\x70\151\x4b\x65\171"]) ? $hS["\x61\160\151\x4b\x65\171"] : '';
            $CS = isset($hS["\164\157\x6b\x65\x6e"]) ? $hS["\x74\157\153\x65\156"] : '';
            $iX = isset($hS["\141\x70\x70\x53\145\x63\x72\x65\164"]) ? $hS["\141\x70\160\123\145\143\x72\x65\x74"] : '';
            mo2fa_save_success_customer_config($fK, $L4, $Yl, $CS, $iX);
            mo2fa_get_current_customer($fK, $uk);
            $pd->mo2f_show_message(MoWpnsMessages::lang_translate($Oc), "\x53\x55\x43\103\105\x53\123");
            return;
            oJ:
            goto Ph;
        case "\123\125\103\x43\x45\123\123":
            update_option("\x6d\x6f\x5f\x32\x66\x61\x63\164\157\x72\x5f\141\144\155\151\x6e\137\162\x65\x67\151\163\x74\x72\141\164\x69\157\156\x5f\163\164\x61\x74\x75\x73", "\115\117\137\x32\137\106\x41\x43\124\117\122\137\126\105\x52\x49\x46\131\x5f\x43\x55\123\124\x4f\x4d\105\x52");
            update_option("\155\157\x5f\x77\x70\156\163\137\166\x65\162\x69\146\171\x5f\x63\x75\163\x74\x6f\155\x65\162", "\x74\x72\x75\x65");
            delete_option("\155\x6f\x5f\167\160\x6e\x73\x5f\x6e\x65\167\x5f\162\145\147\151\163\164\x72\x61\x74\x69\157\x6e");
            $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ACCOUNT_EXISTS), "\x45\122\x52\117\x52");
            return;
        case "\105\122\122\x4f\x52":
            $pd->mo2f_show_message(__($hP["\155\x65\163\163\141\147\x65"], "\x6d\x69\x6e\x69\157\162\141\x6e\x67\145\55\62\x2d\x66\x61\x63\164\x6f\162\55\141\165\x74\x68\x65\x6e\x74\x69\143\x61\164\151\157\156"), "\x45\122\122\x4f\x52");
            return;
        default:
            mo2fa_get_current_customer($fK, $uk);
            return;
    }
    Kt:
    Ph:
    $jD = __("\x45\162\x72\157\162\x20\x4f\x63\143\165\162\145\144\40\167\150\x69\x6c\x65\40\162\x65\147\x69\x73\164\162\x61\x74\151\157\156", "\155\x69\x6e\151\157\x72\141\x6e\147\x65\55\62\x2d\x66\141\143\164\157\162\55\141\165\164\150\145\x6e\164\151\x63\141\164\151\157\x6e");
    $pd->mo2f_show_message(MoWpnsMessages::lang_translate($jD), "\x45\x52\x52\x4f\122");
}
function mo2fa_verify_customer($post)
{
    global $uz;
    $fK = sanitize_email($post["\x65\x6d\141\x69\x6c"]);
    $uk = $post["\x70\141\x73\163\x77\157\162\144"];
    $pd = new MoWpnsMessages();
    if (!($uz->check_empty_or_null($fK) || $uz->check_empty_or_null($uk))) {
        goto ah;
    }
    $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::REQUIRED_FIELDS), "\105\122\122\x4f\122");
    return;
    ah:
    mo2fa_get_current_customer($fK, $uk);
}
function mo2f_revert_back_registration()
{
    delete_option("\x6d\157\x32\146\137\x65\x6d\141\151\x6c");
    delete_option("\155\157\137\x77\x70\x6e\x73\x5f\162\145\147\151\163\x74\162\141\x74\x69\x6f\x6e\137\x73\x74\x61\x74\x75\x73");
    delete_option("\x6d\157\137\x77\160\156\163\137\x76\145\x72\x69\146\x79\137\x63\165\163\x74\x6f\155\145\162");
    update_option("\155\157\137\62\146\141\143\x74\157\162\137\x61\144\155\151\156\137\162\145\147\151\163\164\x72\141\164\x69\x6f\x6e\137\163\164\x61\x74\165\x73", '');
}
function mo2f_reset_password()
{
    $uU = new MocURL();
    $pd = new MoWpnsMessages();
    $r5 = json_decode($uU->mo_wpns_forgot_password());
    if (!("\123\x55\x43\103\105\123\x53" === $r5->status)) {
        goto qn;
    }
    $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::RESET_PASS), "\123\125\103\x43\x45\x53\123");
    qn:
}
function mo2f_goto_sign_in_page()
{
    update_option("\x6d\x6f\137\x77\x70\x6e\163\137\166\145\162\151\x66\171\x5f\143\x75\x73\164\x6f\155\145\x72", "\x74\162\x75\145");
    update_option("\155\x6f\137\x32\146\x61\x63\x74\x6f\x72\x5f\x61\x64\x6d\x69\x6e\137\162\x65\x67\x69\163\x74\x72\x61\x74\151\157\156\x5f\x73\x74\141\x74\x75\163", "\x4d\117\x5f\x32\x5f\x46\x41\103\124\117\x52\137\x56\105\122\111\106\131\x5f\x43\125\x53\x54\x4f\x4d\105\122");
}
