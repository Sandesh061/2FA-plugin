<?php


if (defined("\101\x42\123\x50\x41\x54\x48")) {
    goto xP;
}
exit;
xP:
use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Helper\TwoFAMoSessions;
use TwoFA\Helper\Mo2f_Common_Helper;
use TwoFA\Onprem\Mo2f_Main_Handler;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Onprem\MO2f_Utility;
if (class_exists("\x4d\x6f\62\146\137\102\x61\163\151\x63\137\120\x72\145\x6d\x69\165\155\x5f\x53\x65\x74\x74\x69\156\147\163")) {
    goto ke;
}
class Mo2f_Basic_Premium_Settings
{
    private $show_message;
    public function __construct()
    {
        add_action("\x6d\x6f\x32\146\137\142\141\163\x69\x63\x5f\x70\154\x61\x6e\x5f\163\x65\164\x74\151\x6e\147\x73\137\x61\x63\x74\x69\157\156", array($this, "\x6d\x6f\62\146\x5f\x68\141\156\x64\154\145\x5f\141\x63\164\151\157\x6e\137\142\141\x73\151\143\137\x70\154\x61\156\137\x73\x65\x74\164\x69\156\x67\163"), 10, 2);
        add_filter("\x6d\x6f\62\x66\137\x62\141\x73\x69\x63\x5f\x70\x6c\141\x6e\x5f\x73\145\164\164\x69\156\147\x73\x5f\146\x69\154\x74\145\162", array($this, "\x6d\157\62\x66\137\150\x61\156\144\154\145\137\146\151\154\164\x65\162\x5f\x62\141\x73\151\x63\137\160\154\141\156\137\163\x65\x74\x74\x69\156\147\x73"), 10, 3);
        add_filter("\142\165\x6c\x6b\x5f\141\143\x74\151\157\156\x73\55\x75\163\x65\x72\x73", array($this, "\x6d\x6f\62\146\x5f\x61\x64\x64\137\x32\x66\141\137\142\165\x6c\153\137\x61\143\164\x69\x6f\156\163"));
        add_filter("\150\x61\x6e\x64\x6c\145\x5f\142\165\x6c\153\x5f\141\x63\164\151\x6f\x6e\x73\x2d\165\x73\145\162\163", array($this, "\x6d\x6f\x32\x66\x5f\x68\x61\x6e\144\154\145\x5f\x62\165\x6c\x6b\137\141\143\x74\151\x6f\x6e\x73"), 10, 3);
        add_filter("\155\141\x6e\141\x67\x65\137\165\x73\145\x72\x73\x5f\143\157\154\x75\x6d\156\x73", array($this, "\x6d\157\62\146\x5f\155\x61\x70\160\145\144\x5f\x32\146\x61\137\143\157\x6c\165\x6d\156\x73"));
        add_action("\155\141\156\141\147\145\x5f\165\x73\145\x72\163\x5f\143\x75\x73\x74\x6f\x6d\x5f\143\x6f\x6c\x75\155\156", array($this, "\x6d\157\x32\146\x5f\155\141\x70\x70\145\144\x5f\x32\146\141\x5f\143\157\x6c\x75\x6d\x6e\163\137\x63\x6f\x6e\164\145\156\164"), 10, 3);
        add_action("\x72\145\147\x69\163\164\x65\162\x5f\146\x6f\x72\155", array($this, "\155\157\62\x66\137\x69\156\x73\x65\x72\x74\x5f\x73\x68\157\162\164\143\157\144\145\137\x69\156\x5f\x72\x65\x67\151\x73\x74\162\141\x74\x69\157\x6e\x5f\x66\157\162\155"));
    }
    public function mo2f_handle_filter_basic_plan_settings($F6, $D4, $post)
    {
        switch ($D4) {
            case "\x69\163\137\x74\x77\157\x66\x61\137\145\156\141\x62\x6c\145\144":
                return $this->mo2f_check_if_twofa_is_enabled($F6, $post);
            case "\x67\x65\164\x5f\x62\x61\143\x6b\165\x70\x5f\x6d\x65\164\150\x6f\144\x73":
                return $this->mo2f_get_backup_methods($F6, $post);
            case "\x67\145\156\x65\x72\x61\x74\x65\137\x62\141\143\153\x75\160\x5f\x63\x6f\144\x65\x73":
                return $this->mo2f_get_backup_codes($F6, $post);
            case "\x66\x65\164\x63\150\x5f\x74\x77\157\x66\x61\137\155\145\x74\150\x6f\144\x73":
                return $this->mo2f_fetch_methods($F6, $post);
        }
        Yi:
        pB:
    }
    public function mo2f_fetch_methods($qu, $post)
    {
        $DX = get_site_option("\x6d\x6f\62\146\x5f\x73\x65\x6c\x65\x63\x74\x5f\155\145\164\x68\x6f\x64\x73\137\x66\x6f\162\x5f\165\163\145\x72\163");
        $cB = new Mo2f_Common_Helper();
        if ($DX) {
            goto s9;
        }
        return $cB->fetch_methods($post["\165\163\x65\x72"]);
        goto O1;
        s9:
        $TU = get_site_option("\155\x6f\x32\146\x5f\x61\154\154\137\x75\163\145\162\163\x5f\x6d\145\164\150\x6f\144");
        if ($TU) {
            goto bg;
        }
        return (array) get_site_option("\155\157\x32\x66\x5f\x61\x75\x74\x68\137\x6d\x65\x74\150\x6f\144\163\137\x66\157\x72\x5f\165\x73\145\162\x73");
        goto kN;
        bg:
        $F9 = $post["\165\x73\x65\162"]->roles[0];
        $VQ = get_site_option("\x6d\157\x32\146\137\x61\x75\164\x68\137\x6d\x65\164\x68\x6f\x64\x73\x5f\146\x6f\162\x5f" . $F9);
        return !empty($VQ) && in_array($F9, get_site_option("\x6d\157\x32\146\x5f\141\165\x74\150\x5f\155\145\164\x68\x6f\x64\163\137\162\x6f\x6c\145\163"), true) ? $VQ : $cB->fetch_methods($post["\165\163\145\162"]);
        kN:
        O1:
    }
    public function mo2f_handle_action_basic_plan_settings($wD, $post)
    {
        switch ($wD) {
            case "\x73\150\x6f\167\137\153\142\x61\x5f\162\145\x67\x69\x73\x74\x72\141\164\x69\157\x6e\x5f\x66\x6f\162\x6d":
                $this->mo2f_call_kba_inline_prompt($post);
                goto Cj;
            case "\150\x61\156\144\x6c\x65\x5f\142\x61\143\153\x75\x70\143\157\x64\x65\x5f\x76\x61\x6c\151\144\141\164\151\x6f\156":
                $this->mo2f_handle_backupcode_validation($post);
                goto Cj;
            case "\163\141\166\145\x5f\x73\x65\154\145\x63\x74\145\x64\x5f\x32\146\141\x5f\155\145\164\150\x6f\144\163":
                $this->mo2f_save_selected_2fa_methods($post);
                goto Cj;
            case "\x6d\x6f\62\x66\x5f\x73\x61\166\x65\x5f\143\x75\x73\164\x6f\155\137\x72\x65\x67\151\x73\164\x72\x61\x74\x69\x6f\156\x5f\146\x6f\x72\x6d\137\x73\145\164\164\x69\x6e\x67\x73":
                $this->mo2f_save_custom_registration_form_settings($post);
                goto Cj;
            case "\155\157\62\x66\137\x65\x6e\x61\142\154\x65\x5f\143\165\x73\x74\157\x6d\137\162\145\x67\x69\163\x74\162\x61\164\151\157\x6e\137\146\x6f\162\155\137\163\150\157\x72\x74\x63\157\x64\x65\x73":
                $this->mo2f_enable_custom_registration_form_shortcodes($post);
                goto Cj;
        }
        Ui:
        Cj:
    }
    public function mo2f_call_kba_inline_prompt($post)
    {
        $sF = new Mo2f_KBA_Handler();
        TwoFAMoSessions::add_session_var("\155\x6f\62\x66\137\151\x73\x5f\x6b\142\141\x5f\142\141\143\153\x75\160\137\x63\157\x6e\146\151\147\x75\x72\145\x64" . $post["\x75\x73\145\162\x5f\x69\144"], true);
        $sF->mo2f_prompt_2fa_setup_inline($post["\x73\x65\163\x73\151\x6f\x6e\x5f\x69\x64"], $post["\162\145\144\151\x72\x65\x63\164\x5f\x74\x6f"], $post["\x75\x73\145\x72\x5f\x69\144"], '');
        exit;
    }
    public function mo2f_handle_backupcode_validation($post)
    {
        global $Gw;
        $v1 = isset($post["\165\163\145\162\137\151\x64"]) ? $post["\165\x73\145\162\x5f\x69\144"] : null;
        $h8 = isset($post["\x62\141\x63\x6b\165\160\137\143\x6f\144\145"]) ? $post["\x62\x61\143\153\165\160\137\x63\157\x64\x65"] : null;
        $ou = get_user_meta($v1, "\x6d\x6f\62\x66\137\142\141\x63\153\165\x70\x5f\x63\157\x64\x65\163", true);
        if (empty($ou)) {
            goto id;
        }
        $h8 = md5($h8);
        if (in_array($h8, $ou, true)) {
            goto NS;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_BACKUPCODE));
        goto o3;
        NS:
        foreach ($ou as $t8 => $iY) {
            if (!($iY === $h8)) {
                goto mf;
            }
            unset($ou[$t8]);
            update_user_meta($v1, "\155\157\x32\146\137\142\x61\143\153\165\160\137\x63\157\x64\x65\x73", $ou);
            $Gw->delete_user_details($v1);
            wp_send_json_success(MoWpnsMessages::lang_translate(MoWpnsMessages::BACKUPCODE_VALIDATED));
            mf:
            vg:
        }
        r9:
        o3:
        id:
    }
    public function mo2f_save_selected_2fa_methods($post)
    {
        $mG = isset($post["\163\145\154\x65\143\164\137\155\x65\164\150\x6f\x64\x73"]) ? "\164\162\165\145" === sanitize_text_field(wp_unslash($post["\x73\145\154\x65\143\164\x5f\155\145\164\150\157\x64\x73"])) : null;
        $hT = isset($post["\163\x65\154\x65\x63\x74\x69\157\x6e\x5f\164\171\160\x65"]) ? sanitize_text_field(wp_unslash($post["\163\145\x6c\145\143\x74\151\x6f\x6e\x5f\x74\171\160\x65"])) : 0;
        update_site_option("\x6d\x6f\x32\x66\137\x73\x65\x6c\145\x63\164\x5f\155\145\x74\x68\x6f\144\x73\137\146\x6f\x72\x5f\x75\163\145\162\x73", $mG);
        update_site_option("\x6d\x6f\62\x66\137\x61\x6c\154\137\x75\163\x65\162\x73\137\x6d\x65\164\150\157\144", $hT);
        if ($hT) {
            goto In;
        }
        $pQ = isset($post["\x74\167\x6f\x66\x61\x5f\x6d\x65\x74\x68\x6f\x64\163"]) ? $post["\x74\167\157\x66\x61\x5f\x6d\145\164\x68\x6f\144\x73"] : array();
        if (!empty($pQ)) {
            goto zR;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::SELECT_ANY_AUTHENTICATION_METHOD));
        zR:
        foreach ($pQ as $yt) {
            if (in_array($yt, $pQ, true)) {
                goto Qg;
            }
            array_push($pQ, $yt);
            Qg:
            N3:
        }
        bx:
        update_site_option("\x6d\157\62\x66\137\x61\165\164\x68\x5f\155\x65\164\x68\x6f\x64\163\137\x66\x6f\162\137\165\x73\x65\x72\x73", $pQ);
        goto yM;
        In:
        $i2 = isset($post["\165\163\145\162\137\162\x6f\x6c\145\163"]) ? $post["\165\163\145\x72\x5f\162\x6f\154\x65\163"] : array();
        $g_ = array();
        foreach ($i2 as $gO => $LX) {
            update_site_option("\155\157\62\146\x5f\141\165\164\x68\x5f\x6d\145\x74\150\x6f\x64\x73\x5f\146\157\x72\137" . $gO, $LX);
            array_push($g_, $gO);
            u0:
        }
        vM:
        update_site_option("\x6d\157\x32\146\137\x61\165\x74\150\137\155\x65\164\150\x6f\x64\163\137\162\157\x6c\145\x73", $g_);
        yM:
        wp_send_json_success(MoWpnsMessages::lang_translate(MoWpnsMessages::SETTINGS_SAVED_SUCCESSFULLY));
    }
    public function mo2f_get_backup_methods($bB, $post)
    {
        return isset($post["\x6d\x6f\x32\x66\137\145\156\x61\x62\x6c\145\144\137\x62\x61\143\x6b\x75\160\x5f\155\145\x74\150\x6f\144\163"]) ? array_map("\x73\141\x6e\x69\164\151\x7a\x65\x5f\x74\x65\x78\164\137\x66\151\x65\154\144", wp_unslash($post["\155\x6f\62\146\137\x65\156\x61\142\x6c\x65\144\x5f\142\x61\143\153\165\x70\137\x6d\145\x74\150\157\x64\x73"])) : $bB;
    }
    public function mo2f_add_2fa_bulk_actions($I0)
    {
        $I0["\x45\x6e\x61\x62\154\145\137\x32\106\101"] = "\105\156\141\x62\x6c\145\40\62\106\x41";
        $I0["\x44\151\x73\141\x62\x6c\145\x5f\62\x46\x41"] = "\x44\x69\x73\141\142\x6c\x65\x20\x32\x46\101";
        return $I0;
    }
    public function mo2f_mapped_2fa_columns($vd)
    {
        $vd["\x6d\141\x70\160\x65\x64\x5f\145\x6d\141\x69\x6c"] = "\x52\145\x67\x69\x73\x74\145\x72\x65\x64\x20\x32\x46\101\40\x45\x6d\141\151\x6c";
        $vd["\x73\145\154\x65\143\x74\x65\144\137\165\163\x65\x72"] = "\62\106\x41\40\105\156\141\x62\x6c\145\x64";
        return $vd;
    }
    public function mo2f_mapped_2fa_columns_content($iY, $Bk, $v1)
    {
        global $Gw;
        $user = get_userdata($v1);
        $eG = $Gw->get_user_detail("\x6d\x6f\62\146\137\143\x6f\x6e\x66\x69\147\165\x72\x65\x64\x5f\62\106\x41\137\155\145\x74\150\157\x64", $v1);
        $fK = $Gw->get_user_detail("\155\157\x32\x66\x5f\165\163\145\x72\x5f\145\155\x61\151\x6c", $v1);
        if ($eG) {
            goto IR;
        }
        $eG = "\116\157\x74\40\x52\145\x67\151\163\x74\x65\x72\x65\144\x20\146\157\x72\x20\x32\x46\101";
        IR:
        if ("\143\165\x72\162\x65\x6e\x74\137\x6d\x65\164\x68\157\144" === $Bk) {
            goto Fs;
        }
        if ("\x6d\141\x70\x70\x65\144\x5f\x65\155\141\151\154" === $Bk) {
            goto kr;
        }
        if ("\163\x65\154\145\x63\164\145\x64\x5f\165\163\x65\162" === $Bk) {
            goto TI;
        }
        goto sW;
        Fs:
        return MoWpnsConstants::mo2f_convert_method_name($eG, "\143\x61\160\137\x74\x6f\x5f\163\155\x61\x6c\x6c");
        goto sW;
        kr:
        if ($fK) {
            goto CK;
        }
        $fK = "\x4e\157\x74\40\122\145\x67\x69\x73\164\x65\x72\145\x64\x20\x66\x6f\162\40\62\106\x41";
        CK:
        return $fK;
        goto sW;
        TI:
        $y4 = new Mo2f_Main_Handler();
        $tm = $y4->mo2f_check_if_twofa_is_enabled($user);
        $IU = $tm ? "\131\x65\x73" : "\x4e\157";
        $Ux = get_site_option("\x6d\x6f\62\x66\137\163\145\x6c\145\143\x74\137\165\x73\x65\162\137\x66\157\162\x5f\x32\146\141", array());
        $b_ = get_site_option("\155\x6f\62\146\x5f\162\x65\155\x6f\x76\145\x5f\x75\x73\x65\x72\x5f\x66\157\x72\x5f\x32\x66\141", array());
        if (in_array($v1, $Ux, true)) {
            goto WJ;
        }
        if (in_array($v1, $b_, true)) {
            goto gL;
        }
        goto LH;
        WJ:
        $IU = "\x59\145\x73";
        goto LH;
        gL:
        $IU = "\116\x6f";
        LH:
        return $IU;
        sW:
        return $iY;
    }
    public function mo2f_check_if_twofa_is_enabled($RC, $post)
    {
        $cs = isset($post["\x75\x73\x65\162"]) ? $post["\165\163\x65\x72"] : null;
        $Ux = get_site_option("\155\157\62\146\137\163\x65\154\x65\x63\x74\x5f\165\x73\x65\x72\x5f\146\157\162\x5f\62\x66\141", array());
        $Yz = get_site_option("\155\157\62\x66\x5f\162\x65\155\157\166\x65\137\x75\163\145\x72\137\x66\x6f\x72\x5f\x32\146\x61", array());
        if (!in_array($cs->ID, $Ux, true)) {
            goto DF;
        }
        return true;
        DF:
        if (!in_array($cs->ID, $Yz, true)) {
            goto GE;
        }
        return false;
        GE:
        return $RC;
    }
    public function mo2f_handle_bulk_actions($ok, $MA, $qU)
    {
        if (!("\105\x6e\x61\142\x6c\145\137\62\106\101" !== $MA && "\104\151\x73\x61\142\x6c\145\137\x32\x46\x41" !== $MA)) {
            goto Ed;
        }
        return $ok;
        Ed:
        $Ux = get_site_option("\x6d\x6f\x32\x66\x5f\163\x65\x6c\x65\143\164\137\x75\163\x65\162\137\146\157\x72\x5f\62\x66\141", array());
        $Yz = get_site_option("\155\x6f\x32\146\137\162\145\x6d\157\x76\x65\x5f\165\x73\x65\x72\137\146\157\162\x5f\x32\x66\x61", array());
        if ("\x45\x6e\141\142\154\x65\x5f\62\106\x41" === $MA) {
            goto OM;
        }
        if ("\x44\x69\x73\x61\x62\154\x65\x5f\x32\106\101" === $MA) {
            goto dV;
        }
        goto Bv;
        OM:
        foreach ($qU as $nt) {
            if (in_array($nt, $Ux, true)) {
                goto Mn;
            }
            array_push($Ux, $nt);
            Mn:
            $nc = array_search($nt, $Yz, true);
            if (!isset($nc)) {
                goto lV;
            }
            unset($Yz[$nc]);
            lV:
            dQ:
        }
        Qb:
        goto Bv;
        dV:
        foreach ($qU as $nt) {
            if (in_array($nt, $Yz, true)) {
                goto Nb;
            }
            array_push($Yz, $nt);
            Nb:
            $nc = array_search($nt, $Ux, true);
            if (!isset($nc)) {
                goto Mo;
            }
            unset($Ux[$nc]);
            Mo:
            Yb:
        }
        lc:
        Bv:
        update_site_option("\x6d\x6f\x32\x66\137\x73\145\x6c\x65\x63\164\137\165\x73\x65\x72\x5f\x66\157\162\x5f\x32\146\141", $Ux);
        update_site_option("\155\x6f\x32\x66\x5f\x72\x65\155\157\166\145\x5f\165\x73\145\x72\137\146\x6f\162\x5f\62\x66\141", $Yz);
        return $ok;
    }
    public function mo2f_get_backup_codes($dY, $post)
    {
        $v1 = isset($post["\x75\163\x65\x72\137\151\x64"]) ? $post["\x75\x73\145\162\x5f\x69\144"] : null;
        $oB = array();
        $oI = array();
        $T8 = 0;
        Tq:
        if (!($T8 < 5)) {
            goto ya;
        }
        $SB = MO2f_Utility::random_str(10);
        array_push($oB, $SB);
        array_push($oI, md5($SB));
        oO:
        $T8++;
        goto Tq;
        ya:
        update_user_meta($v1, "\x6d\157\x32\146\137\x62\141\x63\153\165\160\137\143\157\144\x65\163", $oI);
        return $oB;
    }
    public function mo2f_save_custom_registration_form_settings($post)
    {
        $qx = isset($post["\x73\x75\x62\x6d\x69\x74\x5f\x73\x65\154\145\x63\164\157\x72"]) ? sanitize_text_field(wp_unslash($post["\x73\x75\x62\x6d\x69\x74\x5f\163\x65\x6c\145\143\x74\157\x72"])) : '';
        $Xq = isset($post["\146\x6f\162\x6d\x5f\x73\x65\x6c\x65\143\x74\157\162"]) ? sanitize_text_field(wp_unslash($post["\146\157\162\x6d\x5f\163\145\x6c\145\x63\x74\x6f\x72"])) : '';
        $i1 = isset($post["\x65\155\141\x69\154\x5f\163\145\154\145\143\164\x6f\162"]) ? sanitize_text_field(wp_unslash($post["\x65\x6d\141\151\x6c\137\163\145\x6c\145\x63\164\x6f\x72"])) : '';
        $iA = isset($post["\x70\x68\157\x6e\x65\137\163\x65\154\x65\143\x74\x6f\x72"]) ? sanitize_text_field(wp_unslash($post["\160\150\x6f\x6e\145\137\x73\145\154\145\x63\x74\157\x72"])) : '';
        $dX = isset($post["\141\x75\164\150\x54\171\x70\145"]) ? sanitize_text_field(wp_unslash($post["\141\165\164\x68\124\171\160\145"])) : '';
        $rK = isset($post["\143\x75\163\x74\157\x6d\106\x6f\x72\155"]) ? sanitize_text_field(wp_unslash($post["\x63\165\x73\164\157\x6d\106\157\162\x6d"])) : '';
        $rA = isset($post["\x72\145\147\x46\x6f\162\155\114\x69\x73\164"]) ? sanitize_text_field(wp_unslash($post["\162\x65\147\106\x6f\162\x6d\114\x69\x73\164"])) : '';
        $A8 = isset($post["\x66\157\x72\155\123\165\142\155\x69\x74"]) ? sanitize_text_field(wp_unslash($post["\146\x6f\162\155\x53\x75\x62\155\151\164"])) : '';
        if ($qx !== '' && $Xq !== '' && $i1 !== '' && $rK !== '' && $rA !== '' && $dX !== '') {
            goto dv;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::EMPTY_LOGIN_FIELDS));
        goto Av;
        dv:
        $x3 = array("\146\157\162\x6d\137\156\141\x6d\145" => $rA, "\143\165\163\x74\x6f\155\137\146\157\162\x6d\x5f\156\141\155\x65" => $Xq, "\143\165\x73\x74\x6f\155\x5f\145\x6d\141\151\154\x5f\x73\x65\154\x65\143\x74\157\x72" => $i1, "\143\165\x73\164\x6f\x6d\137\x70\150\x6f\156\x65\137\x73\145\x6c\x65\x63\164\157\x72" => $iA, "\x63\x75\163\164\x6f\x6d\x5f\x73\x75\x62\x6d\x69\164\137\163\x65\154\145\x63\x74\157\x72" => $qx, "\143\165\x73\164\157\x6d\137\141\x75\x74\x68\x5f\164\x79\x70\x65" => $dX, "\x66\x6f\x72\x6d\x5f\163\165\x62\155\x69\164\137\141\146\164\145\x72\x5f\x76\141\154\x69\144\141\164\151\x6f\156" => $A8);
        update_site_option("\155\157\62\146\137\143\x75\163\164\x6f\x6d\137\x72\145\147\x69\163\164\162\x61\164\151\x6f\156\137\146\x6f\x72\x6d\137\x63\x6f\156\146\151\147\x75\162\x61\x74\x69\157\156\x73", $x3);
        wp_send_json_success(MoWpnsMessages::lang_translate(MoWpnsMessages::SETTINGS_SAVED_SUCCESSFULLY));
        Av:
    }
    public function mo2f_insert_shortcode_in_registration_form()
    {
        echo do_shortcode("\133\x6d\x6f\62\x66\137\145\x6e\141\142\x6c\145\137\162\145\147\x69\x73\164\145\x72\135");
    }
    public function mo2f_enable_custom_registration_form_shortcodes($post)
    {
        $Ot = !empty($post["\x6d\157\62\x66\137\x65\156\x61\142\154\x65\137\x73\x68\157\162\x74\x63\x6f\144\x65\163"]) && sanitize_text_field(wp_unslash($post["\155\157\x32\146\x5f\145\156\141\142\154\145\x5f\163\x68\157\162\x74\x63\157\144\145\x73"])) === "\164\162\x75\x65" ? 1 : 0;
        update_site_option("\155\x6f\x32\146\x5f\x65\156\x61\142\x6c\x65\137\x66\157\x72\155\137\x73\x68\x6f\162\164\143\157\144\145", $Ot);
        wp_send_json_success(MoWpnsMessages::lang_translate(MoWpnsMessages::SETTINGS_SAVED_SUCCESSFULLY));
    }
}
new Mo2f_Basic_Premium_Settings();
ke:
