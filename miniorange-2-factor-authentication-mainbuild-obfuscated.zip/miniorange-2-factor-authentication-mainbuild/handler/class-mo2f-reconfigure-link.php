<?php


namespace TwoFA\Onprem;

use TwoFA\Onprem\MO2f_Utility;
use TwoFA\Helper\Mo2f_Login_Popup;
use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Helper\Mo2f_Common_Helper;
use WP_REST_Request;
if (defined("\101\102\123\x50\101\x54\110")) {
    goto ym;
}
exit;
ym:
if (class_exists("\115\157\62\146\137\x52\145\143\157\156\146\151\x67\x75\x72\145\137\x4c\151\x6e\153")) {
    goto vh;
}
class Mo2f_Reconfigure_Link
{
    public function __construct()
    {
        add_action("\162\145\163\x74\x5f\x61\x70\151\x5f\151\x6e\x69\x74", array($this, "\x6d\x6f\62\146\137\141\x64\144\x5f\x63\x75\163\x74\157\x6d\137\x75\x73\x65\162\163\137\141\x70\151"));
        add_filter("\x6c\x6f\x67\x69\x6e\x5f\155\x65\163\163\141\x67\x65", array($this, "\x6d\x6f\62\x66\x5f\x72\145\x63\x6f\156\146\x69\x67\x75\x72\141\164\x69\157\156\137\163\x75\143\x63\145\x73\x73\x5f\155\x65\x73\x73\141\147\x65"));
    }
    public function mo2f_send_reconfig_link($post)
    {
        $Ty = isset($post["\163\x65\163\163\x69\x6f\x6e\137\x69\x64"]) ? sanitize_text_field($post["\x73\x65\x73\x73\151\x6f\x6e\x5f\151\144"]) : null;
        $ok = isset($post["\162\145\144\151\162\x65\143\x74\137\x74\157"]) ? esc_url_raw($post["\162\145\144\151\162\x65\143\x74\x5f\x74\157"]) : null;
        $ix = isset($post["\155\157\x32\146\x5f\154\157\147\151\x6e\137\x6d\x65\x74\x68\x6f\144"]) ? sanitize_text_field(wp_unslash($post["\x6d\x6f\62\146\137\x6c\x6f\x67\x69\x6e\x5f\155\145\164\x68\157\144"])) : null;
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\155\x6f\x32\146\137\143\x75\x72\162\145\x6e\x74\x5f\x75\163\145\x72\x5f\x69\x64");
        $cs = get_user_by("\151\x64", $v1);
        $ba = $this->mo2f_send_reconfig_link_on_email($cs, $cs->user_email);
        $xW = $ba ? "\101\143\x63\157\165\156\164\x20\122\145\x63\157\166\x65\162\171\x20\x45\x6d\x61\151\154\40\123\145\156\x74" : "\x41\x63\143\157\165\x6e\x74\x20\122\x65\143\x6f\166\x65\x72\x79\40\x45\x6d\x61\x69\154\40\x43\157\x75\x6e\x6c\144\x6e\x27\x74\40\x53\145\156\144";
        $Oc = $this->mo2f_get_message($ba, $v1);
        $AP = MoWpnsConstants::MO_2_FACTOR_RECONFIGURATION_LINK_SENT;
        $this->mo2f_show_login_prompt($Oc, $AP, $cs, $ok, $Ty, $xW, $ix);
    }
    public function mo2f_get_message($ba, $v1)
    {
        if ($ba) {
            goto Vz;
        }
        return "\x41\x70\x6f\x6c\157\147\x69\145\163\x2c\40\167\x65\47\162\x65\x20\x65\156\x63\x6f\x75\x6e\164\x65\x72\151\x6e\x67\x20\141\156\x20\x69\x73\x73\165\145\40\x77\150\151\x6c\x65\40\141\x74\x74\145\x6d\160\164\x69\156\x67\x20\164\157\x20\x73\x65\x6e\x64\x20\164\x68\145\40\x72\145\x63\x6f\x6e\x66\x69\x67\x75\x72\141\164\151\157\x6e\40\145\x6d\141\x69\154\56\40\113\x69\156\x64\154\171\40\x76\x65\162\x69\146\x79\x20\171\157\165\162\40\x6e\145\164\x77\157\162\x6b\40" . (user_can($v1, "\141\144\155\x69\156\151\163\x74\162\x61\x74\x6f\x72") ? "\157\x72\40\x53\x4d\124\120\x20\143\157\x6e\x6e\145\143\164\x69\157\156\40\x73\145\164\164\151\x6e\147\x73\56" : "\x61\156\144\x20\164\162\x79\40\141\x67\x61\x69\156\56");
        goto RK;
        Vz:
        return "\101\156\x20\145\x6d\x61\151\154\40\x63\157\156\164\141\151\x6e\x69\x6e\147\40\x74\150\x65\40\154\x69\x6e\x6b\x20\164\x6f\x20\162\145\x63\x6f\x76\145\x72\x20\171\x6f\165\162\x20\141\x63\143\x6f\x75\156\164\40\142\171\x20\x72\x65\163\x65\x74\164\x69\156\x67\x73\40\x79\x6f\165\162\x20\x54\x77\157\x2d\x46\141\x63\x74\157\x72\x20\101\165\x74\150\x65\x6e\164\x69\x63\141\164\x69\x6f\x6e\40\50\x32\106\101\x29\40\144\x65\164\x61\x69\x6c\x73\x20\x68\x61\x73\40\x62\x65\x65\x6e\x20\163\x65\x6e\x74\x20\164\157\40\x79\157\165\x72\x20\151\x6e\x62\x6f\x78\56\40\x50\x6c\145\x61\163\x65\40\x63\x6c\151\143\153\40\x6f\x6e\40\x74\150\141\164\x20\x6c\151\156\153\40\146\x6f\162\x20\x74\150\145\40\163\141\155\145\x2e";
        RK:
    }
    public function mo2f_show_login_prompt($we, $AP, $current_user, $ok, $jg, $xW, $ix)
    {
        $yV = new Mo2f_Login_Popup();
        $cB = new Mo2f_Common_Helper();
        $gH = $yV->mo2f_twofa_login_prompt_skeleton_values($we, $AP, null, null, $current_user->ID, "\154\x6f\x67\151\x6e\x5f\62\x66\x61", $xW);
        $XZ = $yV->mo2f_twofa_authentication_login_prompt($AP, $we, $ok, $jg, $gH, $ix);
        $XZ .= $cB->mo2f_get_hidden_forms_login($ok, $jg, $AP, $we, $ix, $current_user->ID);
        $XZ .= $cB->mo2f_get_hidden_script_login();
        echo $XZ;
        exit;
    }
    public function mo2f_send_reconfig_link_on_email($current_user, $fK)
    {
        $cN = $this->mo2f_generate_2fa_reconfiguration_token($current_user);
        $a3 = MoWpnsUtility::get_mo2f_db_option("\155\157\62\x66\x5f\x32\x66\141\x5f\162\x65\143\x6f\156\x66\151\x67\137\145\155\141\151\x6c\137\163\165\x62\152\x65\143\x74", "\x73\151\164\x65\x5f\x6f\160\164\x69\157\156");
        $Tp = array("\x43\157\x6e\164\x65\x6e\164\55\124\x79\160\x65\72\x20\164\145\x78\x74\x2f\x68\164\155\x6c\x3b\x20\143\150\x61\162\x73\x65\x74\75\125\124\106\x2d\70");
        $jD = $this->mo2f_2fa_reconfiguration_email_template($cN, $current_user, $fK);
        $vv = wp_mail($fK, $a3, $jD, $Tp);
        return $vv;
    }
    public function mo2f_generate_2fa_reconfiguration_token($current_user)
    {
        $Zi = base64_encode($current_user->user_login);
        $v1 = $current_user->ID;
        $j1 = base64_encode(strtotime(current_datetime()->format("\150\x3a\151\141\x20\115\40\144\x20\x59")));
        $e9 = bin2hex(openssl_random_pseudo_bytes(32));
        $cN = $j1 . $Zi . $e9;
        update_user_meta($v1, "\155\157\x32\x66\x5f\x72\x65\163\x65\x74\137\164\157\x6b\x65\x6e", $cN);
        return $cN;
    }
    public function mo2f_2fa_reconfiguration_email_template($cN, $current_user, $fK)
    {
        global $ai;
        $v1 = $current_user->ID;
        $yy = wp_upload_dir();
        $KD = $ai . "\x69\156\x63\154\x75\x64\145\163\x2f\x69\155\141\147\145\x73\57" . get_site_option("\x6d\x6f\x32\x66\137\143\165\x73\164\157\x6d\x5f\x6c\157\x67\157", "\155\x69\x6e\x69\117\x72\x61\x6e\147\x65\x32\x2e\160\156\x67");
        $xz = get_site_option("\x73\x69\x74\x65\x75\x72\x6c");
        $xz .= "\57\167\x70\x2d\x6a\163\x6f\156\57\155\151\x6e\151\x6f\162\141\156\x67\145\57\x6d\x6f\x5f\x32\146\141\x5f\x74\167\157\137\146\141\x2f\162\145\x73\145\x74\x75\x73\x65\x72\62\x66\x61\x3d" . $cN . "\57\155\145\163\x73\141\x67\145\75\162\145\163\145\164\163\x75\x63\x63\145\163\x73";
        $jD = MoWpnsUtility::get_mo2f_db_option("\155\x6f\62\146\137\162\x65\x63\157\156\x66\151\x67\x5f\x6c\151\x6e\153\x5f\145\155\x61\151\x6c\x5f\x74\x65\x6d\160\x6c\x61\x74\x65", "\163\x69\x74\x65\x5f\x6f\160\x74\151\157\x6e");
        $jD = str_replace("\x23\x23\x69\155\141\x67\x65\x5f\x70\141\x74\x68\x23\43", $KD, $jD);
        $jD = str_replace("\x23\43\165\x73\145\x72\137\151\x64\x23\x23", $v1, $jD);
        $jD = str_replace("\43\x23\x75\x73\145\162\137\x65\x6d\141\151\x6c\x23\43", $fK, $jD);
        $jD = str_replace("\x23\x23\x75\163\145\162\x5f\x6e\141\x6d\145\x23\43", $current_user->user_login, $jD);
        $jD = str_replace("\43\43\x75\162\x6c\43\43", $xz, $jD);
        return $jD;
    }
    public function mo2f_add_custom_users_api()
    {
        register_rest_route("\155\x69\x6e\151\157\x72\141\x6e\147\145\57\155\157\137\x32\x66\141\137\164\x77\157\x5f\146\141", "\x2f\x72\x65\163\x65\164\165\x73\x65\162\x32\146\x61\75\x28\77\x50\x3c\x72\145\x73\145\x74\x75\x73\145\x72\62\146\x61\x3e\x5b\x41\55\132\x61\x2d\x7a\60\55\x39\x3d\x2b\57\135\x2b\x29\x2f\x6d\145\163\163\141\147\145\75\x28\x3f\120\74\155\145\163\163\141\147\145\x3e\133\101\x2d\132\x61\x2d\x7a\x5d\x2b\x29", array("\155\x65\164\150\157\144\163" => "\x47\105\124", "\x63\x61\154\x6c\x62\x61\143\x6b" => array($this, "\x6d\x6f\62\x66\x5f\x61\154\154\157\x77\x5f\165\163\145\x72\x73\x5f\x32\146\141\x5f\162\x65\143\x6f\156\x66\151\147\x75\162\x61\164\151\x6f\x6e"), "\x70\145\x72\155\151\163\163\151\157\x6e\x5f\x63\x61\x6c\154\x62\141\143\153" => "\137\x5f\162\145\164\x75\162\x6e\137\x74\x72\165\x65"));
    }
    public function mo2f_allow_users_2fa_reconfiguration(WP_REST_Request $rx)
    {
        global $Gw;
        $cN = $rx["\x72\x65\x73\145\x74\x75\x73\145\162\x32\x66\x61"];
        $mp = $rx["\155\x65\x73\163\141\x67\145"];
        $v1 = $Gw->mo2f_get_userid_from_reset_token($cN);
        if (!isset($v1)) {
            goto IA;
        }
        $current_user = get_user_by("\x69\144", $v1);
        $Zi = base64_encode($current_user->user_login);
        if (!strpos($cN, $Zi)) {
            goto wa;
        }
        $mC = explode($Zi, $cN);
        $Ow = base64_decode($mC[0]);
        $uI = strtotime(current_datetime()->format("\x68\72\x69\141\40\x4d\x20\144\40\131"));
        delete_user_meta($v1, "\155\x6f\62\146\137\x72\145\x73\x65\164\x5f\x74\x6f\153\x65\x6e");
        if (!($uI < $Ow + 24 * 60 * 60)) {
            goto ay;
        }
        $this->mo2f_reset_users_2fa_for_reconfiguration($v1);
        wp_safe_redirect(get_site_url() . "\x2f\167\x70\55\x6c\x6f\x67\151\156\56\160\x68\x70\x3f\x72\x65\163\145\x74\137\x6d\145\163\x73\141\x67\x65\75" . $mp);
        exit;
        ay:
        wa:
        IA:
        wp_safe_redirect(get_site_url() . "\57\167\x70\55\154\157\x67\151\156\56\x70\150\160\x3f");
        exit;
    }
    public function mo2f_reset_users_2fa_for_reconfiguration($v1)
    {
        global $Gw;
        delete_user_meta($v1, "\155\157\x32\146\137\153\142\x61\137\x63\x68\141\x6c\x6c\145\156\x67\x65");
        delete_user_meta($v1, "\155\x6f\x32\x66\x5f\62\106\x41\x5f\x6d\x65\164\150\x6f\144\137\x74\x6f\137\x63\x6f\156\x66\x69\147\x75\162\x65");
        delete_user_meta($v1, "\x53\145\x63\x75\162\x69\x74\x79\40\121\x75\x65\163\x74\151\157\156\x73");
        delete_user_meta($v1, "\x6d\157\62\x66\x5f\143\150\x61\x74\137\x69\144");
        $Gw->delete_user_details($v1);
        delete_user_meta($v1, "\x6d\x6f\x32\146\x5f\62\x46\x41\137\x6d\x65\164\x68\157\x64\x5f\x74\157\137\x74\x65\x73\x74");
    }
    public function mo2f_reconfiguration_success_message()
    {
        if (!(isset($_GET["\x72\x65\163\145\x74\x5f\x6d\145\x73\x73\x61\147\x65"]) && "\162\145\x73\x65\164\x73\165\x63\143\145\x73\163" === sanitize_text_field(wp_unslash($_GET["\x72\x65\x73\x65\164\137\155\145\163\163\x61\x67\x65"])))) {
            goto h5;
        }
        $jD = "\131\157\x75\x20\x68\141\x76\145\x20\163\x75\143\143\x65\163\163\146\x75\x6c\x6c\x79\x20\x72\x65\x73\145\164\x20\x79\x6f\x75\162\x20\x32\106\101\x2e\x20\120\x6c\145\x61\x73\145\40\x6c\x6f\147\x69\x6e\x20\x61\156\x64\40\x72\145\143\157\x6e\x66\x69\147\165\x72\x65\40\x74\150\145\40\x32\x46\x41\x20\x6d\x65\x74\x68\x6f\x64\40\x66\157\x72\x20\171\x6f\165\162\163\145\x6c\146\56";
        return "\74\144\x69\x76\76\40\x3c\160\40\143\154\141\163\163\75\47\x6d\145\x73\x73\141\x67\x65\x27\76" . $jD . "\x3c\x2f\x70\76\x3c\x2f\x64\151\x76\76";
        h5:
    }
}
new Mo2f_Reconfigure_Link();
vh:
