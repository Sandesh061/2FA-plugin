<?php


if (defined("\x41\102\x53\x50\x41\x54\110")) {
    goto pR;
}
exit;
pR:
use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Helper\TwoFAMoSessions;
use TwoFA\Helper\Mo2f_Common_Helper;
use TwoFA\Onprem\Mo2f_Main_Handler;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Onprem\MO2f_Utility;
use TwoFA\Onprem\Mo2f_Premium_Common_Helper;
use TwoFA\Helper\MoWpnsUtility;
if (class_exists("\115\157\x32\146\137\101\x6c\154\x5f\111\156\143\154\x75\x73\x69\x76\x65\137\120\x72\x65\x6d\x69\165\155\x5f\123\145\164\164\151\156\147\x73")) {
    goto OF;
}
class Mo2f_All_Inclusive_Premium_Settings
{
    private $show_message;
    public function __construct()
    {
        add_action("\167\x70\137\141\x6a\x61\x78\x5f\155\x6f\62\x66\x5f\x63\165\x73\164\x6f\155\137\x6c\x6f\x67\x69\x6e\x5f\146\157\x72\155\137\141\152\x61\170", array($this, "\155\x6f\x5f\164\167\x6f\x5f\x66\141\x63\164\x6f\162\137\143\165\x73\x74\157\155\x5f\x6c\x6f\x67\x69\x6e\x5f\146\x6f\x72\x6d\137\141\152\x61\170"));
        add_action("\167\160\137\141\152\141\170\x5f\156\157\x70\162\x69\166\x5f\155\x6f\62\x66\x5f\x63\x75\x73\164\157\155\137\x6c\x6f\x67\151\156\137\x66\x6f\x72\x6d\x5f\141\152\x61\x78", array($this, "\x6d\157\137\164\x77\x6f\x5f\146\141\143\164\x6f\162\x5f\x63\x75\x73\x74\157\x6d\x5f\154\157\147\x69\x6e\137\146\157\162\x6d\x5f\x61\x6a\x61\170"));
        add_action("\155\x6f\x32\x66\137\x61\x6c\x6c\x5f\x69\156\x63\154\x75\163\151\x76\x65\x5f\160\x6c\141\156\x5f\163\145\164\x74\151\x6e\x67\x73\137\x61\143\x74\151\x6f\156", array($this, "\x6d\x6f\x32\x66\137\150\x61\x6e\x64\x6c\145\137\x61\x63\x74\x69\157\156\x5f\141\154\x6c\137\x69\x6e\143\154\x75\x73\x69\166\145\137\160\154\x61\x6e\x5f\163\145\164\x74\151\x6e\147\163"), 10, 2);
        add_action("\x69\x6e\x69\164", array($this, "\155\157\x32\146\x5f\x65\x6e\x71\165\145\x75\x65\137\143\x75\163\164\x6f\155\x5f\x6c\x6f\147\151\x6e\x5f\146\157\x72\155\137\x73\x63\x72\x69\160\x74"));
        add_action("\151\x6e\x69\x74", array($this, "\x6d\157\x32\x66\x61\x5f\x63\x75\163\164\157\155\x5f\154\x6f\147\151\156\137\x66\157\162\155\x5f\163\164\141\x72\x74\x5f\164\167\157\146\x61"));
        add_action("\x69\x6e\151\x74", array($this, "\x6d\x6f\x32\146\137\155\x69\x67\162\141\164\x65\x5f\x63\165\x73\x74\157\x6d\137\x6c\x6f\x67\x69\x6e\x5f\x66\157\x72\155\137\x64\145\x74\141\x69\x6c\x73"));
    }
    public function mo2fa_custom_login_form_start_twofa()
    {
        $dk = isset($_POST["\155\x69\156\151\x6f\162\x61\156\x67\x65\137\x75\162\154\x5f\x6c\157\x67\151\x6e\x5f\156\x6f\x6e\143\145"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\x69\x6e\x69\157\162\141\x6e\147\145\137\165\162\154\x5f\154\157\x67\151\156\137\156\157\x6e\143\x65"])) : null;
        if (wp_verify_nonce($dk, "\x6d\151\x6e\151\157\162\x61\x6e\x67\x65\x2d\x32\x2d\146\x61\x63\164\157\x72\55\154\157\x67\x69\156\x2d\x6e\157\x6e\x63\145")) {
            goto WF;
        }
        return;
        WF:
        if (!(isset($_POST["\155\x6f\x32\146\x61\137\154\x6f\x67\x69\156\x5f\165\163\x65\162\x5f\x6e\141\155\x65"]) && !empty($_POST["\155\157\x32\x66\x61\x5f\x6c\157\147\151\156\x5f\165\163\x65\x72\137\x6e\141\155\x65"]))) {
            goto lP;
        }
        $Zi = sanitize_text_field(wp_unslash($_POST["\155\157\x32\146\141\137\x6c\157\x67\151\156\137\x75\163\x65\162\137\156\141\155\x65"]));
        $cB = new Mo2f_Common_Helper();
        $user = $cB->mo2f_get_user($Zi);
        $y4 = new Mo2f_Main_Handler();
        $jY = $y4->miniorange_initiate_2nd_factor($user);
        return $jY;
        lP:
    }
    public function mo_two_factor_custom_login_form_ajax()
    {
        if (check_ajax_referer("\x6d\x6f\62\x66\x2d\154\157\147\x69\x6e\x2d\x73\145\164\x74\151\156\x67\163\x2d\x61\x6a\x61\x78\55\x6e\157\156\143\x65", "\x6e\x6f\156\143\x65", false)) {
            goto x2;
        }
        wp_send_json_error(MoWpnsConstants::ERROR);
        x2:
        $GLOBALS["\x6d\x6f\x32\x66\137\x69\x73\x5f\141\152\x61\170\x5f\x72\x65\x71\165\x65\x73\x74"] = true;
        $Xh = isset($_POST["\x6f\x70\164\x69\x6f\156"]) ? sanitize_text_field(wp_unslash($_POST["\157\160\164\151\157\156"])) : '';
        switch ($Xh) {
            case "\155\x6f\x32\146\x5f\141\x6a\x61\170\x5f\166\145\162\x69\x66\171\x5f\143\162\145\144\x65\156\164\151\141\154\x73":
                $this->mo2f_verify_credentials($_POST);
                goto Pu;
            case "\155\157\62\146\x5f\x61\152\x61\x78\137\x76\x65\162\x69\146\171\x5f\143\x72\x65\144\145\156\164\151\141\154\163\137\160\x61\163\163\167\157\162\144\x6c\145\163\x73":
                $this->mo2f_verify_credentials_passwordless($_POST);
                goto Pu;
        }
        mY:
        Pu:
    }
    public function mo2f_verify_credentials($post)
    {
        if (!(isset($post["\x6d\x6f\x32\x66\141\x5f\154\x6f\147\151\156\137\x75\163\x65\162\x6e\141\155\x65"]) && !empty($post["\x6d\157\x32\x66\x61\x5f\154\157\x67\x69\156\137\165\163\x65\162\x6e\x61\x6d\145"]) && isset($post["\x6d\x6f\x32\x66\x5f\x6c\157\x67\x69\156\137\x70\141\163\x73\167\x6f\162\x64"]) && !empty($post["\155\x6f\x32\x66\137\154\x6f\147\x69\x6e\x5f\x70\141\x73\x73\x77\x6f\162\144"]))) {
            goto Zo;
        }
        $Zi = sanitize_text_field(wp_unslash($post["\155\157\x32\x66\141\137\154\x6f\x67\x69\x6e\x5f\x75\163\145\162\156\x61\x6d\x65"]));
        $uk = $post["\x6d\157\x32\x66\x5f\x6c\x6f\x67\x69\156\137\160\x61\163\x73\167\157\162\144"];
        $user = null;
        $cB = new Mo2f_Common_Helper();
        $AK = $cB->mo2f_wp_authenticate($Zi, $uk, $user);
        if (is_wp_error($AK)) {
            goto eS;
        }
        if (get_site_option("\155\x6f\x32\x66\137\x73\145\163\163\163\151\x6f\x6e\137\x72\x65\163\164\x72\151\x63\x74\x69\x6f\156")) {
            goto JH;
        }
        goto o2;
        eS:
        wp_send_json_error(MoWpnsConstants::INVALIDE_CREDS);
        goto o2;
        JH:
        $cs = $cB->mo2f_get_user($Zi);
        $RS = new MoWpnsUtility();
        $RS->mo2f_check_session_management_details($cs);
        o2:
        wp_send_json_success(MoWpnsConstants::VALIDATED);
        Zo:
        wp_send_json_error(MoWpnsConstants::ERROR);
    }
    public function mo2f_verify_credentials_passwordless($post)
    {
        global $Gw;
        if (!(isset($post["\x6d\x6f\62\146\x61\x5f\154\157\x67\x69\156\137\x70\141\x73\x73\167\x6f\162\144\154\x65\163\163\x5f\165\x73\x65\162\156\141\x6d\x65"]) && !empty($post["\155\x6f\62\x66\141\137\154\157\x67\x69\x6e\x5f\x70\x61\x73\163\x77\157\162\x64\154\x65\x73\x73\x5f\165\x73\x65\162\156\141\x6d\145"]))) {
            goto ha;
        }
        $Zi = sanitize_text_field($post["\x6d\x6f\62\x66\141\137\x6c\x6f\147\151\x6e\137\160\x61\x73\x73\167\x6f\x72\x64\x6c\145\163\x73\137\165\x73\145\162\x6e\141\155\145"]);
        $cB = new Mo2f_Common_Helper();
        $user = $cB->mo2f_get_user($Zi);
        if ($user) {
            goto kt;
        }
        wp_send_json_error(MoWpnsConstants::INVALIDE_CREDS);
        goto YC;
        kt:
        $yR = $Gw->get_user_detail("\155\x6f\x32\x66\x5f\143\x6f\156\146\x69\147\x75\x72\x65\144\137\62\x46\x41\x5f\155\145\164\x68\x6f\x64", $user->ID);
        if (empty($yR)) {
            goto fE;
        }
        if (get_site_option("\x6d\x6f\x32\x66\x5f\x73\x65\163\163\163\x69\157\x6e\137\162\x65\163\x74\x72\151\x63\164\x69\157\x6e")) {
            goto Hy;
        }
        wp_send_json_success(MoWpnsConstants::VALIDATED);
        goto iu;
        fE:
        wp_send_json_error(MoWpnsConstants::TWOFA_NOT_CONFIGURED);
        goto iu;
        Hy:
        $RS = new MoWpnsUtility();
        $RS->mo2f_check_session_management_details($user);
        iu:
        YC:
        ha:
        wp_send_json_error(MoWpnsConstants::ERROR);
    }
    public function mo2f_handle_action_all_inclusive_plan_settings($wD, $post)
    {
        switch ($wD) {
            case "\155\157\62\x66\137\163\x61\x76\x65\x5f\x6c\157\147\151\x6e\137\x66\x6f\162\x6d\x5f\163\x65\x74\x74\151\156\147\x73":
                $this->mo2f_save_login_form_settings($post);
                goto i1;
            case "\x6d\157\62\x66\137\145\x6e\141\x62\154\x65\137\144\x69\x73\141\x62\x6c\x65\137\154\157\147\151\156\x5f\146\x6f\x72\155":
                $this->mo2f_enable_disable_login_form($post);
                goto i1;
        }
        rr:
        i1:
    }
    public function mo2f_enable_disable_login_form($post)
    {
        $sc = isset($post["\x6c\157\x67\151\x6e\x5f\146\157\162\155\x5f\145\156\141\x62\x6c\x65\x64"]) ? "\164\x72\165\x65" === sanitize_text_field(wp_unslash($post["\154\x6f\x67\x69\156\x5f\146\x6f\162\155\x5f\x65\156\141\x62\x6c\x65\144"])) : false;
        update_site_option("\x6d\157\x32\146\x5f\x65\x6e\141\x62\154\x65\x5f\x63\165\x73\164\157\x6d\x5f\154\x6f\147\151\156\137\146\x6f\162\155", $sc);
        wp_send_json_success(MoWpnsMessages::lang_translate(MoWpnsMessages::SETTINGS_SAVED_SUCCESSFULLY));
    }
    public function mo2f_save_login_form_settings($post)
    {
        $qx = isset($post["\163\165\142\155\x69\x74\137\163\145\154\145\143\x74\x6f\162"]) ? sanitize_text_field(wp_unslash($post["\163\165\142\155\x69\164\137\163\x65\154\145\143\164\157\x72"])) : '';
        $i1 = isset($post["\x65\x6d\x61\151\x6c\137\163\145\154\145\x63\x74\x6f\x72"]) ? sanitize_text_field(wp_unslash($post["\145\155\x61\x69\x6c\137\x73\x65\154\145\x63\164\x6f\x72"])) : '';
        $a7 = isset($post["\x70\141\163\x73\137\x73\145\x6c\145\x63\164\157\162"]) ? sanitize_text_field(wp_unslash($post["\x70\141\x73\x73\x5f\x73\x65\154\x65\143\164\x6f\162"])) : '';
        $jz = isset($post["\160\x61\x73\x73\154\x61\142\x65\x6c\123\x65\154\145\x63\164\x6f\162"]) ? sanitize_text_field(wp_unslash($post["\x70\141\x73\x73\154\141\x62\x65\x6c\123\x65\x6c\x65\143\x74\157\162"])) : '';
        $xz = isset($post["\165\x72\154"]) ? sanitize_text_field(wp_unslash($post["\x75\x72\154"])) : '';
        $Xq = isset($post["\146\157\162\x6d\x5f\x73\x65\x6c\x65\143\164\157\x72"]) ? sanitize_text_field(wp_unslash($post["\x66\157\x72\155\137\163\145\154\145\143\x74\157\x72"])) : '';
        if (!($xz && $qx && $i1 && $a7 && $Xq)) {
            goto Yv;
        }
        update_site_option("\x6d\157\x32\146\x5f\x63\165\x73\x74\x6f\x6d\137\154\157\147\x69\156\x5f\146\x6f\x72\x6d\x5f\x63\157\x6e\x66\151\x67\x75\x72\141\x74\x69\x6f\x6e\x73", array("\155\157\x32\x66\x5f\x6c\157\147\151\x6e\x5f\145\155\141\151\154\137\163\x65\x6c\x65\143\164\x6f\x72" => $i1, "\155\157\x32\146\x5f\x6c\157\x67\151\x6e\137\160\141\163\163\137\x73\145\154\145\143\x74\x6f\162" => $a7, "\155\157\62\146\x5f\154\x6f\x67\151\156\x5f\x73\165\x62\155\x69\x74\x5f\x73\x65\x6c\x65\x63\x74\157\x72" => $qx, "\x6d\157\x32\146\x5f\x6c\x6f\147\x69\156\x5f\160\141\x73\163\x6c\141\142\x65\154\x5f\163\145\x6c\145\143\x74\157\162" => $jz, "\155\157\x32\146\137\154\x6f\147\x69\x6e\137\x66\157\x72\x6d\137\165\x72\x6c" => $xz, "\155\x6f\x32\146\137\154\157\x67\151\156\137\146\x6f\x72\155\137\x73\x65\154\145\143\x74\x6f\162" => $Xq));
        wp_send_json_success(MoWpnsMessages::lang_translate(MoWpnsMessages::SETTINGS_SAVED_SUCCESSFULLY));
        Yv:
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::EMPTY_LOGIN_FIELDS));
    }
    public function mo2f_enqueue_custom_login_form_script()
    {
        global $uz;
        $cB = new Mo2f_Premium_Common_Helper();
        $lS = get_site_option("\155\x6f\62\x66\137\x65\x6e\141\x62\154\145\x5f\x63\x75\163\164\x6f\155\x5f\154\157\147\151\x6e\137\146\x6f\162\155");
        $Rf = get_site_option("\155\157\62\146\137\x63\x75\x73\x74\x6f\x6d\137\154\157\147\151\x6e\137\146\157\x72\x6d\x5f\143\157\x6e\146\151\x67\x75\x72\141\164\x69\157\x6e\163", array());
        $R_ = $cB->mo2f_apply_2fa_settings();
        $Yi = isset($Rf["\x6d\x6f\62\x66\137\154\x6f\147\151\156\137\x66\157\162\x6d\137\x75\162\x6c"]) ? $Rf["\155\x6f\62\146\137\x6c\x6f\x67\151\x6e\137\146\157\162\x6d\x5f\165\162\x6c"] : null;
        if (!($lS && !is_user_logged_in() && $R_ && $Yi && wp_http_validate_url($Yi))) {
            goto hC;
        }
        $l8 = $uz->get_current_url();
        if (str_contains($Yi, "\x2c")) {
            goto f2;
        }
        if (strpos($l8, $Yi) !== false) {
            goto R4;
        }
        goto ZD;
        f2:
        $eH = explode("\x2c", $Yi);
        foreach ($eH as $cQ) {
            if (!(strpos($l8, $cQ) !== false)) {
                goto H3;
            }
            $this->mo2f_enqueue_url_script();
            H3:
            V_:
        }
        Xg:
        goto ZD;
        R4:
        $this->mo2f_enqueue_url_script();
        ZD:
        hC:
    }
    public function mo2f_enqueue_url_script()
    {
        $Rf = get_site_option("\155\x6f\x32\x66\x5f\x63\x75\163\164\x6f\155\137\x6c\x6f\x67\151\x6e\x5f\146\x6f\x72\x6d\137\x63\157\x6e\146\x69\x67\x75\x72\x61\164\x69\x6f\156\x73", array());
        $qx = isset($Rf["\x6d\x6f\x32\x66\137\x6c\x6f\147\151\x6e\137\163\x75\x62\x6d\151\164\x5f\x73\145\x6c\x65\x63\x74\x6f\162"]) ? $Rf["\x6d\x6f\x32\x66\137\x6c\x6f\x67\x69\x6e\x5f\x73\x75\x62\155\x69\164\x5f\163\x65\154\145\143\x74\x6f\x72"] : '';
        $i1 = isset($Rf["\x6d\x6f\62\x66\x5f\154\157\x67\151\156\x5f\x65\155\x61\151\x6c\137\x73\x65\154\x65\143\x74\x6f\x72"]) ? $Rf["\155\x6f\x32\146\x5f\154\157\147\151\156\137\x65\155\x61\151\x6c\137\x73\145\x6c\145\143\164\157\x72"] : '';
        $a7 = isset($Rf["\155\157\x32\146\137\x6c\x6f\147\x69\x6e\x5f\x70\141\163\x73\x5f\x73\x65\154\145\x63\x74\x6f\162"]) ? $Rf["\155\x6f\x32\146\x5f\x6c\x6f\147\x69\156\x5f\160\141\x73\163\x5f\x73\145\154\x65\x63\164\x6f\x72"] : '';
        $Xq = isset($Rf["\155\157\62\146\x5f\x6c\157\x67\x69\156\x5f\x66\157\162\155\137\163\x65\x6c\x65\143\164\x6f\162"]) ? $Rf["\x6d\157\x32\146\137\x6c\x6f\147\x69\156\x5f\x66\157\x72\x6d\137\163\145\154\145\143\164\157\x72"] : '';
        $jz = isset($Rf["\x6d\x6f\62\146\137\x6c\x6f\x67\x69\x6e\x5f\160\x61\163\163\154\141\x62\145\x6c\137\x73\x65\154\x65\x63\x74\157\162"]) ? $Rf["\155\157\x32\x66\x5f\154\x6f\x67\x69\x6e\137\x70\x61\163\x73\x6c\141\x62\x65\x6c\x5f\x73\145\x6c\145\x63\x74\x6f\162"] : '';
        $jG = get_site_option("\155\x6f\62\146\137\x73\150\x6f\x77\137\x6c\x6f\x67\151\156\167\151\x74\150\x5f\160\150\157\x6e\x65");
        $m1 = array("\x65\155\x61\x69\x6c\137\x6c\141\x62\x65\x6c" => MoWpnsMessages::lang_translate(MoWpnsMessages::EMAIL_LABEL), "\160\141\163\x73\x77\x6f\x72\x64\x6c\145\163\163\137\154\x6f\x67\x69\156\137\x62\x74\156" => MoWpnsMessages::lang_translate(MoWpnsMessages::LOGIN_WITH_TWO_FACTOR), "\151\x6e\166\141\154\151\x64\x5f\143\162\145\144\145\x6e\164\151\141\154\x73" => MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_CREDS), "\x74\167\x6f\x5f\146\x61\x63\164\157\162\137\x6e\157\164\137\x63\157\x6e\x66\151\147\x75\x72\x65\144" => MoWpnsMessages::lang_translate(MoWpnsMessages::TWOFA_NOT_CONFIGURED), "\151\156\166\141\x6c\x69\144\137\x72\145\161\x75\145\x73\164" => MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_REQ), "\x73\145\163\163\151\x6f\x6e\x5f\162\x65\x73\164\162\151\x63\x74\151\x6f\156" => MoWpnsMessages::lang_translate(MoWpnsMessages::SESSION_LIMIT_REACHED));
        wp_enqueue_script("\x6a\x71\x75\145\x72\171");
        wp_enqueue_script("\x6d\x6f\x32\x66\141\x5f\x6c\157\x67\151\x6e\x73\x63\x72\x69\160\164", plugin_dir_url(dirname(__FILE__)) . "\151\156\143\x6c\x75\x64\145\163\x2f\x6a\x73\x2f\143\x75\x73\164\157\155\x2d\x6c\x6f\147\x69\x6e\x2d\x66\x6f\x72\x6d\56\x6d\151\x6e\x2e\152\163", array(), MO2F_VERSION, true);
        wp_localize_script("\x6d\x6f\62\x66\x61\x5f\154\157\x67\151\x6e\163\x63\x72\151\160\164", "\155\x79\137\x61\152\141\170\137\157\142\152\145\x63\164", array("\x61\x6a\141\x78\x5f\165\x72\x6c" => admin_url("\141\x64\x6d\151\x6e\55\x61\x6a\x61\170\56\160\150\160"), "\x6e\x6f\156\143\145" => wp_create_nonce("\155\151\156\151\x6f\162\x61\156\147\x65\55\x32\55\x66\x61\143\164\157\x72\x2d\x6c\x6f\x67\151\156\x2d\156\157\156\x63\x65"), "\x61\x6a\141\170\137\x6e\x6f\x6e\x63\x65" => wp_create_nonce("\x6d\157\x32\146\x2d\x6c\x6f\x67\x69\156\55\x73\x65\x74\x74\151\156\x67\x73\x2d\x61\152\141\x78\55\156\157\x6e\143\x65"), "\141\152\141\170\x5f\160\141\x73\163\167\x6f\162\144\154\145\163\x73\x5f\x6e\x6f\x6e\x63\x65" => wp_create_nonce("\x6d\151\156\151\x6f\162\x61\x6e\x67\x65\x2d\x32\55\146\141\143\164\157\162\x2d\x70\x61\163\163\x77\157\162\144\x6c\x65\x73\163\55\141\152\x61\x78\55\x6c\x6f\147\151\156\x2d\x6e\x6f\156\x63\x65"), "\x6d\157\62\146\137\154\157\147\x69\x6e\137\157\x70\x74\x69\157\156" => get_site_option("\155\157\x32\x66\x5f\154\157\147\x69\156\x5f\x6f\160\x74\151\x6f\156", "\61"), "\x6d\157\x32\x66\137\163\x68\x6f\x77\137\x6c\157\x67\151\x6e\167\151\x74\150\x5f\x70\150\157\x6e\x65" => $jG, "\163\x75\x62\x6d\151\x74\x53\145\x6c\x65\x63\164\157\162" => $qx, "\145\x6d\141\x69\x6c\123\145\x6c\x65\x63\x74\157\162" => $i1, "\160\141\x73\x73\x53\x65\154\x65\x63\x74\157\162" => $a7, "\x70\x61\163\163\x4c\x61\142\x65\154\123\x65\154\x65\143\x74\x6f\x72" => $jz, "\146\x6f\162\155\123\145\x6c\145\143\164\157\162" => $Xq, "\x6d\x6f\x32\x66\137\162\x65\x6d\145\x6d\x62\x65\x72\137\x64\145\166\151\143\x65" => get_site_option("\x6d\x6f\x32\146\137\x72\145\155\x65\155\142\145\x72\x5f\144\x65\x76\x69\x63\145"), "\146\157\162\x6d\x53\164\x72\x69\x6e\x67\x73" => $m1));
    }
    public function mo2f_migrate_custom_login_form_details()
    {
        if (!(!get_site_option("\155\x6f\62\146\137\155\x69\147\x72\x61\164\145\x5f\x63\165\163\x74\x6f\x6d\x5f\154\157\x67\x69\x6e\x5f\x66\157\162\155\137\144\141\x74\141") && get_site_option("\155\x6f\x32\146\x5f\154\x6f\x67\x69\156\x5f\146\x6f\162\x6d\137\165\162\x6c"))) {
            goto iN;
        }
        $i1 = get_site_option("\155\x6f\62\x66\137\154\157\147\151\x6e\137\x65\155\141\x69\x6c\x5f\x73\x65\154\x65\x63\164\157\x72");
        $a7 = get_site_option("\x6d\157\x32\146\x5f\154\157\147\x69\x6e\x5f\x70\x61\163\x73\137\163\145\x6c\145\x63\x74\x6f\162");
        $qx = get_site_option("\x6d\x6f\62\x66\137\154\x6f\147\151\156\137\x73\x75\x62\x6d\151\164\x5f\x73\145\154\x65\143\164\x6f\x72");
        $jz = get_site_option("\x6d\x6f\x32\x66\137\x6c\157\147\151\156\137\x70\141\x73\x73\154\x61\x62\145\x6c\x5f\163\x65\x6c\x65\143\x74\x6f\x72");
        $xz = get_site_option("\x6d\x6f\x32\146\137\x6c\x6f\147\151\156\x5f\146\x6f\x72\x6d\x5f\x75\162\154");
        $Xq = get_site_option("\x6d\157\x32\x66\x5f\154\x6f\x67\x69\156\137\x66\x6f\162\x6d\x5f\163\x65\154\x65\x63\x74\x6f\x72");
        update_site_option("\x6d\157\62\x66\x5f\143\x75\163\x74\x6f\155\137\x6c\157\x67\151\156\137\x66\x6f\x72\155\137\x63\157\156\146\x69\147\x75\x72\x61\164\x69\x6f\156\x73", array("\155\157\62\146\x5f\154\x6f\x67\151\156\137\145\155\x61\151\x6c\137\x73\x65\154\145\x63\x74\x6f\162" => $i1, "\155\x6f\62\146\x5f\x6c\157\x67\151\156\x5f\x70\141\x73\x73\137\163\x65\x6c\145\x63\x74\157\162" => $a7, "\x6d\157\62\x66\x5f\x6c\x6f\x67\x69\x6e\137\x73\165\142\x6d\x69\164\137\163\145\x6c\145\143\164\157\x72" => $qx, "\x6d\x6f\62\x66\137\x6c\157\147\x69\156\137\160\141\163\163\x6c\141\142\x65\154\137\163\145\x6c\145\143\x74\x6f\162" => $jz, "\155\x6f\62\x66\137\154\x6f\x67\151\156\x5f\x66\157\x72\155\137\165\162\x6c" => $xz, "\155\157\x32\146\137\x6c\x6f\x67\x69\156\x5f\x66\157\x72\x6d\x5f\x73\145\x6c\x65\x63\x74\157\162" => $Xq));
        update_site_option("\155\157\x32\146\137\155\151\147\162\141\x74\x65\137\x63\165\x73\164\x6f\155\x5f\154\x6f\147\151\x6e\137\146\157\162\155\137\x64\x61\164\141", 1);
        iN:
    }
}
new Mo2f_All_Inclusive_Premium_Settings();
OF:
