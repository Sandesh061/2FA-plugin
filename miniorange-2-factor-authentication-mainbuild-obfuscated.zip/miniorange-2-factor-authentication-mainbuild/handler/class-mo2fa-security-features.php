<?php


use TwoFA\Helper\MoWpnsMessages;
if (defined("\101\102\123\120\x41\124\x48")) {
    goto SA;
}
exit;
SA:
if (class_exists("\x4d\x6f\x32\x66\x61\137\x53\x65\143\165\162\151\x74\171\x5f\x46\145\x61\164\165\x72\145\163")) {
    goto J3;
}
class Mo2fa_Security_Features
{
    public function wpns_2fa_features_only()
    {
        update_site_option("\155\x6f\137\167\160\x6e\163\x5f\62\146\141\137\167\151\164\x68\x5f\x6e\145\164\x77\157\x72\x6b\137\163\x65\x63\x75\162\151\164\x79", 0);
        update_site_option("\155\157\137\167\x70\156\163\x5f\62\x66\141\137\167\x69\164\x68\x5f\156\145\164\x77\157\162\x6b\x5f\x73\145\143\165\162\x69\x74\171\137\x70\157\160\x75\160\137\166\151\x73\x69\142\x6c\x65", 0);
        echo "\x3c\163\x63\162\x69\160\164\x3e\167\x69\x6e\x64\x6f\167\56\x6c\157\143\x61\164\151\x6f\156\x2e\x68\x72\145\x66\75\42\x61\x64\x6d\x69\156\56\160\x68\x70\77\x70\x61\x67\145\75\155\x6f\x5f\62\146\x61\137\164\167\157\x5f\146\141\42\x3b\x3c\x2f\x73\x63\x72\151\160\x74\x3e\15\12\x9\x9\11";
    }
    public function wpns_2fa_with_network_security($x9)
    {
        $pd = new MoWpnsMessages();
        $dk = isset($_POST["\x6d\x6f\137\x73\x65\143\x75\x72\x69\164\x79\x5f\x66\x65\141\x74\165\162\145\x73\x5f\x6e\x6f\156\x63\145"]) ? sanitize_key(wp_unslash($_POST["\155\157\137\163\145\143\x75\162\x69\x74\x79\x5f\146\145\x61\164\x75\x72\145\x73\137\156\157\x6e\143\x65"])) : '';
        if (wp_verify_nonce($dk, "\x6d\157\x5f\x32\146\141\x5f\x73\x65\143\165\162\151\164\171\x5f\146\145\141\164\165\162\145\x73\x5f\x6e\x6f\156\143\145")) {
            goto u_;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\x52\122\x4f\122");
        goto b9;
        u_:
        $Nr = isset($x9["\x6d\x6f\137\167\x70\156\x73\137\x32\x66\141\x5f\167\x69\x74\x68\x5f\x6e\x65\x74\167\x6f\162\x6b\137\x73\x65\143\165\162\151\164\x79"]) ? true : false;
        update_site_option("\x6d\x6f\137\x77\x70\156\163\137\62\x66\x61\137\167\151\164\x68\x5f\x6e\x65\x74\167\157\x72\153\137\163\145\x63\x75\x72\x69\164\x79", $Nr);
        if ($Nr) {
            goto HH;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ALL_DISABLED), "\x45\122\122\117\x52");
        goto d4;
        HH:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ALL_ENABLED), "\123\x55\103\103\x45\123\x53");
        d4:
        update_site_option("\155\x6f\137\167\160\x6e\163\x5f\62\x66\141\x5f\x77\x69\164\150\x5f\x6e\x65\164\167\157\x72\153\137\163\145\143\x75\162\x69\164\x79\137\160\x6f\160\x75\x70\x5f\166\151\163\151\142\154\145", 0);
        echo "\11\x9\x9\74\163\x63\x72\x69\x70\164\76\167\151\156\144\x6f\167\x2e\x6c\157\x63\141\164\151\x6f\156\x2e\150\162\x65\146\75\x22\x61\144\155\151\x6e\x2e\160\x68\x70\x3f\160\x61\147\x65\75\155\x6f\x5f\x32\146\x61\x5f\x74\167\x6f\137\x66\x61\42\x3b\x3c\57\163\143\162\151\160\x74\76\xd\12\11\x9\x9\x9";
        b9:
    }
}
new Mo2fa_Security_Features();
J3:
