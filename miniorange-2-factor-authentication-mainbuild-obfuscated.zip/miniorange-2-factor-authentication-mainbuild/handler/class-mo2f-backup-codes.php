<?php


namespace TwoFA\Onprem;

use TwoFA\Onprem\MO2f_Utility;
use TwoFA\Helper\Mo2f_Login_Popup;
use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Helper\Mo2f_Common_Helper;
use WP_REST_Request;
use TwoFA\Helper\MocURL;
if (defined("\101\102\123\x50\101\x54\x48")) {
    goto Os;
}
exit;
Os:
if (class_exists("\x4d\157\62\146\x5f\x42\x61\x63\153\165\x70\x5f\103\x6f\x64\145\163")) {
    goto kL;
}
class Mo2f_Backup_Codes
{
    public function mo2f_use_backup_codes($post)
    {
        $Ty = isset($post["\x73\145\x73\x73\151\x6f\x6e\x5f\x69\x64"]) ? sanitize_text_field($post["\163\145\x73\x73\x69\157\156\x5f\x69\144"]) : null;
        $ok = isset($post["\x72\x65\144\151\x72\x65\x63\164\x5f\x74\x6f"]) ? esc_url_raw($post["\x72\145\144\151\162\145\143\x74\x5f\164\x6f"]) : null;
        $ib = isset($post["\x6c\x6f\147\x69\156\x5f\155\145\x74\150\157\x64"]) ? sanitize_text_field($post["\154\x6f\x67\x69\156\x5f\155\145\x74\x68\x6f\144"]) : '';
        $we = __("\120\154\145\141\163\x65\x20\160\162\x6f\166\x69\144\x65\40\171\x6f\x75\162\x20\x62\x61\x63\x6b\x75\x70\40\x63\157\144\145\x73\56", "\155\151\x6e\151\157\162\141\156\x67\x65\x2d\62\55\x66\x61\143\164\157\x72\x2d\x61\x75\x74\x68\x65\x6e\164\x69\x63\x61\164\x69\x6f\156");
        $this->mo2f_call_backup_code_validation_form($we, $ok, $Ty, $ib);
    }
    public function mo2f_send_backup_codes($post)
    {
        global $Gw;
        $ok = isset($post["\162\x65\144\x69\162\x65\143\164\x5f\x74\x6f"]) ? esc_url_raw(wp_unslash($post["\162\145\144\151\x72\145\x63\x74\137\x74\x6f"])) : '';
        $jg = isset($post["\x73\x65\163\x73\151\x6f\156\137\151\144"]) ? sanitize_text_field(wp_unslash($post["\x73\145\163\x73\x69\157\x6e\137\x69\x64"])) : '';
        $AP = isset($post["\x6c\x6f\147\151\156\137\163\x74\x61\x74\x75\x73"]) ? sanitize_text_field(wp_unslash($post["\154\157\x67\151\156\x5f\163\x74\x61\164\x75\x73"])) : '';
        $m9 = isset($post["\x6c\157\x67\151\x6e\x5f\155\x65\164\150\x6f\x64"]) ? sanitize_text_field(wp_unslash($post["\x6c\157\x67\151\156\137\x6d\145\x74\x68\157\x64"])) : '';
        $v1 = MO2f_Utility::mo2f_get_transient($jg, "\x6d\x6f\62\146\137\143\165\162\162\145\156\x74\137\165\163\145\162\137\151\x64");
        $cs = get_user_by("\x69\144", $v1);
        $y2 = $Gw->get_user_detail("\155\157\62\x66\x5f\x75\163\x65\162\x5f\145\155\x61\151\154", $v1) ?? $cs->user_email;
        $ta = new MocURL();
        $oB = $ta->mo2f_get_backup_codes($y2, site_url());
        $oB = apply_filters("\155\x6f\x32\x66\137\142\141\x73\151\x63\x5f\x70\x6c\x61\156\137\163\x65\164\164\x69\156\x67\x73\137\x66\151\x6c\164\x65\162", $oB, "\x67\x65\156\x65\162\x61\x74\x65\137\x62\x61\143\x6b\165\x70\x5f\143\157\144\145\x73", array("\x75\x73\145\x72\137\151\144" => $cs->ID));
        $cB = new Mo2f_Common_Helper();
        $Oc = $cB->mo2f_check_backupcode_status($oB, $v1);
        if ($Oc) {
            goto aH;
        }
        $oB = is_array($oB) ? $oB : explode("\x20", $oB);
        $Oc = $cB->mo2f_send_backcodes_on_email($oB, $y2, $v1);
        aH:
        $this->mo2f_show_backup_code_sent_message($Oc, $AP, $cs, $ok, $jg, $m9);
    }
    public function mo2f_validate_backup_codes($post)
    {
        global $Gw;
        $Ty = isset($post["\x73\145\x73\x73\x69\157\x6e\x5f\151\x64"]) ? sanitize_text_field($post["\x73\145\x73\x73\x69\157\156\x5f\151\144"]) : null;
        $ok = isset($post["\x72\145\x64\x69\x72\x65\143\x74\137\164\157"]) ? esc_url_raw($post["\x72\145\144\151\162\145\x63\164\x5f\164\x6f"]) : null;
        $vC = isset($post["\155\x6f\62\146\x5f\x62\x61\x63\153\165\x70\137\x63\x6f\144\x65"]) ? sanitize_text_field($post["\155\x6f\62\146\137\142\x61\x63\x6b\165\x70\x5f\x63\157\x64\x65"]) : null;
        $ix = isset($post["\x74\x77\x6f\x66\x61\x5f\155\x65\x74\x68\x6f\x64"]) ? sanitize_text_field($post["\164\x77\x6f\146\141\x5f\155\145\164\x68\x6f\144"]) : '';
        $TX = MO2f_Utility::mo2f_get_transient($Ty, "\155\x6f\62\146\x5f\143\165\162\162\145\156\164\137\165\x73\145\162\137\x69\x64");
        $y2 = $Gw->get_user_detail("\x6d\x6f\x32\146\137\165\x73\145\162\137\145\155\x61\x69\154", $TX);
        $this->mo2f_handle_backupcode_validation($vC, $TX, $ok, $Ty, $y2, $ix);
    }
    public function mo2f_show_backup_code_sent_message($Oc, $AP, $cs, $ok, $jg, $m9)
    {
        $cB = new Mo2f_Common_Helper();
        $HE = $cB->mo2f_get_object($m9);
        $HE->mo2f_show_login_prompt($Oc, $AP, $cs, $ok, $jg);
    }
    public function mo2f_show_error_prompt($we, $current_user, $ok, $jg, $ix)
    {
        $yV = new Mo2f_Login_Popup();
        $AP = MoWpnsConstants::MO2F_ERROR_MESSAGE_PROMPT;
        $gH = $yV->mo2f_twofa_login_prompt_skeleton_values($we, $AP, null, null, $current_user->ID, '');
        $XZ = $yV->mo2f_get_twofa_skeleton_html($AP, $we, '', '', $gH, $ix, '');
        $XZ .= $yV->mo2f_get_validation_popup_script('', $ix, '', '');
        exit;
    }
    public function mo2f_call_backup_code_validation_form($we, $ok, $Ty, $ib)
    {
        $yV = new Mo2f_Login_Popup();
        $cB = new Mo2f_Common_Helper();
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\155\x6f\62\x66\137\143\165\x72\x72\145\x6e\x74\x5f\x75\x73\145\162\x5f\151\144");
        $cB->mo2f_echo_js_css_files();
        $AP = MoWpnsConstants::MO_2_FACTOR_USE_BACKUP_CODES;
        $gH = $yV->mo2f_twofa_login_prompt_skeleton_values($we, $AP, null, null, $v1, '');
        $XZ = $yV->mo2f_twofa_authentication_login_prompt($AP, $we, $ok, $Ty, $gH, $ib);
        $XZ .= $cB->mo2f_get_hidden_forms_login($ok, $Ty, $AP, $we, $ib, $v1);
        $XZ .= $cB->mo2f_get_hidden_script_login();
        $XZ .= $this->mo2f_get_validation_hidden_form($ok, $Ty);
        $XZ .= $this->mo2f_get_login_script();
        echo $XZ;
        exit;
    }
    public function mo2f_get_validation_hidden_form($ok, $jg)
    {
        $XZ = "\x3c\146\157\x72\155\x20\x6e\x61\155\x65\x3d\x22\155\x6f\62\146\x5f\x62\141\x63\x6b\x75\x70\137\143\x6f\144\x65\137\x76\141\x6c\151\x64\141\164\x69\157\x6e\x5f\146\157\x72\155\42\40\155\x65\164\150\157\x64\x3d\42\160\157\x73\x74\42\x20\x61\143\164\151\x6f\156\x3d\42\42\x20\x69\144\x3d\x22\155\157\62\x66\137\142\141\143\153\x75\160\x5f\x63\157\x64\145\x5f\x76\141\154\151\x64\x61\x74\x69\157\x6e\137\x66\157\x72\x6d\42\40\x73\x74\x79\154\145\75\42\x64\151\163\160\154\x61\x79\x3a\156\x6f\x6e\145\73\x22\76\15\12\x9\x9\x9\x3c\x69\x6e\x70\165\x74\x20\164\x79\160\145\75\42\150\151\144\144\145\156\42\x20\x6e\141\155\145\75\x22\162\x65\144\x69\162\145\143\x74\x5f\x74\157\42\x20\x76\x61\x6c\x75\x65\x3d\42" . esc_url($ok) . "\42\57\x3e\xd\xa\x9\11\11\x3c\151\x6e\x70\165\164\x20\164\x79\x70\x65\x3d\42\150\x69\144\x64\145\156\42\x20\156\x61\155\x65\x3d\42\x73\x65\x73\163\151\157\x6e\x5f\151\x64\42\40\x76\141\154\x75\145\75\x22" . esc_attr($jg) . "\x22\57\x3e\15\xa\11\x9\11\x3c\x69\x6e\160\x75\164\x20\164\171\160\x65\75\42\150\151\x64\x64\x65\x6e\42\x20\156\141\155\145\x3d\x22\x6f\160\164\x69\157\x6e\42\x20\166\141\x6c\165\x65\x3d\42\x6d\x6f\x32\146\x5f\142\141\x63\x6b\165\x70\137\x63\x6f\x64\x65\x5f\x76\141\x6c\x69\144\x61\x74\151\x6f\x6e\x5f\163\165\x63\143\x65\x73\x73\42\x2f\76\15\xa\11\x9\x9\x3c\151\x6e\160\x75\x74\x20\x74\x79\160\x65\x3d\42\150\151\x64\x64\145\x6e\x22\40\x6e\x61\x6d\x65\75\x22\155\151\x6e\x69\x6f\162\141\156\x67\145\137\151\156\154\x69\156\145\x5f\163\x61\166\145\x5f\62\146\x61\x63\164\x6f\x72\x5f\x6d\x65\164\x68\157\144\x5f\156\x6f\156\143\x65\42\40\x76\141\x6c\x75\x65\75\x22" . esc_attr(wp_create_nonce("\155\x69\156\x69\157\162\141\156\x67\145\55\x32\55\146\141\x63\164\157\162\x2d\151\x6e\x6c\151\156\145\x2d\x73\x61\x76\x65\55\x32\x66\x61\x63\x74\157\x72\55\155\x65\164\x68\157\x64\55\156\x6f\156\143\x65")) . "\x22\57\76\xd\12\x9\11\x3c\x2f\x66\157\x72\x6d\x3e";
        return $XZ;
    }
    public function mo2f_get_login_script()
    {
        $cB = new Mo2f_Common_Helper();
        $lW = "\74\x73\x63\162\151\160\x74\x3e\11\x9\11\x6a\x51\165\145\x72\x79\50\x22\43\x6d\x6f\62\146\x5f\x76\x61\154\x69\x64\x61\164\x65\42\51\x2e\143\x6c\x69\143\153\x28\x66\165\x6e\x63\x74\151\x6f\156\x28\x29\x20\173" . $cB->mo2f_show_loader() . "\xd\12\x9\x9\11\11\166\141\x72\40\156\x6f\x6e\143\145\x20\75\x20\x22" . wp_create_nonce("\x6d\x6f\55\164\167\x6f\55\x66\x61\x63\164\x6f\162\55\x61\x6a\141\170\55\156\x6f\x6e\143\x65") . "\x22\x3b\15\xa\x9\11\x9\x9\x76\141\162\x20\x61\152\141\x78\x75\x72\154\40\75\x20\42" . esc_js(admin_url("\x61\x64\155\151\x6e\x2d\141\152\141\x78\x2e\x70\150\160")) . "\42\x3b\15\12\11\11\11\11\166\141\162\40\x64\x61\164\x61\40\x3d\40\x7b\xd\12\x9\11\11\11\11\141\x63\x74\x69\x6f\x6e\72\40\x22\155\157\x5f\x74\167\157\137\146\141\x63\x74\x6f\162\137\x61\x6a\x61\170\x22\x2c\15\12\11\x9\x9\11\x9\155\x6f\137\x32\x66\x5f\x74\x77\x6f\137\146\141\143\164\157\162\x5f\141\x6a\x61\x78\x3a\40\42\155\157\62\146\137\x76\x61\x6c\x69\144\x61\x74\x65\137\142\141\143\x6b\x75\160\x5f\143\157\x64\x65\163\42\54\15\xa\x9\x9\x9\11\x9\x74\167\x6f\146\x61\x5f\x6d\145\x74\150\x6f\144\x3a\x20\x6a\121\x75\145\162\171\50\x22\x69\156\x70\165\164\133\156\141\x6d\145\75\x27\x6d\x6f\62\146\x5f\154\x6f\x67\151\156\x5f\x6d\x65\164\150\x6f\x64\x27\135\42\51\56\166\141\x6c\50\51\54\xd\xa\11\x9\x9\x9\x9\162\x65\144\x69\162\x65\143\164\x5f\164\157\x3a\40\152\x51\165\145\x72\171\x28\42\151\x6e\160\x75\x74\133\156\141\155\x65\x3d\47\x72\x65\x64\x69\162\x65\143\x74\x5f\164\157\x27\135\x22\51\x2e\x76\141\x6c\x28\x29\54\xd\12\11\11\11\x9\x9\163\x65\x73\x73\151\x6f\x6e\137\151\x64\x3a\x20\152\121\x75\145\162\171\50\42\x69\156\x70\x75\164\133\156\x61\x6d\x65\x3d\47\163\x65\x73\163\151\157\x6e\137\151\x64\47\135\x22\x29\x2e\x76\141\154\x28\x29\54\xd\xa\x9\11\x9\11\11\x6d\157\x32\146\x5f\x62\x61\143\153\165\160\137\143\x6f\144\145\x3a\x20\x6a\x51\x75\x65\x72\x79\x28\42\x69\x6e\x70\x75\164\x5b\x6e\141\155\145\x3d\x27\x6d\x6f\x32\x66\137\142\x61\143\153\x75\160\x5f\143\157\144\x65\x27\x5d\42\x29\x2e\166\x61\x6c\x28\51\x2c\xd\xa\x9\x9\11\11\11\x6e\157\156\x63\x65\72\x20\156\157\x6e\143\145\54\15\xa\11\x9\x9\x9\x7d\x3b\xd\xa\11\11\x9\x9\152\x51\x75\145\162\x79\56\x70\x6f\163\x74\50\141\x6a\x61\170\165\162\154\54\x20\x64\x61\164\x61\x2c\x20\x66\165\156\x63\164\151\157\x6e\50\162\145\x73\x70\x6f\x6e\163\x65\51\40\173\xd\xa\11\11\11\11" . $cB->mo2f_hide_loader() . "\15\xa\11\11\11\x9\11\x69\146\40\x28\162\145\x73\x70\x6f\x6e\x73\x65\56\x73\x75\143\143\145\163\163\51\40\173\15\xa\x9\11\x9\x9\11\x9\x6a\x51\x75\145\162\x79\50\42\x23\155\x6f\x32\146\137\142\141\x63\x6b\x75\160\137\143\157\144\145\137\x76\141\154\151\144\x61\164\x69\x6f\x6e\137\x66\157\x72\155\x22\x29\56\x73\x75\142\x6d\151\x74\x28\x29\x3b\15\xa\11\x9\11\11\11\x7d\40\x65\154\x73\x65\40\x7b\15\xa\11\x9\11\11\11\11\x6d\x6f\x32\146\x5f\163\150\x6f\167\137\x6d\145\163\x73\x61\x67\x65\50\162\x65\x73\x70\x6f\156\163\145\x2e\x64\141\x74\x61\x29\73\15\12\x9\11\11\11\x9\x7d\xd\12\x9\x9\x9\x9\175\x29\x3b\15\xa\x9\x9\11\x7d\x29\73\xd\xa\x9\11\74\57\x73\x63\x72\x69\160\x74\x3e";
        return $lW;
    }
    public function mo2f_handle_backupcode_validation($vC, $TX, $ok, $Ty, $y2, $ix)
    {
        do_action("\155\157\62\146\x5f\142\141\x73\x69\143\x5f\x70\x6c\141\156\x5f\163\145\x74\164\151\156\x67\163\137\141\143\164\151\157\x6e", "\x68\x61\x6e\144\x6c\145\137\x62\x61\x63\153\x75\160\143\157\144\145\x5f\166\x61\154\x69\x64\141\x74\x69\x6f\156", array("\x75\163\145\x72\137\x69\x64" => $TX, "\x62\x61\x63\x6b\x75\x70\137\x63\x6f\x64\x65" => $vC));
        if (isset($vC)) {
            goto tk;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_BACKUP_CODES));
        goto cr;
        tk:
        $ta = new MocURL();
        $mC = $ta->mo2f_validate_backup_codes($vC, $y2);
        if ("\x73\x75\143\143\145\163\163" === $mC) {
            goto UR;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_BACKUPCODE));
        goto Mz;
        UR:
        $rT = new Miniorange_Authentication();
        $rT->mo2f_delete_user($TX);
        wp_send_json_success(MoWpnsMessages::lang_translate(MoWpnsMessages::BACKUPCODE_VALIDATED));
        Mz:
        cr:
    }
    public function mo2f_backup_code_validation_success($post)
    {
        global $Gw;
        $Ty = isset($post["\x73\x65\x73\x73\151\x6f\156\137\151\x64"]) ? sanitize_text_field(wp_unslash($post["\163\145\x73\163\x69\157\156\x5f\x69\x64"])) : '';
        $ok = isset($post["\162\x65\144\x69\x72\145\143\164\137\164\157"]) ? esc_url_raw(wp_unslash($post["\x72\x65\144\x69\162\x65\143\164\137\x74\157"])) : '';
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\x6d\157\62\x66\x5f\143\x75\162\x72\145\x6e\x74\137\165\x73\145\x72\x5f\x69\144");
        if (!get_site_option("\x6d\x6f\62\x66\x5f\x64\x69\x73\141\142\x6c\145\137\151\156\x6c\x69\156\145\x5f\162\145\147\151\x73\x74\x72\141\x74\151\x6f\156")) {
            goto lX;
        }
        $QN = new Mo2f_Main_Handler();
        $QN->mo2fa_pass2login($ok, $Ty);
        goto LB;
        lX:
        $Gw->insert_user($v1);
        $we = "\120\154\145\x61\163\145\x20\143\157\156\146\x69\x67\165\x72\145\x20\x79\157\x75\x72\40\x32\x46\101\x20\141\x67\141\x69\x6e\40\163\x6f\40\x74\150\141\164\40\x79\x6f\x75\x20\143\141\x6e\40\x61\x76\157\x69\144\40\x62\x65\151\156\147\x20\x6c\x6f\x63\x6b\x65\x64\40\x6f\x75\x74\56";
        $Aw = new Mo2f_Inline_Popup();
        $Gw->update_user_details($v1, array("\x75\x73\145\162\x5f\x72\x65\x67\x69\x73\x74\162\x61\x74\x69\x6f\156\x5f\167\x69\x74\150\x5f\x6d\151\156\x69\157\162\x61\156\147\x65" => "\123\x55\x43\103\x45\x53\x53"));
        $Aw->prompt_user_to_select_2factor_mthod_inline($v1, $we, $ok, $Ty);
        exit;
        LB:
        exit;
    }
}
new Mo2f_Backup_Codes();
kL:
