<?php


if (defined("\101\102\123\x50\101\124\110")) {
    goto nU;
}
exit;
nU:
use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Helper\Mo2f_Common_Helper;
if (class_exists("\x4d\157\x32\x66\x5f\x41\144\166\x61\156\x63\x65\x5f\123\145\164\164\x69\x6e\x67\x73\x5f\110\141\x6e\x64\x6c\x65\162")) {
    goto e9;
}
class Mo2f_Advance_Settings_Handler
{
    public function __construct()
    {
        add_action("\x61\x64\155\151\x6e\137\x69\x6e\151\x74", array($this, "\x6d\x6f\x5f\62\x66\137\x74\167\x6f\137\x66\x61\x63\x74\157\x72"));
    }
    public function mo_2f_two_factor()
    {
        add_action("\x77\x70\137\141\152\x61\170\137\155\157\62\x66\137\141\144\x76\141\x6e\x63\x65\x5f\163\x65\164\164\151\156\147\x73\137\141\x6a\141\x78", array($this, "\155\x6f\62\x66\137\141\144\x76\x61\x6e\x63\x65\x5f\x73\145\164\x74\x69\156\x67\163\137\x61\x6a\141\x78"));
    }
    public function mo2f_advance_settings_ajax()
    {
        if (!(!check_ajax_referer("\155\157\55\164\x77\157\x2d\x66\141\x63\164\157\x72\x2d\141\x6a\x61\170\55\x6e\157\156\143\x65", "\156\x6f\x6e\x63\x65", false) || !current_user_can("\155\x61\156\141\x67\145\137\157\x70\164\151\x6f\x6e\163"))) {
            goto sG;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG));
        sG:
        $cB = new Mo2f_Common_Helper();
        $cB->mo2f_ilvn();
        $GLOBALS["\155\x6f\x32\146\137\x69\x73\x5f\141\x6a\141\x78\137\162\x65\161\x75\145\163\x74"] = true;
        $Xh = isset($_POST["\157\160\164\x69\x6f\x6e"]) ? sanitize_text_field(wp_unslash($_POST["\x6f\160\164\151\157\x6e"])) : '';
        switch ($Xh) {
            case "\155\157\x5f\167\x70\156\163\137\x6d\x61\156\165\x61\154\137\143\154\145\141\x72":
                $this->mo_wpns_manual_clear();
                goto QI;
            case "\x6d\157\x32\x66\137\x65\x6e\141\x62\x6c\145\x5f\x74\x72\x61\156\x73\141\x63\164\x69\x6f\x6e\x73\x5f\162\x65\160\x6f\162\x74":
                $this->mo2f_enable_transactions_report($_POST);
                goto QI;
            case "\155\x6f\62\146\x5f\160\x61\x73\x73\x77\x6f\x72\144\x6c\x65\x73\163\137\x6c\x6f\147\x69\x6e\137\x73\x65\x74\164\x69\156\147\163":
                do_action("\155\x6f\x32\x66\137\145\x6e\164\x65\x72\x70\x72\x69\x73\145\x5f\160\154\x61\156\x5f\163\x65\164\x74\151\156\147\x73\x5f\x61\x63\x74\151\x6f\x6e", "\155\157\62\x66\x5f\160\141\163\163\x77\157\162\144\154\145\163\x73\137\x6c\x6f\x67\x69\156\x5f\163\x65\164\x74\x69\156\147\163", $_POST);
                goto QI;
            case "\155\x6f\x32\x66\137\x73\141\x76\x65\137\162\x62\x61\137\163\x65\x74\x74\151\x6e\147\x73":
                do_action("\x6d\x6f\x32\146\137\145\156\164\145\162\160\x72\151\163\145\137\x70\154\141\156\137\163\x65\x74\x74\x69\x6e\147\163\x5f\141\143\164\x69\157\x6e", "\x6d\157\62\146\x5f\163\x61\x76\x65\x5f\x72\x62\x61\x5f\x73\x65\x74\164\151\x6e\147\x73", $_POST);
                goto QI;
            case "\x6d\x6f\62\x66\137\x72\x65\155\157\x76\145\137\162\145\x6d\x65\155\142\145\162\x65\x64\137\x64\145\166\151\143\145":
                do_action("\x6d\x6f\62\x66\137\145\x6e\x74\145\162\160\162\151\x73\x65\x5f\x70\x6c\141\x6e\x5f\x73\x65\x74\x74\x69\x6e\x67\x73\137\141\143\164\151\157\x6e", "\155\157\x32\x66\x5f\x72\x65\x6d\x6f\166\x65\137\x72\145\x6d\145\155\x62\145\162\x65\x64\x5f\x64\x65\x76\x69\x63\145", $_POST);
                goto QI;
            case "\x6d\x6f\62\146\x5f\x73\141\166\145\137\163\x65\x73\x73\151\x6f\156\x5f\x6d\141\156\x61\147\x65\x6d\145\x6e\x74\137\163\x65\164\x74\x69\156\147\163":
                do_action("\155\x6f\62\x66\137\145\156\164\x65\162\x70\x72\x69\x73\145\x5f\x70\x6c\141\156\x5f\x73\x65\164\x74\x69\156\147\163\x5f\141\x63\164\x69\157\x6e", "\155\x6f\62\146\x5f\x73\x61\166\x65\x5f\x73\x65\163\x73\x69\157\x6e\137\x6d\141\156\141\x67\145\155\x65\156\x74\137\163\x65\164\x74\x69\156\147\163", $_POST);
                goto QI;
        }
        bO:
        QI:
    }
    public function mo_wpns_manual_clear()
    {
        global $GI;
        $GI->mo_wpns_clear_login_report();
        wp_send_json_success();
    }
    public function mo2f_enable_transactions_report($post)
    {
        $Ji = isset($post["\x6d\157\x32\x66\137\x65\156\141\142\x6c\x65\137\x74\162\x61\156\x73\141\x63\164\x69\157\x6e\137\x72\x65\160\157\x72\x74"]) ? sanitize_text_field(wp_unslash($post["\155\x6f\62\x66\x5f\x65\156\x61\x62\154\145\137\164\162\x61\x6e\x73\141\143\x74\x69\x6f\x6e\137\162\x65\x70\x6f\x72\164"])) : 0;
        update_site_option("\x6d\x6f\62\x66\x5f\x65\156\x61\x62\154\145\137\x6c\157\x67\151\156\x5f\x72\x65\x70\x6f\162\164", $Ji);
        wp_send_json($Ji);
    }
}
new Mo2f_Advance_Settings_Handler();
e9:
