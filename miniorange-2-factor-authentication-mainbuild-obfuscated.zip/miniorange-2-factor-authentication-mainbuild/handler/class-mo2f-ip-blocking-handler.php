<?php


if (defined("\101\x42\123\x50\101\x54\110")) {
    goto sZ;
}
exit;
sZ:
use TwoFA\Helper\MoWpnsHandler;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Helper\MoWpnsMessages;
if (class_exists("\x4d\x6f\x32\x66\137\111\120\137\x42\154\x6f\143\153\x69\x6e\x67\137\x48\141\156\144\154\x65\x72")) {
    goto Vl;
}
class Mo2f_IP_Blocking_Handler
{
    public function __construct()
    {
        add_action("\141\144\x6d\151\x6e\x5f\151\156\151\x74", array($this, "\x6d\157\x5f\62\x66\137\x74\x77\157\137\x66\141\143\x74\157\162"));
        add_action("\141\x64\x6d\x69\156\x5f\x69\156\x69\x74", array($this, "\x6d\x6f\62\146\x5f\x68\x61\156\144\154\x65\x5f\x61\x64\x76\141\156\143\x65\x64\137\x62\x6c\157\143\153\x69\156\147"));
    }
    public function mo_2f_two_factor()
    {
        add_action("\167\160\137\141\x6a\141\x78\137\x6d\157\x32\x66\137\151\x70\x5f\x62\x6c\x61\143\153\x5f\x6c\151\163\164\137\x61\x6a\141\170", array($this, "\x6d\157\62\146\137\x69\160\x5f\142\x6c\141\x63\153\x5f\154\x69\x73\x74\137\141\152\x61\x78"));
    }
    public function mo2f_handle_advanced_blocking()
    {
        if (!(current_user_can("\x6d\141\156\141\147\x65\x5f\x6f\160\x74\x69\x6f\156\x73") && isset($_POST["\x6f\x70\164\x69\157\x6e"]) && isset($_POST["\x6d\157\62\146\x5f\x73\x65\x63\165\x72\x69\x74\x79\x5f\146\x65\141\x74\x75\162\145\x73\137\x6e\157\156\143\x65"]))) {
            goto sJ;
        }
        if (!wp_verify_nonce(sanitize_key($_POST["\155\157\62\146\137\163\x65\143\165\x72\151\x74\x79\137\146\145\141\164\x75\162\145\163\137\156\x6f\x6e\143\145"]), "\x6d\157\62\146\137\163\145\x63\x75\162\151\x74\x79\137\x6e\x6f\x6e\143\145")) {
            goto aK;
        }
        switch (sanitize_text_field(wp_unslash($_POST["\x6f\x70\x74\x69\157\156"]))) {
            case "\x6d\157\x5f\x77\x70\156\163\x5f\142\154\157\x63\153\137\x69\160\137\x72\x61\x6e\x67\145":
                $this->wpns_handle_range_blocking($_POST);
                goto o4;
        }
        lv:
        o4:
        goto En;
        aK:
        $pd = new MoWpnsMessages();
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\x52\x52\x4f\x52");
        En:
        sJ:
    }
    public function mo2f_ip_black_list_ajax()
    {
        if (check_ajax_referer("\155\x6f\62\x66\55\151\160\55\x62\x6c\x61\x63\x6b\55\x6c\151\x73\x74\55\141\x6a\x61\x78\x2d\156\157\156\x63\145", "\x6e\157\156\143\x65", false)) {
            goto SJ;
        }
        wp_send_json_error("\x63\154\x61\163\x73\55\x77\x70\156\x73\55\141\x6a\141\x78");
        SJ:
        $GLOBALS["\x6d\x6f\62\x66\137\151\x73\x5f\141\x6a\x61\170\137\x72\x65\161\165\145\163\164"] = true;
        $Xh = isset($_POST["\x6f\x70\x74\151\157\x6e"]) ? sanitize_text_field(wp_unslash($_POST["\x6f\x70\164\x69\157\156"])) : '';
        switch ($Xh) {
            case "\x6d\x6f\x5f\167\160\x6e\x73\137\155\x61\156\165\141\154\137\x62\x6c\157\143\x6b\137\151\160":
                $this->wpns_handle_manual_block_ip($_POST);
                goto ZR;
            case "\155\157\137\x77\160\156\163\137\167\x68\151\x74\145\154\x69\x73\164\x5f\x69\160":
                $this->wpns_handle_whitelist_ip($_POST);
                goto ZR;
            case "\167\160\x6e\163\x5f\x69\160\x5f\x6c\x6f\x6f\153\x75\160":
                $this->wpns_ip_lookup();
                goto ZR;
            case "\x6d\x6f\137\x77\x70\156\163\x5f\165\x6e\142\x6c\157\143\x6b\x5f\x69\x70":
                $this->wpns_handle_unblock_ip($_POST);
                goto ZR;
            case "\x6d\x6f\x5f\167\x70\x6e\x73\x5f\162\145\x6d\x6f\166\145\137\167\150\x69\164\145\x6c\151\x73\x74":
                $this->wpns_handle_remove_whitelist($_POST);
                goto ZR;
        }
        Hs:
        ZR:
    }
    public function wpns_handle_manual_block_ip($post)
    {
        global $uz;
        $CG = isset($post["\x49\120"]) ? sanitize_text_field(wp_unslash($post["\111\x50"])) : '';
        if (!$uz->check_empty_or_null($CG)) {
            goto fL;
        }
        echo "\145\155\x70\164\171\40\111\120";
        exit;
        fL:
        if (!preg_match("\57\x5e\134\x64\173\61\x2c\63\x7d\134\56\x5c\144\173\x31\x2c\x33\175\x5c\x2e\x5c\144\173\x31\x2c\63\175\134\56\134\144\173\61\x2c\x33\175\x5c\x7a\x2f", $CG)) {
            goto kZ;
        }
        $nb = filter_var($CG, FILTER_VALIDATE_IP) ? $CG : "\x49\x4e\x56\101\x4c\x49\104\x5f\111\x50\137\x46\x4f\122\x4d\101\x54";
        $wB = new MoWpnsHandler();
        $kv = $wB->is_whitelisted($nb);
        if (!$kv) {
            goto lG;
        }
        echo "\111\x50\x5f\111\x4e\137\x57\110\x49\x54\x45\114\x49\x53\x54\x45\104";
        exit;
        goto dX;
        lG:
        if ($wB->mo_wpns_is_ip_blocked($nb)) {
            goto Gf;
        }
        $wB->mo_wpns_block_ip($nb, MoWpnsConstants::BLOCKED_BY_ADMIN, true);
        echo "\11\x9\x9\11\11\x9\11\74\164\x61\x62\154\x65\x20\x69\x64\75\x22\142\x6c\x6f\143\153\x65\x64\x69\160\163\137\x74\141\142\154\145\61\x22\40\x63\x6c\x61\x73\163\x3d\42\x64\151\x73\160\154\141\171\x22\76\xd\xa\11\x9\x9\11\11\x9\74\x74\150\145\141\x64\76\74\164\162\76\74\164\x68\76\111\120\x20\x41\x64\144\x72\145\x73\163\46\x65\x6d\163\160\x3b\x26\145\155\163\160\73\x3c\57\164\150\76\x3c\x74\x68\x3e\x52\145\141\163\x6f\156\x26\x65\155\163\x70\73\46\x65\x6d\163\x70\x3b\74\57\x74\x68\x3e\74\x74\x68\x3e\x42\x6c\157\143\x6b\145\144\x20\x55\156\x74\151\x6c\46\x65\155\x73\160\x3b\46\145\x6d\163\160\73\74\x2f\164\x68\76\74\x74\150\76\102\x6c\157\x63\153\x65\x64\x20\104\141\164\145\x26\x65\155\x73\x70\x3b\x26\x65\x6d\163\160\x3b\74\x2f\164\x68\x3e\74\x74\150\76\101\x63\x74\x69\157\156\46\145\155\x73\x70\x3b\46\x65\x6d\x73\160\x3b\x3c\x2f\x74\150\x3e\74\x2f\x74\162\76\74\57\164\x68\x65\x61\x64\76\xd\xa\x9\x9\11\11\x9\x9\74\164\142\157\x64\171\x3e\xd\xa\11\x9\x9\x9\11\x9";
        $g8 = new MoWpnsHandler();
        $F8 = $g8->get_blocked_ips();
        $tB = $g8->get_whitelisted_ips();
        global $V0;
        foreach ($F8 as $Zj) {
            echo "\x3c\x74\162\40\143\154\141\163\x73\x3d\x27\155\157\137\167\160\x6e\163\137\x6e\157\x74\x5f\x62\157\x6c\x64\x27\x3e\74\164\144\x3e" . esc_html($Zj->ip_address) . "\x3c\x2f\164\144\x3e\74\164\x64\x3e" . esc_html($Zj->reason) . "\x3c\57\x74\144\x3e\x3c\x74\x64\76";
            if (empty($Zj->blocked_for_time)) {
                goto Kp;
            }
            echo esc_html(gmdate("\x4d\x20\x6a\x2c\x20\131\x2c\40\147\x3a\x69\72\x73\x20\x61", $Zj->blocked_for_time));
            goto Id;
            Kp:
            echo "\74\163\160\x61\x6e\x20\x63\154\141\163\163\x3d\x72\x65\x64\x74\x65\x78\x74\x3e\120\x65\x72\155\x61\156\x65\156\x74\154\171\x3c\x2f\163\x70\141\x6e\x3e";
            Id:
            echo "\x3c\x2f\164\x64\x3e\x3c\164\x64\76" . esc_html(gmdate("\x4d\x20\x6a\54\x20\x59\54\x20\147\x3a\151\x3a\163\40\141", $Zj->created_timestamp)) . "\74\57\x74\144\x3e\x3c\x74\x64\x3e\74\x61\x20\40\x6f\156\x63\x6c\151\143\x6b\75\x75\156\142\154\157\143\153\x69\160\x28\47" . esc_js($Zj->id) . "\47\x29\76\125\x6e\x62\x6c\x6f\143\x6b\40\111\x50\74\x2f\141\76\74\x2f\x74\x64\x3e\x3c\57\164\162\76";
            Si:
        }
        Du:
        echo "\11\x9\11\11\11\11\11\x3c\57\164\x62\x6f\x64\x79\x3e\xd\xa\11\11\x9\11\11\11\11\74\57\x74\141\142\x6c\145\76\15\xa\11\11\11\x9\11\x9\x9\x3c\163\143\x72\151\160\x74\x20\x74\171\160\x65\x3d\x22\164\145\x78\164\x2f\x6a\141\x76\x61\x73\x63\162\151\x70\x74\x22\76\xd\12\x9\11\11\x9\x9\11\11\x9\152\121\165\x65\162\x79\x28\42\x23\x62\154\157\143\153\145\x64\151\160\x73\x5f\x74\x61\x62\154\145\61\x22\x29\x2e\x44\141\x74\141\x54\141\142\154\145\x28\173\15\12\x9\11\x9\x9\11\11\11\x9\42\157\162\144\145\x72\x22\72\x20\133\x5b\x20\x33\x2c\x20\x22\x64\145\163\143\x22\x20\135\135\15\12\x9\x9\11\11\x9\11\x9\x9\x7d\x29\73\xd\12\11\x9\11\11\11\x9\11\x3c\x2f\163\x63\162\151\x70\x74\76\xd\xa\11\11\11\11\11\11";
        exit;
        goto c_;
        Gf:
        echo "\x61\154\x72\145\x61\x64\x79\40\x62\154\x6f\143\153\145\144";
        exit;
        c_:
        dX:
        goto De;
        kZ:
        echo "\x49\x4e\x56\x41\x4c\111\104\137\111\x50\137\106\x4f\x52\115\101\x54";
        exit;
        De:
    }
    public function wpns_handle_whitelist_ip($post)
    {
        global $uz;
        $CG = isset($post["\x49\120"]) ? sanitize_text_field(wp_unslash($post["\x49\x50"])) : '';
        if (!$uz->check_empty_or_null($CG)) {
            goto SI;
        }
        echo "\105\x4d\x50\x54\131\40\x49\x50";
        exit;
        SI:
        if (!preg_match("\x2f\x5e\134\x64\173\61\54\x33\175\x5c\56\134\x64\x7b\x31\x2c\63\x7d\134\56\134\144\x7b\x31\54\63\x7d\x5c\x2e\x5c\144\x7b\x31\x2c\63\x7d\x5c\172\x2f", $CG)) {
            goto Gl;
        }
        $nb = filter_var($CG, FILTER_VALIDATE_IP) ? $CG : "\x49\116\126\x41\114\111\104\x5f\x49\120";
        $wB = new MoWpnsHandler();
        if ($wB->is_whitelisted($nb)) {
            goto FF;
        }
        $wB->whitelist_ip($CG);
        $g8 = new MoWpnsHandler();
        $tB = $g8->get_whitelisted_ips();
        echo "\x9\x9\x9\11\x3c\x74\141\x62\154\145\40\x69\144\75\42\x77\x68\151\164\145\154\x69\163\164\x65\x64\151\x70\163\x5f\164\141\142\154\145\x31\42\40\143\154\x61\x73\163\x3d\x22\144\151\163\x70\x6c\141\171\42\76\xd\xa\x9\x9\11\11\x3c\164\150\x65\141\144\76\x3c\x74\x72\x3e\74\164\150\x20\x3e\x49\120\40\x41\x64\144\162\x65\163\x73\74\x2f\164\150\76\x3c\x74\x68\40\x3e\x57\x68\x69\x74\x65\154\x69\163\164\x65\144\x20\x44\x61\x74\x65\x3c\57\x74\150\x3e\74\x74\150\x20\x3e\122\x65\x6d\x6f\166\x65\x20\x66\162\x6f\x6d\40\127\150\151\x74\x65\154\151\x73\164\x3c\57\164\x68\x3e\x3c\57\164\x72\76\x3c\57\164\150\x65\x61\x64\x3e\xd\12\11\11\x9\11\x3c\x74\x62\157\x64\171\x3e\15\xa\x9\x9\11\x9\11";
        foreach ($tB as $Hu) {
            echo "\74\164\162\x20\x63\x6c\x61\x73\x73\x3d\47\155\x6f\137\x77\160\156\x73\137\x6e\x6f\164\137\x62\157\154\144\x27\76\74\x74\x64\x3e" . esc_html($Hu->ip_address) . "\x3c\57\x74\x64\x3e\x3c\x74\x64\76" . esc_html(gmdate("\115\40\x6a\x2c\40\131\x2c\40\x67\72\x69\x3a\163\40\141", $Hu->created_timestamp)) . "\x3c\57\x74\144\x3e\74\x74\144\x3e\x3c\141\x20\x20\x6f\x6e\143\x6c\151\143\153\75\162\145\x6d\x6f\x76\x65\x66\162\x6f\155\x77\150\x69\164\x65\154\x69\x73\x74\50\x27" . esc_js($Hu->id) . "\x27\x29\76\x52\x65\x6d\157\166\145\74\57\x61\76\74\57\164\x64\76\74\x2f\164\162\76";
            oV:
        }
        hv:
        echo "\11\x9\11\11\74\57\x74\142\157\144\x79\76\15\12\x9\11\x9\x9\x3c\57\164\141\142\x6c\x65\x3e\15\12\11\x9\11\x3c\x73\143\162\151\x70\164\x20\x74\x79\x70\145\x3d\42\x74\x65\x78\164\x2f\152\141\166\141\x73\x63\162\151\160\164\42\76\xd\12\x9\11\x9\11\x6a\x51\165\x65\162\x79\x28\42\x23\x77\x68\x69\164\145\x6c\151\x73\164\x65\x64\x69\x70\163\x5f\x74\141\x62\x6c\x65\x31\42\51\56\104\x61\x74\141\x54\x61\142\x6c\x65\50\173\15\12\x9\x9\11\11\42\x6f\x72\x64\x65\x72\42\x3a\x20\133\x5b\x20\61\x2c\40\42\x64\145\x73\143\x22\x20\135\135\15\12\11\x9\11\11\x7d\51\73\xd\12\x9\x9\x9\74\x2f\x73\143\162\x69\x70\x74\76\xd\xa\xd\12\11\x9\11\x9\11";
        exit;
        goto UB;
        FF:
        echo "\x49\x50\137\101\x4c\122\105\101\x44\131\x5f\127\110\x49\124\x45\114\x49\x53\x54\x45\x44";
        exit;
        UB:
        goto ik;
        Gl:
        echo "\111\x4e\126\x41\x4c\111\104\x5f\x49\120";
        exit;
        ik:
    }
    public function wpns_ip_lookup()
    {
        if (!check_ajax_referer("\x4c\x6f\x67\x69\156\x53\145\143\165\162\151\164\x79\x4e\x6f\156\x63\x65", "\x6e\157\156\143\145", false)) {
            goto qT;
        }
        $CG = isset($_POST["\x49\120"]) ? sanitize_text_field(wp_unslash($_POST["\111\120"])) : '';
        if (!preg_match("\x2f\136\x5c\x64\x7b\x31\54\x33\x7d\134\56\134\x64\173\x31\54\x33\x7d\x5c\56\134\x64\173\61\54\63\x7d\134\x2e\x5c\144\173\x31\x2c\x33\175\134\x7a\x2f", $CG)) {
            goto rF;
        }
        if (!filter_var($CG, FILTER_VALIDATE_IP)) {
            goto Uf;
        }
        goto Ih;
        rF:
        wp_send_json_error("\111\x4e\126\101\114\111\104\137\111\x50\137\106\x4f\122\115\101\124");
        goto Ih;
        Uf:
        wp_send_json_error("\111\116\126\101\x4c\111\x44\x5f\111\x50");
        Ih:
        $vv = wp_remote_get("\150\164\x74\160\x3a\x2f\x2f\x77\167\x77\56\x67\x65\157\160\x6c\x75\147\151\x6e\56\156\145\x74\57\x6a\163\x6f\156\56\147\x70\x3f\x69\160\75" . $CG);
        if (is_wp_error($vv)) {
            goto Ig;
        }
        $vv = json_decode(wp_remote_retrieve_body($vv), true);
        Ig:
        try {
            $u3 = timezone_offset_get(new DateTimeZone($vv["\x67\x65\157\x70\x6c\165\147\151\156\x5f\164\x69\x6d\145\172\157\156\145"]), new DateTime("\156\x6f\x77"));
            $u3 = $u3 / 3600;
        } catch (Exception $vA) {
            $vv["\147\x65\157\160\154\x75\147\x69\x6e\137\164\x69\x6d\145\x7a\x6f\x6e\145"] = '';
            $u3 = '';
        }
        $kz = MoWpnsConstants::IP_LOOKUP_TEMPLATE;
        if ($vv["\x67\145\x6f\x70\x6c\165\147\x69\156\x5f\x72\x65\x71\x75\145\163\x74"] === $CG) {
            goto Yq;
        }
        $vv["\151\160\x44\145\164\141\151\154\163"]["\x73\164\x61\164\165\x73"] = "\105\x52\x52\117\x52";
        goto i5;
        Yq:
        $Kn = array("\163\x74\141\x74\165\163" => "\x67\x65\x6f\160\x6c\165\147\x69\x6e\137\163\x74\x61\x74\x75\x73", "\151\160" => "\147\145\157\x70\x6c\165\x67\151\156\137\162\x65\x71\x75\145\x73\x74", "\162\x65\147\x69\157\156" => "\147\145\157\160\x6c\x75\x67\151\156\x5f\x72\x65\147\151\157\156", "\143\157\x75\x6e\164\x72\x79" => "\147\x65\x6f\x70\x6c\165\147\151\x6e\x5f\143\x6f\165\x6e\164\x72\x79\116\x61\x6d\145", "\x63\x69\x74\171" => "\x67\145\x6f\160\154\x75\x67\151\156\x5f\x63\x69\x74\171", "\x63\157\156\x74\151\156\x65\156\x74" => "\147\x65\157\x70\x6c\165\x67\x69\x6e\x5f\143\x6f\156\164\x69\x6e\145\156\164\x4e\x61\155\145", "\x6c\x61\164\151\164\165\144\145" => "\147\145\157\160\154\x75\x67\151\x6e\137\x6c\141\164\151\164\x75\144\x65", "\154\x6f\x6e\x67\151\x74\x75\144\145" => "\147\x65\157\160\x6c\x75\x67\x69\x6e\x5f\154\157\156\147\x69\164\x75\144\x65", "\x74\151\x6d\145\x7a\x6f\156\145" => "\x67\x65\157\160\154\x75\x67\151\156\x5f\x74\151\x6d\145\x7a\157\156\145", "\143\x75\162\x72\x65\x6e\x79\137\x63\x6f\144\x65" => "\147\145\x6f\160\x6c\165\x67\x69\x6e\x5f\143\x75\x72\x72\x65\156\143\x79\x43\157\x64\145", "\x63\165\162\x72\145\156\x79\x5f\x73\171\x6d\x62\x6f\154" => "\x67\145\x6f\x70\154\x75\147\151\x6e\x5f\143\165\x72\x72\145\156\143\x79\123\x79\x6d\142\157\154", "\160\x65\x72\137\x64\x6f\154\154\141\162\x5f\166\141\x6c\x75\145" => "\147\145\157\160\154\x75\x67\x69\x6e\137\x63\165\162\x72\145\156\143\171\103\x6f\x6e\166\x65\162\164\x65\x72", "\157\146\146\x73\145\164" => $u3);
        foreach ($Kn as $Pj => $iY) {
            $kz = str_replace("\173\173" . $Pj . "\x7d\x7d", $vv[$iY], $kz);
            eI:
        }
        JE:
        $vv["\x69\x70\x44\x65\x74\x61\x69\154\x73"] = $kz;
        i5:
        wp_send_json($vv);
        goto oL;
        qT:
        wp_send_json_error("\143\154\141\x73\x73\55\x77\160\x6e\163\x2d\141\x6a\141\170");
        oL:
    }
    public function wpns_handle_unblock_ip($post)
    {
        global $uz;
        $lu = isset($post["\x69\x64"]) ? sanitize_text_field(wp_unslash($post["\x69\x64"])) : '';
        if ($uz->check_empty_or_null($lu)) {
            goto Tt;
        }
        $Of = sanitize_text_field($lu);
        $wB = new MoWpnsHandler();
        $wB->unblock_ip_entry($Of);
        echo "\x9\11\11\11\74\x74\141\x62\x6c\145\40\151\x64\75\42\142\154\x6f\143\153\x65\x64\x69\x70\163\x5f\x74\x61\x62\x6c\145\61\x22\x20\143\154\x61\163\163\75\42\144\x69\x73\x70\x6c\141\x79\x22\x3e\xd\xa\x9\11\x9\x9\74\x74\x68\145\x61\x64\x3e\74\164\162\76\74\x74\150\x3e\111\120\x20\x41\144\x64\162\145\163\x73\46\145\155\x73\x70\73\46\145\x6d\x73\x70\x3b\x3c\57\x74\x68\76\x3c\x74\x68\76\x52\145\141\x73\157\x6e\46\145\x6d\x73\x70\x3b\x26\145\x6d\x73\160\73\x3c\57\x74\x68\x3e\x3c\164\150\76\102\154\157\143\153\145\144\40\125\x6e\x74\151\x6c\46\x65\155\163\160\73\x26\x65\x6d\163\x70\x3b\x3c\x2f\164\150\x3e\x3c\x74\x68\x3e\102\x6c\x6f\x63\x6b\x65\144\40\104\x61\x74\145\46\x65\x6d\x73\160\x3b\46\x65\x6d\163\x70\73\74\x2f\x74\x68\x3e\74\164\x68\x3e\x41\143\x74\151\x6f\156\46\x65\x6d\163\160\x3b\46\x65\155\x73\160\x3b\x3c\x2f\x74\150\76\x3c\x2f\x74\162\76\74\57\164\x68\x65\x61\x64\x3e\xd\xa\x9\x9\11\x9\74\164\142\157\x64\x79\76\15\12\x9\11\11\11";
        $g8 = new MoWpnsHandler();
        $F8 = $g8->get_blocked_ips();
        $tB = $g8->get_whitelisted_ips();
        foreach ($F8 as $Zj) {
            echo "\x3c\164\x72\x20\x63\x6c\141\x73\163\75\47\155\157\x5f\x77\160\x6e\163\137\x6e\157\x74\x5f\142\157\154\144\47\x3e\x3c\164\144\76" . esc_html($Zj->ip_address) . "\74\x2f\164\144\76\x3c\x74\144\x3e" . esc_html($Zj->reason) . "\x3c\57\x74\x64\x3e\74\x74\144\x3e";
            if (empty($Zj->blocked_for_time)) {
                goto kA;
            }
            echo esc_html(gmdate("\115\x20\152\54\40\x59\x2c\40\147\72\151\72\163\x20\141", $Zj->blocked_for_time));
            goto ng;
            kA:
            echo "\x3c\x73\160\x61\x6e\40\143\154\x61\x73\x73\75\162\x65\144\164\145\170\164\x3e\x50\x65\162\155\141\x6e\x65\x6e\x74\x6c\x79\x3c\x2f\x73\x70\141\156\x3e";
            ng:
            echo "\74\x2f\164\144\76\74\164\x64\x3e" . esc_html(gmdate("\115\40\152\x2c\40\131\54\x20\x67\x3a\x69\72\163\x20\141", $Zj->created_timestamp)) . "\74\x2f\164\x64\76\74\164\x64\x3e\x3c\141\40\x6f\156\x63\154\x69\x63\153\x3d\165\x6e\x62\x6c\157\x63\x6b\151\160\x28\x27" . esc_js($Zj->id) . "\47\x29\76\125\x6e\x62\154\x6f\143\x6b\x20\111\120\74\x2f\141\76\x3c\57\164\144\x3e\x3c\57\164\x72\x3e";
            wl:
        }
        B3:
        echo "\11\11\11\x9\11\x3c\x2f\164\142\157\x64\x79\x3e\xd\xa\x9\11\11\x9\x9\74\x2f\x74\x61\x62\x6c\x65\x3e\15\12\x9\x9\11\x9\11\74\x73\x63\x72\151\160\x74\40\164\x79\x70\145\75\42\x74\145\170\164\57\152\x61\x76\x61\x73\x63\x72\x69\160\164\42\x3e\xd\xa\11\x9\11\x9\11\11\x6a\x51\x75\x65\x72\x79\50\x22\x23\x62\x6c\x6f\x63\153\145\x64\151\160\163\x5f\164\141\x62\154\145\61\x22\51\x2e\104\141\x74\x61\124\141\x62\154\145\50\173\xd\12\x9\x9\x9\11\11\x9\42\157\x72\x64\x65\x72\x22\x3a\x20\133\x5b\x20\63\x2c\x20\x22\144\x65\x73\x63\42\x20\135\135\15\12\x9\11\x9\11\x9\x9\175\x29\73\xd\xa\11\x9\11\x9\11\74\x2f\x73\x63\162\151\x70\164\76\xd\xa\x9\x9\11\x9";
        exit;
        goto q7;
        Tt:
        echo "\125\116\113\116\117\x57\116\137\x45\x52\122\117\x52";
        exit;
        q7:
    }
    public function wpns_handle_remove_whitelist($post)
    {
        global $uz;
        $lu = isset($post["\x69\x64"]) ? sanitize_text_field(wp_unslash($post["\x69\x64"])) : '';
        if ($uz->check_empty_or_null($lu)) {
            goto P3;
        }
        $Of = isset($lu) ? sanitize_text_field($lu) : '';
        $wB = new MoWpnsHandler();
        $wB->remove_whitelist_entry($Of);
        $g8 = new MoWpnsHandler();
        $tB = $g8->get_whitelisted_ips();
        echo "\x9\x9\11\11\74\164\x61\142\154\x65\x20\151\x64\x3d\x22\x77\x68\x69\x74\x65\x6c\151\x73\x74\145\144\x69\160\x73\137\x74\141\x62\154\x65\x31\x22\40\x63\x6c\141\163\x73\75\x22\x64\x69\x73\x70\154\141\x79\42\76\xd\12\x9\x9\11\11\x3c\164\x68\x65\141\x64\76\74\164\162\x3e\x3c\164\150\40\x3e\111\x50\x20\x41\x64\144\x72\x65\x73\163\74\x2f\x74\150\76\x3c\164\150\40\x3e\127\150\151\164\145\x6c\x69\x73\x74\145\x64\x20\104\141\164\145\x3c\x2f\164\150\76\x3c\x74\x68\x20\x3e\x52\145\155\x6f\x76\x65\40\x66\x72\x6f\x6d\x20\x57\150\x69\164\x65\154\151\x73\x74\x3c\57\x74\x68\76\74\57\x74\162\x3e\74\57\164\150\x65\141\x64\76\15\12\x9\11\11\x9\74\x74\142\x6f\x64\x79\76\15\xa\11\11\11\11";
        foreach ($tB as $Hu) {
            echo "\74\x74\162\x20\143\154\x61\x73\x73\75\47\x6d\157\137\x77\160\156\x73\137\156\157\164\137\x62\157\x6c\x64\x27\76\74\164\144\x3e" . esc_html($Hu->ip_address) . "\x3c\x2f\164\144\76\74\x74\144\x3e" . esc_html(gmdate("\115\x20\x6a\x2c\40\131\54\x20\x67\72\151\x3a\x73\x20\x61", $Hu->created_timestamp)) . "\74\x2f\164\x64\x3e\x3c\x74\x64\76\x3c\x61\40\x6f\x6e\143\x6c\x69\143\153\75\162\x65\x6d\157\x76\145\x66\162\x6f\155\x77\x68\x69\x74\x65\154\x69\x73\164\x28\x27" . esc_js($Hu->id) . "\x27\51\x3e\x52\x65\155\x6f\166\145\x3c\x2f\x61\x3e\x3c\57\x74\144\x3e\x3c\57\164\162\76";
            ao:
        }
        S1:
        echo "\x9\11\11\11\74\x2f\164\142\157\x64\x79\x3e\xd\xa\11\x9\11\x9\74\x2f\164\x61\142\154\145\76\15\xa\x9\11\11\74\x73\x63\x72\151\x70\164\x20\x74\171\x70\x65\75\42\164\x65\x78\164\x2f\152\141\x76\x61\163\143\x72\x69\x70\164\x22\76\15\12\x9\x9\11\x9\152\121\x75\x65\162\x79\x28\42\x23\x77\x68\151\164\x65\x6c\151\163\164\x65\144\151\x70\163\137\164\x61\x62\154\145\x31\42\x29\56\x44\x61\164\x61\x54\x61\142\154\x65\50\173\xd\12\x9\11\11\x9\42\157\x72\144\x65\162\x22\72\x20\x5b\x5b\x20\61\x2c\x20\x22\x64\145\163\143\x22\40\x5d\x5d\15\xa\11\11\x9\x9\x7d\x29\x3b\15\12\x9\x9\x9\74\x2f\163\x63\162\x69\160\x74\76\xd\12\15\12\11\x9\11\11";
        exit;
        goto AM;
        P3:
        echo "\125\x4e\x4b\116\x4f\x57\116\137\x45\122\x52\117\x52";
        exit;
        AM:
    }
    public function wpns_handle_range_blocking($ig)
    {
        $UQ = 0;
        $xN = 100;
        $LH = 0;
        $pd = new MoWpnsMessages();
        $ET = 1;
        s2:
        if (!($ET <= $xN)) {
            goto V3;
        }
        if (!(isset($ig["\163\x74\141\162\x74\137" . $ET]) && isset($ig["\145\156\x64\x5f" . $ET]) && !empty($ig["\163\x74\x61\162\x74\137" . $ET]) && !empty($ig["\145\156\x64\x5f" . $ET]))) {
            goto iD;
        }
        $ig["\x73\x74\x61\162\x74\137" . $ET] = sanitize_text_field($ig["\163\164\x61\162\164\137" . $ET]);
        $ig["\x65\156\144\137" . $ET] = sanitize_text_field($ig["\x65\156\x64\x5f" . $ET]);
        if (filter_var($ig["\x73\x74\141\162\x74\137" . $ET], FILTER_VALIDATE_IP) && filter_var($ig["\145\x6e\x64\137" . $ET], FILTER_VALIDATE_IP) && ip2long($ig["\x65\x6e\144\x5f" . $ET]) > ip2long($ig["\x73\164\x61\162\164\x5f" . $ET])) {
            goto Oj;
        }
        $UQ = 1;
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_IP), "\105\x52\x52\117\x52");
        return;
        goto RJ;
        Oj:
        $Lp = '';
        $Lp = sanitize_text_field($ig["\163\x74\x61\162\164\x5f" . $ET]);
        $Lp .= "\55";
        $Lp .= sanitize_text_field($ig["\x65\x6e\144\x5f" . $ET]);
        $LH++;
        update_site_option("\155\x6f\x5f\167\160\156\163\x5f\151\x70\x72\x61\x6e\147\145\x5f\x72\141\156\x67\145\x5f" . $LH, $Lp);
        RJ:
        iD:
        i9:
        $ET++;
        goto s2;
        V3:
        if (!(0 === $LH)) {
            goto pg;
        }
        update_site_option("\x6d\x6f\x5f\167\x70\156\x73\137\151\160\162\141\156\147\x65\x5f\162\x61\156\147\x65\137\61", '');
        pg:
        update_site_option("\x6d\x6f\x5f\167\160\156\x73\x5f\151\x70\162\x61\156\x67\145\137\x63\157\165\x6e\164", $LH);
        if (!(0 === $UQ)) {
            goto UF;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::IP_BLOCK_RANGE_ADDED), "\x53\x55\103\x43\105\x53\123");
        UF:
    }
}
new Mo2f_IP_Blocking_Handler();
Vl:
