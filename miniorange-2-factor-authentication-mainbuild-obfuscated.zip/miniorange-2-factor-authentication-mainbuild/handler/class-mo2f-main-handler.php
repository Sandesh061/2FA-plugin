<?php


namespace TwoFA\Onprem;

use Error;
use TwoFA\Helper\Mo2f_Common_Helper;
use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Onprem\MO2f_Utility;
use TwoFA\Database\Mo2fDB;
use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Handler\Miniorange_Mobile_Login;
use TwoFA\Helper\Mo2f_Login_Popup;
use TwoFA\Helper\MocURL;
use WP_Error;
use TwoFA\Helper\TwoFAMoSessions;
use TwoFA\Onprem\Mo2f_Reconfigure_Link;
if (defined("\x41\x42\123\120\x41\124\110")) {
    goto dw;
}
exit;
dw:
if (class_exists("\115\157\62\x66\x5f\115\x61\151\x6e\x5f\x48\141\156\x64\x6c\x65\x72")) {
    goto m3;
}
class Mo2f_Main_Handler
{
    private $mo2f_user_id;
    private $fstfactor;
    private $mo2f_onprem_cloud_obj;
    public function __construct()
    {
        $this->mo2f_onprem_cloud_obj = MO2f_Cloud_Onprem_Interface::instance();
        add_action("\x69\156\151\x74", array($this, "\x6d\x69\156\151\157\x72\x61\156\x67\145\x5f\160\141\x73\163\x32\x6c\157\x67\151\156\x5f\162\145\x64\x69\162\x65\x63\164"));
        add_action("\167\160\x5f\x61\x6a\x61\x78\137\155\x6f\137\164\167\x6f\x5f\x66\141\x63\164\157\162\137\x61\152\141\x78", array($this, "\x6d\157\137\164\x77\x6f\137\x66\x61\143\164\x6f\x72\x5f\x61\x6a\141\170"));
        add_action("\167\x70\x5f\141\152\141\170\x5f\156\x6f\160\x72\151\166\x5f\x6d\x6f\137\x74\167\x6f\137\x66\141\143\164\x6f\162\x5f\x61\152\141\170", array($this, "\x6d\x6f\137\164\x77\x6f\x5f\146\141\x63\x74\x6f\x72\x5f\141\152\141\170"));
        add_filter("\x6c\157\147\151\x6e\137\145\162\x72\x6f\x72\x73", array($this, "\155\157\x32\146\x5f\x73\150\157\x77\137\145\162\x72\157\x72\137\x6f\156\137\167\160\x5f\154\x6f\x67\x69\x6e\137\146\x6f\162\155"));
        add_filter("\154\x6f\147\x69\156\137\155\145\x73\x73\141\147\145", array($this, "\155\x6f\x32\146\137\163\x68\x6f\167\x5f\157\x6e\137\167\x70\137\154\157\147\151\156\x5f\x66\x6f\x72\x6d"));
    }
    public function mo_two_factor_ajax()
    {
        $GLOBALS["\x6d\x6f\62\x66\x5f\151\163\137\141\152\x61\x78\137\162\x65\161\165\145\163\164"] = true;
        if (check_ajax_referer("\155\x6f\x2d\x74\167\157\55\x66\141\143\164\x6f\162\55\141\x6a\x61\x78\55\156\x6f\156\143\x65", "\156\x6f\x6e\143\145", false)) {
            goto mq;
        }
        wp_send_json_error("\x63\154\x61\163\163\x2d\155\157\x32\x66\55\x61\x6a\x61\170");
        mq:
        $Xh = isset($_POST["\155\157\137\x32\146\137\164\x77\157\x5f\x66\x61\143\x74\x6f\162\137\x61\152\x61\x78"]) ? sanitize_text_field(wp_unslash($_POST["\155\157\x5f\x32\146\137\x74\167\157\137\x66\141\143\164\x6f\x72\x5f\x61\152\141\170"])) : '';
        switch ($Xh) {
            case "\x6d\157\x32\146\x5f\x73\145\156\x64\x5f\x6f\164\160\x5f\146\157\x72\x5f\143\157\156\x66\151\x67\x75\x72\141\164\x69\x6f\x6e":
                $this->mo2f_send_otp_for_configuration($_POST);
                goto OY;
            case "\x6d\x6f\x32\x66\x5f\166\x61\x6c\x69\144\x61\x74\x65\x5f\157\x74\x70\137\146\157\x72\137\143\157\156\146\x69\x67\165\x72\x61\164\151\157\156":
                $this->mo2f_validate_otp_for_configuration($_POST);
                goto OY;
            case "\155\157\62\146\x5f\x73\x74\141\162\x74\137\163\145\x74\165\160\x5f\x32\146\141\137\x64\141\x73\150\x62\157\141\162\144":
                $this->mo2f_start_setup_2fa_dashboard($_POST);
                goto OY;
            case "\x6d\157\x32\146\x5f\163\145\x74\137\153\x62\141":
                $this->mo2f_set_kba($_POST);
                goto OY;
            case "\155\x6f\x32\x66\137\x76\x61\x6c\151\144\141\x74\145\137\x75\163\x65\162\137\146\x6f\162\137\x6c\x6f\147\151\156":
                $this->mo2f_validate_user_for_login($_POST);
                goto OY;
            case "\155\x6f\x32\146\137\166\141\154\x69\144\x61\x74\x65\x5f\x62\141\143\153\165\x70\137\143\x6f\x64\x65\x73":
                $this->mo2f_validate_backup_codes($_POST);
                goto OY;
            case "\155\157\62\146\137\163\153\x69\160\x74\167\157\x66\141\x63\x74\157\162\137\x77\x69\x7a\141\162\x64":
                $this->mo2f_skiptwofactor_wizard($_POST);
                goto OY;
            case "\x6d\x6f\x32\x66\137\162\145\x73\x65\156\144\137\x6f\x74\x70\x5f\154\x6f\x67\x69\x6e":
                $this->mo2f_resend_otp_login($_POST);
                goto OY;
        }
        D1:
        OY:
    }
    public function miniorange_pass2login_redirect()
    {
        if (!(isset($_GET["\x54\x78\x69\144"]) && isset($_GET["\141\143\x63\x65\x73\163\124\157\x6b\x65\156"]))) {
            goto ZW;
        }
        $Aw = new Mo2f_Common_Helper();
        $mm = $Aw->mo2f_get_object(MoWpnsConstants::OUT_OF_BAND_EMAIL);
        $I1 = isset($_GET["\x75\163\145\x72\x49\104"]) ? sanitize_text_field(wp_unslash($_GET["\x75\x73\145\x72\111\x44"])) : '';
        $mb = isset($_GET["\124\170\151\144"]) ? sanitize_text_field(wp_unslash($_GET["\x54\x78\x69\144"])) : '';
        $sp = isset($_GET["\141\x63\x63\x65\163\163\124\x6f\x6b\145\156"]) ? sanitize_text_field(wp_unslash($_GET["\141\143\143\145\163\163\124\x6f\153\x65\156"])) : '';
        $mm->mo2f_process_link_validation($I1, $mb, $sp);
        ZW:
        if (!isset($_POST["\155\x6f\x32\146\137\157\165\164\x5f\x6f\146\x5f\142\141\156\x64\137\145\x6d\141\x69\x6c"])) {
            goto N6;
        }
        $Aw = new Mo2f_Common_Helper();
        $mm = $Aw->mo2f_get_object(MoWpnsConstants::OUT_OF_BAND_EMAIL);
        $ed = TwoFAMoSessions::get_session_var("\155\157\62\146\x5f\x74\162\x61\156\163\x61\143\x74\151\x6f\x6e\x49\x64");
        $mm->mo2f_handle_polling($ed);
        N6:
        $dk = isset($_POST["\155\151\156\x69\x6f\x72\141\x6e\147\145\x5f\x69\x6e\154\x69\156\x65\x5f\x73\141\x76\145\137\x32\x66\x61\143\164\x6f\x72\x5f\155\x65\x74\x68\x6f\x64\137\x6e\x6f\x6e\143\145"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\x69\156\151\157\162\x61\x6e\147\145\x5f\151\x6e\154\x69\156\145\x5f\163\x61\166\x65\x5f\62\x66\x61\x63\x74\x6f\x72\137\x6d\145\164\150\157\144\x5f\x6e\157\x6e\x63\x65"])) : '';
        if (wp_verify_nonce($dk, "\x6d\x69\156\151\x6f\x72\x61\156\147\x65\55\62\x2d\146\141\x63\164\157\162\55\151\156\154\x69\x6e\145\55\163\x61\166\x65\55\62\x66\x61\x63\164\x6f\162\55\155\145\x74\150\x6f\x64\55\x6e\157\156\x63\145")) {
            goto iB;
        }
        return;
        iB:
        $Xh = isset($_POST["\157\160\x74\x69\x6f\x6e"]) ? sanitize_text_field(wp_unslash($_POST["\x6f\160\164\x69\x6f\x6e"])) : '';
        switch ($Xh) {
            case "\155\151\x6e\x69\x6f\162\141\x6e\x67\x65\x5f\x69\156\154\151\x6e\145\137\163\141\166\x65\x5f\62\146\x61\143\164\157\162\137\x6d\x65\x74\150\x6f\144":
                $this->save_inline_2fa_method($_POST);
                goto nN;
            case "\155\x6f\62\146\137\160\162\x6f\143\145\x73\163\x5f\166\x61\x6c\151\x64\x61\164\x69\157\x6e\137\163\165\143\x63\145\163\x73":
                $this->mo2f_process_validation_success($_POST);
                goto nN;
            case "\155\x6f\x32\146\x5f\142\141\143\x6b\165\x70\x5f\143\x6f\x64\x65\x5f\x76\141\154\151\144\141\x74\151\x6f\x6e\137\x73\165\143\x63\x65\163\163":
                $this->mo2f_backup_code_validation_success($_POST);
                goto nN;
            case "\x6d\157\62\x66\137\163\145\156\x64\137\x72\x65\x63\x6f\156\x66\151\x67\137\154\151\x6e\x6b":
                $this->mo2f_send_reconfig_link($_POST);
                goto nN;
            case "\155\157\62\146\137\x65\155\141\151\154\x5f\166\x65\x72\151\x66\x69\143\x61\164\151\x6f\156\x5f\163\x75\143\x63\x65\163\x73":
                $this->mo2f_email_verification_success($_POST);
                goto nN;
            case "\155\x6f\x32\146\x5f\145\155\x61\x69\x6c\x5f\166\145\162\151\146\151\143\x61\x74\x69\x6f\156\137\146\x61\151\154\145\x64":
                $this->mo2f_email_verification_failed($_POST);
                goto nN;
            case "\x6d\157\x32\x66\137\x75\x73\145\x5f\142\x61\143\153\x75\160\137\143\x6f\x64\x65\163":
                $this->mo2f_use_backup_codes($_POST);
                goto nN;
            case "\x6d\157\x32\146\137\163\145\x6e\144\137\142\x61\143\153\x75\160\137\x63\x6f\144\x65\x73":
                $this->mo2f_send_backup_codes($_POST);
                goto nN;
            case "\x6d\151\x6e\151\x6f\162\x61\156\147\145\62\x66\x5f\x62\141\143\153\137\164\x6f\137\x69\156\154\x69\156\x65\137\162\145\x67\151\163\x74\162\x61\x74\151\x6f\156":
                $this->miniorange2f_back_to_inline_registration($_POST);
                exit;
            case "\x6d\x6f\x32\x66\x5f\x62\x61\143\153\x5f\164\x6f\x5f\155\146\x61\x5f\x73\x63\x72\145\x65\x6e":
                $this->mo2f_back_to_mfa_screen($_POST);
                exit;
            case "\x6d\151\156\151\x6f\x72\x61\x6e\147\145\x5f\x6d\146\141\143\x74\157\x72\137\155\x65\x74\150\157\x64":
                $this->mo2f_select_mfa_method($_POST);
                goto nN;
            case "\155\x6f\62\146\137\142\x61\x63\x6b\x5f\x74\x6f\137\62\x66\141\x5f\x76\x61\x6c\151\x64\141\x74\x69\157\x6e\x5f\163\143\162\x65\x65\x6e":
                $this->mo2f_twofa_validation_screen($_POST);
                goto nN;
            case "\155\x6f\62\146\x5f\x73\x6b\151\x70\137\x32\146\x61\137\163\145\x74\x75\160":
                $this->mo2f_skip_2fa_setup($_POST);
                goto nN;
            case "\x6d\x6f\x32\x66\x5f\144\157\x77\x6e\154\157\141\144\137\x62\141\x63\153\165\x70\137\143\x6f\144\x65\x73\x5f\x69\x6e\x6c\151\156\x65":
                $this->mo2f_download_backup_codes_inline($_POST);
                goto nN;
            case "\155\157\62\146\137\x66\151\156\151\163\x68\x5f\151\x6e\x6c\151\x6e\x65\x5f\141\156\144\137\x6c\157\147\x69\x6e":
                $this->mo2f_finish_inline_and_login($_POST);
                goto nN;
            case "\x6d\x6f\x32\x66\137\x73\x68\157\x77\x5f\142\x61\143\153\x75\x70\137\x6d\x65\164\x68\157\144":
                $this->mo2f_show_backup_method($_POST);
                goto nN;
            case "\x6d\157\62\146\x5f\x72\x65\x6d\145\x62\145\x72\x5f\x64\x65\166\x69\x63\x65\x5f\x74\162\165\145":
                do_action("\155\157\62\x66\x5f\145\156\x74\x65\x72\x70\162\151\x73\x65\137\x70\x6c\x61\x6e\x5f\x73\x65\x74\x74\x69\156\x67\x73\x5f\x61\143\x74\x69\157\x6e", "\155\x6f\62\146\x5f\x72\x65\155\145\142\145\x72\137\144\x65\166\151\x63\145\x5f\164\162\165\x65", $_POST);
                goto nN;
            case "\x6d\x6f\x32\146\x5f\162\x65\x6d\145\142\x65\x72\x5f\144\145\166\151\143\145\x5f\x66\x61\x6c\x73\x65":
                do_action("\x6d\x6f\x32\x66\x5f\145\x6e\x74\x65\x72\160\x72\151\163\x65\x5f\160\154\x61\x6e\137\x73\x65\x74\164\151\156\147\163\137\x61\143\x74\x69\157\x6e", "\155\x6f\x32\146\137\x72\x65\x6d\x65\x62\145\162\137\144\145\166\151\143\145\137\x66\141\x6c\163\145", $_POST);
                goto nN;
        }
        Uz:
        nN:
    }
    public function mo2f_validate_backup_codes($post)
    {
        $sI = new Mo2f_Backup_Codes();
        $sI->mo2f_validate_backup_codes($post);
    }
    public function mo2f_show_backup_method($post)
    {
        $ok = isset($post["\x72\x65\x64\151\162\145\x63\164\137\164\x6f"]) ? esc_url_raw(wp_unslash($post["\162\145\x64\151\162\145\x63\164\137\x74\x6f"])) : '';
        $Ty = isset($post["\x73\145\x73\x73\151\157\x6e\137\x69\x64"]) ? sanitize_text_field(wp_unslash($post["\163\145\x73\163\x69\157\x6e\137\151\144"])) : '';
        $Z0 = MoWpnsConstants::SECURITY_QUESTIONS;
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\x6d\x6f\x32\x66\137\x63\x75\x72\162\145\156\164\137\165\163\x65\x72\137\x69\x64");
        $this->mo2f_select_method_for_login(get_user_by("\151\x64", $v1), $Z0, $Ty, $ok);
    }
    public function mo2f_show_error_on_wp_login_form($jY)
    {
        if (!isset($_SESSION["\x65\155\141\x69\x6c\137\x74\x72\x61\x6e\163\x61\x63\164\151\x6f\156\x5f\x64\145\x6e\x69\x65\144\137\x65\x72\162\x6f\x72"])) {
            goto zP;
        }
        $jY = $_SESSION["\x65\155\141\151\x6c\137\x74\162\x61\x6e\x73\141\143\164\x69\157\x6e\x5f\144\145\x6e\x69\145\144\x5f\145\162\x72\x6f\x72"];
        unset($_SESSION["\x65\155\x61\x69\154\137\x74\162\141\156\x73\141\x63\164\151\x6f\x6e\137\144\x65\x6e\151\145\x64\x5f\x65\x72\x72\x6f\x72"]);
        zP:
        if (!TwoFAMoSessions::get_session_var("\155\x6f\x32\146\x5f\x63\x68\141\x6e\147\145\137\145\162\x72\x6f\x72\137\155\x65\x73\x73\141\x67\x65")) {
            goto RZ;
        }
        $jY = TwoFAMoSessions::get_session_var("\155\x6f\62\x66\137\143\x68\141\x6e\147\145\137\x65\162\x72\157\x72\137\x6d\x65\163\163\x61\x67\145");
        TwoFAMoSessions::unset_session("\x6d\157\x32\x66\137\143\x68\141\156\x67\x65\x5f\x65\162\x72\157\162\x5f\x6d\145\x73\x73\141\x67\145");
        RZ:
        return $jY;
    }
    public function mo2f_show_on_wp_login_form($jY)
    {
        if (!TwoFAMoSessions::get_session_var("\155\x6f\x32\146\x5f\163\x68\157\167\x5f\x65\162\162\x6f\162\x5f\155\145\x73\163\x61\x67\x65")) {
            goto G4;
        }
        $jY = "\74\144\151\x76\x20\151\x64\75\x27\x6c\157\147\x69\156\137\145\x72\162\x6f\x72\x31\47\x3e\x20\x3c\x70\x3e" . TwoFAMoSessions::get_session_var("\x6d\x6f\x32\146\x5f\x73\150\x6f\167\x5f\x65\162\162\157\162\x5f\155\x65\163\163\141\147\x65") . "\74\57\x70\76\74\57\x64\151\x76\x3e";
        TwoFAMoSessions::unset_session("\155\x6f\x32\x66\x5f\163\150\x6f\167\137\x65\162\x72\x6f\x72\x5f\x6d\x65\x73\x73\141\147\x65");
        G4:
        return $jY;
    }
    public function mo2f_backup_code_validation_success($post)
    {
        $sI = new Mo2f_Backup_Codes();
        $sI->mo2f_backup_code_validation_success($post);
    }
    public function mo2f_use_backup_codes($post)
    {
        $sI = new Mo2f_Backup_Codes();
        $sI->mo2f_use_backup_codes($post);
    }
    public function mo2f_send_backup_codes($post)
    {
        $sI = new Mo2f_Backup_Codes();
        $sI->mo2f_send_backup_codes($post);
    }
    public function mo2f_send_reconfig_link($post)
    {
        $sI = new Mo2f_Reconfigure_Link();
        $sI->mo2f_send_reconfig_link($post);
    }
    public function mo2f_resend_otp_login($post)
    {
        $Ty = isset($post["\x73\x65\163\163\151\157\x6e\x5f\x69\144"]) ? sanitize_text_field(wp_unslash($post["\163\x65\163\163\x69\x6f\x6e\137\151\144"])) : null;
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\155\x6f\62\x66\x5f\143\165\x72\162\x65\x6e\164\137\x75\163\145\x72\x5f\151\144");
        $XV = isset($post["\141\x75\x74\150\137\x6d\145\164\150\x6f\144"]) ? sanitize_text_field(wp_unslash($post["\141\165\x74\150\137\155\145\x74\150\x6f\x64"])) : null;
        $current_user = get_user_by("\x69\x64", $v1);
        $Aw = new Mo2f_Common_Helper();
        $Dp = $Aw->mo2f_get_object($XV);
        $jD = MoWpnsMessages::lang_translate(MoWpnsMessages::NEW_OTP_SENT);
        $Dp->mo2f_send_otp(null, $Ty, $current_user, $jD);
    }
    public function mo2f_skiptwofactor_wizard($post)
    {
        $Me = isset($post["\164\x77\157\x66\141\143\x74\x6f\x72\x73\x6b\x69\160\160\145\x64\x6f\156"]) ? sanitize_text_field(wp_unslash($post["\164\x77\157\146\x61\143\164\157\162\x73\153\151\160\x70\x65\144\x6f\156"])) : null;
        update_site_option("\155\157\x32\146\x5f\x77\151\172\141\162\x64\x5f\x73\x6b\151\160\160\145\144", $Me);
        wp_send_json_success();
    }
    public function save_inline_2fa_method($post)
    {
        global $Gw;
        $nR = new Miniorange_Password_2Factor_Login();
        $nR->miniorange_pass2login_start_session();
        $we = '';
        $Ty = isset($post["\x73\x65\163\163\151\157\x6e\x5f\x69\x64"]) ? sanitize_text_field(wp_unslash($post["\x73\145\x73\163\x69\x6f\156\x5f\151\144"])) : null;
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\x6d\x6f\62\146\x5f\x63\x75\162\162\145\x6e\164\x5f\x75\163\145\162\137\151\144");
        $ok = isset($post["\162\145\144\x69\162\x65\x63\x74\x5f\x74\157"]) ? esc_url_raw(wp_unslash($post["\162\145\144\x69\162\x65\143\x74\x5f\164\157"])) : null;
        $current_user = get_user_by("\151\144", $v1);
        $M0 = $Gw->get_user_detail("\165\x73\145\x72\137\162\x65\147\151\163\164\x72\141\164\151\x6f\x6e\x5f\167\x69\x74\x68\137\x6d\151\x6e\x69\x6f\162\x61\156\147\145", $current_user->ID);
        if ("\123\125\103\103\105\123\x53" === $M0) {
            goto mP;
        }
        $Aw = new Mo2f_Inline_Popup();
        $Aw->prompt_user_to_select_2factor_mthod_inline($v1, '', $ok, $Ty);
        goto jE;
        mP:
        $YE = isset($post["\x6d\x6f\62\x66\137\163\145\x6c\145\143\x74\145\x64\137\62\x66\141\143\x74\157\162\x5f\155\x65\x74\x68\x6f\144"]) ? sanitize_text_field(wp_unslash($post["\155\157\62\x66\x5f\163\145\x6c\x65\143\164\x65\144\137\x32\146\x61\x63\x74\x6f\162\x5f\155\x65\164\x68\x6f\x64"])) : "\116\117\x4e\105";
        $Aw = new Mo2f_Common_Helper();
        $sF = $Aw->mo2f_get_object($YE);
        $sF->mo2f_prompt_2fa_setup_inline($Ty, $ok, $v1, $we);
        jE:
        exit;
    }
    public function miniorange2f_back_to_inline_registration($post)
    {
        $Ty = isset($post["\x73\x65\163\163\151\157\156\137\x69\144"]) ? sanitize_text_field(wp_unslash($post["\x73\145\163\163\x69\157\156\x5f\x69\x64"])) : null;
        $ok = esc_url_raw($post["\x72\145\x64\x69\162\x65\143\x74\137\164\157"]);
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\155\157\x32\x66\137\x63\x75\x72\x72\x65\156\x74\x5f\165\x73\145\162\x5f\151\144");
        $Aw = new Mo2f_Inline_Popup();
        $Aw->prompt_user_to_select_2factor_mthod_inline($v1, '', $ok, $Ty);
        exit;
    }
    public function mo2f_back_to_mfa_screen($post)
    {
        $Ty = isset($post["\163\x65\163\x73\x69\157\x6e\x5f\151\144"]) ? sanitize_text_field(wp_unslash($post["\163\x65\x73\x73\151\x6f\x6e\x5f\151\144"])) : null;
        $ok = esc_url_raw($post["\x72\145\144\x69\x72\145\143\x74\137\x74\157"]);
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\155\x6f\x32\146\x5f\143\x75\162\162\145\156\x74\137\165\163\145\162\x5f\151\144");
        $cB = new Mo2f_Common_Helper();
        $Ga = $cB->mo2fa_return_methods_value($v1);
        $yV = new Mo2f_Login_Popup();
        $yV->mo2fa_prompt_mfa_form_for_user($Ga, $Ty, $ok);
        exit;
    }
    public function mo2f_send_otp_for_configuration($post)
    {
        $ix = isset($post["\x6d\157\x32\x66\137\x6f\x74\x70\x5f\x62\141\163\145\x64\x5f\x6d\x65\164\150\x6f\x64"]) ? sanitize_text_field(wp_unslash($post["\155\157\x32\x66\137\157\164\x70\x5f\x62\141\163\x65\144\x5f\155\145\164\x68\157\x64"])) : '';
        $TC = isset($post["\x6d\x6f\x32\146\x5f\x70\150\x6f\x6e\145\137\x65\155\141\151\154\137\x74\145\154\145\x67\x72\x61\x6d"]) ? sanitize_text_field(wp_unslash($post["\155\x6f\62\x66\137\x70\150\x6f\x6e\145\137\145\x6d\141\x69\x6c\137\164\145\x6c\145\147\x72\141\155"])) : null;
        $Ty = isset($post["\155\157\62\146\137\163\x65\x73\163\x69\157\x6e\x5f\151\144"]) ? sanitize_text_field(wp_unslash($post["\x6d\157\62\x66\x5f\x73\x65\163\163\x69\x6f\x6e\137\151\144"])) : null;
        if (!MO2f_Utility::mo2f_check_empty_or_null($TC)) {
            goto F_;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_ENTRY));
        F_:
        $TC = str_replace("\40", '', $TC);
        $user = wp_get_current_user();
        if ($user->ID) {
            goto ib;
        }
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\x6d\x6f\x32\146\x5f\143\165\x72\x72\145\156\164\137\x75\163\x65\x72\137\x69\x64");
        $user = get_user_by("\x69\144", $v1);
        ib:
        $Aw = new Mo2f_Common_Helper();
        $VA = $Aw->mo2f_get_object($ix);
        $jD = MoWpnsMessages::lang_translate(MoWpnsMessages::OTP_SENT);
        $VA->mo2f_send_otp($TC, $Ty, $user, $jD);
    }
    public function mo2f_twofa_validation_screen($post)
    {
        $ok = isset($post["\x72\x65\144\151\x72\145\143\164\137\x74\x6f"]) ? esc_url_raw(wp_unslash($post["\x72\145\144\x69\x72\145\143\x74\137\164\x6f"])) : '';
        $jg = isset($post["\x73\145\x73\163\151\157\x6e\137\151\x64"]) ? sanitize_text_field(wp_unslash($post["\163\145\x73\163\x69\157\x6e\x5f\x69\x64"])) : '';
        $Z0 = isset($post["\x74\167\x6f\x66\x61\137\x6d\145\164\x68\157\x64"]) ? sanitize_text_field(wp_unslash($post["\x74\x77\157\146\x61\137\x6d\145\164\x68\157\x64"])) : '';
        $v1 = MO2f_Utility::mo2f_get_transient($jg, "\155\157\62\146\137\143\165\x72\x72\x65\156\164\x5f\x75\163\145\162\x5f\151\x64");
        $this->mo2f_select_method_for_login(get_user_by("\151\144", $v1), $Z0, $jg, $ok);
        exit;
    }
    public function mo2f_validate_otp_for_configuration($post)
    {
        $li = isset($post["\157\x74\x70\137\164\157\x6b\145\x6e"]) ? sanitize_text_field(wp_unslash($post["\157\x74\x70\x5f\164\x6f\153\145\x6e"])) : '';
        $Ty = isset($post["\x6d\x6f\62\146\x5f\x73\145\x73\x73\x69\157\x6e\137\x69\x64"]) ? sanitize_text_field(wp_unslash($post["\x6d\157\x32\146\x5f\163\x65\x73\x73\151\157\x6e\137\151\x64"])) : null;
        $user = wp_get_current_user();
        if ($user->ID) {
            goto Ny;
        }
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\155\x6f\62\x66\x5f\x63\x75\x72\162\145\x6e\x74\137\165\163\x65\x72\137\151\x64");
        $user = get_user_by("\x69\x64", $v1);
        Ny:
        if (!MO2f_Utility::mo2f_check_empty_or_null($li)) {
            goto aP;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_ENTRY));
        aP:
        $ix = isset($post["\x6d\157\x32\x66\137\157\x74\160\137\142\x61\163\x65\144\137\155\145\x74\150\x6f\144"]) ? sanitize_text_field(wp_unslash($post["\155\157\x32\x66\137\157\x74\160\x5f\x62\141\163\145\x64\137\155\145\x74\150\x6f\144"])) : '';
        $P3 = isset($post["\155\157\62\x66\137\x70\150\x6f\x6e\145\x5f\x65\x6d\141\151\154\x5f\x74\145\154\145\147\162\x61\155"]) ? str_replace("\40", '', sanitize_text_field(wp_unslash($post["\x6d\157\62\x66\137\x70\x68\157\x6e\x65\x5f\145\155\x61\x69\x6c\x5f\164\x65\154\145\x67\162\141\155"]))) : '';
        $Aw = new Mo2f_Common_Helper();
        $zV = $Aw->mo2f_get_object($ix);
        $zV->mo2f_validate_otp($li, $Ty, $user, $P3, $post);
    }
    public function mo2f_validate_user_for_login($post)
    {
        $ix = isset($post["\x6d\x6f\62\x66\137\x6c\x6f\147\151\x6e\137\x6d\x65\164\150\x6f\144"]) ? sanitize_text_field(wp_unslash($post["\155\157\x32\146\x5f\154\x6f\x67\151\x6e\x5f\155\x65\x74\x68\x6f\x64"])) : null;
        $Ty = isset($post["\x73\145\x73\163\x69\157\x6e\137\151\x64"]) ? sanitize_text_field(wp_unslash($post["\163\145\x73\x73\151\157\156\137\151\x64"])) : null;
        $ok = isset($post["\x72\145\144\151\162\145\143\x74\137\164\x6f"]) ? esc_url_raw(wp_unslash($post["\x72\x65\144\151\x72\x65\143\x74\137\x74\157"])) : null;
        $li = isset($post["\x6d\x6f\62\146\141\x5f\163\x6f\146\x74\x74\157\153\145\x6e"]) ? sanitize_text_field(wp_unslash($post["\155\x6f\x32\146\x61\137\163\x6f\146\x74\x74\x6f\153\145\156"])) : '';
        $ka = new Mo2f_Common_Helper();
        $HE = $ka->mo2f_get_object($ix);
        $HE->mo2f_login_validate($li, $ok, $Ty);
    }
    public function mo2f_process_validation_success($post)
    {
        global $Gw;
        $Ty = isset($post["\x73\145\x73\163\151\x6f\x6e\137\151\x64"]) ? sanitize_text_field(wp_unslash($post["\163\145\163\163\151\x6f\x6e\137\151\144"])) : '';
        $ok = isset($post["\x72\x65\x64\x69\x72\145\x63\x74\137\x74\157"]) ? esc_url_raw(wp_unslash($post["\x72\145\x64\151\x72\x65\143\x74\137\164\x6f"])) : '';
        $AP = isset($post["\x74\167\x6f\146\x61\x5f\163\x74\141\x74\165\x73"]) ? sanitize_text_field(wp_unslash($post["\164\x77\157\146\x61\137\x73\164\x61\x74\x75\x73"])) : '';
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\x6d\x6f\x32\146\x5f\x63\x75\x72\162\145\x6e\x74\137\x75\x73\x65\x72\x5f\151\x64");
        if (MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS !== $AP || TwoFAMoSessions::get_session_var("\155\x6f\x32\x66\x5f\151\163\137\x6b\x62\141\137\x62\x61\x63\x6b\165\x70\137\143\x6f\x6e\146\x69\147\x75\162\x65\144" . $v1)) {
            goto R1;
        }
        if (!get_site_option("\155\157\62\x66\x5f\162\x65\155\x65\155\x62\145\x72\x5f\144\x65\x76\151\x63\x65")) {
            goto kY;
        }
        do_action("\155\x6f\62\146\x5f\145\156\164\x65\162\160\162\x69\163\145\137\160\x6c\x61\x6e\x5f\x73\145\164\164\x69\156\147\163\137\141\143\x74\151\x6f\x6e", "\155\157\62\146\x5f\162\x65\155\x65\x6d\142\145\x72\137\144\145\166\x69\x63\145\x5f\144\145\164\x61\x69\x6c\x73", array("\x75\163\x65\162\137\151\x64" => $v1, "\163\145\x73\163\151\157\x6e\x5f\151\144" => $Ty, "\162\145\144\x69\x72\x65\x63\164\137\x74\x6f" => $ok));
        kY:
        $this->mo2fa_pass2login($ok, $Ty);
        goto Qp;
        R1:
        $Kl = new Mo2f_Common_Helper();
        $Kl->mo2f_inline_setup_success($v1, $ok, $Ty);
        Qp:
    }
    public function mo2fa_pass2login($ok = null, $bJ = null)
    {
        $cB = new Mo2f_Common_Helper();
        if (empty($this->mo2f_user_id) && empty($this->fstfactor)) {
            goto Mv;
        }
        $v1 = $this->mo2f_user_id;
        $W0 = $this->fstfactor;
        goto qi;
        Mv:
        $v1 = MO2f_Utility::mo2f_get_transient($bJ, "\155\157\x32\146\x5f\x63\165\x72\162\x65\x6e\x74\x5f\165\x73\x65\x72\x5f\151\144");
        $W0 = MO2f_Utility::mo2f_get_transient($bJ, "\x6d\157\62\146\137\61\163\x74\x66\141\x63\x74\x6f\x72\x5f\163\x74\141\x74\x75\x73");
        qi:
        if ($v1 && $W0 && "\126\101\x4c\111\104\x41\x54\x45\x5f\x53\x55\103\103\105\x53\x53" === $W0) {
            goto uN;
        }
        $cB->mo2f_remove_current_activity($bJ);
        goto oc;
        uN:
        $cs = get_user_by("\x69\x64", $v1);
        wp_set_current_user($v1, $cs->user_login);
        $cB->mo2f_remove_current_activity($bJ);
        delete_expired_transients(true);
        delete_site_option($bJ);
        wp_set_auth_cookie($v1, true);
        do_action("\x77\x70\137\154\x6f\147\151\156", $cs->user_login, $cs);
        $cB->mo2f_redirect_user_to($cs, $ok);
        exit;
        oc:
    }
    public function mo2f_set_kba($post)
    {
        $Aw = new Mo2f_Common_Helper();
        $Xz = $Aw->mo2f_get_object(MoWpnsConstants::SECURITY_QUESTIONS);
        $Xz->mo2f_set_kba($post);
    }
    public function mo2f_check_username_password($user, $Zi, $uk, $ok = null)
    {
        global $uz;
        $pb = MO2f_Utility::get_index_value("\107\114\117\x42\101\x4c\123", "\155\157\62\146\x5f\x69\163\x5f\141\152\x61\x78\x5f\x72\x65\x71\165\145\x73\x74");
        if (!(is_a($user, "\127\120\x5f\105\162\162\157\162") && !empty($user))) {
            goto bS;
        }
        if ($pb) {
            goto Xs;
        }
        return $user;
        goto QZ;
        Xs:
        $mC = MO2f_Utility::mo2f_show_error_on_login(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_CREDS));
        wp_send_json_success($mC);
        QZ:
        bS:
        $cs = wp_authenticate_username_password($user, $Zi, $uk);
        if (is_wp_error($cs)) {
            goto MP;
        }
        $Pa = apply_filters("\155\157\62\x66\x5f\145\156\164\x65\162\x70\162\x69\163\x65\137\x70\154\141\156\x5f\163\145\164\x74\x69\156\147\x73\137\146\x69\154\164\145\162", false, "\x6d\157\x32\146\137\x63\x68\145\143\153\137\x73\145\163\x73\x69\x6f\x6e\x5f\x64\x65\164\x61\x69\154\x73", array("\165\x73\x65\162\x5f\151\x64" => $cs->ID));
        if (!$Pa) {
            goto th;
        }
        return new WP_Error("\x73\x65\163\x73\x69\157\x6e\137\154\151\155\151\164\x5f\x65\170\143\145\x65\144\145\144", MoWpnsMessages::lang_translate(MoWpnsMessages::SESSION_LIMIT_REACHED));
        th:
        $nR = new Miniorange_Password_2Factor_Login();
        MO2f_Utility::mo2f_debug_file("\x55\x73\145\162\x6e\141\x6d\145\40\x61\x6e\144\x20\160\x61\x73\x73\x77\x6f\162\x64\x20\40\166\141\154\x69\144\141\164\145\40\163\x75\143\143\x65\x73\163\146\x75\x6c\154\171\40\x55\163\x65\162\137\x49\120\55" . $uz->get_client_ip() . "\x20\125\x73\x65\162\x5f\111\144\x2d" . $cs->ID . "\40\105\x6d\141\x69\x6c\x2d" . $cs->user_email);
        $jg = isset($_POST["\x73\x65\163\163\x69\157\156\137\151\144"]) ? sanitize_text_field(wp_unslash($_POST["\x73\145\x73\163\x69\157\x6e\137\151\x64"])) : $nR->create_session();
        $ok = $nR->mo2f_get_redirect_url();
        $jY = $this->miniorange_initiate_2nd_factor($cs, $ok, $jg);
        return $jY;
        goto vK;
        MP:
        if ($pb) {
            goto Dr;
        }
        MO2f_Utility::mo2f_debug_file("\x49\x6e\x76\x61\x6c\151\x64\40\x75\163\x65\x72\156\x61\x6d\145\40\x61\156\144\x20\x70\x61\163\x73\167\x6f\162\144\x2e\x20\x55\x73\x65\162\137\111\x50\55" . $uz->get_client_ip());
        $cs->add("\151\156\166\x61\154\151\144\x5f\165\163\x65\162\x6e\141\x6d\x65\137\x70\x61\163\x73\167\157\x72\x64", "\x3c\x73\x74\162\157\x6e\x67\76" . esc_html("\x45\122\122\x4f\x52") . "\74\57\163\x74\162\157\156\x67\x3e\x3a\x20" . esc_html(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_CREDS)));
        return $cs;
        goto vP;
        Dr:
        $mC = MO2f_Utility::mo2f_show_error_on_login(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_CREDS));
        wp_send_json_success($mC);
        vP:
        vK:
    }
    public function miniorange_initiate_2nd_factor($cs, $ok = '', $Ty = null)
    {
        global $Gw, $uz, $Xw;
        $nR = new Miniorange_Password_2Factor_Login();
        MO2f_Utility::mo2f_debug_file("\115\x4f\x20\x69\156\151\x74\151\141\x74\145\40\x32\156\x64\x20\146\141\x63\164\x6f\x72\x20\125\x73\145\162\137\x49\x50\55" . $uz->get_client_ip() . "\40\125\x73\145\162\x5f\111\144\55" . $cs->ID . "\x20\x45\x6d\141\x69\x6c\x2d" . $cs->user_email);
        $nR->miniorange_pass2login_start_session();
        if (!is_null($Ty)) {
            goto lb;
        }
        $Ty = $nR->create_session();
        lb:
        $ok = class_exists("\x55\115\137\106\165\156\x63\164\151\x6f\156\x73") ? $nR->mo2f_redirect_url_for_um($cs) : $ok;
        MO2f_Utility::mo2f_set_transient($Ty, "\155\157\62\146\137\143\x75\x72\162\145\x6e\x74\x5f\x75\163\145\x72\x5f\x69\144", $cs->ID, 600);
        MO2f_Utility::mo2f_set_transient($Ty, "\x6d\x6f\x32\146\137\x31\163\x74\146\141\x63\164\x6f\x72\137\163\x74\141\x74\165\x73", "\126\101\x4c\111\104\101\x54\x45\137\x53\125\103\x43\105\123\x53", 600);
        $this->mo2f_user_id = $cs->ID;
        $this->fstfactor = "\x56\x41\x4c\111\x44\101\x54\105\137\x53\125\103\103\105\123\x53";
        if ($this->mo2f_check_if_twofa_is_enabled($cs)) {
            goto bj;
        }
        return $cs;
        goto Oh;
        bj:
        $cB = new Mo2f_Common_Helper();
        if (!apply_filters("\x6d\157\62\x66\137\142\x61\163\151\143\x5f\160\x6c\x61\x6e\137\163\145\164\x74\151\156\x67\163\x5f\x66\x69\x6c\164\145\x72", $Gw->check_alluser_limit_exceeded($cs->ID), "\x69\163\x5f\x75\163\145\x72\137\x6c\x69\155\151\x74\x5f\145\x78\143\145\x65\x64\145\144", array())) {
            goto k5;
        }
        return $cs;
        k5:
        if (!(false === get_site_option("\155\x6f\62\146\137\x64\x69\x73\x61\142\x6c\145\137\151\156\x6c\151\156\145\x5f\x72\x65\x67\151\x73\164\162\141\x74\x69\x6f\x6e"))) {
            goto lH;
        }
        update_site_option("\x6d\157\62\146\137\144\x69\x73\x61\x62\x6c\145\x5f\x69\x6e\154\x69\x6e\145\x5f\x72\145\x67\x69\163\x74\x72\141\x74\x69\157\x6e", get_site_option("\x6d\157\x32\x66\137\151\x6e\154\151\x6e\145\137\x72\145\x67\x69\x73\x74\162\x61\x74\151\157\x6e", 1) ? null : 1);
        lH:
        if ($cB->mo2f_is_2fa_set($cs->ID)) {
            goto Aq;
        }
        if (!get_site_option("\x6d\x6f\62\x66\137\144\x69\x73\141\142\154\x65\137\151\156\x6c\151\x6e\x65\137\x72\145\147\x69\163\164\x72\x61\x74\151\157\156")) {
            goto Zg;
        }
        if (MO2f_Utility::get_index_value("\x47\114\x4f\102\x41\x4c\x53", "\x6d\157\62\146\137\x69\x73\137\x61\x6a\141\170\x5f\162\145\161\165\x65\163\x74")) {
            goto BL;
        }
        return $cs;
        goto b3;
        BL:
        $this->mo2fa_pass2login($ok, $Ty);
        b3:
        goto yC;
        Aq:
        $zK = isset($_POST["\155\151\156\x69\x6f\x72\x61\x6e\147\145\137\162\x62\141\137\141\164\164\x72\151\x62\165\162\x65\163"]) ? sanitize_text_field($_POST["\x6d\x69\x6e\151\157\x72\141\x6e\x67\x65\137\162\x62\141\137\141\164\x74\162\151\142\x75\162\145\163"]) : null;
        do_action("\x6d\x6f\x32\x66\x5f\145\156\x74\x65\162\x70\x72\151\163\145\137\160\154\x61\x6e\x5f\x73\145\x74\x74\151\x6e\147\163\x5f\x61\x63\164\151\x6f\x6e", "\x6d\x6f\x32\146\x5f\143\x68\x65\x63\x6b\137\162\142\141\x5f\x64\x65\x74\x61\151\x6c\163", array("\x75\x73\145\162\137\151\144" => $cs->ID, "\x61\164\x74\x72\151\142\x75\164\145\163" => $zK, "\163\x65\x73\x73\x69\x6f\156\137\x69\144" => $Ty, "\162\145\144\151\x72\145\143\164\137\x74\x6f" => $ok));
        $this->mo2f_remove_miniorange_auth_entries($cs->ID);
        $Z0 = $Xw->mo2f_get_user_2ndfactor($cs);
        $Ga = $cB->mo2fa_return_methods_value($cs->ID);
        if ($cB->mo2f_check_mfa_details($Ga)) {
            goto FT;
        }
        $user = $this->mo2f_select_method_for_login($cs, $Z0, $Ty, $ok);
        return $user;
        goto kg;
        FT:
        $yV = new Mo2f_Login_Popup();
        update_site_option("\x6d\157\62\146\137\x6c\x6f\x67\151\x6e\x5f\x77\x69\x74\150\137\155\146\141\x5f\165\163\x65", "\x31");
        $yV->mo2fa_prompt_mfa_form_for_user($Ga, $Ty, $ok);
        exit;
        kg:
        goto yC;
        Zg:
        if (get_site_option("\155\157\62\146\137\x67\x72\x61\x63\145\x5f\160\145\162\151\x6f\144") && $cB->mo2f_is_grace_period_expired($cs) && "\142\154\x6f\x63\x6b\x5f\165\163\x65\x72\137\154\x6f\x67\151\156" === get_site_option("\155\157\62\146\137\147\162\x61\143\x65\x70\145\x72\151\x6f\144\137\141\143\x74\x69\157\x6e")) {
            goto kJ;
        }
        $this->mo2f_start_inline_2fa($cs, $ok, $Ty);
        goto Cl;
        kJ:
        $we = "\131\157\165\x72\40\147\x72\x61\x63\x65\40\x70\145\x72\151\157\x64\x20\x74\x6f\x20\x73\145\x74\165\160\40\x74\150\x65\40\62\106\x41\x20\x68\141\163\40\145\x78\160\151\x72\x65\x64\x2e\x20\x50\x6c\145\x61\163\145\40\143\x6f\x6e\164\x61\x63\x74\40\x73\151\x74\145\x20\141\144\155\x69\156\40\164\157\x20\165\x6e\142\x6c\x6f\143\153\40\x79\157\x75\x72\163\x65\x6c\146\x2e";
        $AP = MoWpnsConstants::MO2F_USER_BLOCKED_PROMPT;
        $yV = new Mo2f_Login_Popup();
        $yV->mo2f_show_login_prompt_for_otp_based_methods($we, $AP, $cs, $ok, $Ty, '');
        exit;
        Cl:
        yC:
        Oh:
    }
    public function mo2f_check_if_twofa_is_enabled($cs)
    {
        $bk = (array) $cs->roles;
        $KP = 0;
        foreach ($bk as $gO) {
            if (!(get_site_option("\155\157\62\x66\141\x5f" . $gO) === "\61")) {
                goto Ng;
            }
            $KP = 1;
            goto Lq;
            Ng:
            da:
        }
        Lq:
        if (!(1 !== $KP && is_super_admin($cs->ID) && (int) get_site_option("\x6d\x6f\62\146\141\x5f\x73\165\160\x65\162\x61\144\x6d\151\x6e") === 1)) {
            goto cd;
        }
        $KP = 1;
        cd:
        return apply_filters("\x6d\157\62\x66\137\x62\141\x73\151\143\137\x70\x6c\x61\156\137\x73\x65\x74\164\x69\156\147\x73\137\146\x69\x6c\x74\x65\162", $KP, "\151\163\x5f\164\167\x6f\146\141\137\145\x6e\141\x62\154\x65\144", array("\165\x73\x65\162" => $cs));
    }
    public function mo2f_remove_miniorange_auth_entries($v1)
    {
        global $Gw;
        if (!($Gw->get_user_detail("\x6d\157\62\x66\137\155\151\156\151\x4f\162\x61\x6e\147\x65\123\x6f\146\x74\124\157\x6b\x65\156\137\x63\157\156\146\151\x67\x5f\x73\x74\x61\x74\165\163", $v1) || $Gw->get_user_detail("\155\x6f\x32\x66\137\x6d\x69\x6e\x69\117\162\x61\x6e\147\145\x51\x52\103\x6f\144\145\101\x75\x74\x68\145\156\x74\151\143\141\x74\x69\x6f\156\137\143\157\156\x66\x69\x67\137\163\164\x61\x74\165\x73", $v1) || $Gw->get_user_detail("\x6d\x6f\62\146\x5f\x6d\151\156\x69\117\x72\141\x6e\x67\x65\x50\x75\163\x68\116\x6f\x74\x69\x66\151\143\141\164\151\157\156\137\x63\157\x6e\146\x69\x67\x5f\163\164\x61\x74\x75\163", $v1))) {
            goto po;
        }
        $Gw->delete_user_details($v1);
        po:
    }
    public function mo2f_start_inline_2fa($cs, $ok, $Ty)
    {
        global $Gw;
        $cB = new Mo2f_Common_Helper();
        if (get_user_meta($cs->ID, "\155\x6f\62\146\x5f\x75\163\145\x72\137\x70\x72\157\x66\x69\154\x65\x5f\x73\x65\x74", true)) {
            goto bA;
        }
        $cB->mo2fa_inline($cs, $ok, $Ty);
        goto kQ;
        bA:
        $YE = $Gw->get_user_detail("\x6d\x6f\x32\x66\137\143\x6f\156\x66\x69\147\165\162\145\x64\137\62\106\101\137\155\x65\x74\150\157\x64", $cs->ID);
        $Aw = new Mo2f_Common_Helper();
        $sF = $Aw->mo2f_get_object($YE);
        $sF->mo2f_prompt_2fa_setup_inline($Ty, $ok, $cs->ID, '');
        kQ:
        exit;
    }
    public function mo2f_start_setup_2fa_dashboard($post)
    {
        $cB = new Mo2f_Common_Helper();
        $cB->mo2f_ilvn();
        $Ix = isset($post["\141\165\x74\150\137\155\145\x74\150\157\144"]) ? sanitize_text_field(wp_unslash($post["\x61\x75\164\150\137\155\x65\164\150\157\144"])) : '';
        $Sl = isset($post["\x72\145\161\x75\x65\x73\x74\x74\171\x70\145"]) ? sanitize_text_field(wp_unslash($post["\162\x65\161\165\145\163\x74\164\171\160\145"])) : '';
        $Ix = MoWpnsConstants::mo2f_convert_method_name($Ix, "\x70\141\163\x63\141\154\x5f\x74\157\137\143\141\160");
        $HE = $cB->mo2f_get_object($Ix);
        $y0 = array($HE, "\155\x6f\x32\x66\137\x70\162\157\155\x70\164\x5f\x32\146\141\x5f" . $Sl . "\x5f\144\x61\x73\150\142\157\x61\162\x64");
        if (empty($y0)) {
            goto xI;
        }
        call_user_func($y0);
        xI:
    }
    public function mo2f_select_method_for_login($cs, $Z0, $Ty, $ok)
    {
        $Aw = new Mo2f_Common_Helper();
        $Dp = $Aw->mo2f_get_object($Z0);
        $Dp->mo2f_prompt_2fa_login($cs, $Ty, $ok);
    }
    public function mo2f_select_mfa_method($post)
    {
        $jg = isset($post["\x73\x65\x73\163\x69\157\x6e\137\151\x64"]) ? sanitize_text_field(wp_unslash($post["\163\145\x73\x73\x69\x6f\x6e\137\151\x64"])) : null;
        $AA = isset($post["\x6d\157\x32\146\137\x73\145\x6c\x65\x63\x74\145\144\137\x6d\146\141\x63\164\157\162\x5f\155\145\164\x68\157\144"]) ? sanitize_text_field(wp_unslash($post["\x6d\x6f\62\x66\137\x73\145\x6c\x65\143\164\145\x64\137\x6d\146\x61\143\164\x6f\162\x5f\x6d\x65\x74\x68\157\x64"])) : '';
        $ok = isset($post["\x72\145\144\151\x72\145\x63\x74\137\x74\157"]) ? esc_url_raw(wp_unslash($post["\x72\145\x64\151\x72\x65\x63\x74\137\x74\x6f"])) : null;
        $v1 = MO2f_Utility::mo2f_get_transient($jg, "\x6d\x6f\62\146\137\143\x75\162\162\x65\x6e\164\x5f\x75\x73\x65\162\137\151\x64");
        $cs = get_user_by("\151\144", $v1);
        $this->mo2f_select_method_for_login($cs, $AA, $jg, $ok);
        exit;
    }
    public function mo2f_email_verification_success($post)
    {
        $Ty = isset($post["\x73\145\x73\x73\x69\157\x6e\x5f\x69\144"]) ? sanitize_text_field($post["\x73\145\163\x73\x69\x6f\156\137\151\144"]) : null;
        $HN = isset($post["\x74\167\157\146\141\137\163\x74\141\x74\165\163"]) ? sanitize_text_field($post["\164\x77\x6f\146\141\137\x73\164\141\x74\x75\x73"]) : '';
        $ok = isset($post["\162\145\144\x69\x72\x65\x63\164\x5f\x74\157"]) ? esc_url_raw($post["\162\x65\144\151\162\145\143\x74\137\164\x6f"]) : null;
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\155\x6f\62\146\x5f\x63\x75\162\162\x65\x6e\164\x5f\x75\163\145\x72\x5f\151\x64");
        if (MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS !== $HN || TwoFAMoSessions::get_session_var("\155\157\x32\x66\137\x69\163\137\x6b\142\x61\x5f\x62\x61\x63\153\165\160\x5f\143\157\x6e\x66\x69\147\x75\x72\x65\x64" . $v1)) {
            goto HD;
        }
        if (!get_site_option("\155\157\x32\x66\137\162\x65\x6d\x65\x6d\x62\145\x72\x5f\x64\x65\x76\x69\x63\145")) {
            goto mv;
        }
        do_action("\x6d\x6f\x32\x66\x5f\145\156\164\145\x72\x70\162\x69\x73\x65\x5f\160\154\x61\156\x5f\163\145\x74\164\151\x6e\x67\x73\137\x61\143\164\x69\x6f\156", "\155\157\x32\146\x5f\x72\x65\x6d\145\155\142\x65\162\x5f\144\x65\x76\151\x63\145\137\x64\145\164\141\151\154\163", array("\x75\x73\x65\162\x5f\151\x64" => $v1, "\163\145\163\x73\151\x6f\156\x5f\x69\x64" => $Ty, "\x72\x65\x64\151\162\145\143\x74\x5f\164\x6f" => $ok));
        mv:
        $this->mo2fa_pass2login($ok, $Ty);
        goto JQ;
        HD:
        $Kl = new Mo2f_Common_Helper();
        $Kl->mo2f_inline_setup_success($v1, $ok, $Ty);
        JQ:
        exit;
    }
    public function mo2f_skip_2fa_setup($post)
    {
        global $Gw;
        $Ty = isset($post["\163\145\163\x73\x69\x6f\156\137\151\144"]) ? sanitize_text_field(wp_unslash($post["\163\145\x73\x73\151\x6f\156\x5f\151\x64"])) : null;
        $ok = isset($post["\162\145\x64\151\x72\x65\143\x74\x5f\x74\x6f"]) ? esc_url_raw(wp_unslash($post["\162\145\144\151\162\x65\143\x74\137\164\x6f"])) : '';
        $Ty = sanitize_text_field($Ty);
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\x6d\x6f\x32\x66\x5f\143\165\x72\162\145\x6e\164\x5f\x75\x73\145\162\137\x69\144");
        if (get_user_meta($v1, "\155\x6f\62\146\137\147\x72\141\x63\x65\137\x70\x65\x72\x69\157\x64\x5f\x73\164\x61\162\164\137\x74\151\155\x65", true)) {
            goto g1;
        }
        update_user_meta($v1, "\155\x6f\x32\146\137\x67\x72\141\x63\x65\137\x70\145\x72\151\x6f\144\x5f\x73\164\141\x72\x74\x5f\x74\x69\x6d\x65", strtotime(current_datetime()->format("\x68\72\x69\141\40\115\x20\144\x20\x59")));
        g1:
        $this->mo2fa_pass2login($ok, $Ty);
    }
    public function mo2f_email_verification_failed($post)
    {
        MO2f_Utility::mo2f_debug_file("\115\117\x20\121\122\55\143\x6f\x64\x65\x2f\160\x75\163\x68\40\x6e\157\x74\x69\x66\151\x63\141\164\x69\157\156\x20\141\x75\164\150\x20\x64\x65\x6e\x69\x65\x64\x2e");
        $_SESSION["\x65\x6d\x61\x69\x6c\137\x74\x72\141\156\163\x61\x63\x74\151\157\x6e\137\x64\x65\156\x69\145\x64\137\x65\162\x72\157\x72"] = "\x59\157\165\x72\x20\x74\x72\141\156\163\x61\x63\164\151\157\x6e\40\x68\x61\163\40\x62\145\145\x6e\x20\x64\145\156\x69\x65\x64\x21";
    }
    public function mo2f_download_backup_codes_inline($post)
    {
        $oz = isset($post["\155\x6f\62\x66\x5f\x69\156\154\151\156\x65\137\142\x61\x63\x6b\x75\160\x5f\x63\157\x64\145\163"]) ? sanitize_text_field(wp_unslash($post["\x6d\157\x32\x66\x5f\151\156\x6c\x69\x6e\x65\137\142\141\143\x6b\x75\160\137\x63\x6f\144\x65\163"])) : '';
        $oB = explode("\x2c", $oz);
        $jg = isset($post["\x73\x65\163\163\x69\157\156\x5f\x69\x64"]) ? sanitize_text_field(wp_unslash($post["\163\145\x73\163\x69\157\156\x5f\151\x64"])) : '';
        $L4 = $this->mo2f_user_id ? $this->mo2f_user_id : MO2f_Utility::mo2f_get_transient($jg, "\x6d\x6f\62\146\137\x63\165\x72\162\145\x6e\x74\x5f\x75\x73\x65\162\x5f\x69\144");
        MO2f_Utility::mo2f_download_backup_codes($L4, $oB);
    }
    public function mo2f_finish_inline_and_login($post)
    {
        $QN = new Miniorange_Password_2Factor_Login();
        $Ty = isset($post["\x73\145\x73\x73\x69\x6f\x6e\x5f\151\x64"]) ? sanitize_text_field(wp_unslash($post["\163\145\x73\x73\x69\157\x6e\137\151\144"])) : null;
        $ok = isset($post["\x72\x65\x64\x69\162\x65\x63\164\137\164\x6f"]) ? esc_url_raw(wp_unslash($post["\162\x65\x64\x69\162\145\x63\x74\x5f\x74\157"])) : '';
        $this->mo2fa_pass2login($ok, $Ty);
        exit;
    }
}
new Mo2f_Main_Handler();
m3:
