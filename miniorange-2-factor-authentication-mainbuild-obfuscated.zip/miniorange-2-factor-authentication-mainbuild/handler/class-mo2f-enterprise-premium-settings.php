<?php


namespace TwoFA\Onprem;

if (defined("\101\x42\123\x50\x41\124\110")) {
    goto M0;
}
exit;
M0:
use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Onprem\Mo2f_Premium_Common_Helper;
use TwoFA\Helper\Mo2f_Common_Helper;
use TwoFA\Helper\TwoFAMoSessions;
use TwoFA\Helper\Mo2f_Login_Popup;
use TwoFA\Helper\MoWpnsConstants;
use WP_Session_Tokens;
if (class_exists("\x4d\x6f\62\146\137\x45\156\164\145\x72\x70\x72\151\x73\145\137\120\x72\145\155\x69\165\155\137\123\x65\x74\164\151\x6e\147\x73")) {
    goto Mj;
}
class Mo2f_Enterprise_Premium_Settings
{
    private $show_message;
    public function __construct()
    {
        add_action("\x6d\x6f\x32\146\x5f\x65\156\164\145\x72\160\x72\151\x73\x65\x5f\160\154\x61\x6e\137\x73\145\x74\164\x69\x6e\x67\x73\137\141\x63\x74\151\x6f\x6e", array($this, "\155\157\x32\146\137\x68\141\156\x64\154\x65\x5f\141\x63\x74\151\157\156\x5f\145\x6e\x74\145\162\160\162\151\163\145\x5f\x70\x6c\x61\x6e\137\163\x65\164\164\x69\156\x67\163"), 10, 2);
        add_action("\x69\x6e\151\x74", array($this, "\x6d\157\x32\146\x5f\155\x69\147\162\141\164\145\x5f\162\142\x61\137\144\x65\164\141\x69\x6c\x73"));
        add_filter("\x6d\x6f\x32\146\137\x65\x6e\x74\x65\x72\x70\162\151\163\145\x5f\x70\x6c\x61\156\137\163\145\x74\164\x69\156\x67\x73\x5f\x66\151\154\164\145\x72", array($this, "\x6d\157\x32\x66\x5f\x68\141\156\x64\x6c\145\137\x66\x69\154\x74\x65\x72\x5f\145\x6e\164\x65\x72\x70\162\151\163\145\x5f\x70\154\141\x6e\x5f\163\145\x74\x74\151\156\x67\x73"), 10, 3);
        add_filter("\x61\165\164\150\x5f\x63\157\157\153\x69\145\137\145\x78\x70\x69\x72\141\x74\x69\157\x6e", array($this, "\155\x6f\62\146\x5f\165\x73\145\x72\x5f\163\145\163\163\x69\x6f\156\137\x65\x78\160\x69\x72\x79"), 10, 3);
        add_action("\x6c\157\x67\x69\156\137\146\x6f\x6f\164\145\x72", array($this, "\155\x6f\62\146\x5f\x65\x6e\x71\165\145\165\x65\137\x72\142\x61\x5f\163\x63\x72\x69\x70\164"));
        add_action("\154\x6f\147\151\x6e\137\x66\157\x72\x6d", array($this, "\155\x6f\x32\146\137\x63\150\x61\x6e\147\145\137\x77\x70\x5f\x6c\157\x67\151\x6e\x5f\146\157\162\155"));
        add_action("\154\157\x67\x69\x6e\137\146\x6f\157\x74\x65\162", array($this, "\155\157\x32\146\137\x63\150\x61\156\147\x65\x5f\167\160\x5f\x6c\157\x67\151\x6e\137\x66\x6f\162\x6d\137\146\157\x6f\x74\145\162"));
        add_filter("\x69\x6e\151\x74", array($this, "\155\157\62\146\137\x68\x61\x6e\x64\x6c\x65\x5f\x65\x6e\x74\145\x72\160\x72\151\x73\x65\137\x66\x6c\157\167"));
        add_filter("\x6c\157\x67\151\x6e\x5f\155\x65\x73\163\x61\x67\x65", array($this, "\x6d\x6f\62\x66\137\x73\150\x6f\x77\137\157\156\x5f\x77\160\x5f\154\157\147\151\x6e\137\x66\x6f\162\x6d"));
    }
    public function mo2f_handle_enterprise_flow()
    {
        $dk = isset($_POST["\x6d\x6f\62\x66\x5f\145\156\x74\x65\162\x70\162\151\x73\145\137\160\x6c\141\156\137\x6e\157\x6e\x63\x65"]) ? sanitize_text_field(wp_unslash($_POST["\155\157\62\x66\137\145\156\164\x65\162\160\x72\x69\x73\145\137\x70\154\x61\156\137\x6e\157\156\x63\x65"])) : '';
        if (wp_verify_nonce($dk, "\155\157\x32\146\x2d\x65\156\164\x65\162\160\162\x69\163\x65\x2d\160\x6c\141\x6e\x2d\x6e\157\x6e\143\145")) {
            goto SM;
        }
        return;
        SM:
        $Xh = isset($_POST["\x6f\x70\164\x69\157\156"]) ? sanitize_text_field(wp_unslash($_POST["\157\x70\164\151\157\156"])) : '';
        switch ($Xh) {
            case "\x6d\x6f\62\146\137\x70\x61\x73\163\167\157\x72\144\154\145\x73\x73\x5f\154\157\x67\151\x6e":
                return $this->mo2f_passwordless_login($_POST);
        }
        PG:
        JY:
    }
    public function mo2f_handle_action_enterprise_plan_settings($wD, $post)
    {
        switch ($wD) {
            case "\x6d\x6f\x32\146\137\x73\141\x76\145\x5f\x73\x65\x73\x73\x69\157\156\x5f\x6d\x61\x6e\141\x67\145\155\x65\x6e\164\137\x73\x65\x74\164\x69\x6e\x67\163":
                $this->mo2f_save_session_management_settings($post);
                goto Dp;
            case "\155\157\x32\146\x5f\x73\141\166\x65\x5f\x72\x62\141\x5f\163\145\x74\x74\151\156\x67\x73":
                $this->mo2f_save_rba_settings($post);
                goto Dp;
            case "\155\x6f\x32\x66\137\143\150\x65\143\153\x5f\x72\142\x61\137\x64\145\164\x61\151\x6c\163":
                $this->mo2f_check_rba_details($post);
                goto Dp;
            case "\x6d\157\x32\146\x5f\x72\145\x6d\145\155\x62\145\x72\x5f\144\145\x76\x69\x63\145\x5f\x64\x65\x74\141\x69\x6c\x73":
                $this->mo2f_remember_device_details($post);
                goto Dp;
            case "\155\x6f\62\x66\137\x72\145\x6d\x65\x62\145\x72\137\144\x65\166\x69\143\x65\137\x74\x72\165\x65":
                $this->mo2f_remeber_device_true($post);
                goto Dp;
            case "\x6d\x6f\x32\146\137\162\x65\x6d\145\142\145\x72\x5f\x64\145\x76\x69\x63\x65\x5f\146\x61\154\163\145":
                $this->mo2f_remeber_device_false($post);
                goto Dp;
            case "\x6d\157\x32\146\137\x72\145\x6d\157\x76\145\137\x72\x65\155\145\155\x62\x65\162\x65\144\137\x64\145\x76\151\x63\x65":
                $this->mo2f_remove_remembered_device($post);
                goto Dp;
            case "\x6d\x6f\62\146\137\141\144\x64\x5f\x63\x75\163\164\x6f\x6d\x5f\x6c\x6f\147\157":
                $this->mo2f_add_custom_logo($post);
                goto Dp;
            case "\155\157\62\146\x5f\162\145\163\x65\164\137\143\x75\163\164\x6f\x6d\137\x6c\157\x67\x6f":
                $this->mo2f_reset_custom_logo($post);
                goto Dp;
            case "\163\x61\x76\145\x5f\x63\x75\163\x74\x6f\x6d\137\x72\145\x64\x69\162\x65\143\x74\x69\x6f\x6e\x5f\165\162\x6c\x73":
                $this->mo2f_save_custom_redirection_urls($post);
                goto Dp;
            case "\x6d\x6f\62\x66\137\x6c\157\147\x69\156\137\x70\x6f\x70\165\x70\137\143\165\x73\x74\x6f\155\151\x7a\x61\x74\151\x6f\156":
                $this->mo2f_login_popup_customization($post);
                goto Dp;
            case "\x6d\157\62\146\x5f\x73\x61\166\x65\137\x6c\157\x67\151\156\137\x70\x6f\160\x75\x70\137\163\x65\164\x74\x74\151\x6e\147\163":
                $this->mo2f_save_login_popup_setttings($post);
                goto Dp;
            case "\x6d\x6f\62\x66\137\162\x65\163\x65\164\x5f\163\141\x76\145\x5f\x6c\157\147\151\x6e\137\x70\x6f\160\165\x70\137\163\x65\x74\x74\164\x69\156\147\163":
                $this->mo2f_reset_save_login_popup_setttings();
                goto Dp;
            case "\155\157\62\x66\137\x73\x61\166\145\137\x63\x75\163\164\157\x6d\137\x65\x6d\x61\151\x6c\137\166\145\x72\151\x66\151\x63\141\x74\x69\x6f\x6e\x5f\x72\x65\163\160\x6f\x6e\x73\145\137\x73\145\x74\x74\151\156\x67\x73":
                $this->mo2f_save_custom_email_verification_response_settings($post);
                goto Dp;
            case "\155\x6f\62\x66\137\x72\x65\x73\x65\164\x5f\x61\x63\143\145\160\x74\137\x64\145\156\x79\x5f\145\x6d\x61\x69\154\x5f\x76\145\162\x69\146\x69\x63\x61\164\x69\x6f\156\137\163\x65\x74\164\x69\156\147\x73":
                $this->mo2f_reset_accept_deny_email_verification_settings($post);
                goto Dp;
            case "\155\157\x32\x66\x5f\x73\141\166\x65\x5f\x63\165\x73\x74\x6f\x6d\x5f\x73\x65\x63\165\162\x69\164\x79\137\161\165\145\x73\x74\x69\157\156\163\x5f\x73\145\164\164\151\156\x67\163":
                $this->mo2f_save_custom_security_questions_settings($post);
                goto Dp;
            case "\155\157\x32\x66\x5f\x72\145\163\x65\x74\137\x63\x75\x73\x74\x6f\x6d\137\163\145\x63\x75\162\151\x74\x79\137\161\165\x65\163\164\151\157\156\163\x5f\x73\145\164\x74\151\x6e\x67\163":
                $this->mo2f_reset_custom_security_questions_settings();
                goto Dp;
            case "\x6d\x6f\x32\x66\x5f\x70\x61\x73\x73\167\x6f\162\x64\154\145\x73\163\137\x6c\x6f\147\151\x6e\137\163\145\x74\x74\151\156\x67\x73":
                $this->mo2f_passwordless_login_settings($post);
                goto Dp;
        }
        dG:
        Dp:
    }
    public function mo2f_change_wp_login_form()
    {
        $cB = new Mo2f_Premium_Common_Helper();
        $R_ = $cB->mo2f_apply_2fa_settings();
        if (!($R_ && !get_site_option("\x6d\157\62\x66\137\x6c\x6f\147\151\x6e\137\157\x70\x74\151\x6f\156", 1) && !TwoFAMoSessions::get_session_var("\155\157\x32\x66\137\x73\x68\157\167\137\144\145\x66\x75\154\164\137\x6c\x6f\x67\151\x6e\x5f\x66\x6f\162\155"))) {
            goto mK;
        }
        $P8 = new Mo2f_Premium_Common_Helper();
        $P8->mo2f_enqueue_for_passwordless_login();
        $P8->mo_2_factor_show_wp_login_form();
        mK:
    }
    public function mo2f_show_on_wp_login_form($jY)
    {
        if (!TwoFAMoSessions::get_session_var("\x6d\x6f\62\146\137\163\x68\157\x77\x5f\145\162\x72\157\162\x5f\x6d\x65\163\163\141\147\145")) {
            goto T3;
        }
        $jY = "\x3c\x64\x69\166\40\x69\x64\x3d\x27\154\x6f\147\x69\x6e\137\x65\162\x72\x6f\x72\x31\x27\76\x20\x3c\x70\x3e" . TwoFAMoSessions::get_session_var("\155\157\x32\146\137\163\x68\x6f\x77\x5f\x65\x72\x72\x6f\162\x5f\x6d\x65\163\x73\x61\147\x65") . "\x3c\57\x70\76\x3c\x2f\144\x69\166\x3e";
        TwoFAMoSessions::unset_session("\155\157\x32\146\137\163\150\x6f\x77\137\145\162\x72\157\162\137\x6d\x65\x73\x73\141\147\x65");
        T3:
        return $jY;
    }
    public function mo2f_passwordless_login($post)
    {
        $Zi = isset($post["\x6d\x6f\x32\x66\x61\137\165\x73\x65\162\x6e\x61\x6d\145"]) ? sanitize_text_field(wp_unslash($post["\x6d\157\x32\146\141\137\x75\x73\145\x72\x6e\141\155\x65"])) : '';
        $cB = new Mo2f_Common_Helper();
        $current_user = $cB->mo2f_get_user($Zi);
        $cs = $cB->mo2f_wp_authenticate($Zi, '', $current_user);
        if (!is_wp_error($cs)) {
            goto LN;
        }
        if (get_site_option("\x6d\x6f\x32\146\137\163\x68\157\x77\x5f\x6c\157\147\x69\156\x77\x69\x74\150\x5f\x70\150\x6f\156\145")) {
            goto ja;
        }
        TwoFAMoSessions::add_session_var("\155\x6f\x32\146\x5f\143\150\x61\x6e\x67\145\137\x65\x72\x72\x6f\x72\137\x6d\x65\163\163\141\x67\x65", MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_USERNAME));
        goto fx;
        ja:
        TwoFAMoSessions::add_session_var("\155\x6f\x32\146\137\x73\150\x6f\x77\x5f\145\x72\162\x6f\162\137\155\145\x73\x73\141\x67\145", MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_USERNAME));
        fx:
        return $cs;
        LN:
        $cB = new Mo2f_Common_Helper();
        if ($cB->mo2f_is_2fa_set($cs->ID)) {
            goto eW;
        }
        TwoFAMoSessions::add_session_var("\155\157\x32\146\137\x63\x68\x61\x6e\x67\x65\137\145\x72\x72\157\x72\137\x6d\145\x73\x73\x61\x67\145", MoWpnsMessages::lang_translate(MoWpnsMessages::TWOFA_NOT_CONFIGURED));
        TwoFAMoSessions::add_session_var("\x6d\x6f\x32\x66\137\x73\x68\x6f\x77\x5f\144\x65\x66\x75\154\164\x5f\x6c\157\147\x69\x6e\137\146\157\162\x6d", true);
        goto z9;
        eW:
        $y4 = new Mo2f_Main_Handler();
        $cs = $y4->miniorange_initiate_2nd_factor($cs, '', null);
        TwoFAMoSessions::add_session_var("\155\157\62\146\x5f\x63\x68\141\156\147\145\x5f\145\x72\162\x6f\162\x5f\155\145\x73\x73\141\147\x65", MoWpnsMessages::lang_translate(MoWpnsMessages::TWOFA_NOT_ENABLED));
        TwoFAMoSessions::add_session_var("\155\x6f\x32\x66\x5f\163\150\157\x77\x5f\144\145\146\165\154\164\137\154\157\147\x69\156\x5f\146\157\x72\155", true);
        z9:
        return $cs;
    }
    public function mo2f_change_wp_login_form_footer()
    {
        $cB = new Mo2f_Premium_Common_Helper();
        $R_ = $cB->mo2f_apply_2fa_settings();
        if (!($R_ && !get_site_option("\x6d\x6f\62\146\137\x6c\157\147\151\x6e\137\157\x70\x74\x69\x6f\156", 1) && !TwoFAMoSessions::get_session_var("\x6d\157\62\146\137\163\150\x6f\167\137\x64\x65\146\x75\x6c\164\x5f\154\x6f\147\151\x6e\x5f\146\157\x72\155"))) {
            goto g0;
        }
        $P8 = new Mo2f_Premium_Common_Helper();
        $P8->mo2f_pwd_less_wp_login_form_footer();
        g0:
    }
    public function mo2f_remove_remembered_device($post)
    {
        $v1 = $post["\x75\163\145\x72\137\151\x64"];
        $wN = $post["\x66\151\x6e\x67\145\x72\x70\x72\151\x6e\x74"];
        $xa = get_user_meta($post["\x75\163\x65\162\x5f\x69\x64"], "\x6d\x6f\62\x66\137\x72\142\x61\x5f\144\145\166\151\143\x65\137\144\x65\164\x61\x69\x6c\x73", true);
        unset($xa[$wN]);
        update_user_meta($v1, "\x6d\157\x32\x66\x5f\162\142\141\x5f\x64\x65\166\x69\x63\x65\x5f\144\145\x74\x61\x69\154\163", $xa);
        wp_send_json_success("\x44\145\x76\151\143\145\x20\x72\x65\x6d\157\166\x65\x64\40\x73\x75\x63\143\145\163\163\x66\165\154\154\x79\x2e");
    }
    public function mo2f_remeber_device_false($post)
    {
        $Ty = $post["\163\x65\163\x73\151\x6f\x6e\x5f\151\x64"];
        $ok = $post["\x72\x65\144\x69\x72\x65\143\164\x5f\x74\x6f"];
        $y4 = new Mo2f_Main_Handler();
        $y4->mo2fa_pass2login($ok, $Ty);
    }
    public function mo2f_remeber_device_true($post)
    {
        $v1 = $post["\165\163\145\162\137\151\x64"];
        $Ty = $post["\x73\x65\x73\x73\151\157\156\x5f\151\144"];
        $zK = MO2f_Utility::mo2f_get_transient($Ty, "\x6d\x6f\x32\146\141\137\x72\x62\x61\x5f\141\164\x74\162\x69\x62\165\x74\145\163");
        $ok = $post["\162\x65\144\x69\x72\x65\x63\164\137\164\x6f"];
        $bC = $this->mo2f_register_rba_profile($v1, $zK, $Ty);
        $y4 = new Mo2f_Main_Handler();
        $y4->mo2fa_pass2login($ok, $Ty);
    }
    public function mo2f_check_rba_details($post)
    {
        $v1 = $post["\165\x73\145\x72\x5f\151\x64"];
        $zK = $post["\x61\x74\x74\162\151\x62\x75\x74\x65\x73"];
        $Ty = $post["\x73\145\x73\163\151\157\x6e\137\151\144"];
        $ok = $post["\x72\145\144\151\162\145\x63\164\137\164\x6f"];
        if (get_site_option("\x6d\x6f\62\x66\x5f\162\145\x6d\x65\x6d\x62\x65\162\x5f\144\145\x76\151\x63\145") && get_site_option("\155\x6f\x32\x66\x5f\x6c\x6f\147\x69\x6e\x5f\157\x70\x74\x69\x6f\x6e", "\x31")) {
            goto DT;
        }
        $QK["\x73\164\141\164\165\163"] = "\x52\102\101\137\x4e\117\124\x5f\x45\x4e\x41\x42\x4c\105\x44";
        goto AF;
        DT:
        $_SESSION["\141\x74\x74\x72\151\x62\x75\x74\x65\x73"] = '';
        $_SESSION["\x75\x73\x65\162\x5f\151\144"] = '';
        $vF = json_decode(stripslashes($zK), true);
        if (is_array($vF)) {
            goto ob;
        }
        $QK["\163\164\x61\x74\165\x73"] = "\101\x54\124\x52\x49\102\x55\124\105\137\105\122\x52\117\122";
        goto XV;
        ob:
        if (count($vF) !== 9) {
            goto WG;
        }
        $hU = sanitize_text_field($vF[8]["\141\x74\164\162\x56\141\154\x75\x65"]);
        $cB = new Mo2f_Premium_Common_Helper();
        $vv = $cB->mo2f_get_rba_device_details($v1, md5($hU), $Ty);
        if (!("\x53\125\103\103\x45\x53\x53" !== $vv)) {
            goto dJ;
        }
        MO2f_Utility::mo2f_set_transient($Ty, "\155\x6f\x32\146\x61\x5f\x72\x62\x61\137\x61\x74\164\162\151\x62\x75\x74\x65\163", $zK, 600);
        dJ:
        $QK["\163\164\x61\164\165\x73"] = $vv;
        goto x0;
        WG:
        $QK["\163\164\x61\x74\165\163"] = "\x41\124\x54\x52\x49\x42\x55\x54\105\x5f\x45\122\122\x4f\x52";
        x0:
        XV:
        AF:
        $this->mo2f_handle_rba_response($QK, $Ty, $ok, $v1);
    }
    public function mo2f_add_custom_logo($post)
    {
        $pd = new MoWpnsMessages();
        if (!(isset($post["\x69\155\147\106\151\154\145"]) && !empty($post))) {
            goto cu;
        }
        $X4 = isset($post["\151\x6d\147\x46\151\x6c\145"]["\164\x6d\x70\x5f\x6e\141\155\x65"]) ? $post["\151\x6d\x67\x46\151\x6c\145"]["\x74\155\x70\137\156\x61\x6d\x65"] : '';
        if (!empty($X4)) {
            goto Hh;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate("\111\156\166\141\154\151\x64\40\x66\x69\x6c\145\40\x74\x79\160\145\56"), "\x45\122\x52\117\x52");
        return;
        Hh:
        cu:
        $rI = dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . "\151\156\143\x6c\165\x64\145\163" . DIRECTORY_SEPARATOR . "\x69\155\141\x67\145\163";
        $rD = isset($post["\x69\x6d\147\106\151\154\145"]["\156\141\x6d\145"]) ? $post["\151\155\147\106\x69\x6c\145"]["\x6e\141\155\145"] : '';
        $uC = $rI . DIRECTORY_SEPARATOR . basename($rD);
        $zs = strtolower(pathinfo($uC, PATHINFO_EXTENSION));
        $C9 = array("\x70\x6e\x67", "\152\160\147", "\x6a\160\145\x67", "\147\x69\x66", "\163\x76\147");
        if (isset($post["\x69\x6d\147\x46\x69\x6c\x65"]["\x73\x69\x7a\x65"]) && $post["\151\x6d\x67\x46\x69\154\x65"]["\x73\x69\x7a\x65"] > 500000) {
            goto vL;
        }
        if (!in_array($zs, $C9, true)) {
            goto UA;
        }
        $uC = $rI . DIRECTORY_SEPARATOR . basename("\155\157\x32\x66\x5f\x63\165\163\164\157\155\56" . $zs);
        move_uploaded_file($X4, $uC);
        update_site_option("\x6d\157\x32\x66\137\143\165\x73\x74\157\155\137\x6c\157\147\157", "\x6d\157\62\146\x5f\143\165\x73\164\157\x6d\56" . $zs);
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate("\106\151\x6c\145\x20\x75\160\x6c\x6f\141\x64\x65\x64\x20\x73\x75\143\143\x65\163\163\x66\x75\154\154\171\x21"), "\x53\125\103\103\x45\x53\x53");
        goto JR;
        vL:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate("\106\151\154\145\40\163\x69\x7a\x65\x20\x69\x73\40\x74\x6f\157\x20\154\x61\162\x67\145\56"), "\105\x52\x52\117\x52");
        goto JR;
        UA:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate("\111\156\166\x61\x6c\151\x64\x20\146\151\154\x65\40\146\x6f\162\x6d\141\164\56"), "\x45\122\x52\117\122");
        JR:
    }
    public function mo2f_remember_device_details($post)
    {
        $v1 = $post["\165\163\x65\162\x5f\x69\x64"];
        $Ty = $post["\163\145\x73\163\151\x6f\x6e\x5f\x69\x64"];
        $zK = MO2f_Utility::mo2f_get_transient($Ty, "\155\x6f\62\146\141\137\x72\x62\141\137\x61\x74\x74\162\151\x62\165\164\145\x73");
        $ok = $post["\162\145\x64\x69\x72\145\x63\164\x5f\164\x6f"];
        $fb = is_array(get_user_meta($v1, "\x6d\x6f\x32\146\x5f\x72\142\x61\137\144\145\x76\x69\143\145\137\144\x65\x74\141\151\154\163", true)) ? count(get_user_meta($v1, "\x6d\x6f\62\x66\x5f\x72\x62\x61\137\x64\145\x76\x69\143\145\137\x64\145\164\141\x69\154\x73", true)) : 0;
        if (get_site_option("\x6d\157\62\x66\137\145\x6e\141\x62\154\145\x5f\x72\x62\141\137\x74\171\160\x65\x73", 1)) {
            goto Wr;
        }
        if ($fb < (int) get_site_option("\155\157\x32\x66\x5f\x64\x65\x76\x69\143\x65\137\x6c\x69\x6d\x69\164", 1)) {
            goto pA;
        }
        goto y5;
        Wr:
        $bC = $this->mo2f_register_rba_profile($v1, $zK, $Ty);
        if (!$bC) {
            goto Lw;
        }
        $y4 = new Mo2f_Main_Handler();
        $y4->mo2fa_pass2login($ok, $Ty);
        Lw:
        goto y5;
        pA:
        $AP = MoWpnsConstants::MO2F_RBA_GET_USER_CONSENT;
        $we = "\104\157\x20\171\157\165\40\167\x61\156\x74\x20\x74\157\40\x72\x65\x6d\x65\x6d\x62\x65\162\x20\x74\x68\151\163\40\144\x65\166\151\143\x65\77\40\122\x65\155\145\155\x62\145\x72\151\156\x67\x20\x74\x68\x69\163\x20\144\145\x76\x69\x63\145\x20\x65\156\x61\142\x6c\x65\x73\40\x79\x6f\165\x20\x74\157\40\x61\x76\157\x69\144\40\x74\150\x65\x20\x54\x77\157\x20\106\x61\143\x74\x6f\x72\x20\101\x75\164\x68\145\156\164\151\x63\141\x74\x69\157\156\40\50\62\106\x41\x29\40\x74\150\x65\40\x6e\145\x78\x74\x20\164\151\155\145\x20\171\x6f\x75\40\154\157\147\x69\156\x20\146\162\x6f\x6d\40\164\150\151\x73\40\144\x65\166\151\143\145\x2e";
        $yV = new Mo2f_Login_Popup();
        $yV->mo2f_show_login_prompt_for_otp_based_methods($we, $AP, get_user_by("\151\x64", $v1), $ok, $Ty, '');
        exit;
        y5:
    }
    public function mo2f_register_rba_profile($v1, $zK, $Ty = null)
    {
        $vF = json_decode(stripslashes($zK), true);
        if (!(is_array($vF) && count($vF) === 9)) {
            goto Sj;
        }
        return $this->mo2f_update_user_device_details($v1, $vF, $Ty);
        Sj:
        return "\x45\x52\x52\117\122";
    }
    public function mo2f_update_user_device_details($v1, $vF, $Ty = null)
    {
        $q_ = is_array(get_user_meta($v1, "\155\157\x32\x66\x5f\162\142\x61\x5f\x64\145\x76\x69\143\x65\x5f\144\x65\x74\141\151\x6c\x73", true)) ? get_user_meta($v1, "\x6d\157\x32\146\137\162\x62\141\137\144\x65\166\151\x63\x65\x5f\144\x65\164\141\x69\154\x73", true) : array();
        $fb = is_array(get_user_meta($v1, "\155\x6f\62\146\x5f\162\142\141\137\x64\145\166\x69\x63\145\x5f\x64\x65\164\141\x69\154\163", true)) ? count(get_user_meta($v1, "\155\157\62\146\137\x72\x62\x61\x5f\x64\x65\x76\151\x63\145\137\x64\145\x74\x61\x69\x6c\163", true)) : 0;
        if (!($fb >= (int) get_site_option("\x6d\157\62\146\137\144\x65\x76\151\x63\x65\137\x6c\151\x6d\x69\164", 1) && !MO2f_Utility::mo2f_get_transient($Ty, "\155\x6f\x32\146\137\x64\x65\166\x69\x63\145\x5f\145\170\x70\x69\162\145\144"))) {
            goto WD;
        }
        return false;
        WD:
        $user = get_userdata($v1);
        $ws = $user->user_nicename;
        $L9 = time() + get_site_option("\x6d\157\x32\146\x5f\144\145\x76\151\143\x65\x5f\x65\x78\160\151\162\171", 1) * 86400;
        $k8 = array("\x6d\x6f\62\146\137\165\x73\x65\x72\137\x69\x64" => $v1, "\155\157\x32\x66\x5f\x75\163\x65\x72\x5f\156\141\155\145" => $ws, "\x65\170\x70\151\x72\171" => $L9);
        foreach ($vF as $Tf) {
            if (isset($Tf["\141\164\x74\162\126\141\154\165\x65"])) {
                goto f9;
            }
            return false;
            goto w1;
            f9:
            $k8[$Tf["\x61\164\164\x72\x4e\141\155\x65"]] = $Tf["\x61\x74\x74\x72\126\141\154\x75\x65"];
            if (!("\x64\145\166\151\143\145\137\x64\x61\164\141" === $Tf["\141\164\164\x72\116\x61\x6d\x65"])) {
                goto qv;
            }
            $hU = sanitize_text_field($Tf["\x61\164\164\162\x56\141\154\165\145"]);
            $k8["\144\x65\x76\x69\143\145\x5f\144\x61\x74\x61\137\150\141\x73\150"] = md5($hU);
            qv:
            w1:
            LA:
        }
        vv:
        $q_[$k8["\144\x65\x76\x69\143\145\x5f\144\x61\164\141\x5f\150\x61\163\x68"]] = $k8;
        update_user_meta($v1, "\155\x6f\62\x66\137\162\x62\x61\137\144\x65\166\x69\x63\145\x5f\x64\145\164\x61\151\154\163", $q_);
        return true;
    }
    public function mo2f_handle_rba_response($QK, $Ty, $ok, $v1)
    {
        if ("\123\x55\x43\103\105\123\x53" === $QK["\163\x74\x61\164\165\x73"]) {
            goto Oz;
        }
        if ("\101\103\103\x45\x53\x53\137\x44\105\116\x59" === $QK["\163\164\x61\164\x75\163"]) {
            goto BT;
        }
        goto Mx;
        Oz:
        $y4 = new Mo2f_Main_Handler();
        $y4->mo2fa_pass2login($ok, $Ty);
        goto Mx;
        BT:
        $AP = MoWpnsConstants::MO2F_USER_BLOCKED_PROMPT;
        $we = "\x59\x6f\165\162\40\x61\x63\x63\145\163\x73\x20\151\x73\40\x6c\151\155\x69\164\145\x64\x20\164\x6f\40" . get_site_option("\155\157\62\146\x5f\x64\145\166\151\143\x65\137\154\151\x6d\151\164", "\163\151\164\145\137\157\160\x74\x69\157\156") . "\x20\144\145\x76\x69\143\x65\163\x2e\40\120\x6c\145\x61\x73\x65\40\x6c\x6f\x67\x69\x6e\40\x77\x69\164\x68\x20\157\x6c\x64\x20\x64\x65\166\151\143\x65\x73\x20\164\157\x20\147\x61\151\x6e\x20\141\x63\143\145\x73\163\x20\x6f\162\x20\x63\157\x6e\164\141\x63\x74\x20\x73\151\164\145\x20\141\x64\155\151\156\x69\163\164\x72\141\x74\157\x72\x20\x66\x6f\x72\x20\155\x6f\162\x65\40\x69\x6e\146\157\162\x6d\x61\x74\x69\157\156\56";
        $yV = new Mo2f_Login_Popup();
        $yV->mo2f_show_login_prompt_for_otp_based_methods($we, $AP, get_user_by("\x69\x64", $v1), $ok, $Ty, '');
        exit;
        Mx:
    }
    public function mo2f_passwordless_login_settings($post)
    {
        $sl = isset($post["\145\x6e\x61\142\154\x65\137\154\x6f\x67\x69\x6e\x5f\x77\x69\x74\x68\x5f\62\x66\141"]) ? "\164\162\165\145" === sanitize_text_field(wp_unslash($post["\145\x6e\141\x62\154\145\137\x6c\x6f\147\x69\156\137\167\151\x74\x68\x5f\x32\x66\141"])) : false;
        $Z3 = isset($post["\154\x6f\x67\151\x6e\x5f\x77\151\x74\150\x5f\160\x61\163\x73\x77\157\162\144"]) ? sanitize_text_field(wp_unslash($post["\x6c\157\x67\151\x6e\x5f\167\151\164\x68\x5f\160\x61\163\163\167\x6f\x72\x64"])) : 1;
        $H0 = get_site_option("\x6d\157\62\x66\x5f\x72\x65\155\x65\155\x62\x65\x72\137\x69\160\137\x63\157\156\146\x69\x67\165\x72\x61\x74\x69\157\156\x73", array());
        $CU = isset($H0["\155\157\x32\x66\x5f\162\145\x6d\145\155\142\145\x72\137\x69\x70\137\146\145\141\x74\x75\162\x65"]) ? $H0["\x6d\157\62\146\x5f\x72\x65\155\x65\x6d\142\145\162\x5f\x69\x70\x5f\x66\145\x61\x74\x75\162\145"] : 0;
        if (!(!$Z3 && (get_site_option("\x6d\x6f\x32\x66\137\162\x65\x6d\x65\x6d\142\145\162\137\144\x65\x76\x69\x63\145") || $CU))) {
            goto rD;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::PASSWORDLESS_LOGIN_CANNOT_BE_ENABLED_ERROR));
        rD:
        update_site_option("\155\x6f\x32\146\137\x6c\x6f\147\x69\x6e\x5f\x6f\160\x74\x69\157\156", $Z3);
        update_site_option("\x6d\157\x32\146\x5f\x73\x68\x6f\167\x5f\x6c\157\147\x69\156\167\151\x74\x68\137\160\x68\x6f\x6e\x65", $Z3 ? 0 : $sl);
        wp_send_json_success(MoWpnsMessages::lang_translate(MoWpnsMessages::SETTINGS_SAVED_SUCCESSFULLY));
    }
    public function mo2f_save_rba_settings($post)
    {
        $mZ = isset($post["\145\156\141\142\x6c\145\137\162\x62\141"]) ? "\164\162\x75\145" === sanitize_text_field(wp_unslash($post["\x65\x6e\x61\142\154\x65\137\x72\142\141"])) : false;
        $pL = isset($post["\x72\142\141\137\x74\171\x70\x65"]) ? sanitize_text_field(wp_unslash($post["\162\x62\x61\137\x74\171\160\x65"])) : 0;
        $xL = isset($post["\x72\142\x61\x5f\144\145\166\151\143\x65\x5f\x6c\x69\155\x69\x74"]) ? sanitize_text_field(wp_unslash($post["\x72\x62\x61\137\144\x65\x76\151\143\145\137\x6c\x69\155\x69\x74"])) : 1;
        $IA = isset($post["\x72\x62\141\x5f\x65\x78\160\x69\x72\171"]) ? sanitize_text_field(wp_unslash($post["\x72\x62\x61\x5f\145\x78\160\151\x72\x79"])) : 1;
        $AX = isset($post["\162\x62\141\137\154\x6f\147\151\x6e"]) ? sanitize_text_field(wp_unslash($post["\162\x62\x61\137\154\x6f\147\x69\x6e"])) : 0;
        $H0 = get_site_option("\155\157\x32\x66\137\162\x65\155\145\155\142\145\162\137\151\x70\137\x63\157\156\x66\x69\147\x75\162\x61\x74\151\x6f\156\163", array());
        $CU = isset($H0["\155\x6f\62\x66\x5f\x72\x65\x6d\145\x6d\x62\x65\x72\137\151\x70\137\146\x65\141\164\165\162\x65"]) ? $H0["\x6d\x6f\62\146\x5f\162\x65\155\x65\155\142\145\x72\137\x69\x70\x5f\x66\x65\141\x74\165\x72\x65"] : 0;
        if (!($mZ && (!get_site_option("\x6d\x6f\62\x66\x5f\x6c\157\x67\151\156\137\157\x70\x74\x69\x6f\156", 1) || $CU))) {
            goto q4;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::RBA_CANNOT_BE_ENABLED_ERROR));
        q4:
        if (!(1 > (int) $xL)) {
            goto yW;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::EXPECTED_RBA_DEVICE_LIMIT));
        yW:
        if (!(1 > (int) $IA)) {
            goto OQ;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::EXPECTED_RBA_EXPIRY));
        OQ:
        update_site_option("\x6d\157\x32\146\x5f\x64\x65\166\151\143\145\x5f\154\151\155\151\x74", $xL);
        update_site_option("\x6d\157\62\x66\x5f\x64\145\x76\151\143\145\x5f\x65\x78\x70\x69\x72\x79", $IA);
        update_site_option("\155\x6f\x32\146\137\x72\x65\x6d\145\155\142\x65\162\x5f\144\145\166\151\143\145", $mZ);
        update_site_option("\x6d\157\62\x66\x5f\x65\x6e\x61\x62\154\x65\x5f\x72\142\141\137\x74\x79\x70\x65\x73", $pL);
        update_site_option("\155\157\62\146\x5f\141\x63\164\151\157\x6e\x5f\x72\142\x61\137\154\151\x6d\x69\x74\x5f\x65\170\143\x65\145\144", $AX);
        wp_send_json_success(MoWpnsMessages::lang_translate(MoWpnsMessages::SETTINGS_SAVED_SUCCESSFULLY));
    }
    public function mo2f_save_custom_redirection_urls($post)
    {
        $g0 = $post["\x6d\157\62\146\137\x63\165\x73\164\x6f\x6d\137\x72\157\154\x65\163\x5f\x61\x6e\x64\137\165\x72\x6c\163"];
        $DV = array();
        foreach ($g0 as $t8 => $mn) {
            foreach ($mn as $gO => $xz) {
                if (isset($xz) && !empty($xz)) {
                    goto X3;
                }
                if (isset($xz) && empty($xz)) {
                    goto hc;
                }
                goto qu;
                X3:
                $cB = new Mo2f_Common_Helper();
                $Bc = $cB->mo2f_check_url_validation($xz);
                if ($Bc) {
                    goto DS;
                }
                $TO = explode("\137", $gO)[1];
                wp_send_json_error(MoWpnsMessages::lang_translate("\x49\x6e\x76\x61\154\151\x64\x20\162\145\144\x69\x72\145\143\x74\x69\157\156\x20\x75\x72\x6c\40\x66\157\162\x20" . $TO . "\56\x20\120\154\145\141\163\145\40\145\x6e\x74\145\162\40\166\x61\x6c\151\144\x20\x75\162\154\x2e"));
                goto ub;
                DS:
                $DV[sanitize_text_field(wp_unslash($gO))] = esc_url_raw(wp_unslash($xz));
                ub:
                goto qu;
                hc:
                wp_send_json_error(MoWpnsMessages::lang_translate("\x41\154\x6c\40\143\x75\163\x74\157\x6d\40\x72\x65\144\x69\x72\x65\143\x74\x69\157\x6e\x20\165\x72\x6c\x20\x66\151\145\x6c\144\x73\40\x6d\165\163\x74\x20\x62\x65\40\x66\x69\154\154\145\144\56"));
                qu:
                rb:
            }
            hG:
            z0:
        }
        t1:
        update_option("\155\x6f\x32\146\137\143\165\x73\x74\x6f\x6d\x5f\154\157\x67\x69\x6e\x5f\x75\162\x6c\x73", $DV);
        wp_send_json_success(MoWpnsMessages::lang_translate(MoWpnsMessages::SETTINGS_SAVED_SUCCESSFULLY));
    }
    public function mo2f_login_popup_customization($post)
    {
        $sc = isset($post["\143\x75\x73\164\157\x6d\x69\x7a\141\x74\151\157\156\x5f\145\x6e\x61\x62\154\145\144"]) ? "\x74\x72\165\145" === sanitize_text_field(wp_unslash($post["\143\165\x73\x74\157\155\151\x7a\x61\164\x69\x6f\156\137\145\x6e\x61\x62\154\x65\144"])) : false;
        update_site_option("\155\x6f\62\x66\x5f\x65\156\141\142\154\x65\x5f\x6c\x6f\x67\151\156\x5f\x70\157\x70\165\160\137\143\x75\x73\164\157\155\151\172\x61\164\x69\x6f\x6e", $sc);
        wp_send_json_success(MoWpnsMessages::lang_translate(MoWpnsMessages::SETTINGS_SAVED_SUCCESSFULLY));
    }
    public function mo2f_migrate_rba_details()
    {
        global $Gw;
        if (get_site_option("\155\x6f\x32\146\x5f\162\142\141\137\155\151\147\x72\x61\x74\x69\157\156")) {
            goto gW;
        }
        $zO = $Gw->mo2f_get_all_device_details();
        if (!$zO) {
            goto nL;
        }
        foreach ($zO as $WT) {
            $q_ = is_array(get_user_meta($WT->mo2f_user_id, "\x6d\157\62\146\x5f\x72\142\x61\x5f\x64\145\166\x69\x63\145\137\x64\x65\164\141\151\x6c\x73", true)) ? get_user_meta($WT->mo2f_user_id, "\155\157\x32\x66\137\x72\142\x61\x5f\144\145\x76\x69\x63\x65\x5f\144\x65\164\x61\x69\154\163", true) : array();
            $q_[$WT->device_data_hash] = (array) $WT;
            update_user_meta($WT->mo2f_user_id, "\x6d\x6f\62\146\x5f\x72\142\141\137\144\x65\166\x69\x63\x65\x5f\x64\x65\x74\x61\151\154\163", $q_);
            Xz:
        }
        SV:
        nL:
        update_site_option("\x6d\157\x32\x66\137\x72\x62\x61\x5f\x6d\151\x67\x72\141\x74\x69\157\156", 1);
        gW:
    }
    public function mo2f_handle_filter_enterprise_plan_settings($F6, $D4, $post)
    {
        switch ($D4) {
            case "\155\157\62\x66\x5f\x63\x68\x65\143\x6b\x5f\x73\x65\163\163\x69\157\x6e\x5f\x64\x65\164\x61\x69\154\163":
                return $this->mo2f_check_session_details($post);
            case "\x6d\157\62\146\137\x67\x65\x74\x5f\x61\154\154\x5f\165\x73\x65\x72\x73\x5f\162\142\141\137\x64\145\x74\x61\151\154\x73":
                return $this->mo2f_get_all_users_rba_details();
            case "\x6d\x6f\x32\146\137\x63\165\163\x74\x6f\155\137\x65\155\141\x69\x6c\x5f\x76\x65\162\151\146\151\x63\141\164\x69\157\156\137\160\x6f\160\x75\160\137\x61\x72\x67\x73":
                return $this->mo2f_modify_popup_args($post);
            case "\155\157\62\x66\137\143\x68\145\x63\153\x5f\146\x6f\x72\x5f\143\165\163\164\157\155\x5f\x73\145\x63\165\162\151\164\171\137\161\x75\145\x73\x74\x69\157\156\163":
                return $this->mo2f_check_for_custom_security_questions($post);
        }
        QW:
        AP:
    }
    public function mo2f_get_all_users_rba_details()
    {
        global $Gw;
        return $Gw->mo2f_get_all_users_rba_details();
    }
    public function mo2f_save_session_management_settings($post)
    {
        $YQ = isset($post["\x65\156\141\x62\154\x65\x5f\x73\x65\x73\x73\151\157\x6e\137\x73\x65\164\164\151\156\147"]) ? "\x74\x72\x75\145" === sanitize_text_field(wp_unslash($post["\x65\156\x61\x62\154\145\137\x73\145\x73\163\x69\x6f\x6e\x5f\163\x65\x74\164\151\156\x67"])) : false;
        $Kp = isset($post["\155\x61\170\137\x73\145\163\x73\151\x6f\x6e\163\x5f\141\x6c\x6c\x6f\167\x65\x64"]) ? sanitize_text_field(wp_unslash($post["\x6d\x61\x78\137\x73\x65\163\x73\x69\x6f\156\163\137\x61\154\x6c\157\x77\x65\144"])) : 1;
        $eE = isset($post["\162\145\163\164\162\x69\x63\164\151\x6f\156\x5f\164\x79\x70\x65"]) ? sanitize_text_field(wp_unslash($post["\162\145\x73\164\162\151\x63\x74\151\157\x6e\137\x74\171\160\145"])) : "\x65\x6e\146\157\x72\143\145\x5f\x75\163\145\x72\163";
        if (!(1 > (int) $Kp)) {
            goto um;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::EXPECTED_MAX_SESSIONS));
        um:
        $to = isset($post["\x65\156\x61\142\154\x65\x5f\163\x65\163\x73\x69\157\156\x5f\145\x78\160\x69\162\x79"]) ? "\164\x72\165\x65" === sanitize_text_field(wp_unslash($post["\x65\156\141\142\154\145\x5f\163\x65\x73\163\x69\157\156\137\x65\x78\x70\151\162\x79"])) : false;
        $QY = isset($post["\155\x61\170\137\163\145\x73\163\x69\x6f\x6e\163\137\164\151\x6d\x65"]) ? sanitize_text_field(wp_unslash($post["\x6d\141\x78\137\x73\145\163\163\151\x6f\156\163\x5f\164\151\155\x65"])) : 24;
        if (!(1 > (int) $QY)) {
            goto fi;
        }
        wp_send_json_error(MoWpnsMessages::lang_translate(MoWpnsMessages::EXPECTED_MAX_SESSION_TIME));
        fi:
        update_site_option("\x6d\157\x32\146\x5f\163\145\163\163\x69\157\156\x5f\154\157\x67\x6f\x75\x74\137\x74\x69\x6d\145\x5f\145\156\x61\x62\154\145", $to);
        update_site_option("\x6d\157\x32\x66\137\x6e\x75\x6d\x62\x65\162\137\157\x66\x5f\164\151\x6d\145\157\x75\164\137\x68\157\165\x72\x73", $QY);
        update_site_option("\x6d\157\x32\146\x5f\x73\x65\x73\x73\x73\x69\157\x6e\x5f\162\145\163\164\162\x69\x63\164\x69\x6f\x6e", $YQ);
        update_site_option("\x6d\157\x32\x66\137\x6d\x61\170\x69\x6d\x75\x6d\x5f\x61\x6c\x6c\x6f\167\x65\x64\x5f\x73\x65\163\x73\151\x6f\156", $Kp);
        update_site_option("\155\157\x32\x66\x5f\163\x65\x73\x73\x69\x6f\x6e\137\141\x6c\x6c\157\167\145\x64\x5f\164\171\x70\145", $eE);
        wp_send_json_success(MoWpnsMessages::lang_translate(MoWpnsMessages::SETTINGS_SAVED_SUCCESSFULLY));
    }
    public function mo2f_check_session_details($post)
    {
        $v1 = $post["\165\163\x65\162\x5f\x69\144"];
        if (!get_site_option("\x6d\x6f\x32\146\137\163\x65\163\x73\163\151\x6f\156\x5f\x72\x65\163\164\162\x69\x63\164\x69\157\x6e")) {
            goto nP;
        }
        $do = get_site_option("\155\157\62\x66\x5f\155\x61\170\x69\155\165\155\x5f\141\154\x6c\157\x77\145\x64\x5f\163\x65\163\x73\x69\157\x6e", 1);
        $ua = WP_Session_Tokens::get_instance($v1);
        $cK = count($ua->get_all());
        if (!($cK >= (int) $do)) {
            goto U4;
        }
        $Gm = get_site_option("\x6d\157\x32\x66\137\163\x65\x73\x73\151\x6f\156\137\x61\154\154\157\x77\x65\144\x5f\x74\171\160\145", "\x61\154\154\157\167\x5f\141\143\x63\x65\x73\x73");
        if ("\x61\x6c\154\x6f\167\x5f\x61\143\x63\145\x73\163" === $Gm) {
            goto HE;
        }
        return true;
        goto bi;
        HE:
        $Xf = WP_Session_Tokens::get_instance($v1);
        $vv = $Xf->destroy_all();
        bi:
        U4:
        nP:
        return false;
    }
    public function mo2f_user_session_expiry()
    {
        $pK = get_site_option("\155\x6f\62\146\137\x6e\165\x6d\x62\145\162\x5f\x6f\x66\x5f\164\151\x6d\145\157\x75\164\137\150\x6f\x75\162\x73");
        return $pK ? $pK * 60 * 60 : 14 * 24 * 60 * 60;
    }
    public function mo2f_save_login_popup_setttings($post)
    {
        global $wA;
        $pd = new MoWpnsMessages();
        if (!function_exists("\127\120\137\106\151\x6c\145\163\171\x73\x74\x65\x6d")) {
            require_once ABSPATH . "\x77\160\x2d\x61\144\x6d\x69\156\57\151\x6e\x63\154\165\x64\x65\163\x2f\146\151\154\x65\56\160\x68\x70";
        }
        WP_Filesystem();
        $cV = dirname(dirname(__FILE__)) . "\57\151\156\x63\x6c\165\x64\145\x73\57\x63\163\163\57\x6d\x6f\x32\146\x5f\154\x6f\147\x69\x6e\x5f\x70\157\x70\165\160\x5f\x75\151\x2e\x6d\151\156\56\143\163\x73";
        $hC = '';
        $Ob = array("\155\157\62\146\x5f\x63\165\163\x74\x6f\155\x5f\142\141\x63\x6b\x67\x72\x6f\x75\156\x64\137\143\x6f\154\x6f\162" => "\x2e\155\x6f\62\x66\x2d\x6d\x6f\144\141\154\55\x62\x61\x63\153\144\x72\157\x70\x7b\x62\141\x63\153\x67\x72\x6f\x75\156\x64\55\143\x6f\x6c\157\162\x3a\x20\43\x23\x63\165\x73\164\x6f\x6d\x5f\x63\163\x73\x23\43\x20\x21\x69\155\160\x6f\x72\164\141\x6e\164\x3b\x7d", "\x6d\157\x32\146\x5f\142\x61\143\x6b\147\x72\157\x75\156\144\x5f\x69\x6d\141\x67\x65" => "\x2e\x6d\x6f\62\146\x2d\x6d\157\x64\141\x6c\55\x62\141\x63\x6b\144\162\x6f\160\173\x20\x62\x61\x63\x6b\x67\162\x6f\165\x6e\x64\55\x69\x6d\x61\x67\x65\x3a\40\x75\x72\x6c\50\x22\43\43\x63\x75\163\x74\x6f\x6d\x5f\143\163\x73\x23\43\x22\x29\x20\41\151\x6d\x70\x6f\162\x74\x61\156\164\x3b\x20\142\x61\x63\x6b\147\162\x6f\165\156\144\55\162\x65\x70\145\141\164\72\x20\x6e\157\x2d\162\x65\160\145\141\164\x2c\40\162\x65\x70\145\x61\x74\73\x20\x62\141\143\153\147\x72\x6f\165\156\144\x2d\x73\x69\172\145\x3a\x63\x6f\166\145\x72\x3b\x62\x61\x63\x6b\147\162\157\165\x6e\x64\55\141\164\164\141\143\x68\155\145\x6e\164\72\40\146\x69\x78\145\x64\x3b\142\x61\x63\153\x67\162\x6f\165\156\x64\x2d\160\x6f\x73\x69\x74\x69\x6f\156\72\x20\143\145\156\164\145\162\x3b\40\x20\x7d", "\x6d\x6f\62\x66\x5f\x63\x75\163\x74\157\155\x5f\x70\157\x70\x75\160\x5f\142\x67\137\x63\157\x6c\157\x72" => "\x2e\155\x6f\137\143\165\163\x74\x6f\x6d\x65\x72\x5f\166\x61\154\151\144\141\x74\x69\157\x6e\55\155\x6f\x64\x61\154\x2d\143\157\x6e\164\145\156\164\54\40\x2e\155\157\62\x66\137\x67\141\165\164\150\x5f\147\x65\x74\141\x70\x70\173\142\x61\143\153\x67\162\x6f\x75\x6e\144\72\x23\43\x63\165\163\x74\x6f\155\137\x63\163\x73\x23\x23\x20\x21\x69\155\160\x6f\162\x74\141\x6e\164\73\175", "\x6d\x6f\x32\x66\x5f\143\165\x73\164\x6f\155\x5f\157\164\160\137\142\147\137\x63\157\x6c\x6f\162" => "\x2e\x6d\157\137\157\x74\x70\137\x74\x6f\153\145\x6e\173\x62\x61\143\x6b\x67\x72\x6f\165\x6e\144\x2d\143\157\x6c\x6f\x72\72\x23\43\143\165\163\x74\x6f\x6d\137\143\x73\x73\43\43\x20\41\151\155\x70\157\x72\x74\141\156\164\73\175", "\x6d\157\x32\146\137\143\165\163\164\157\155\137\157\x74\x70\x5f\x74\145\x78\164\137\143\157\154\157\162" => "\56\155\x6f\x5f\x6f\164\x70\137\x74\157\153\145\156\173\143\x6f\x6c\x6f\162\x3a\x23\x23\143\165\163\164\x6f\155\137\x63\x73\x73\43\43\x20\41\x69\x6d\160\x6f\162\164\141\x6e\x74\73\175", "\155\157\62\146\137\x63\165\x73\x74\x6f\155\137\155\x69\144\144\154\145\137\164\145\x78\164\x5f\143\x6f\154\x6f\x72" => "\56\x6d\x6f\62\x66\137\155\x69\x64\144\x6c\x65\x5f\x74\145\x78\x74\x7b\143\x6f\154\x6f\x72\72\43\43\143\x75\163\164\x6f\x6d\x5f\143\x73\163\x23\43\x21\151\155\160\157\162\x74\x61\156\164\x3b\175", "\x6d\x6f\x32\146\137\x63\165\x73\x74\157\155\137\150\145\x61\x64\145\162\137\164\145\x78\164\137\143\x6f\x6c\x6f\162" => "\x2e\x6d\157\x32\x66\x5f\155\x6f\144\141\x6c\55\x74\x69\x74\x6c\145\173\x63\x6f\x6c\x6f\x72\72\x23\43\143\165\163\x74\157\x6d\x5f\x63\x73\x73\x23\x23\41\151\155\160\157\x72\x74\141\x6e\x74\73\175", "\155\x6f\x32\x66\137\143\165\x73\x74\157\x6d\x5f\146\157\x6f\164\145\x72\x5f\164\x65\170\164\137\x63\157\154\x6f\x72" => "\x2e\x6d\157\62\x66\137\x66\157\x6f\x74\x65\162\137\x74\145\170\164\x7b\x63\157\x6c\157\162\72\x23\43\143\165\163\x74\157\155\137\143\x73\163\43\x23\41\x69\x6d\160\x6f\x72\164\141\x6e\164\73\175", "\x6d\x6f\x32\x66\x5f\x63\x75\163\164\157\155\x5f\154\x69\156\x6b\x73\137\x74\x65\x78\164\137\x63\x6f\154\157\x72" => "\x2e\160\165\163\x68\x48\145\x6c\x70\x4c\x69\156\153\x7b\143\x6f\154\157\x72\72\x23\43\143\165\163\x74\157\x6d\x5f\x63\x73\x73\x23\43\41\151\155\160\x6f\162\x74\x61\156\x74\73\x7d", "\155\x6f\62\x66\137\143\165\x73\x74\157\x6d\x5f\x6e\x6f\x74\151\x66\137\164\145\170\x74\x5f\x63\157\154\x6f\162" => "\x2e\x6d\x6f\x32\x66\141\x5f\x64\151\x73\160\x6c\141\171\137\155\x65\x73\163\x61\x67\145\137\x66\x72\157\156\x74\145\x6e\x64\x7b\143\157\154\x6f\x72\x3a\43\43\x63\165\163\x74\x6f\x6d\137\143\163\163\x23\43\41\x69\x6d\x70\157\162\164\141\x6e\164\73\175", "\155\x6f\x32\146\137\x63\x75\x73\164\x6f\x6d\137\156\x6f\x74\151\x66\x5f\x62\x67\x5f\x63\157\154\x6f\162" => "\43\157\x74\160\115\145\163\163\141\x67\145\x7b\142\141\x63\153\147\162\x6f\165\156\144\x3a\43\x23\143\165\163\x74\x6f\155\x5f\143\163\163\43\43\x21\151\155\x70\x6f\x72\164\141\x6e\164\x3b\175", "\x6d\x6f\x32\x66\137\143\165\x73\164\x6f\155\x5f\142\165\x74\x74\x6f\x6e\137\x63\x6f\154\157\162" => "\56\155\x69\156\151\157\x72\141\156\147\x65\x5f\157\x74\160\x5f\x74\x6f\x6b\145\156\137\163\x75\142\x6d\151\x74\54\x20\56\x6d\x69\x6e\x69\157\162\141\156\x67\x65\x5f\x6b\142\141\137\x76\x61\154\151\144\141\x74\x65\54\40\56\155\x69\x6e\151\x6f\x72\x61\156\147\145\137\x62\x75\x74\x74\157\156\x20\x7b\142\x61\x63\x6b\x67\162\x6f\x75\x6e\x64\72\x23\43\143\x75\163\164\x6f\155\x5f\143\x73\x73\x23\43\41\x69\155\160\x6f\x72\x74\x61\x6e\x74\73\175\x2e\x6d\151\x6e\151\x6f\162\x61\156\147\x65\137\157\164\160\x5f\x74\x6f\x6b\145\156\137\x73\x75\142\155\x69\164\72\150\x6f\x76\x65\162\54\x20\56\155\151\156\151\157\162\x61\156\147\x65\137\153\x62\x61\x5f\x76\141\x6c\x69\x64\x61\164\145\x3a\x68\x6f\166\x65\162\40\173\142\141\143\x6b\x67\x72\157\165\x6e\144\72\43\43\x63\x75\x73\x74\x6f\x6d\137\x63\163\163\43\x23\144\x36\x20\41\151\155\x70\157\x72\x74\x61\x6e\x74\x3b\x7d\x2e\x6d\x69\x6e\151\x6f\x72\141\x6e\x67\145\x5f\x6f\164\x70\137\x74\157\x6b\x65\156\137\163\165\x62\155\151\164\x7b\x62\157\x72\x64\x65\x72\x2d\x63\157\x6c\157\162\72\43\x23\x63\x75\x73\164\157\x6d\137\143\163\163\x23\x23\x21\x69\x6d\160\157\x72\164\141\156\164\73\175");
        $z2 = get_site_option("\155\x6f\62\x66\137\143\165\x73\x74\157\155\137\x32\146\x61\x5f\x70\157\x70\165\160\137\x63\x73\x73", array());
        foreach ($Ob as $UX => $iY) {
            if (!isset($post[$UX])) {
                goto cy;
            }
            $re = $post[$UX];
            $hC .= str_replace("\43\43\x63\x75\163\x74\157\x6d\x5f\143\x73\163\43\43", $re, $iY);
            $z2[$UX] = $re;
            cy:
            update_site_option("\155\157\x32\146\137\x65\x6e\x61\142\x6c\x65\x5f\154\x6f\x67\151\156\x5f\x70\157\160\x75\x70\x5f\143\x75\163\164\x6f\x6d\151\x7a\141\164\151\157\156", true);
            u7:
        }
        GJ:
        update_site_option("\155\157\62\x66\137\143\x75\x73\164\x6f\x6d\x5f\x32\x66\141\x5f\160\157\160\165\x70\137\x63\163\x73", $z2);
        $wA->put_contents($cV, $hC, FS_CHMOD_FILE);
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SETTINGS_SAVED_SUCCESSFULLY), "\123\125\x43\103\x45\x53\123");
    }
    public function mo2f_save_custom_email_verification_response_settings($post)
    {
        $pd = new MoWpnsMessages();
        $Ln = array();
        if (!isset($post["\x6d\157\x32\146\x5f\141\143\x63\145\x70\x74\137\164\145\x78\x74\137\x63\157\154\157\162"])) {
            goto tF;
        }
        $QC = sanitize_hex_color($post["\x6d\x6f\x32\146\137\141\x63\x63\145\160\x74\x5f\x74\x65\170\164\x5f\143\157\154\x6f\162"]);
        $Ln["\155\x6f\x32\x66\x5f\x61\143\x63\x65\160\164\137\x74\x65\x78\x74\137\x63\x6f\x6c\x6f\x72"] = $QC;
        tF:
        if (!isset($post["\x6d\x6f\x32\146\x5f\144\x65\156\x79\x5f\164\145\170\x74\x5f\x63\x6f\x6c\x6f\162"])) {
            goto Fd;
        }
        $cO = sanitize_hex_color($post["\x6d\157\62\x66\x5f\144\145\156\x79\137\164\x65\170\x74\x5f\x63\157\154\x6f\162"]);
        $Ln["\155\x6f\62\146\x5f\x64\145\x6e\x79\137\164\x65\170\164\x5f\143\157\154\157\x72"] = $cO;
        Fd:
        if (!isset($post["\x6d\x6f\62\146\x5f\141\143\143\x65\160\x74\137\x64\145\156\x79\137\x62\x67\137\143\x6f\x6c\x6f\162"])) {
            goto W8;
        }
        $B9 = sanitize_hex_color($post["\x6d\x6f\62\146\137\x61\143\x63\x65\x70\x74\137\x64\x65\x6e\171\x5f\142\x67\x5f\x63\157\x6c\157\x72"]);
        $Ln["\x6d\157\x32\146\x5f\x61\143\143\x65\x70\x74\137\x64\145\x6e\x79\x5f\142\147\137\x63\x6f\x6c\x6f\162"] = $B9;
        W8:
        if (!isset($post["\155\157\62\x66\x5f\x63\x75\163\164\157\x6d\137\x61\143\143\145\x70\x74\137\144\x65\156\171\x5f\151\155\147"])) {
            goto O_;
        }
        $KK = esc_url_raw($post["\155\x6f\62\x66\137\143\165\x73\x74\x6f\155\137\141\143\x63\145\x70\x74\x5f\144\x65\x6e\x79\x5f\x69\155\x67"]);
        $Ln["\x6d\x6f\x32\x66\137\x63\x75\x73\164\x6f\x6d\137\141\143\143\145\160\164\x5f\144\145\x6e\x79\x5f\x69\x6d\147"] = $KK;
        O_:
        update_site_option("\x6d\x6f\x32\146\137\145\x6d\x61\151\x6c\x5f\x76\145\x72\151\x66\x69\x63\x61\164\151\157\156\x5f\163\x65\x74\x74\151\156\147\x73", $Ln);
        update_site_option("\x6d\157\62\x66\x5f\145\x6e\x61\x62\x6c\x65\137\x63\165\x73\x74\157\155\x5f\x65\155\141\x69\x6c\x5f\x74\145\155\x70\154\x61\164\x65", true);
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SETTINGS_SAVED_SUCCESSFULLY), "\123\125\x43\x43\105\123\x53");
    }
    public function mo2f_reset_save_login_popup_setttings()
    {
        global $wA;
        if (!function_exists("\127\x50\137\x46\151\x6c\x65\x73\x79\x73\164\145\x6d")) {
            require_once ABSPATH . "\x77\x70\x2d\x61\144\155\151\x6e\x2f\x69\x6e\x63\154\x75\144\x65\x73\57\x66\x69\x6c\x65\x2e\x70\150\160";
        }
        WP_Filesystem();
        $cV = dirname(dirname(__FILE__)) . "\57\151\156\x63\x6c\165\144\145\x73\57\143\x73\x73\57\x6d\x6f\62\146\x5f\x6c\x6f\x67\151\156\137\160\x6f\160\165\160\137\x75\x69\56\155\x69\156\x2e\143\x73\163";
        $hC = '';
        $wA->put_contents($cV, $hC, FS_CHMOD_FILE);
        delete_site_option("\155\157\x32\146\137\x63\x75\163\x74\x6f\155\137\62\146\x61\x5f\x70\157\160\x75\x70\137\x63\x73\163");
        $pd = new MoWpnsMessages();
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SETTINGS_SAVED_SUCCESSFULLY), "\x53\x55\103\x43\x45\123\x53");
    }
    public function mo2f_reset_custom_logo($post)
    {
        $pd = new MoWpnsMessages();
        $rI = dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . "\151\156\x63\x6c\x75\144\x65\x73" . DIRECTORY_SEPARATOR . "\x69\x6d\141\147\145\x73" . DIRECTORY_SEPARATOR;
        $BS = get_site_option("\155\x6f\62\x66\x5f\x63\x75\163\x74\x6f\x6d\137\154\157\x67\157");
        $cV = $rI . $BS;
        if (!$BS) {
            goto k2;
        }
        unlink($cV);
        delete_site_option("\155\x6f\x32\x66\137\x63\x75\163\x74\157\x6d\x5f\x6c\157\x67\x6f");
        k2:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate("\x4c\x6f\x67\157\x20\162\x65\163\x65\x74\40\x73\x75\x63\x63\x65\163\x73\x66\x75\154\154\171\x21"), "\x53\x55\x43\103\x45\x53\123");
    }
    public function mo2f_reset_accept_deny_email_verification_settings($post)
    {
        $pd = new MoWpnsMessages();
        delete_site_option("\155\x6f\62\146\137\145\155\141\x69\154\137\x76\x65\162\x69\x66\151\143\141\164\x69\157\x6e\x5f\163\x65\164\x74\151\x6e\147\x73");
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SETTINGS_SAVED_SUCCESSFULLY), "\x53\x55\103\x43\105\123\123");
    }
    public function mo2f_modify_popup_args($W8)
    {
        global $yv;
        $oK = get_site_option("\155\x6f\x32\146\137\x65\156\x61\142\x6c\145\137\143\165\163\164\157\155\137\x65\x6d\x61\151\154\x5f\164\x65\x6d\x70\x6c\141\164\145");
        if (!$oK) {
            goto B7;
        }
        $Ln = get_site_option("\x6d\157\x32\146\x5f\145\155\x61\151\x6c\137\166\145\x72\x69\x66\151\143\x61\x74\x69\157\x6e\x5f\163\145\x74\164\x69\156\x67\163", array());
        $CK = $W8["\x63\157\154\x6f\x72"];
        $rl = isset($Ln["\x6d\x6f\62\x66\x5f\141\143\143\145\x70\x74\x5f\x74\145\170\x74\x5f\143\157\x6c\x6f\x72"]) ? $Ln["\155\157\x32\x66\137\x61\x63\143\145\x70\x74\x5f\164\x65\170\x74\137\143\x6f\154\157\162"] : "\43\60\60\106\106\60\60";
        $B_ = isset($Ln["\x6d\x6f\62\x66\137\144\x65\156\171\x5f\x74\145\170\164\x5f\x63\x6f\154\x6f\162"]) ? $Ln["\155\157\x32\x66\137\x64\145\x6e\171\137\164\x65\x78\164\x5f\143\x6f\154\157\x72"] : "\43\x46\x46\60\60\60\60";
        $vz = isset($Ln["\155\157\x32\x66\137\x61\143\143\x65\160\164\137\x64\x65\156\171\137\142\147\137\x63\157\x6c\157\162"]) ? $Ln["\x6d\157\x32\146\137\x61\143\143\x65\x70\164\137\144\x65\x6e\x79\x5f\142\x67\137\x63\x6f\x6c\x6f\162"] : "\x23\106\106\106\x46\x46\106";
        $Uu = isset($Ln["\155\157\x32\146\x5f\143\165\163\x74\x6f\x6d\137\x61\x63\x63\x65\160\164\x5f\144\145\156\171\137\x69\155\x67"]) ? $Ln["\x6d\157\62\x66\x5f\x63\x75\x73\x74\157\155\x5f\141\143\x63\x65\x70\x74\x5f\144\x65\x6e\171\x5f\x69\x6d\147"] : '';
        $o9 = get_site_option("\x6d\157\x32\x66\x5f\x63\x75\163\x74\x6f\x6d\137\154\x6f\x67\x6f", "\155\151\x6e\151\x4f\x72\x61\x6e\147\145\62\x2e\x70\x6e\x67");
        $W8["\143\157\x6c\x6f\x72"] = "\x67\x72\x65\145\x6e" === $CK ? $rl : $B_;
        $W8["\142\x67\x5f\x63\157\x6c\x6f\162"] = $vz;
        $W8["\142\162\141\x6e\x64\x69\156\x67\137\x69\x6d\x67"] = !empty($Uu) ? "\x62\141\x63\153\x67\x72\x6f\x75\x6e\x64\55\151\x6d\141\x67\145\72\40\x75\x72\x6c\50" . esc_url($Uu) . "\40\x29\x3b\40\142\x61\143\x6b\x67\x72\157\165\x6e\x64\x2d\162\x65\x70\145\x61\x74\72\x20\156\x6f\55\162\145\x70\145\141\x74\73\x20\142\141\x63\x6b\147\162\157\x75\156\144\55\x73\x69\172\x65\72\x20\x63\157\166\145\x72\73\x20\142\141\x63\x6b\x67\162\x6f\165\156\x64\55\160\157\x73\x69\164\151\x6f\x6e\72\40\x63\145\156\x74\x65\162\x20\x74\x6f\x70\73" : "\x62\141\x63\x6b\147\162\157\165\x6e\x64\55\143\157\154\x6f\x72\x3a\x20\43\144\x35\145\x33\x64\x39\73";
        $W8["\x6c\x6f\x67\x6f\x5f\165\162\154"] = esc_url($yv . "\151\x6e\x63\x6c\x75\144\x65\163\x2f\x69\155\141\147\145\163\57" . $o9);
        B7:
        return $W8;
    }
    public function mo2f_save_custom_security_questions_settings($post)
    {
        $pd = new MoWpnsMessages();
        $yp = array();
        $qc = isset($post["\x6d\157\x32\x66\137\144\145\146\x61\x75\x6c\164\x5f\x6b\142\141\161\165\145\x73\x74\x69\x6f\x6e\x73\x5f\x75\x73\145\162\163"]) ? intval(sanitize_text_field($post["\155\x6f\62\146\x5f\x64\x65\146\x61\165\154\164\x5f\153\142\141\x71\165\x65\163\164\151\157\x6e\x73\x5f\x75\163\x65\x72\163"])) : 2;
        $QD = isset($post["\155\x6f\62\146\137\143\165\x73\164\157\x6d\x5f\x6b\142\x61\161\x75\x65\x73\164\151\x6f\156\x73\137\x75\163\x65\x72\x73"]) ? intval(sanitize_text_field($post["\155\157\62\x66\137\143\165\x73\x74\157\155\137\153\142\141\x71\x75\145\163\164\x69\x6f\156\x73\137\x75\163\145\x72\x73"])) : 1;
        $qc = max(0, $qc);
        $QD = max(0, $QD);
        update_site_option("\155\157\x32\146\137\x64\x65\x66\x61\x75\154\164\x5f\153\142\x61\161\165\145\163\164\151\x6f\x6e\x73\x5f\x75\163\145\162\163", $qc);
        update_site_option("\x6d\x6f\x32\146\137\143\x75\163\x74\x6f\155\x5f\153\142\x61\161\x75\x65\163\164\151\157\156\x73\137\165\163\x65\162\163", $QD);
        if (!(isset($post["\x6d\157\x32\x66\137\153\142\x61\161\165\145\163\164\151\x6f\156\x5f\x63\165\x73\164\x6f\x6d\x5f\x61\x64\x6d\x69\156"]) && is_array($post["\x6d\x6f\62\146\x5f\x6b\142\x61\x71\165\x65\x73\x74\x69\x6f\x6e\x5f\143\x75\x73\x74\x6f\x6d\137\141\x64\155\151\156"]))) {
            goto zM;
        }
        $JT = $post["\x6d\157\62\146\x5f\153\x62\x61\161\165\145\x73\x74\151\x6f\156\x5f\x63\165\163\x74\x6f\155\x5f\x61\144\x6d\x69\x6e"];
        foreach ($JT as $ZB) {
            $jt = stripslashes(sanitize_text_field($ZB));
            if (empty($jt)) {
                goto wB;
            }
            $yp[] = $jt;
            wB:
            N_:
        }
        jl:
        update_site_option("\x6d\157\x32\x66\x5f\143\x75\x73\x74\157\x6d\x5f\x73\x65\143\x75\162\x69\x74\171\x5f\161\165\145\163\164\x69\157\156\163", $yp);
        zM:
        wp_send_json_success();
    }
    public function mo2f_check_for_custom_security_questions($post)
    {
        $St = get_site_option("\155\x6f\62\146\x5f\x63\x75\163\x74\157\155\137\163\145\x63\165\x72\151\x74\171\137\161\x75\x65\x73\164\151\x6f\x6e\163", array());
        if (empty($St)) {
            goto nh;
        }
        return $St;
        nh:
        return $post;
    }
    public function mo2f_reset_custom_security_questions_settings()
    {
        $pd = new MoWpnsMessages();
        delete_site_option("\155\x6f\62\146\x5f\143\165\163\x74\157\155\137\163\x65\x63\x75\x72\151\164\x79\137\x71\x75\x65\x73\x74\x69\157\x6e\x73");
        delete_site_option("\x6d\157\x32\146\137\x64\x65\x66\x61\x75\154\164\137\153\x62\x61\x71\x75\x65\163\164\x69\157\156\163\137\165\163\x65\162\x73");
        delete_site_option("\155\157\62\146\x5f\x63\165\163\x74\157\155\137\x6b\142\141\161\165\145\x73\x74\151\157\156\163\x5f\x75\163\145\x72\x73");
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::RESET_SETTINGS_SUCCESSFULLY), "\123\125\103\x43\x45\x53\x53");
    }
    public function mo2f_enqueue_rba_script()
    {
        $UD = get_site_option("\155\157\62\146\x5f\141\x63\164\151\x76\x61\164\145\x5f\x70\x6c\x75\147\151\156");
        $Hc = get_site_option("\x6d\157\62\x66\137\x72\145\155\145\x6d\142\145\x72\x5f\144\x65\x76\151\x63\x65");
        $J5 = get_site_option("\155\x6f\62\146\141\x5f\154\153");
        if (!($UD && $Hc && $J5)) {
            goto eg;
        }
        echo "\11\11\x9\11\x3c\163\x63\x72\151\x70\164\40\164\171\160\x65\75\42\x74\x65\170\x74\x2f\x6a\141\x76\x61\x73\143\x72\x69\160\x74\42\x3e\15\xa\11\11\x9\x9\11\152\121\x75\x65\x72\x79\x28\42\43\165\x73\145\162\x5f\x70\x61\x73\x73\x22\51\56\x61\160\x70\145\156\x64\50\42\74\151\x6e\160\165\164\40\x74\x79\160\145\x3d\47\150\x69\x64\x64\x65\156\47\40\151\144\75\47\x6d\151\x6e\x69\x6f\162\x61\x6e\x67\145\137\162\x62\141\x5f\x61\164\x74\162\151\142\165\162\145\163\47\x20\156\x61\x6d\145\75\x27\155\151\x6e\x69\157\162\141\x6e\147\x65\x5f\x72\x62\141\137\141\164\164\162\151\x62\x75\162\x65\x73\x27\x20\x76\x61\154\x75\145\x3d\47\x27\57\76\42\x29\x3b\15\12\11\11\11\11\x9\x73\145\164\x54\x69\155\x65\x6f\165\164\50\xd\xa\x9\x9\11\11\x9\x9\50\x29\x20\75\76\x20\x7b\xd\12\11\11\11\11\11\11\11\152\121\x75\145\x72\171\x28\144\x6f\143\165\x6d\145\156\164\51\56\x72\x65\x61\144\171\50\x66\165\156\143\x74\151\157\156\50\x29\x20\x7b\15\12\15\12\11\x9\x9\x9\11\11\x9\x9\152\121\165\145\x72\171\x28\47\151\x6e\x70\165\164\133\x6e\x61\155\145\x3d\42\x6d\151\156\151\x6f\x72\141\x6e\147\145\137\x72\142\x61\137\141\164\164\162\151\142\x75\x72\145\163\x22\x5d\x27\51\56\x76\x61\154\x28\x4a\x53\117\x4e\x2e\163\164\162\x69\156\147\151\x66\x79\x28\x72\x62\141\101\164\164\x72\151\x62\165\164\x65\x73\x2e\141\164\x74\162\x69\142\165\x74\x65\163\51\51\x3b\xd\xa\15\12\11\11\11\x9\x9\11\x9\11\151\146\40\50\144\x6f\x63\165\x6d\145\156\164\x2e\x67\145\164\x45\154\145\x6d\x65\156\x74\102\x79\111\144\50\47\154\157\x67\151\156\x66\157\x72\155\x27\x29\40\41\x3d\x20\x6e\165\154\x6c\51\x20\x7b\15\12\11\x9\x9\x9\11\11\11\x9\x9\x6a\121\165\145\x72\x79\50\x27\43\154\x6f\147\151\x6e\146\x6f\162\155\x27\x29\x2e\157\x6e\50\47\163\x75\142\155\x69\x74\47\x2c\x20\x66\165\156\x63\164\x69\x6f\156\x28\145\x29\40\173\xd\12\x9\x9\x9\11\11\x9\11\x9\x9\11\152\121\x75\x65\162\x79\x28\47\x69\x6e\x70\x75\164\x5b\x6e\x61\x6d\x65\x3d\42\x6d\x69\156\151\x6f\162\x61\x6e\147\145\x5f\162\x62\x61\x5f\x61\164\164\162\151\x62\x75\162\x65\x73\42\x5d\47\x29\x2e\x76\141\x6c\50\x4a\123\117\116\x2e\x73\x74\x72\x69\x6e\147\x69\x66\x79\x28\162\142\141\x41\164\x74\162\151\x62\165\x74\x65\163\56\141\x74\164\162\151\142\x75\164\x65\163\x29\x29\x3b\xd\12\x9\11\11\11\11\x9\x9\x9\x9\x7d\x29\73\15\xa\11\x9\x9\x9\x9\x9\11\x9\x7d\x20\145\x6c\x73\145\40\x7b\15\12\11\x9\x9\11\11\x9\x9\x9\11\151\146\x20\x28\144\157\x63\165\x6d\145\x6e\164\56\x67\145\x74\x45\154\145\155\x65\x6e\x74\x73\x42\171\x43\154\x61\163\163\116\141\x6d\145\x28\47\x6c\157\147\151\156\47\51\x20\41\x3d\x20\x6e\165\154\154\51\40\x7b\xd\xa\11\11\x9\x9\x9\x9\x9\x9\11\x9\152\x51\x75\x65\x72\x79\50\47\x2e\154\157\x67\151\156\47\51\56\x6f\156\50\47\163\x75\142\x6d\x69\164\x27\x2c\x20\x66\165\x6e\x63\x74\151\x6f\x6e\x28\x65\51\x20\x7b\15\12\11\x9\11\x9\x9\11\x9\x9\11\x9\x9\x6a\x51\165\x65\162\171\50\47\x69\156\160\x75\164\x5b\156\141\x6d\145\75\x22\155\x69\x6e\151\157\162\141\x6e\147\x65\137\162\142\x61\137\x61\164\x74\x72\151\x62\x75\162\x65\163\42\x5d\47\51\x2e\x76\141\x6c\x28\112\x53\117\116\x2e\x73\164\162\151\156\147\151\146\x79\50\x72\142\x61\x41\164\164\162\x69\x62\165\164\x65\x73\x2e\141\164\164\162\x69\x62\x75\164\x65\163\x29\51\x3b\xd\12\x9\x9\11\x9\11\x9\x9\11\11\x9\x7d\51\73\15\xa\11\x9\11\11\x9\x9\11\x9\11\175\xd\12\11\11\11\x9\x9\11\11\x9\175\15\12\15\12\11\x9\x9\11\x9\x9\11\175\x29\15\xa\11\x9\x9\11\x9\11\175\54\40\x31\x30\x30\60\51\x3b\15\xa\11\x9\11\11\74\x2f\x73\143\162\x69\x70\x74\76\15\12\x9\11\11\11";
        wp_enqueue_script("\155\157\62\146\x61\x5f\155\x6f\144\145\137\x73\x63\162\x69\x70\x74", plugins_url("\151\x6e\143\154\165\x64\145\163\x2f\x6a\x73\57\102\x72\157\x77\163\x69\x6e\147\x4d\157\x64\145\104\x65\164\145\143\164\x6f\x72\x2e\155\151\156\x2e\x6a\x73", dirname(__FILE__)), array(), MO2F_VERSION, true);
        wp_enqueue_script("\x6d\x6f\62\x66\141\x5f\x63\x6c\x69\x65\x6e\164\137\x6d\x69\x6e\137\x73\x63\x72\x69\x70\x74", plugins_url("\151\x6e\143\154\x75\x64\145\x73\57\x6a\163\57\x63\154\x69\145\x6e\x74\x2e\x6d\x69\x6e\x2e\x6a\x73", dirname(__FILE__)), array(), MO2F_VERSION, true);
        wp_enqueue_script("\x6d\157\62\x66\141\137\x64\x65\x76\x69\143\x65\x5f\x73\x63\x72\151\160\164", plugins_url("\151\156\143\x6c\x75\144\x65\163\x2f\x6a\x73\x2f\144\145\x76\x69\x63\x65\x5f\x64\145\x74\x61\x69\x6c\163\x2e\x6d\x69\x6e\56\x6a\163", dirname(__FILE__)), array(), MO2F_VERSION, true);
        eg:
    }
}
new Mo2f_Enterprise_Premium_Settings();
Mj:
