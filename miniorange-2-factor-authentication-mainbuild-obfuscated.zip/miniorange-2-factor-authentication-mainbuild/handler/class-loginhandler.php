<?php


use TwoFA\Onprem\Miniorange_Password_2Factor_Login;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Helper\MoWpnsHandler;
use TwoFA\Onprem\Mo2f_Main_Handler;
if (defined("\x41\102\x53\120\101\x54\x48")) {
    goto i3;
}
exit;
i3:
if (class_exists("\x4c\x6f\147\x69\x6e\x48\141\x6e\x64\x6c\x65\x72")) {
    goto SE;
}
class LoginHandler
{
    public function __construct()
    {
        add_action("\151\156\151\164", array($this, "\x6d\157\x5f\x77\x70\156\x73\137\151\x6e\151\164"));
        if (!get_site_option("\155\157\62\146\x5f\162\145\163\164\x72\x69\x63\164\x5f\x72\145\x73\x74\x41\x50\x49")) {
            goto YK;
        }
        add_action("\162\145\x73\x74\x5f\141\x70\151\x5f\x69\156\x69\164", array($this, "\155\x6f\x5f\142\154\x6f\143\153\137\x72\145\x73\164\137\141\x70\151"));
        YK:
        add_action("\167\x70\137\x6c\x6f\147\x69\156", array($this, "\x6d\157\x5f\x77\x70\x6e\163\137\154\157\x67\x69\156\137\x73\x75\143\x63\145\x73\x73"));
        add_action("\167\x70\137\x6c\157\147\x69\x6e\137\x66\141\x69\154\145\x64", array($this, "\x6d\157\137\x77\x70\x6e\x73\x5f\154\x6f\147\x69\156\x5f\x66\x61\151\154\145\x64"));
        if (!get_site_option("\155\x6f\x5f\167\160\156\163\137\141\x63\x74\151\166\141\164\x65\137\162\145\143\x61\160\x74\143\150\141\x5f\146\x6f\162\x5f\167\157\157\x63\x6f\155\155\x65\162\143\145\x5f\162\145\147\151\163\164\x72\141\x74\x69\x6f\156")) {
            goto cX;
        }
        add_action("\167\x6f\157\143\x6f\155\x6d\145\x72\x63\x65\137\x72\x65\147\x69\x73\x74\145\162\137\x70\157\x73\164", array($this, "\x77\157\x6f\143\137\x76\141\x6c\151\144\141\x74\x65\x5f\165\x73\145\162\137\143\x61\160\x74\143\x68\x61\137\x72\145\147\151\x73\x74\x65\x72"), 1, 3);
        cX:
    }
    public function mo_block_rest_api()
    {
        if (!(isset($_SERVER["\122\105\121\125\x45\123\124\137\x55\x52\111"]) && strpos(esc_url_raw(wp_unslash($_SERVER["\x52\x45\x51\x55\x45\123\124\137\125\122\111"])), "\x2f\x77\x70\x2d\152\x73\157\156\x2f\x77\x70\57\x76\x32\x2f\165\x73\x65\162\x73"))) {
            goto GS;
        }
        include_once "\155\x6f\x2d\x62\154\x6f\x63\153\x2e\150\x74\155\154";
        exit;
        GS:
    }
    public function mo_wpns_init()
    {
        add_action("\163\150\157\x77\137\x75\163\145\162\137\x70\x72\x6f\146\151\x6c\x65", array($this, "\164\167\x6f\x66\x61\137\x6f\156\137\165\x73\x65\162\x5f\x70\x72\x6f\x66\x69\154\145"), 10, 3);
        add_action("\145\x64\151\x74\137\x75\x73\145\162\x5f\160\x72\157\146\x69\x6c\145", array($this, "\x74\167\157\146\x61\137\157\x6e\x5f\165\x73\145\162\x5f\160\162\157\x66\x69\x6c\x65"), 10, 3);
        add_action("\160\x65\x72\x73\x6f\x6e\141\x6c\137\x6f\160\164\x69\x6f\156\x73\x5f\x75\x70\x64\141\164\x65", array($this, "\165\163\145\x72\x5f\164\167\157\137\x66\141\x63\164\x6f\162\x5f\x6f\x70\x74\x69\157\156\x73\137\165\160\144\x61\x74\x65"), 10, 3);
        add_action("\145\x64\x69\x74\137\x75\163\145\x72\x5f\160\162\157\146\x69\154\145\x5f\165\160\x64\x61\x74\x65", array($this, "\165\163\x65\x72\137\164\167\157\x5f\x66\x61\x63\x74\157\x72\x5f\x6f\x70\164\x69\157\x6e\163\137\165\160\144\x61\x74\145"), 10, 3);
        global $uz, $V0;
        $Oz = get_site_option("\x57\x41\x46\x45\156\x61\x62\x6c\145\x64");
        $Gd = get_site_option("\127\x41\106");
        if (!(1 === $Oz)) {
            goto MD;
        }
        if (!("\x50\x6c\165\147\151\x6e\114\145\x76\x65\154" === $Gd)) {
            goto Et;
        }
        if (!file_exists($V0 . "\150\141\x6e\144\x6c\x65\x72" . DIRECTORY_SEPARATOR . "\x57\101\106" . DIRECTORY_SEPARATOR . "\155\157\55\167\x61\x66\x2d\x70\x6c\165\x67\151\x6e\x2e\x70\x68\x70")) {
            goto MY;
        }
        include_once $V0 . "\x68\141\x6e\x64\x6c\145\x72" . DIRECTORY_SEPARATOR . "\x57\101\x46" . DIRECTORY_SEPARATOR . "\x6d\157\55\x77\141\146\55\x70\x6c\x75\x67\x69\156\56\160\150\x70";
        MY:
        Et:
        MD:
        $Px = $uz->get_client_ip();
        $Px = sanitize_text_field($Px);
        $wB = new MoWpnsHandler();
        $kv = $wB->is_whitelisted($Px);
        $nZ = false;
        if ($kv) {
            goto Tm;
        }
        $nZ = $wB->is_ip_blocked_in_anyway($Px);
        Tm:
        if (!$nZ) {
            goto hi;
        }
        include_once "\x6d\x6f\x2d\142\x6c\x6f\143\153\x2e\x68\164\x6d\154";
        exit;
        hi:
    }
    public function twofa_on_user_profile($user)
    {
        global $V0;
        $y4 = new Mo2f_Main_Handler();
        $UD = $y4->mo2f_check_if_twofa_is_enabled($user);
        if (!($UD && file_exists($V0 . "\x68\141\x6e\144\x6c\x65\x72" . DIRECTORY_SEPARATOR . "\165\x73\145\162\x2d\x70\x72\157\x66\x69\x6c\x65\x2d\62\146\x61\x2e\160\x68\160"))) {
            goto LX;
        }
        include_once $V0 . "\150\x61\156\144\x6c\145\162" . DIRECTORY_SEPARATOR . "\165\163\x65\162\55\160\162\x6f\146\151\154\145\55\62\146\141\56\x70\x68\160";
        LX:
    }
    public function user_two_factor_options_update($v1)
    {
        global $V0;
        if (!file_exists($V0 . "\150\141\156\x64\154\145\x72" . DIRECTORY_SEPARATOR . "\165\163\x65\162\x2d\x70\x72\x6f\146\x69\x6c\145\x2d\62\x66\x61\55\x75\x70\x64\x61\164\145\x2e\x70\150\x70")) {
            goto QA;
        }
        include_once $V0 . "\x68\x61\156\144\x6c\x65\162" . DIRECTORY_SEPARATOR . "\x75\x73\x65\162\55\x70\162\x6f\146\151\x6c\145\x2d\62\146\141\x2d\x75\160\144\141\164\145\56\160\150\x70";
        QA:
    }
    public function mo_wpns_login_success($Zi)
    {
        global $uz, $Gw;
        $wB = new MoWpnsHandler();
        $Px = $uz->get_client_ip();
        $wB->move_failed_transactions_to_past_failed($Px);
        $user = get_user_by("\x6c\x6f\x67\151\156", $Zi);
        $g_ = get_userdata($user->ID)->roles;
        $Qs = 0;
        foreach ($g_ as $mY) {
            if (!get_site_option("\x6d\x6f\62\146\x61\137" . $mY)) {
                goto J_;
            }
            $Qs = 1;
            goto VH;
            J_:
            wG:
        }
        VH:
        $lY = "\123\125\103\103\x45\123\x53" === $Gw->get_user_detail("\x75\163\x65\162\x5f\162\x65\147\151\x73\164\x72\x61\164\x69\157\156\x5f\x77\151\x74\x68\x5f\x6d\x69\156\151\157\x72\x61\156\147\145", $user->ID);
        if (!(get_site_option("\x6d\x6f\x5f\x77\160\156\x73\x5f\145\156\x61\142\154\x65\137\x75\156\x75\163\x75\141\x6c\x5f\141\x63\x74\x69\x76\151\x74\x79\137\145\x6d\x61\151\x6c\137\164\157\x5f\x75\163\145\162") && $Qs && $lY)) {
            goto iM;
        }
        $uz->send_notification_to_user_for_unusual_activities($Zi, $Px, MoWpnsConstants::LOGGED_IN_FROM_NEW_IP);
        iM:
        if (!("\x74\162\x75\145" === get_site_option("\x6d\x6f\x32\146\137\145\156\141\x62\154\x65\137\x6c\157\x67\x69\x6e\x5f\162\x65\x70\157\x72\164"))) {
            goto Sc;
        }
        $wB->add_transactions($Px, $Zi, MoWpnsConstants::LOGIN_TRANSACTION, MoWpnsConstants::SUCCESS);
        Sc:
    }
    public function mo_wpns_login_failed($Zi)
    {
        global $uz, $Gw;
        $Px = $uz->get_client_ip();
        if (!(empty($Px) || empty($Zi) || !MoWpnsUtility::get_mo2f_db_option("\155\x6f\x32\x66\137\x65\x6e\x61\x62\x6c\x65\137\142\162\165\x74\x65\137\146\x6f\x72\x63\x65", "\x73\151\x74\x65\137\x6f\x70\164\151\x6f\x6e"))) {
            goto sV;
        }
        return;
        sV:
        $wB = new MoWpnsHandler();
        $kv = $wB->is_whitelisted($Px);
        if (!("\x74\x72\165\x65" === get_site_option("\155\157\62\146\x5f\145\156\x61\x62\154\x65\x5f\x6c\x6f\x67\151\x6e\x5f\x72\x65\x70\x6f\x72\164"))) {
            goto f8;
        }
        $wB->add_transactions($Px, $Zi, MoWpnsConstants::LOGIN_TRANSACTION, MoWpnsConstants::FAILED);
        f8:
        if ($kv) {
            goto Bm;
        }
        $user = get_user_by("\x6c\157\147\x69\156", $Zi);
        $g_ = get_userdata($user->ID)->roles;
        $Qs = 0;
        foreach ($g_ as $mY) {
            if (!get_site_option("\155\x6f\62\146\x61\x5f" . $mY)) {
                goto uz;
            }
            $Qs = 1;
            goto GK;
            uz:
            UD:
        }
        GK:
        $lY = "\x53\x55\x43\x43\105\x53\123" === $Gw->get_user_detail("\x75\163\x65\162\x5f\x72\145\x67\x69\x73\x74\x72\x61\164\151\x6f\156\x5f\167\151\164\150\x5f\155\x69\x6e\x69\x6f\162\141\156\x67\x65", $user->ID);
        if (!(get_site_option("\x6d\157\137\167\x70\156\x73\x5f\145\x6e\x61\x62\154\x65\137\165\156\x75\163\x75\141\154\x5f\141\143\164\x69\166\x69\x74\x79\x5f\x65\x6d\x61\151\154\137\164\157\x5f\165\x73\x65\162") && $Qs && $lY)) {
            goto uV;
        }
        $uz->send_notification_to_user_for_unusual_activities($Zi, $Px, MoWpnsConstants::FAILED_LOGIN_ATTEMPTS_FROM_NEW_IP);
        uV:
        Bm:
    }
}
new LoginHandler();
SE:
