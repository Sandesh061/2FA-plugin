<?php


use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Helper\MocURL;
use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Onprem\MO2f_Utility;
if (defined("\101\102\123\120\101\x54\x48")) {
    goto BK;
}
exit;
BK:
if (class_exists("\106\x65\x65\x64\142\141\143\153\x48\141\156\x64\154\145\162")) {
    goto bF;
}
class FeedbackHandler
{
    public function __construct()
    {
        add_action("\x61\144\x6d\151\156\137\x69\156\151\164", array($this, "\x6d\157\137\167\x70\x6e\163\x5f\x66\x65\x65\x64\x62\x61\143\153\137\141\143\164\151\157\x6e\163"));
    }
    public function mo_wpns_feedback_actions()
    {
        $dk = isset($_POST["\x6d\x6f\137\x77\160\x6e\x73\137\146\145\145\x64\142\x61\143\x6b\137\156\157\x6e\143\145"]) ? sanitize_key(wp_unslash($_POST["\x6d\157\x5f\167\160\156\x73\137\x66\145\145\144\x62\141\143\x6b\137\156\x6f\156\143\145"])) : '';
        if (!wp_verify_nonce($dk, "\x6d\157\55\167\160\x6e\x73\55\146\x65\x65\144\x62\x61\x63\x6b\55\x6e\x6f\x6e\143\x65")) {
            goto Vw;
        }
        if (!(current_user_can("\x6d\141\156\141\x67\145\x5f\157\x70\x74\x69\x6f\x6e\x73") && isset($_POST["\x6f\x70\164\x69\157\x6e"]))) {
            goto j6;
        }
        switch (sanitize_text_field(wp_unslash($_POST["\157\160\164\x69\x6f\156"]))) {
            case "\x6d\157\x5f\x77\160\x6e\x73\137\163\x6b\151\x70\x5f\146\145\x65\x64\142\141\143\x6b":
            case "\x6d\157\137\x77\x70\x6e\163\x5f\146\x65\x65\144\142\141\143\x6b":
                $this->wpns_handle_feedback($_POST);
                goto Pl;
            case "\154\x6f\147\137\x66\151\x6c\x65\x5f\x64\157\x77\x6e\x6c\157\141\144":
                $this->mo2f_download_log_file();
                goto Pl;
        }
        pV:
        Pl:
        j6:
        goto RY;
        Vw:
        $jY = new WP_Error();
        $jY->add("\x65\x6d\160\x74\x79\137\165\x73\x65\162\x6e\x61\x6d\145\137\146\145\145\144\x62\141\143\x6b", "\74\x73\x74\x72\157\156\147\76" . __("\105\122\x52\117\x52", "\x6d\151\x6e\x69\x6f\162\141\156\147\x65\55\x32\55\x66\141\x63\164\157\162\x2d\x61\165\164\150\x65\156\x74\x69\x63\x61\164\x69\x6f\156") . "\x3c\x2f\163\x74\x72\x6f\156\x67\76\72\x20" . __("\111\156\166\x61\x6c\151\x64\x20\122\145\x71\165\145\163\164\x2e", "\155\151\156\x69\x6f\162\141\156\x67\145\55\62\55\x66\x61\x63\x74\x6f\162\55\x61\x75\x74\x68\x65\156\164\151\x63\x61\x74\151\157\x6e"));
        return $jY;
        RY:
    }
    public function wpns_handle_feedback($HC)
    {
        if (!MO2F_TEST_MODE) {
            goto Wd;
        }
        deactivate_plugins(dirname(dirname(__FILE__)) . "\134\155\151\156\151\x6f\162\x61\156\147\145\137\62\137\146\x61\x63\x74\x6f\x72\137\x73\145\x74\x74\151\156\x67\x73\x2e\x70\150\x70");
        return;
        Wd:
        $user = wp_get_current_user();
        $uL = isset($HC["\157\160\x74\151\x6f\x6e"]) ? sanitize_text_field(wp_unslash($HC["\x6f\160\164\151\x6f\156"])) : '';
        $jD = "\120\x6c\x75\x67\151\156\x20\104\x65\x61\143\x74\151\166\141\x74\x65\x64\40\72\x20";
        $Og = isset($HC["\155\x6f\137\x77\x70\x6e\163\137\x64\x65\141\x63\164\x69\x76\x61\x74\x65\x5f\x70\154\165\x67\151\x6e"]) ? sanitize_text_field(wp_unslash($HC["\155\157\x5f\x77\160\156\163\x5f\144\x65\x61\143\x74\x69\x76\141\x74\145\137\160\154\165\x67\x69\156"])) : '';
        $jD .= $Og;
        if (!("\x43\x6f\156\146\x6c\x69\143\164\163\40\x77\151\x74\150\x20\x6f\x74\x68\x65\x72\x20\x70\154\165\x67\x69\156\163" === $Og)) {
            goto n4;
        }
        $l4 = isset($HC["\155\157\x32\x66\x5f\x70\154\165\147\151\156\137\163\x65\154\145\x63\164\145\144"]) ? sanitize_text_field(wp_unslash($HC["\x6d\157\62\x66\x5f\x70\154\165\147\x69\156\137\163\145\x6c\x65\x63\x74\145\x64"])) : '';
        $Gu = MO2f_Utility::get_plugin_name_by_identifier($l4);
        $jD .= "\x2c\x20\120\154\165\x67\151\156\x20\163\x65\154\145\143\164\145\x64\x20\55\x20" . $Gu . "\56";
        n4:
        $bg = isset($HC["\155\157\62\146\x5f\x67\145\164\137\162\145\160\154\x79"]) ? sanitize_text_field(wp_unslash($HC["\x6d\157\62\x66\x5f\x67\145\x74\137\162\x65\x70\x6c\171"])) : 0;
        $x_ = array_key_exists("\x77\160\156\163\x5f\x71\165\145\x72\x79\x5f\x66\145\x65\x64\142\141\x63\x6b", $HC) ? htmlspecialchars(sanitize_text_field(wp_unslash($HC["\x77\x70\x6e\163\137\161\x75\x65\162\171\137\146\x65\x65\144\142\141\x63\x6b"]))) : false;
        $TS = get_site_option("\x6d\157\62\146\x5f\x61\x63\x74\x69\x76\141\x74\145\x64\x5f\x74\x69\x6d\x65");
        $hx = time();
        $lv = $TS - $hx;
        if (false === $TS) {
            goto wX;
        }
        $M6 = abs(round($lv / 86400));
        goto Mk;
        wX:
        $M6 = "\116\101";
        Mk:
        update_site_option("\116\157\x5f\x6f\x66\137\x64\141\171\163\x5f\x61\143\164\x69\166\x65\137\167\157\162\153", $M6, "\x79\145\x73");
        $jD .= "\x5b\x44\72" . $M6 . "\54";
        if (MoWpnsUtility::get_mo2f_db_option("\x6d\x6f\x5f\167\x70\x6e\x73\x5f\x32\146\141\137\x77\151\x74\x68\137\156\x65\x74\x77\157\x72\x6b\x5f\x73\145\143\x75\162\x69\x74\171", "\x73\x69\164\x65\x5f\157\160\x74\x69\157\x6e")) {
            goto gx;
        }
        $jD .= "\x32\106\x41\x5d";
        goto Bu;
        gx:
        $jD .= "\x32\x46\101\x2b\116\123\135";
        Bu:
        $jD .= "\54\x20\x46\145\145\144\142\x61\143\153\x20\72\x20" . $x_ . '';
        if (isset($HC["\162\141\164\x65"])) {
            goto yG;
        }
        $Aa = "\55\x2d";
        goto NX;
        yG:
        $Aa = htmlspecialchars(sanitize_text_field(wp_unslash($HC["\x72\x61\164\145"])));
        NX:
        $jD .= "\x2c\x20\133\122\x61\164\x69\x6e\147\x20\72" . $Aa . "\x5d";
        if (!$bg) {
            goto ta;
        }
        $jD .= MoWpnsUtility::mo_2fa_send_configuration();
        ta:
        $fK = isset($HC["\x71\165\145\162\171\x5f\x6d\141\151\154"]) ? sanitize_email(wp_unslash($HC["\161\x75\145\162\x79\x5f\x6d\x61\x69\x6c"])) : '';
        if (filter_var($fK, FILTER_VALIDATE_EMAIL)) {
            goto zs;
        }
        $fK = get_site_option("\155\157\x32\146\x5f\x65\x6d\x61\x69\154");
        if (!empty($fK)) {
            goto wm;
        }
        $fK = $user->user_email;
        wm:
        zs:
        $T7 = get_site_option("\x6d\157\137\x77\x70\x6e\163\x5f\141\144\x6d\151\156\x5f\160\150\x6f\x6e\145");
        $Ea = new MocURL();
        $pd = new MoWpnsMessages();
        global $uz;
        if (is_null($Ea)) {
            goto fA;
        }
        if (!$uz->is_curl_installed()) {
            goto Qc;
        }
        $q8 = json_decode($Ea->send_email_alert($fK, $T7, $jD, $uL), true);
        if (!(json_last_error() === JSON_ERROR_NONE)) {
            goto ny;
        }
        if (is_array($q8) && array_key_exists("\x73\164\x61\x74\x75\x73", $q8) && "\x45\x52\x52\x4f\x52" === $q8["\x73\164\141\164\165\x73"]) {
            goto dZ;
        }
        if ($q8) {
            goto HY;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::QUERY_SUBMISSION_ERROR), "\105\x52\122\117\122");
        HY:
        goto rf;
        dZ:
        $pd->mo2f_show_message(__($q8["\155\x65\163\163\141\x67\145"], "\x6d\x69\156\x69\x6f\x72\141\x6e\147\145\x2d\x32\x2d\146\141\143\x74\x6f\162\x2d\141\x75\164\150\145\x6e\164\x69\x63\x61\x74\x69\157\156"), "\x45\x52\x52\117\x52");
        rf:
        ny:
        if (!("\x6d\157\137\x77\160\156\163\x5f\x66\x65\145\x64\x62\x61\x63\153" === $uL || "\x6d\157\137\167\160\x6e\163\137\163\153\x69\x70\x5f\146\x65\145\x64\142\x61\x63\x6b" === $uL)) {
            goto lI;
        }
        deactivate_plugins(dirname(dirname(__FILE__)) . "\x5c\x6d\151\x6e\x69\157\x72\x61\156\x67\145\137\62\137\146\141\x63\x74\x6f\x72\137\163\145\164\x74\x69\156\147\163\x2e\160\150\x70");
        lI:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::FEEDBACK_APPRECIATION), "\105\122\122\117\x52");
        goto lA;
        Qc:
        deactivate_plugins(dirname(dirname(__FILE__)) . "\x5c\x6d\x69\x6e\x69\157\x72\141\x6e\x67\x65\137\62\137\146\x61\x63\x74\157\162\137\x73\x65\x74\x74\151\x6e\x67\x73\x2e\x70\150\160");
        lA:
        fA:
    }
    public function mo2f_download_log_file()
    {
        global $wA;
        if (!empty($wA)) {
            goto JV;
        }
        require_once ABSPATH . "\x2f\167\x70\x2d\141\144\155\151\x6e\x2f\151\156\143\154\165\144\x65\x73\x2f\x66\151\x6c\x65\x2e\x70\150\160";
        WP_Filesystem();
        JV:
        ob_start();
        $dk = isset($_POST["\x6d\157\x5f\167\160\156\x73\x5f\146\145\145\x64\x62\x61\143\x6b\x5f\156\157\156\143\x65"]) ? sanitize_key(wp_unslash($_POST["\x6d\x6f\137\x77\x70\x6e\x73\x5f\146\145\145\144\142\x61\143\153\137\x6e\157\156\x63\x65"])) : '';
        if (!wp_verify_nonce($dk, "\155\157\55\x77\x70\x6e\163\x2d\146\145\145\144\x62\141\x63\x6b\55\x6e\157\156\x63\x65") || !current_user_can("\x6d\141\156\x61\x67\x65\137\157\160\x74\151\x6f\156\163")) {
            goto Ki;
        }
        $gC = wp_upload_dir();
        $gC = $gC["\x62\x61\163\145\144\x69\x72"];
        $yz = "\155\151\x6e\x69\x6f\162\x61\x6e\x67\145\x5f\144\x65\142\x75\x67\x5f\x6c\x6f\147\56\164\x78\x74";
        $yY = file_exists($gC . DIRECTORY_SEPARATOR . $yz);
        if ($yY) {
            goto m4;
        }
        $pd = new MoWpnsMessages();
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::FILE_NOT_EXISTS), "\105\122\122\117\x52");
        goto ps;
        m4:
        header("\x50\162\141\x67\x6d\x61\72\x20\x70\x75\x62\x6c\151\x63");
        header("\x45\x78\x70\x69\x72\x65\163\72\40\x30");
        header("\103\141\143\150\145\x2d\103\x6f\x6e\164\162\x6f\154\72\x20\x6d\x75\163\x74\55\162\x65\x76\141\x6c\151\x64\141\164\x65\54\40\160\157\163\164\55\x63\x68\x65\143\153\75\60\54\40\160\x72\x65\x2d\143\150\x65\143\x6b\75\x30");
        header("\x43\x6f\156\x74\x65\x6e\x74\55\124\x79\x70\145\72\40\x61\x70\x70\154\151\x63\141\x74\151\157\x6e\x2f\x6f\x63\164\145\x74\x2d\x73\164\x72\145\141\x6d");
        header("\103\157\156\x74\145\x6e\164\x2d\x44\x69\x73\160\x6f\163\x69\164\151\157\156\x3a\40\x61\164\x74\141\143\x68\155\x65\x6e\164\73\x20\x66\151\x6c\x65\156\141\x6d\x65\x3d" . $yz);
        header("\103\x6f\156\x74\x65\156\164\55\124\x72\x61\x6e\163\x66\x65\162\x2d\x45\156\x63\x6f\x64\151\156\x67\x3a\40\142\x69\x6e\141\162\171");
        header("\x43\x6f\x6e\x74\145\x6e\164\x2d\114\145\x6e\x67\164\x68\x3a\x20" . filesize($gC . DIRECTORY_SEPARATOR . $yz));
        z8:
        if (!ob_get_level()) {
            goto cF;
        }
        ob_end_clean();
        echo esc_html($wA->get_contents($gC . DIRECTORY_SEPARATOR . $yz));
        exit;
        goto z8;
        cF:
        ps:
        goto wJ;
        Ki:
        $jY = new WP_Error();
        $jY->add("\x65\155\x70\x74\171\x5f\x75\163\x65\162\x6e\x61\x6d\x65", "\x3c\x73\164\162\157\x6e\x67\76" . __("\x45\x52\122\117\x52", "\x6d\x69\156\x69\x6f\162\x61\156\x67\145\x2d\x32\x2d\146\x61\x63\164\157\162\x2d\141\165\x74\x68\145\x6e\x74\x69\143\x61\164\151\157\x6e") . "\x3c\x2f\x73\164\x72\x6f\156\x67\x3e\x3a\x20" . __("\x49\156\x76\141\154\151\144\40\x52\145\x71\x75\x65\163\x74\x2e", "\x6d\x69\156\151\x6f\162\x61\156\x67\145\x2d\62\x2d\146\x61\x63\164\157\x72\x2d\141\165\164\x68\145\156\164\x69\143\141\x74\x69\157\156"));
        wJ:
    }
}
new FeedbackHandler();
bF:
