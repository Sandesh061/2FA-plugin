<?php


namespace TwoFA\Onprem;

use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Handler\Miniorange_Mobile_Login;
use TwoFA\Helper\MocURL;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Database\Mo2fDB;
use TwoFA\Onprem\MO2f_Cloud_Onprem_Interface;
use TwoFA\Cloud\Customer_Cloud_Setup;
use TwoFA\Helper\Mo2f_Login_Popup;
use TwoFA\Traits\Instance;
use WP_Error;
if (defined("\101\x42\x53\120\101\124\x48")) {
    goto ei;
}
exit;
ei:
require "\143\154\141\163\163\x2d\155\x69\156\x69\x6f\162\x61\x6e\x67\145\x2d\155\157\142\151\x6c\145\55\x6c\x6f\147\151\156\56\160\x68\x70";
if (class_exists("\x4d\151\x6e\x69\157\162\141\156\147\145\x5f\120\141\163\x73\x77\157\x72\144\x5f\62\x46\x61\143\164\157\162\137\114\157\x67\x69\x6e")) {
    goto W4;
}
class Miniorange_Password_2Factor_Login
{
    use Instance;
    private $mo2f_kbaquestions;
    private $mo2f_user_id;
    private $mo2f_transactionid;
    private $fstfactor;
    private $mo2f_onprem_cloud_obj;
    public function __construct()
    {
        $this->mo2f_onprem_cloud_obj = MO2f_Cloud_Onprem_Interface::instance();
    }
    public function mo2f_miniorange_sign_in()
    {
        global $uz;
        $dk = isset($_POST["\x6d\x6f\62\146\137\x69\x6e\x6c\151\x6e\x65\x5f\156\x6f\156\x63\x65"]) ? sanitize_key($_POST["\x6d\x6f\x32\146\x5f\x69\x6e\x6c\151\156\145\x5f\x6e\x6f\x6e\143\145"]) : '';
        if (wp_verify_nonce($dk, "\x6d\x6f\62\146\x2d\151\156\x6c\x69\156\x65\x2d\154\x6f\147\x69\x6e\55\x6e\x6f\x6e\x63\145")) {
            goto cp;
        }
        $jY = new WP_Error();
        return $jY;
        cp:
        $fK = isset($_POST["\145\x6d\x61\151\154"]) ? sanitize_email(wp_unslash($_POST["\x65\155\x61\x69\154"])) : '';
        $uk = isset($_POST["\160\x61\x73\x73\x77\157\x72\x64"]) ? wp_unslash($_POST["\160\141\x73\163\x77\157\162\x64"]) : '';
        $Ty = isset($_POST["\163\145\x73\x73\x69\157\x6e\137\151\144"]) ? wp_unslash($_POST["\163\x65\x73\x73\151\x6f\156\137\x69\x64"]) : null;
        $ok = isset($_POST["\x72\x65\144\151\x72\x65\x63\x74\137\164\x6f"]) ? esc_url_raw(wp_unslash($_POST["\162\x65\144\151\162\145\x63\x74\x5f\x74\157"])) : null;
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\x6d\157\x32\x66\x5f\143\x75\162\162\x65\156\164\x5f\165\163\145\162\137\x69\144");
        if (!($uz->check_empty_or_null($fK) || $uz->check_empty_or_null($uk))) {
            goto qt;
        }
        $ga = MoWpnsMessages::lang_translate(MoWpnsMessages::REQUIRED_FIELDS);
        $Uc = "\x4d\x4f\137\x32\x5f\x46\x41\x43\124\x4f\122\137\x50\122\117\x4d\120\x54\137\125\x53\105\x52\x5f\106\x4f\x52\x5f\62\x46\x41\x5f\x4d\x45\x54\x48\117\104\123";
        $this->miniorange_pass2login_form_fields($Uc, $ga, $ok, null, $Ty);
        return;
        qt:
        $this->mo2f_inline_get_current_customer($v1, $fK, $uk, $ok, $Ty);
    }
    public function mo2f_inline_get_current_customer($v1, $fK, $uk, $ok, $Ty)
    {
        global $Gw;
        $uU = new MocURL();
        $hP = $uU->get_customer_key($fK, $uk);
        $hS = json_decode($hP, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            goto i0;
        }
        $ga = is_string($hP) ? $hP : '';
        $Uc = "\x4d\x4f\137\62\x5f\106\x41\103\124\x4f\x52\137\x50\122\117\115\120\124\x5f\x55\x53\x45\x52\137\x46\117\x52\x5f\62\x46\101\137\x4d\105\124\x48\117\104\123";
        $this->miniorange_pass2login_form_fields($Uc, $ga, $ok, null, $Ty);
        return;
        goto Pp;
        i0:
        if ("\123\x55\x43\x43\105\123\123" === $hS["\x73\x74\141\164\x75\163"]) {
            goto Lk;
        }
        $Gw->update_user_details($v1, array("\x6d\157\x5f\62\146\141\x63\164\x6f\x72\137\165\163\145\x72\137\162\145\x67\151\163\164\x72\x61\164\151\x6f\x6e\137\x73\164\141\164\165\163" => "\x4d\x4f\x5f\62\x5f\106\x41\x43\124\117\x52\x5f\x56\x45\x52\111\x46\x59\x5f\103\125\x53\x54\x4f\115\105\122"));
        $ga = MoWpnsMessages::lang_translate(MoWpnsMessages::ACCOUNT_EXISTS);
        $Uc = "\x4d\x4f\137\x32\137\x46\x41\x43\124\117\x52\x5f\x50\122\117\x4d\120\124\x5f\x55\x53\105\122\137\106\117\x52\x5f\62\106\x41\x5f\115\x45\x54\110\117\x44\123";
        $this->miniorange_pass2login_form_fields($Uc, $ga, $ok, null, $Ty);
        return;
        goto i6;
        Lk:
        if (!isset($hS["\160\150\157\156\x65"])) {
            goto iW;
        }
        update_option("\x6d\x6f\x5f\x77\160\x6e\163\137\x61\144\x6d\x69\156\137\160\x68\x6f\156\x65", $hS["\x70\x68\157\x6e\x65"]);
        $Gw->update_user_details($v1, array("\x6d\157\62\x66\137\x75\x73\145\162\x5f\160\x68\x6f\156\x65" => $hS["\160\150\157\156\x65"]));
        iW:
        update_option("\155\x6f\x32\x66\137\x65\155\x61\151\154", $fK);
        $L4 = isset($hS["\x69\x64"]) ? $hS["\151\144"] : '';
        $Yl = isset($hS["\x61\160\151\x4b\x65\171"]) ? $hS["\x61\x70\x69\113\x65\171"] : '';
        $CS = isset($hS["\x74\157\153\145\x6e"]) ? $hS["\164\x6f\x6b\145\x6e"] : '';
        $iX = isset($hS["\141\160\x70\123\145\x63\x72\145\x74"]) ? $hS["\141\160\160\x53\x65\x63\162\x65\x74"] : '';
        $this->mo2f_inline_save_success_customer_config($v1, $fK, $L4, $Yl, $CS, $iX);
        $ga = MoWpnsMessages::lang_translate(MoWpnsMessages::REG_SUCCESS);
        $Uc = "\115\x4f\x5f\62\137\106\101\103\124\117\x52\137\120\122\x4f\x4d\x50\x54\137\125\123\105\122\137\x46\x4f\x52\x5f\62\x46\101\137\115\x45\x54\x48\x4f\x44\x53";
        $this->miniorange_pass2login_form_fields($Uc, $ga, $ok, null, $Ty);
        return;
        i6:
        Pp:
    }
    public function mo2f_inline_save_success_customer_config($v1, $fK, $L4, $Yl, $CS, $iX)
    {
        global $Gw;
        update_option("\155\157\62\146\137\x63\x75\163\164\157\x6d\x65\x72\x4b\145\x79", $L4);
        update_option("\x6d\157\62\146\137\141\x70\x69\x5f\153\145\171", $Yl);
        update_option("\155\157\62\146\137\x63\165\163\164\x6f\155\145\162\x5f\x74\x6f\x6b\x65\x6e", $CS);
        update_option("\155\157\x32\x66\137\x61\x70\160\x5f\x73\x65\x63\x72\x65\x74", $iX);
        update_option("\155\x6f\x5f\x77\160\x6e\x73\x5f\145\156\x61\142\154\x65\137\x6c\157\x67\x5f\x72\x65\x71\x75\x65\x73\164\163", true);
        update_option("\x6d\157\62\146\x5f\x6d\x69\156\x69\157\x72\141\156\147\145\x5f\141\x64\x6d\x69\x6e", $L4);
        update_site_option("\x6d\157\x5f\62\146\141\143\x74\x6f\162\x5f\141\x64\x6d\x69\x6e\x5f\x72\145\x67\151\163\x74\162\x61\164\x69\x6f\156\137\x73\164\141\164\165\163", "\115\x4f\137\x32\x5f\x46\101\103\x54\117\122\137\x43\x55\123\x54\x4f\x4d\x45\x52\137\122\x45\107\111\123\x54\105\x52\105\x44\137\123\125\x43\103\105\123\123");
        $Gw->update_user_details($v1, array("\155\x6f\x32\x66\137\x75\x73\145\x72\x5f\x65\155\141\151\x6c" => sanitize_email($fK)));
    }
    public function mo2f_inline_validate_otp_complete()
    {
        if (!isset($_POST["\x6d\151\x6e\151\x6f\x72\x61\156\147\x65\137\151\156\x6c\151\x6e\x65\137\x76\x61\154\151\x64\141\x74\x65\137\x6f\x74\160\137\156\x6f\x6e\143\145"])) {
            goto EB;
        }
        $dk = sanitize_text_field(wp_unslash($_POST["\155\151\156\x69\x6f\162\141\x6e\147\145\x5f\x69\156\x6c\x69\x6e\145\137\166\x61\154\151\144\x61\164\145\137\157\164\x70\137\156\157\156\143\145"]));
        if (!wp_verify_nonce($dk, "\155\151\156\151\157\x72\141\156\147\145\55\x32\55\146\x61\x63\x74\157\162\x2d\x69\156\154\151\156\145\x2d\166\x61\154\151\144\141\x74\145\x2d\157\x74\x70\55\156\157\x6e\143\145")) {
            goto I5;
        }
        $Ty = isset($_POST["\163\145\x73\163\x69\157\156\137\x69\144"]) ? sanitize_text_field(wp_unslash($_POST["\163\145\163\x73\x69\157\156\137\x69\144"])) : null;
        $ok = isset($_POST["\162\145\x64\151\162\145\143\164\x5f\164\x6f"]) ? esc_url_raw(wp_unslash($_POST["\x72\x65\144\x69\x72\145\143\164\137\x74\157"])) : null;
        $AP = "\x4d\x4f\x5f\62\137\106\x41\103\x54\x4f\122\x5f\123\x45\x54\x55\120\x5f\x53\x55\x43\103\x45\x53\123";
        $this->miniorange_pass2login_form_fields($AP, '', $ok, null, $Ty);
        goto v5;
        I5:
        $jY = new WP_Error();
        $jY->add("\145\155\160\164\171\x5f\165\x73\145\162\156\x61\x6d\x65", "\x3c\x73\164\x72\x6f\x6e\x67\x3e" . __("\105\122\x52\x4f\122", "\155\x69\156\x69\x6f\162\141\x6e\147\145\x2d\x32\x2d\146\x61\x63\x74\157\162\x2d\x61\165\164\x68\145\x6e\164\x69\x63\141\164\151\x6f\x6e") . "\74\x2f\163\x74\x72\157\156\147\76\x3a\40" . __("\x49\x6e\x76\x61\154\151\x64\40\x52\x65\161\165\145\163\164\56", "\x6d\x69\156\151\x6f\162\141\x6e\x67\x65\x2d\x32\x2d\x66\141\143\164\157\x72\x2d\x61\165\x74\x68\145\x6e\164\x69\143\141\164\x69\x6f\x6e"));
        return $jY;
        v5:
        EB:
    }
    public function mo2f_inline_kba_validation($post, $v1, $fK)
    {
        global $Xw;
        $MX = $this->mo2f_get_kba_details($post);
        $w1 = json_decode($Xw->mo2f_register_kba_details($fK, $MX["\153\x62\x61\137\x71\x31"], $MX["\153\142\x61\x5f\x61\61"], $MX["\x6b\142\141\137\x71\62"], $MX["\x6b\142\x61\137\x61\x32"], $MX["\x6b\142\x61\137\161\63"], $MX["\x6b\x62\141\137\141\63"], $v1), true);
        if (!(json_last_error() === JSON_ERROR_NONE)) {
            goto Fr;
        }
        if (!("\x53\125\x43\103\x45\123\x53" === $w1["\163\164\141\164\x75\x73"])) {
            goto cZ;
        }
        $bC = json_decode($this->mo2f_onprem_cloud_obj->mo2f_update_user_info(null, null, MoWpnsConstants::SECURITY_QUESTIONS, null, null, null, $fK), true);
        cZ:
        Fr:
        return $bC;
    }
    public function mo2f_inline_validate_mobile_authentication()
    {
        if (!isset($_POST["\155\x6f\x5f\141\165\164\150\137\151\156\x6c\x69\x6e\x65\137\x6d\157\142\151\x6c\x65\x5f\162\145\x67\x69\163\x74\x72\141\x74\x69\157\156\137\143\157\155\x70\154\x65\164\x65\137\x6e\x6f\156\143\145"])) {
            goto YN;
        }
        $dk = sanitize_text_field(wp_unslash($_POST["\155\157\x5f\x61\165\x74\150\137\x69\156\x6c\151\x6e\145\x5f\155\x6f\142\x69\154\x65\137\x72\145\x67\151\163\x74\162\141\x74\x69\x6f\156\x5f\x63\x6f\x6d\160\154\x65\x74\x65\137\x6e\x6f\156\143\x65"]));
        if (!wp_verify_nonce($dk, "\x6d\151\x6e\x69\x6f\x72\141\x6e\x67\x65\55\x32\55\146\141\x63\x74\x6f\162\55\x69\x6e\154\151\x6e\x65\55\x6d\157\142\x69\154\x65\x2d\x72\145\x67\x69\163\164\162\141\164\151\x6f\156\x2d\143\157\x6d\x70\154\x65\x74\x65\55\156\x6f\156\143\x65")) {
            goto li;
        }
        global $Gw;
        $this->miniorange_pass2login_start_session();
        $Ty = isset($_POST["\163\145\x73\x73\x69\157\156\x5f\x69\144"]) ? sanitize_text_field(wp_unslash($_POST["\163\x65\163\x73\x69\157\x6e\137\151\x64"])) : null;
        MO2f_Utility::unset_temp_user_details_in_table("\155\157\x32\146\137\x74\162\141\156\163\x61\143\x74\151\157\x6e\x49\x64", $Ty);
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\155\157\x32\146\137\143\x75\x72\x72\145\156\164\137\x75\163\145\x72\137\x69\x64");
        $ok = isset($_POST["\162\145\x64\151\162\x65\x63\164\137\164\157"]) ? esc_url_raw(wp_unslash($_POST["\x72\145\x64\151\x72\145\x63\x74\x5f\x74\157"])) : null;
        $Z7 = $Gw->get_user_detail("\x6d\157\x32\146\137\x63\157\156\x66\151\147\165\x72\145\x64\137\x32\x66\141\137\x6d\145\164\150\x6f\144", $v1);
        $fK = $Gw->get_user_detail("\x6d\x6f\x32\146\x5f\x75\x73\x65\162\x5f\145\155\x61\151\x6c", $v1);
        $we = '';
        $AP = "\115\117\137\62\x5f\106\101\103\x54\x4f\122\137\120\x52\x4f\115\120\124\x5f\125\x53\x45\x52\x5f\106\x4f\122\x5f\62\106\x41\137\x4d\x45\x54\x48\x4f\104\123";
        $VN = new MO2f_Cloud_Onprem_Interface();
        $bC = json_decode($this->mo2f_onprem_cloud_obj->mo2f_update_user_info($v1, true, $Z7, null, MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, true, $fK, null), true);
        if (JSON_ERROR_NONE === json_last_error()) {
            goto St;
        }
        $we = __("\x49\156\166\x61\x6c\151\x64\40\162\145\x71\x75\145\x73\x74\x2e\40\120\154\145\141\163\x65\40\164\x72\171\x20\141\147\x61\x69\156", "\155\x69\156\x69\157\x72\141\x6e\147\x65\x2d\62\x2d\146\141\143\164\157\x72\x2d\141\x75\x74\x68\x65\156\164\x69\x63\141\164\151\x6f\x6e");
        goto Sp;
        St:
        if ("\105\122\x52\117\122" === $bC["\163\164\x61\x74\165\163"]) {
            goto zj;
        }
        if ("\x53\x55\x43\x43\105\x53\123" === $bC["\163\164\x61\x74\165\163"]) {
            goto tU;
        }
        $we = __("\x41\x6e\40\x65\162\162\157\162\x20\x6f\143\143\x75\162\x65\144\40\167\x68\x69\x6c\145\x20\x76\141\x6c\151\x64\x61\x74\x69\156\147\x20\164\150\145\40\165\163\145\162\x2e\x20\x50\x6c\145\141\163\145\40\x54\x72\x79\x20\141\147\141\x69\156\56", "\155\151\156\151\x6f\162\x61\156\x67\145\55\x32\55\146\141\143\x74\157\x72\x2d\141\x75\164\x68\x65\x6e\164\151\x63\x61\164\x69\157\156");
        goto r0;
        zj:
        $we = MoWpnsMessages::lang_translate($bC["\155\145\163\163\x61\147\145"]);
        goto r0;
        tU:
        $AP = "\115\117\137\62\x5f\x46\101\x43\x54\117\x52\x5f\x53\x45\124\x55\x50\x5f\123\125\103\103\x45\x53\x53";
        r0:
        Sp:
        $this->miniorange_pass2login_form_fields($AP, $we, $ok, null, $Ty);
        goto Pq;
        li:
        $jY = new WP_Error();
        $jY->add("\x65\155\160\164\171\137\x75\163\x65\x72\156\141\x6d\x65", "\74\163\x74\x72\157\156\147\x3e" . __("\x45\122\x52\x4f\x52", "\155\151\x6e\151\157\162\x61\x6e\x67\145\55\x32\55\146\141\143\164\157\x72\55\141\165\164\150\145\156\164\x69\143\141\164\x69\157\x6e") . "\x3c\57\x73\164\x72\x6f\156\147\76\x3a\40" . __("\111\x6e\166\x61\154\151\144\x20\122\145\x71\165\145\x73\164\56", "\155\x69\156\x69\157\x72\141\156\x67\145\55\x32\x2d\x66\x61\x63\x74\157\162\55\141\x75\164\150\145\x6e\164\151\143\x61\x74\151\x6f\x6e"));
        return $jY;
        Pq:
        YN:
    }
    public function mo2f_duo_mobile_send_push_notification_for_inline_form()
    {
        if (!isset($_POST["\144\x75\157\x5f\x6d\157\x62\151\x6c\x65\x5f\163\x65\156\144\137\160\x75\x73\150\137\x6e\x6f\x74\151\146\151\143\141\164\151\157\x6e\137\x69\x6e\x6c\151\156\x65\137\146\157\x72\155\137\x6e\157\x6e\143\x65"])) {
            goto tw;
        }
        $dk = sanitize_text_field(wp_unslash($_POST["\x64\x75\157\x5f\x6d\157\x62\151\x6c\x65\x5f\163\x65\x6e\x64\137\x70\x75\x73\150\137\x6e\157\x74\151\x66\151\143\x61\164\x69\157\156\x5f\x69\x6e\x6c\151\x6e\145\137\x66\157\x72\x6d\x5f\x6e\157\156\143\x65"]));
        if (!wp_verify_nonce($dk, "\x6d\x6f\62\x66\55\x73\x65\156\x64\x2d\144\x75\x6f\55\x70\165\x73\x68\55\156\x6f\x74\151\146\x69\x63\x61\x74\151\157\156\55\151\156\x6c\x69\x6e\145\55\x6e\157\x6e\143\145")) {
            goto Ox;
        }
        global $Gw;
        $this->miniorange_pass2login_start_session();
        $Ty = isset($_POST["\163\145\163\x73\x69\x6f\x6e\137\x69\x64"]) ? sanitize_text_field(wp_unslash($_POST["\163\145\163\x73\151\x6f\156\x5f\x69\x64"])) : null;
        MO2f_Utility::unset_temp_user_details_in_table("\155\x6f\62\146\137\x74\162\x61\x6e\x73\x61\x63\164\x69\157\156\x49\144", $Ty);
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\x6d\157\x32\x66\137\x63\x75\x72\162\145\156\x74\137\x75\x73\145\x72\137\x69\144");
        $ok = isset($_POST["\x72\x65\144\x69\162\145\x63\x74\137\164\x6f"]) ? esc_url_raw(wp_unslash($_POST["\x72\x65\x64\151\x72\145\143\164\137\164\157"])) : null;
        $Gw->update_user_details($v1, array("\x6d\157\x62\151\154\x65\137\162\x65\147\151\163\x74\x72\141\164\151\157\x6e\x5f\x73\x74\x61\164\165\163" => true));
        $we = '';
        $AP = "\115\x4f\137\x32\137\106\x41\103\x54\x4f\122\x5f\120\122\x4f\115\120\124\x5f\x55\x53\x45\x52\137\x46\x4f\x52\137\x32\x46\x41\x5f\x4d\105\x54\x48\117\x44\x53";
        $this->miniorange_pass2login_form_fields($AP, $we, $ok, null, $Ty);
        goto zT;
        Ox:
        $jY = new WP_Error();
        $jY->add("\x65\x6d\x70\164\x79\137\165\x73\145\162\156\141\x6d\145", "\x3c\163\x74\162\x6f\x6e\147\76" . __("\105\x52\122\117\122", "\155\x69\x6e\x69\157\x72\x61\x6e\147\x65\55\x32\55\x66\141\x63\164\157\x72\x2d\141\165\x74\x68\145\156\x74\x69\143\x61\164\151\x6f\x6e") . "\x3c\x2f\163\164\x72\157\156\x67\76\x3a\x20" . __("\x49\x6e\x76\141\x6c\x69\x64\x20\122\145\161\165\x65\163\x74\x2e", "\155\x69\156\x69\157\x72\141\156\x67\145\55\x32\55\x66\x61\143\x74\x6f\x72\55\x61\x75\164\x68\145\156\x74\x69\143\141\164\151\x6f\x6e"));
        return $jY;
        zT:
        tw:
    }
    public function mo2f_inline_validate_duo_authentication()
    {
        if (!isset($_POST["\155\157\x5f\x61\165\164\x68\x5f\151\156\154\151\x6e\x65\x5f\x64\165\157\137\x61\165\x74\x68\x5f\155\x6f\142\151\154\145\137\162\145\x67\x69\x73\x74\x72\141\x74\x69\x6f\156\137\143\x6f\155\160\154\145\x74\145\137\156\x6f\156\x63\145"])) {
            goto aJ;
        }
        $dk = sanitize_text_field(wp_unslash($_POST["\155\x6f\137\x61\x75\164\x68\x5f\151\156\x6c\151\x6e\145\137\144\x75\157\x5f\141\165\x74\x68\x5f\x6d\157\x62\x69\x6c\x65\137\x72\145\x67\x69\x73\164\162\x61\x74\151\157\156\137\x63\x6f\155\160\x6c\145\x74\x65\137\156\x6f\156\143\x65"]));
        if (!wp_verify_nonce($dk, "\155\x69\x6e\x69\157\162\141\x6e\147\x65\55\x32\55\x66\141\143\x74\x6f\162\55\151\156\x6c\151\x6e\145\55\x64\x75\157\x5f\141\165\x74\x68\x2d\162\x65\147\151\163\x74\162\x61\x74\151\157\x6e\55\x63\x6f\155\160\154\145\x74\x65\x2d\x6e\157\x6e\143\145")) {
            goto oo;
        }
        global $Gw;
        $this->miniorange_pass2login_start_session();
        $Ty = isset($_POST["\x73\145\x73\163\151\x6f\156\x5f\151\144"]) ? sanitize_text_field(wp_unslash($_POST["\x73\145\163\x73\x69\157\x6e\137\x69\144"])) : null;
        MO2f_Utility::unset_temp_user_details_in_table("\x6d\157\62\146\x5f\164\162\x61\x6e\163\x61\x63\164\151\x6f\x6e\111\144", $Ty);
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\155\157\x32\146\137\x63\165\x72\x72\145\156\x74\x5f\x75\x73\x65\x72\x5f\x69\144");
        $ok = isset($_POST["\162\x65\x64\151\x72\145\x63\164\x5f\x74\157"]) ? esc_url_raw(wp_unslash($_POST["\162\x65\144\x69\x72\145\x63\x74\x5f\164\157"])) : null;
        $Z7 = $Gw->get_user_detail("\155\x6f\x32\x66\137\143\x6f\x6e\146\x69\x67\165\162\x65\144\137\62\x66\x61\137\x6d\x65\x74\150\x6f\x64", $v1);
        $fK = sanitize_email($Gw->get_user_detail("\155\x6f\x32\x66\x5f\x75\x73\x65\x72\137\x65\x6d\141\151\154", $v1));
        $Gw->update_user_details($v1, array("\x6d\x6f\x62\x69\x6c\x65\137\162\145\x67\151\x73\164\x72\x61\x74\x69\157\x6e\x5f\x73\x74\141\164\x75\163" => true));
        $we = '';
        include_once dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . "\150\141\156\144\x6c\x65\162" . DIRECTORY_SEPARATOR . "\164\x77\157\x66\141" . DIRECTORY_SEPARATOR . "\x74\x77\x6f\137\146\141\x5f\x64\165\157\x5f\x68\141\x6e\x64\x6c\145\x72\56\x70\x68\160";
        $OG = get_site_option("\x6d\157\x32\x66\x5f\x64\137\x69\x6e\x74\145\147\x72\x61\x74\151\x6f\x6e\137\153\x65\x79");
        $dU = get_site_option("\x6d\157\x32\146\137\144\137\163\x65\x63\x72\145\164\x5f\x6b\145\171");
        $ax = get_site_option("\x6d\x6f\62\x66\x5f\x64\137\x61\x70\151\x5f\x68\x6f\163\x74\x6e\x61\x6d\145");
        $HO = preauth($fK, true, $dU, $OG, $ax);
        if (isset($HO["\x72\145\x73\x70\x6f\156\163\x65"]["\163\x74\x61\164"]) && "\117\113" === $HO["\x72\145\x73\160\x6f\x6e\x73\x65"]["\163\x74\141\x74"]) {
            goto I0;
        }
        $we = "\x45\x72\162\x6f\x72\x20\x74\150\162\x6f\x75\147\150\40\144\165\x72\x69\x6e\147\x20\x70\162\x65\141\165\x74\150\x2e";
        goto zg;
        I0:
        if (isset($HO["\162\x65\x73\x70\x6f\x6e\163\x65"]["\162\x65\163\x70\157\156\163\x65"]["\163\x74\141\164\x75\163\137\x6d\163\147"]) && "\101\x63\x63\157\165\156\x74\x20\x69\x73\40\x61\143\164\151\166\145" === $HO["\x72\x65\x73\160\x6f\156\x73\x65"]["\x72\145\163\160\157\x6e\163\145"]["\163\x74\141\x74\x75\163\137\155\x73\147"]) {
            goto a9;
        }
        if (isset($HO["\162\145\x73\x70\157\156\x73\x65"]["\162\145\x73\160\x6f\x6e\x73\145"]["\145\156\162\157\x6c\x6c\137\160\157\x72\164\x61\154\137\x75\x72\x6c"])) {
            goto Yt;
        }
        $we = "\x59\157\x75\162\40\x61\143\x63\157\x75\x6e\x74\x20\151\x73\40\x69\x6e\141\143\164\151\166\145\x20\146\x72\x6f\155\40\x64\x75\x6f\40\x73\151\x64\x65\x2c\x20\x70\x6c\x65\x61\x73\145\40\x63\x6f\x6e\x74\141\x63\x74\x20\164\x6f\40\x79\157\x75\162\40\x61\x64\x6d\x69\x6e\151\x73\164\x72\x61\164\157\x72\56";
        goto Jw;
        a9:
        $we = $fK . "\40\165\x73\145\162\x20\x69\x73\40\x61\x6c\162\145\x61\x64\x79\40\x65\170\151\163\x74\x73\54\x20\x70\x6c\145\x61\163\x65\x20\x67\157\40\146\157\x72\x20\163\x74\x65\x70\x20\102\x20\x64\165\x6f\x20\x77\x69\154\154\40\x73\x65\x6e\144\40\160\165\x73\x68\x20\x6e\x6f\164\151\x66\151\x63\x61\164\x69\157\x6e\40\157\156\x20\171\157\165\162\40\x63\x6f\x6e\x66\x69\147\165\162\x65\x64\40\x6d\157\142\151\154\145\x2e";
        goto Jw;
        Yt:
        $G8 = $HO["\x72\145\x73\x70\x6f\156\163\145"]["\162\x65\163\160\157\156\163\x65"]["\x65\x6e\x72\x6f\x6c\x6c\x5f\x70\x6f\x72\x74\x61\154\x5f\x75\162\x6c"];
        update_user_meta($v1, "\165\163\145\162\x5f\156\157\x74\x5f\145\156\162\x6f\x6c\x6c\137\x6f\156\137\x64\x75\157\137\x62\145\x66\x6f\162\145", $G8);
        update_user_meta($v1, "\165\163\x65\x72\137\156\x6f\164\x5f\145\156\162\157\154\x6c", true);
        Jw:
        zg:
        $AP = "\x4d\x4f\137\62\137\106\x41\103\x54\x4f\122\x5f\x50\x52\117\115\x50\x54\x5f\x55\x53\x45\x52\137\106\117\x52\x5f\x32\x46\101\x5f\115\105\x54\x48\x4f\104\123";
        $this->miniorange_pass2login_form_fields($AP, $we, $ok, null, $Ty);
        goto H4;
        oo:
        $jY = new WP_Error();
        $jY->add("\145\x6d\160\164\x79\x5f\x75\x73\145\x72\x6e\x61\x6d\145", "\x3c\x73\x74\162\157\156\147\76" . __("\x45\122\122\117\x52", "\155\x69\x6e\x69\157\x72\x61\x6e\147\x65\55\62\55\146\141\143\164\157\x72\x2d\x61\165\x74\150\x65\156\164\151\143\141\x74\151\157\x6e") . "\74\x2f\x73\x74\162\157\156\x67\76\72\40" . __("\x49\x6e\166\x61\154\151\144\x20\x52\x65\161\x75\145\x73\x74\x2e", "\155\x69\x6e\151\x6f\162\141\x6e\x67\145\x2d\x32\55\146\x61\143\x74\x6f\x72\55\141\165\x74\x68\x65\x6e\164\x69\x63\x61\164\x69\x6f\156"));
        return $jY;
        H4:
        aJ:
    }
    public function back_to_select_2fa()
    {
        if (!isset($_POST["\x6d\x69\x6e\x69\157\162\141\x6e\x67\x65\137\151\156\154\151\x6e\145\x5f\164\167\x6f\137\146\x61\143\164\157\x72\x5f\163\x65\x74\165\160"])) {
            goto oK;
        }
        $dk = sanitize_key(wp_unslash($_POST["\155\x69\156\x69\157\162\x61\156\x67\145\x5f\x69\x6e\154\x69\156\x65\137\x74\167\157\x5f\146\141\143\x74\157\x72\x5f\163\145\164\x75\160"]));
        if (!wp_verify_nonce($dk, "\x6d\x69\x6e\x69\157\162\141\x6e\x67\145\55\x32\55\x66\x61\x63\164\157\x72\55\151\x6e\x6c\x69\156\x65\55\163\145\x74\165\x70\55\156\x6f\x6e\x63\145")) {
            goto E0;
        }
        global $Gw;
        $this->miniorange_pass2login_start_session();
        $Ty = isset($_POST["\x73\x65\x73\163\x69\x6f\x6e\137\151\x64"]) ? sanitize_text_field(wp_unslash($_POST["\x73\145\x73\163\x69\157\156\x5f\x69\144"])) : null;
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\155\x6f\62\146\x5f\x63\x75\162\x72\x65\x6e\x74\x5f\x75\163\x65\162\137\x69\x64");
        $ok = isset($_POST["\162\x65\144\x69\x72\x65\143\x74\137\164\x6f"]) ? esc_url_raw(wp_unslash($_POST["\162\x65\144\151\162\145\143\164\137\x74\x6f"])) : null;
        $current_user = get_user_by("\x69\144", $v1);
        $Gw->update_user_details($current_user->ID, array("\155\x6f\x32\x66\x5f\x63\x6f\x6e\x66\x69\x67\165\x72\x65\x64\137\62\x66\x61\x5f\155\145\164\x68\157\x64" => ''));
        $we = '';
        $AP = "\x4d\117\137\62\x5f\106\101\x43\124\x4f\x52\137\x50\122\x4f\115\x50\x54\137\125\x53\x45\x52\x5f\106\117\x52\x5f\x32\106\101\137\115\105\124\110\117\104\x53";
        $this->miniorange_pass2login_form_fields($AP, $we, $ok, null, $Ty);
        goto GO;
        E0:
        $jY = new WP_Error();
        $jY->add("\145\155\x70\x74\171\x5f\x75\x73\x65\x72\156\x61\155\145", "\x3c\x73\x74\x72\157\156\147\x3e" . __("\105\x52\122\x4f\122", "\155\151\156\151\157\162\141\x6e\147\x65\55\62\55\x66\x61\143\164\x6f\162\x2d\x61\165\x74\150\x65\156\164\x69\x63\141\x74\151\x6f\x6e") . "\74\x2f\x73\x74\162\157\x6e\x67\x3e\72\x20" . __("\x49\x6e\x76\x61\x6c\x69\x64\x20\122\145\161\165\x65\163\164\56", "\155\x69\156\151\157\x72\141\156\x67\x65\x2d\62\55\x66\x61\143\164\x6f\x72\x2d\x61\165\164\150\145\x6e\164\151\x63\141\164\151\157\156"));
        return $jY;
        GO:
        oK:
    }
    public function create_user_in_miniorange($YP, $fK, $eG)
    {
        $WM = get_user_meta($YP, "\x6d\157\62\146\137\145\x6d\x61\151\154\x5f\x6d\151\156\x69\117\162\141\x6e\147\145", true);
        if (!(isset($WM) && !empty($WM))) {
            goto GM;
        }
        $fK = $WM;
        GM:
        global $Gw;
        if (!get_option("\x6d\157\62\x66\x5f\155\x69\x6e\x69\157\162\x61\x6e\147\145\137\141\144\x6d\x69\156" === $YP)) {
            goto e5;
        }
        $fK = get_option("\x6d\x6f\62\146\x5f\145\x6d\x61\151\x6c");
        e5:
        $Ip = new MocURL();
        $Gy = json_decode($Ip->mo_check_user_already_exist($fK), true);
        if (!(JSON_ERROR_NONE === json_last_error())) {
            goto sc;
        }
        if ("\x45\x52\122\x4f\x52" === $Gy["\163\x74\141\164\165\163"] && "\x59\157\165\x20\x61\162\145\x20\156\x6f\x74\x20\x61\x75\164\150\x6f\162\151\x7a\145\144\40\x74\x6f\x20\x63\x72\145\141\x74\145\x20\x75\x73\x65\x72\x73\56\40\x50\154\x65\x61\x73\145\x20\165\x70\x67\x72\x61\144\x65\40\164\157\40\x70\x72\145\155\151\x75\155\x20\160\154\x61\x6e\x2e" === $Gy["\x6d\x65\x73\x73\x61\x67\x65"]) {
            goto aB;
        }
        if (strcasecmp($Gy["\163\x74\141\x74\x75\x73"], "\125\123\105\122\137\106\117\x55\x4e\104") === 0) {
            goto Ac;
        }
        if (0 === strcasecmp($Gy["\163\x74\x61\x74\165\x73"], "\x55\x53\105\122\137\116\117\x54\137\x46\x4f\125\x4e\104")) {
            goto eZ;
        }
        if (0 === strcasecmp($Gy["\163\x74\x61\x74\165\x73"], "\x55\123\x45\x52\x5f\106\x4f\x55\x4e\x44\137\x55\x4e\104\x45\x52\x5f\x44\x49\x46\x46\x45\x52\105\116\x54\137\x43\x55\x53\x54\x4f\x4d\x45\x52")) {
            goto A6;
        }
        goto FJ;
        aB:
        $current_user = get_user_by("\x69\x64", $YP);
        $hP = json_decode($Ip->mo_create_user($current_user, $fK), true);
        update_site_option(base64_encode("\x74\x6f\x74\x61\x6c\x55\x73\x65\x72\163\103\154\x6f\165\144"), get_site_option(base64_encode("\164\157\164\x61\154\125\x73\x65\x72\163\x43\x6c\x6f\x75\x64")) + 1);
        $Gw->update_user_details($YP, array("\165\x73\x65\162\137\x72\145\x67\x69\163\164\162\x61\x74\x69\157\x6e\137\x77\x69\x74\x68\x5f\155\x69\156\x69\157\162\x61\x6e\x67\145" => "\123\x55\103\x43\x45\x53\123", "\x6d\157\x32\x66\137\x75\163\145\x72\x5f\x65\x6d\141\151\x6c" => $fK, "\x6d\157\137\62\x66\141\x63\164\x6f\162\x5f\165\x73\145\x72\137\162\145\147\151\163\164\x72\141\164\151\157\156\x5f\163\x74\x61\164\165\x73" => "\x4d\x4f\137\x32\137\106\x41\103\124\117\122\x5f\x49\x4e\111\x54\x49\x41\x4c\111\132\105\137\124\x57\x4f\x5f\106\101\103\124\117\122"));
        $we = '';
        $AP = "\115\x4f\x5f\62\x5f\106\101\x43\x54\117\122\137\120\122\117\x4d\120\124\x5f\125\x53\105\122\x5f\106\x4f\122\x5f\x32\x46\x41\137\x4d\x45\x54\110\117\104\123";
        goto FJ;
        Ac:
        $Gw->update_user_details($YP, array("\165\163\x65\162\137\x72\145\x67\151\x73\x74\162\x61\x74\x69\157\156\x5f\x77\151\x74\150\137\155\x69\x6e\151\157\162\141\x6e\x67\x65" => "\123\125\x43\103\x45\123\x53", "\x6d\x6f\62\x66\x5f\165\163\145\162\137\145\155\x61\151\x6c" => $fK, "\155\157\x5f\62\146\141\x63\x74\x6f\x72\137\x75\x73\145\x72\x5f\x72\145\x67\x69\163\164\162\x61\164\151\x6f\156\x5f\x73\x74\x61\164\x75\x73" => "\x4d\117\137\62\x5f\x46\x41\x43\x54\x4f\x52\137\x49\x4e\111\124\111\x41\x4c\x49\132\x45\137\124\127\117\137\106\101\x43\124\x4f\x52"));
        update_site_option(base64_encode("\164\x6f\164\x61\x6c\125\163\145\x72\x73\x43\154\157\x75\x64"), get_site_option(base64_encode("\164\x6f\164\x61\x6c\125\163\145\x72\163\103\x6c\157\165\x64")) + 1);
        $AP = "\x4d\117\x5f\62\x5f\106\x41\x43\x54\x4f\122\x5f\x50\122\117\x4d\x50\124\x5f\125\x53\x45\x52\x5f\106\x4f\x52\x5f\x32\x46\x41\x5f\115\x45\x54\110\117\104\123";
        return $Gy;
        goto FJ;
        eZ:
        $current_user = get_user_by("\x69\x64", $YP);
        $hP = json_decode($Ip->mo_create_user($current_user, $fK), true);
        if (!(JSON_ERROR_NONE === json_last_error())) {
            goto bs;
        }
        if (0 === strcasecmp($hP["\163\164\x61\x74\165\x73"], "\x53\x55\103\x43\105\123\x53")) {
            goto Fk;
        }
        $Gy["\163\164\141\x74\x75\x73"] = "\x45\x52\x52\x4f\x52";
        $Gy["\x6d\145\163\x73\x61\147\145"] = "\x54\150\x65\x72\145\40\151\x73\x20\x61\x6e\40\x69\163\x73\165\145\x20\151\x6e\40\x75\x73\145\x72\40\143\x72\x65\141\x74\151\157\x6e\x20\x69\x6e\40\x6d\x69\156\151\x4f\x72\x61\x6e\147\x65\x2e\40\120\x6c\145\x61\x73\145\x20\x73\153\151\x70\x20\141\156\x64\x20\x63\157\156\164\x61\x63\164\x20\155\151\x6e\x69\x6f\162\141\x6e\147\x65";
        return $Gy;
        goto X8;
        Fk:
        update_site_option(base64_encode("\164\x6f\164\141\154\x55\x73\145\162\x73\x43\x6c\157\x75\x64"), get_site_option(base64_encode("\x74\157\x74\x61\x6c\125\163\145\162\163\103\154\157\165\x64")) + 1);
        $Gw->update_user_details($YP, array("\165\x73\x65\162\x5f\162\145\147\151\163\x74\162\141\x74\151\157\x6e\x5f\x77\151\x74\x68\x5f\155\151\x6e\151\157\162\x61\156\147\x65" => "\x53\125\x43\103\105\123\123", "\x6d\x6f\x32\x66\137\x75\163\145\x72\137\145\155\x61\151\x6c" => $fK, "\x6d\x6f\x5f\x32\146\141\x63\164\x6f\x72\x5f\x75\x73\x65\x72\137\162\145\x67\x69\163\x74\162\x61\164\x69\x6f\156\137\163\164\141\x74\x75\163" => "\x4d\x4f\x5f\x32\137\x46\101\x43\124\117\x52\x5f\x49\116\111\124\x49\x41\x4c\x49\x5a\105\x5f\124\127\117\137\x46\x41\x43\x54\117\x52"));
        $we = '';
        $AP = "\115\x4f\137\62\137\106\x41\103\x54\117\x52\x5f\x50\x52\117\x4d\x50\124\137\125\123\105\x52\x5f\106\x4f\122\x5f\x32\106\x41\x5f\x4d\105\124\x48\x4f\x44\123";
        return $Gy;
        X8:
        bs:
        goto FJ;
        A6:
        $we = __("\x54\x68\145\40\145\x6d\141\x69\x6c\x20\x61\163\x73\157\143\x69\141\164\145\x64\40\x77\x69\164\x68\x20\171\x6f\x75\x72\x20\x61\143\143\x6f\x75\156\164\40\151\x73\40\141\154\162\x65\x61\x64\x79\40\x72\145\x67\151\x73\x74\145\x72\145\x64\56\40\x50\154\145\141\163\145\x20\x63\x6f\x6e\x74\141\x63\164\x20\x79\157\x75\162\x20\141\x64\x6d\151\156\x20\x74\x6f\40\x63\150\x61\156\147\145\x20\164\150\x65\x20\x65\155\141\151\154\x2e", "\155\x69\x6e\x69\157\162\141\156\147\x65\x2d\x32\x2d\146\x61\x63\x74\x6f\x72\55\141\x75\x74\x68\x65\x6e\164\x69\x63\x61\164\151\157\156");
        $Gy["\x73\x74\x61\164\x75\163"] = "\105\x52\x52\x4f\122";
        $Gy["\155\145\x73\x73\141\x67\x65"] = $we;
        return $Gy;
        FJ:
        sc:
    }
    public function check_miniorange_alternate_login_kba($Jo)
    {
        $dk = $Jo["\x6d\151\x6e\x69\x6f\162\141\x6e\x67\145\137\x61\154\x74\x65\x72\x6e\141\164\x65\x5f\154\157\x67\x69\x6e\x5f\x6b\142\x61\x5f\156\157\x6e\x63\145"];
        if (!wp_verify_nonce($dk, "\x6d\151\x6e\151\x6f\x72\x61\156\x67\145\55\x32\x2d\146\141\x63\x74\157\162\x2d\141\154\x74\x65\162\156\x61\164\x65\x2d\154\157\147\x69\156\55\153\142\x61\x2d\x6e\x6f\156\143\145")) {
            goto ur;
        }
        $this->miniorange_pass2login_start_session();
        $Ty = isset($Jo["\x73\145\x73\163\x69\157\x6e\x5f\151\144"]) ? $Jo["\x73\145\163\x73\x69\157\x6e\137\151\x64"] : null;
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\155\157\x32\x66\x5f\143\x75\162\x72\145\x6e\164\137\x75\x73\x65\x72\x5f\151\144");
        $ok = isset($Jo["\x72\x65\x64\151\162\x65\x63\164\137\x74\157"]) ? esc_url_raw($Jo["\x72\x65\x64\x69\162\x65\143\x74\x5f\x74\x6f"]) : null;
        $this->mo2f_onprem_cloud_obj->mo2f_pass2login_kba_verification(get_user_by("\151\144", $v1), '', $ok, $Ty);
        goto tQ;
        ur:
        $jY = new WP_Error();
        $jY->add("\145\155\x70\164\x79\x5f\165\x73\145\x72\156\x61\155\145", __("\74\x73\164\162\x6f\x6e\x67\x3e\105\122\122\x4f\122\74\x2f\163\164\162\x6f\x6e\147\x3e\x3a\x20\111\x6e\x76\x61\154\151\x64\40\x52\145\x71\165\x65\163\164\x2e"));
        return $jY;
        tQ:
    }
    public function check_miniorange_duo_push_validation($Jo)
    {
        global $uz;
        $dk = $Jo["\x6d\151\156\x69\157\x72\x61\x6e\x67\145\137\x64\165\157\137\160\165\x73\150\x5f\166\x61\154\x69\144\141\164\151\157\x6e\x5f\x6e\x6f\156\x63\x65"];
        if (!wp_verify_nonce($dk, "\x6d\x69\x6e\x69\157\x72\x61\x6e\x67\x65\55\62\55\x66\141\x63\164\x6f\x72\x2d\144\x75\157\55\x76\x61\154\x69\144\x61\164\151\157\x6e\55\x6e\157\x6e\143\145")) {
            goto gc;
        }
        $this->miniorange_pass2login_start_session();
        $Ty = isset($Jo["\x73\x65\x73\163\x69\x6f\x6e\137\151\144"]) ? sanitize_text_field(wp_unslash($Jo["\x73\145\x73\163\151\x6f\x6e\x5f\151\144"])) : null;
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\x6d\157\x32\146\137\143\x75\162\162\x65\156\x74\137\x75\x73\x65\x72\x5f\151\x64");
        $ok = isset($Jo["\x72\x65\144\151\162\145\143\164\137\x74\x6f"]) ? esc_url_raw($Jo["\x72\x65\x64\x69\162\x65\143\x74\137\164\157"]) : null;
        MO2f_Utility::mo2f_debug_file("\104\165\x6f\40\160\x75\163\150\x20\x6e\157\164\x69\146\151\x63\x61\x74\x69\157\156\x20\x2d\x20\x4c\x6f\147\147\x65\144\40\151\x6e\x20\x73\x75\x63\x63\x65\x73\x73\x66\165\x6c\x6c\171\x20\125\x73\x65\x72\x5f\x49\x50\55" . $uz->get_client_ip() . "\x20\125\163\145\162\x5f\x49\x64\55" . $v1);
        $this->mo2fa_pass2login($ok, $Ty);
        goto rI;
        gc:
        $jY = new WP_Error();
        $jY->add("\x65\x6d\160\164\171\137\165\x73\145\x72\x6e\141\x6d\x65", __("\74\x73\x74\162\x6f\x6e\147\x3e\x45\122\122\x4f\x52\x3c\57\x73\164\x72\x6f\156\147\x3e\x3a\x20\x49\x6e\x76\141\154\151\x64\40\122\x65\161\x75\x65\x73\x74\56"));
        return $jY;
        rI:
    }
    public function check_miniorange_duo_push_validation_failed($Jo)
    {
        global $uz;
        $dk = $Jo["\x6d\x69\156\x69\157\x72\x61\156\147\x65\137\144\165\x6f\x5f\160\x75\163\150\x5f\166\x61\154\151\x64\141\x74\151\x6f\x6e\x5f\x66\x61\x69\x6c\145\x64\137\x6e\x6f\x6e\143\145"];
        if (!wp_verify_nonce($dk, "\x6d\x69\156\x69\157\162\x61\x6e\147\145\x2d\x32\55\146\141\143\164\157\162\55\144\165\157\55\160\x75\163\x68\55\x76\141\154\151\x64\141\164\151\157\156\55\x66\x61\x69\x6c\x65\144\55\156\x6f\x6e\143\145")) {
            goto xF;
        }
        MO2f_Utility::mo2f_debug_file("\104\x65\156\151\145\144\40\x64\165\157\x20\x70\x75\x73\x68\x20\x6e\x6f\164\x69\x66\151\x63\141\x74\151\x6f\156\x20\x20\x55\163\145\x72\137\x49\120\x2d" . $uz->get_client_ip());
        $this->miniorange_pass2login_start_session();
        $Ty = isset($Jo["\x73\145\x73\163\151\x6f\x6e\x5f\x69\144"]) ? sanitize_text_field(wp_unslash($Jo["\x73\145\x73\x73\151\x6f\156\137\151\x64"])) : null;
        $this->remove_current_activity($Ty);
        goto Xc;
        xF:
        $jY = new WP_Error();
        $jY->add("\x65\155\x70\164\171\x5f\x75\x73\145\x72\156\141\155\x65", "\x3c\163\164\162\x6f\156\147\x3e" . esc_textarea("\105\122\122\x4f\x52", "\x6d\x69\x6e\151\157\x72\141\156\x67\x65\55\x32\x2d\146\x61\143\x74\157\162\x2d\141\165\x74\150\x65\x6e\x74\x69\x63\x61\164\151\x6f\156") . "\74\x2f\x73\164\x72\x6f\156\147\76\x3a\x20" . esc_html__("\x49\156\166\x61\x6c\151\144\x20\122\x65\161\165\145\163\x74\56", "\x6d\x69\x6e\151\x6f\162\141\x6e\x67\x65\x2d\62\55\146\141\x63\164\157\x72\x2d\x61\165\164\x68\145\156\164\151\x63\x61\x74\x69\x6f\156"));
        return $jY;
        Xc:
    }
    public function check_mo2f_duo_authenticator_success_form($Jo)
    {
        if (!isset($Jo["\x6d\x6f\62\146\137\144\x75\157\x5f\141\x75\164\150\x65\x6e\164\x69\x63\x61\x74\157\x72\137\163\x75\x63\x63\145\163\163\x5f\x6e\157\x6e\x63\145"])) {
            goto oB;
        }
        $dk = sanitize_text_field($Jo["\155\x6f\62\x66\137\x64\165\x6f\137\141\x75\164\x68\x65\156\164\x69\x63\x61\164\157\x72\x5f\x73\165\143\x63\145\x73\x73\137\x6e\157\x6e\x63\x65"]);
        if (!wp_verify_nonce($dk, "\155\x6f\62\x66\55\x64\x75\x6f\55\x61\165\x74\150\145\156\x74\x69\x63\141\x74\157\162\x2d\163\x75\x63\143\x65\x73\x73\55\156\x6f\156\x63\x65")) {
            goto ZQ;
        }
        global $Gw;
        $this->miniorange_pass2login_start_session();
        $Ty = isset($Jo["\163\x65\x73\x73\x69\157\156\x5f\x69\144"]) ? sanitize_text_field(wp_unslash($Jo["\163\x65\x73\163\151\157\156\x5f\x69\144"])) : null;
        MO2f_Utility::unset_temp_user_details_in_table("\x6d\x6f\x32\x66\x5f\x74\162\141\156\x73\x61\x63\164\x69\157\156\x49\144", $Ty);
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\155\x6f\62\x66\x5f\143\x75\162\162\x65\156\x74\137\165\163\145\x72\x5f\x69\144");
        $ok = isset($Jo["\162\145\144\x69\162\145\x63\164\137\x74\157"]) ? esc_url_raw($Jo["\162\145\144\151\x72\x65\x63\164\x5f\164\x6f"]) : null;
        $Z7 = $Gw->get_user_detail("\x6d\x6f\x32\x66\x5f\x63\157\x6e\146\151\147\x75\x72\x65\x64\137\x32\146\x61\137\x6d\x65\x74\x68\157\144", $v1);
        $fK = $Gw->get_user_detail("\155\x6f\62\146\x5f\x75\163\145\x72\137\x65\155\x61\x69\154", $v1);
        $we = '';
        delete_user_meta($v1, "\165\163\x65\162\x5f\156\157\x74\137\x65\156\162\157\x6c\154");
        delete_site_option("\x63\x75\162\162\145\x6e\x74\137\x75\x73\x65\x72\137\x65\x6d\x61\x69\x6c");
        $Gw->update_user_details($v1, array("\x6d\157\x62\151\x6c\145\137\x72\145\147\151\163\164\x72\141\164\151\x6f\x6e\x5f\x73\x74\x61\164\x75\x73" => true, "\155\x6f\x32\x66\137\104\165\157\x41\165\x74\x68\x65\156\x74\x69\x63\141\164\x6f\x72\x5f\143\x6f\156\x66\151\x67\137\x73\x74\141\x74\x75\163" => true, "\x6d\x6f\62\x66\x5f\143\157\156\146\151\147\x75\x72\145\144\137\62\x66\x61\137\x6d\x65\x74\150\157\x64" => $Z7, "\155\x6f\137\62\146\141\143\x74\157\x72\x5f\x75\x73\x65\x72\x5f\x72\145\x67\x69\163\x74\162\x61\x74\x69\x6f\156\x5f\163\164\141\164\x75\163" => "\x4d\x4f\137\62\137\x46\101\103\124\x4f\122\137\120\114\125\107\x49\116\x5f\123\105\124\x54\x49\x4e\107\x53"));
        $AP = "\x4d\117\137\x32\137\x46\x41\x43\x54\x4f\x52\137\x53\105\x54\x55\x50\x5f\x53\x55\x43\x43\x45\x53\x53";
        $this->miniorange_pass2login_form_fields($AP, $we, $ok, null, $Ty);
        goto LJ;
        ZQ:
        $jY = new WP_Error();
        $jY->add("\145\155\x70\x74\x79\x5f\x75\163\145\x72\x6e\141\155\x65", "\x3c\x73\164\x72\x6f\156\147\x3e" . __("\105\x52\122\x4f\x52", "\155\151\x6e\x69\x6f\x72\x61\x6e\147\x65\x2d\x32\55\x66\141\143\164\157\x72\x2d\x61\165\x74\x68\145\x6e\164\x69\143\141\x74\x69\157\156") . "\x3c\57\x73\164\x72\157\x6e\147\76\x3a\40" . __("\x49\156\x76\x61\x6c\151\x64\x20\x52\x65\x71\x75\x65\x73\164\56", "\155\x69\x6e\x69\157\x72\141\156\147\145\55\62\55\146\x61\143\x74\157\x72\55\141\165\x74\x68\145\156\164\151\x63\141\x74\151\x6f\x6e"));
        return $jY;
        LJ:
        oB:
    }
    public function check_inline_mo2f_duo_authenticator_error($Jo)
    {
        $dk = $Jo["\x6d\157\x32\x66\137\151\x6e\154\151\156\145\x5f\144\x75\x6f\137\x61\165\x74\150\145\x6e\164\143\x61\164\157\162\137\x65\x72\162\x6f\x72\137\156\157\x6e\143\x65"];
        if (!wp_verify_nonce($dk, "\155\157\62\x66\55\151\x6e\x6c\x69\x6e\x65\55\x64\165\157\x2d\x61\165\x74\x68\x65\156\x74\151\x63\x61\164\157\162\55\x65\x72\162\x6f\x72\55\156\x6f\x6e\x63\145")) {
            goto Wv;
        }
        global $Gw;
        $this->miniorange_pass2login_start_session();
        $Ty = isset($Jo["\163\145\x73\163\x69\x6f\x6e\x5f\151\144"]) ? sanitize_text_field(wp_unslash($Jo["\x73\x65\x73\x73\x69\x6f\x6e\x5f\151\x64"])) : null;
        MO2f_Utility::unset_temp_user_details_in_table("\x6d\x6f\x32\146\137\164\x72\141\156\x73\141\x63\x74\151\x6f\156\111\x64", $Ty);
        $v1 = MO2f_Utility::mo2f_get_transient($Ty, "\x6d\x6f\62\x66\137\143\165\x72\162\145\156\x74\137\165\x73\x65\162\137\x69\144");
        $Gw->update_user_details($v1, array("\x6d\x6f\x62\x69\x6c\x65\137\162\x65\x67\151\x73\164\x72\x61\164\151\x6f\x6e\x5f\163\164\141\x74\165\163" => false));
        goto wi;
        Wv:
        $jY = new WP_Error();
        $jY->add("\x65\155\x70\164\171\137\165\163\145\x72\156\141\x6d\x65", "\x3c\x73\164\x72\x6f\156\147\76" . esc_html("\x45\x52\x52\x4f\122") . "\74\x2f\x73\x74\x72\x6f\x6e\x67\76\72\x20" . esc_html("\x49\x6e\166\x61\154\151\x64\40\122\x65\x71\165\145\x73\164\56"));
        return $jY;
        wi:
    }
    public function miniorange_pass2login_redirect()
    {
        do_action("\155\157\x32\146\x5f\x6e\145\x74\x77\x6f\x72\x6b\137\151\x6e\x69\x74");
        global $Gw;
        if (isset($_GET["\x72\145\143\157\x6e\146\x69\147\x75\162\145\x4d\x65\x74\x68\157\144"]) && is_user_logged_in()) {
            goto JI;
        }
        if (isset($_POST["\x65\x6d\x61\x69\x6c\x49\x6e\154\151\x6e\145\x43\x6c\x6f\x75\x64"])) {
            goto HM;
        }
        $iY = isset($_POST["\x6f\160\164\151\157\156"]) ? sanitize_text_field(wp_unslash($_POST["\x6f\x70\x74\x69\157\156"])) : false;
        switch ($iY) {
            case "\x6d\x69\x6e\151\x6f\x72\x61\156\147\145\x5f\141\154\164\x65\x72\156\x61\x74\x65\x5f\154\157\147\x69\x6e\x5f\153\142\x61":
                $this->check_miniorange_alternate_login_kba($_POST);
                goto lF;
            case "\x6d\151\156\151\157\x72\141\156\x67\x65\x5f\x64\165\x6f\137\x70\x75\x73\150\x5f\x76\x61\x6c\x69\x64\141\164\151\157\x6e":
                $this->check_miniorange_duo_push_validation($_POST);
                goto lF;
            case "\155\x6f\62\146\x5f\151\x6e\x6c\151\x6e\x65\x5f\144\165\x6f\x5f\141\165\164\150\x65\156\x74\x69\143\x61\x74\157\x72\x5f\x73\165\143\143\145\x73\163\x5f\146\157\162\x6d":
                $this->check_mo2f_duo_authenticator_success_form($_POST);
                goto lF;
            case "\x6d\157\62\x66\x5f\151\x6e\x6c\x69\x6e\145\x5f\x64\165\x6f\137\141\x75\x74\150\x65\156\x74\x69\x63\x61\x74\157\162\x5f\145\162\x72\x6f\162":
                $this->check_inline_mo2f_duo_authenticator_error($_POST);
                goto lF;
            case "\155\x69\x6e\x69\x6f\162\141\156\x67\145\x5f\144\165\x6f\x5f\x70\x75\163\150\137\x76\141\x6c\151\144\141\164\x69\157\156\137\146\141\151\x6c\145\x64":
                $this->check_miniorange_duo_push_validation_failed($_POST);
                goto lF;
            case "\x6d\x69\x6e\x69\157\162\141\156\x67\x65\x5f\x62\141\143\153\137\151\156\x6c\151\x6e\x65":
                $this->back_to_select_2fa();
                goto lF;
            case "\155\x69\156\151\x6f\162\141\x6e\x67\x65\137\151\156\x6c\x69\x6e\x65\137\x63\157\x6d\x70\x6c\145\x74\x65\x5f\x6d\157\x62\151\x6c\145":
                $this->mo2f_inline_validate_mobile_authentication();
                goto lF;
            case "\155\x69\x6e\x69\x6f\x72\x61\156\x67\145\137\151\156\x6c\151\x6e\x65\x5f\x64\165\157\137\x61\165\164\150\137\x6d\157\x62\x69\x6c\145\137\143\157\155\160\x6c\145\x74\145":
                $this->mo2f_inline_validate_duo_authentication();
                goto lF;
            case "\144\x75\157\137\155\157\142\x69\x6c\x65\x5f\x73\x65\x6e\144\x5f\160\165\x73\150\137\x6e\157\164\x69\146\x69\143\141\164\151\157\x6e\137\x66\x6f\x72\137\x69\x6e\154\x69\156\x65\x5f\x66\x6f\162\155":
                $this->mo2f_duo_mobile_send_push_notification_for_inline_form();
                goto lF;
            default:
                $jY = new WP_Error();
                $jY->add("\145\155\160\164\x79\137\x75\x73\145\162\x6e\x61\x6d\x65", __("\74\x73\164\x72\x6f\156\147\76\x45\122\x52\x4f\122\74\57\x73\164\162\x6f\x6e\x67\x3e\72\x20\111\x6e\166\x61\154\x69\x64\x20\122\145\161\x75\x65\163\x74\56"));
                return $jY;
        }
        RD:
        lF:
        goto v8;
        JI:
        $I1 = get_current_user_id();
        $mb = isset($_GET["\x74\x72\x61\156\163\x61\x63\x74\x69\x6f\x6e\x49\144"]) ? sanitize_text_field(wp_unslash($_GET["\164\x72\141\156\163\x61\143\164\x69\157\156\x49\x64"])) : '';
        $In = isset($_GET["\x72\x65\x63\157\156\146\151\x67\165\162\145\x4d\x65\164\150\157\x64"]) ? sanitize_text_field(wp_unslash($_GET["\x72\x65\143\x6f\x6e\x66\x69\147\x75\x72\x65\115\145\x74\x68\157\144"])) : '';
        if (get_site_option($mb) === $I1 && ctype_xdigit($mb) && ctype_xdigit($In)) {
            goto cw;
        }
        $W8 = array("\x68\145\141\144" => "\131\x6f\165\x20\x61\162\145\x20\x6e\x6f\x74\40\x61\165\164\150\x6f\x72\151\x7a\145\144\40\164\x6f\40\x70\x65\162\x66\157\x72\x6d\x20\x74\x68\151\x73\x20\141\143\x74\151\157\156", "\x62\x6f\x64\x79" => "\x50\154\x65\x61\x73\145\40\x63\x6f\156\164\x61\x63\x74\40\x74\x6f\40\171\x6f\165\x72\x20\x61\x64\x6d\151\x6e", "\x63\157\154\157\x72" => "\x23\106\106\60\60\60\60", "\x62\147\x5f\x63\x6f\x6c\157\x72" => "\43\x46\106\x46\x46\106\x46", "\x62\162\141\x6e\x64\x69\156\147\137\151\155\147" => "\x62\x61\143\x6b\x67\162\x6f\165\x6e\144\x2d\x63\x6f\154\x6f\162\x3a\x20\x23\x64\65\x65\x33\144\71\73", "\x6c\157\147\157\137\165\162\154" => esc_url($yv . "\151\x6e\x63\154\165\144\145\x73\57\x69\155\x61\x67\145\x73\x2f\155\151\156\x69\x4f\x72\141\156\x67\x65\62\56\160\156\147"));
        $bc = new Mo2f_Login_Popup();
        $bc->mo2f_display_email_verification($W8);
        exit;
        goto Th;
        cw:
        $la = get_site_option($In);
        $Gw->update_user_details($I1, array("\155\157\x5f\x32\146\x61\143\x74\x6f\x72\x5f\x75\x73\x65\162\137\x72\145\x67\x69\x73\x74\x72\141\164\x69\157\x6e\x5f\163\164\x61\164\x75\x73" => "\115\117\137\62\137\106\x41\103\124\117\122\x5f\103\x55\123\124\117\x4d\105\x52\137\x52\105\x47\x49\x53\124\x45\x52\x45\x44\137\x53\125\x43\103\105\x53\123", "\x6d\157\x32\146\x5f\x63\x6f\x6e\x66\151\147\x75\x72\x65\144\x5f\62\146\x61\x5f\155\145\x74\150\157\x64" => $la));
        $mt = $Gw->get_user_detail("\x6d\x6f\62\x66\x5f\x41\165\164\x68\171\101\x75\x74\x68\x65\156\x74\151\143\141\164\x6f\162\x5f\x63\157\x6e\146\x69\147\137\163\x74\141\x74\165\163", $I1);
        if (!(MoWpnsConstants::GOOGLE_AUTHENTICATOR === $la || $mt)) {
            goto a4;
        }
        update_user_meta($I1, "\155\157\62\146\x61\137\x73\145\164\137\101\165\x74\x68\x79\137\151\x6e\x6c\x69\156\145", true);
        a4:
        delete_site_option($mb);
        Th:
        goto v8;
        HM:
        $dk = isset($_POST["\x6d\151\x6e\x69\157\162\x61\x6e\x67\145\x5f\x65\x6d\141\x69\x6c\103\150\x61\x6e\x67\x65\137\156\x6f\x6e\143\x65"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\x69\156\x69\x6f\x72\141\x6e\x67\145\x5f\x65\155\141\x69\154\103\150\x61\x6e\147\x65\x5f\x6e\x6f\156\x63\145"])) : '';
        if (!wp_verify_nonce($dk, "\x6d\151\156\151\x6f\162\141\156\147\145\55\62\55\146\141\x63\x74\157\x72\x2d\x65\155\141\x69\154\55\143\x68\141\x6e\x67\145\55\x6e\157\x6e\143\145")) {
            goto Zx;
        }
        $fK = sanitize_text_field(wp_unslash($_POST["\145\155\x61\x69\x6c\x49\156\154\x69\x6e\145\x43\154\157\165\x64"]));
        $YP = isset($_POST["\143\165\x72\162\145\x6e\x74\137\165\163\145\162\137\x69\144"]) ? sanitize_text_field(wp_unslash($_POST["\x63\x75\162\162\x65\156\x74\137\x75\163\145\162\137\151\x64"])) : '';
        $Ty = isset($_POST["\x73\x65\163\x73\151\x6f\156\137\151\x64"]) ? sanitize_text_field(wp_unslash($_POST["\163\x65\x73\x73\151\x6f\156\x5f\x69\x64"])) : null;
        $ok = isset($_POST["\x72\145\144\151\x72\145\x63\164\x5f\164\157"]) ? esc_url_raw(wp_unslash($_POST["\162\x65\x64\x69\x72\145\x63\x74\137\164\157"])) : null;
        if (!filter_var($fK, FILTER_VALIDATE_EMAIL)) {
            goto p5;
        }
        global $Gw;
        $Gw->update_user_details($YP, array("\155\x6f\x32\x66\137\165\x73\145\162\137\x65\x6d\x61\x69\154" => $fK, "\155\x6f\x32\x66\x5f\143\x6f\x6e\146\x69\x67\165\162\x65\144\x5f\x32\x66\141\137\x6d\x65\x74\150\157\x64" => ''));
        prompt_user_to_select_2factor_mthod_inline($YP, "\115\117\x5f\x32\x5f\106\x41\x43\x54\117\122\137\x49\x4e\x49\124\x49\x41\114\111\x5a\105\x5f\124\x57\117\137\x46\101\103\124\x4f\122", '', $ok, $Ty, null);
        p5:
        goto QJ;
        Zx:
        $jY = new WP_Error();
        $jY->add("\x65\155\x70\x74\171\x5f\165\x73\x65\162\x6e\141\155\x65", "\74\x73\164\162\x6f\156\x67\x3e" . esc_html("\105\122\122\x4f\122") . "\74\x2f\163\x74\162\x6f\x6e\147\x3e\x3a\40" . esc_html("\x49\156\166\x61\x6c\151\144\40\x52\x65\161\165\145\163\164\56"));
        return $jY;
        QJ:
        v8:
    }
    public function remove_current_activity($jg)
    {
        global $Gw;
        $XQ = array("\x6d\157\x32\x66\137\143\165\162\162\145\x6e\164\137\x75\163\x65\x72\x5f\x69\x64", "\x6d\157\x32\x66\137\61\x73\164\146\141\x63\164\157\162\137\x73\164\x61\x74\165\x73", "\155\x6f\137\62\x66\141\x63\x74\157\162\137\154\157\x67\x69\156\x5f\x73\164\x61\164\x75\x73", "\x6d\157\x32\x66\55\x6c\x6f\147\151\156\x2d\x71\x72\103\x6f\x64\x65", "\x6d\157\62\x66\x5f\164\x72\x61\x6e\163\141\x63\x74\151\x6f\x6e\x49\144", "\155\x6f\x32\146\x5f\154\157\x67\151\x6e\x5f\x6d\x65\163\163\141\147\x65", "\155\157\137\x32\x5f\x66\x61\x63\x74\x6f\162\x5f\153\x62\x61\137\161\165\145\x73\x74\x69\x6f\x6e\x73", "\x6d\157\62\x66\x5f\x73\150\x6f\x77\x5f\x71\162\137\x63\157\144\145", "\155\157\x32\x66\137\x67\157\x6f\x67\x6c\145\x5f\141\x75\x74\x68", "\x6d\x6f\62\x66\137\x61\x75\x74\x68\x79\137\153\x65\x79\x73");
        $OQ = array("\x6d\157\x32\146\137\x63\x75\x72\162\145\x6e\164\x5f\x75\x73\145\162\137\x69\144", "\x6d\157\62\x66\x5f\x31\x73\x74\x66\x61\143\164\x6f\x72\137\163\164\141\164\x75\x73", "\x6d\x6f\x5f\x32\146\x61\143\x74\157\162\x5f\x6c\157\147\x69\x6e\x5f\x73\164\141\164\165\163", "\x6d\157\62\x66\55\x6c\157\147\151\x6e\x2d\161\162\103\x6f\144\145", "\x6d\157\x32\x66\137\x74\162\x61\x6e\163\141\143\x74\x69\x6f\x6e\111\x64", "\x6d\x6f\62\x66\x5f\x6c\x6f\x67\151\156\x5f\x6d\x65\x73\x73\141\x67\x65", "\153\x62\x61\137\161\165\145\x73\164\151\157\x6e\61", "\153\x62\x61\137\161\165\145\x73\x74\x69\x6f\156\x32", "\x6d\157\x32\x66\x5f\x73\x68\x6f\x77\x5f\161\162\x5f\143\157\x64\x65", "\x6d\157\62\146\137\x67\157\x6f\x67\x6c\145\x5f\x61\165\x74\150", "\x6d\x6f\x32\x66\x5f\x61\165\x74\x68\171\137\x6b\x65\171\163");
        $ml = array("\x73\145\163\163\x69\157\156\x5f\x69\144", "\x6d\157\x32\146\137\x63\165\x72\162\145\x6e\x74\137\165\x73\x65\162\137\151\144", "\155\x6f\62\146\x5f\154\157\x67\151\x6e\x5f\x6d\145\163\163\141\147\145", "\x6d\157\62\146\x5f\x31\163\x74\146\141\x63\x74\157\x72\x5f\x73\164\x61\164\165\x73", "\155\157\62\146\137\164\162\x61\x6e\x73\141\143\x74\151\x6f\x6e\111\144", "\155\x6f\x5f\62\137\x66\141\x63\x74\x6f\162\137\x6b\x62\141\x5f\x71\x75\145\163\164\x69\x6f\156\163", "\x74\163\137\143\162\145\x61\164\x65\144");
        MO2f_Utility::unset_session_variables($XQ);
        MO2f_Utility::unset_cookie_variables($OQ);
        $t8 = get_option("\155\157\x32\x66\137\x65\x6e\143\162\171\160\164\151\x6f\x6e\137\x6b\x65\x79");
        $jg = MO2f_Utility::decrypt_data($jg, $t8);
        $iQ = md5($jg);
        $Gw->save_user_login_details($iQ, array("\x6d\x6f\x32\x66\137\x63\165\162\162\145\156\x74\137\x75\x73\x65\x72\x5f\151\x64" => '', "\x6d\x6f\x32\x66\x5f\x6c\x6f\147\x69\x6e\137\155\145\x73\x73\x61\x67\x65" => '', "\155\x6f\62\x66\x5f\61\x73\x74\146\141\143\x74\157\x72\x5f\x73\x74\x61\x74\x75\163" => '', "\155\157\62\x66\x5f\164\162\x61\x6e\x73\x61\x63\164\x69\157\156\111\144" => '', "\155\157\x5f\x32\137\146\x61\143\164\x6f\162\x5f\153\x62\x61\137\161\165\x65\x73\164\x69\157\156\x73" => '', "\x74\x73\137\x63\x72\145\141\164\x65\144" => ''));
    }
    public function miniorange_pass2login_start_session()
    {
        if (!(!session_id() || '' === session_status() || !isset($_SESSION))) {
            goto Ap;
        }
        $aj = ini_get("\163\x65\x73\x73\151\x6f\x6e\x2e\163\141\x76\145\x5f\x70\141\x74\150");
        if (!(is_writable($aj) && is_readable($aj))) {
            goto iV;
        }
        if (!(PHP_SESSION_DISABLED !== session_status())) {
            goto XU;
        }
        session_start();
        XU:
        iV:
        Ap:
    }
    public function miniorange_pass2login_form_fields($AP = null, $we = null, $ok = null, $P4 = null, $Ty = null, $nA = null, $vj = false)
    {
        $Uc = $AP;
        $ga = $we;
        switch ($Uc) {
            case "\x4d\117\x5f\62\137\106\x41\x43\124\117\x52\137\x43\x48\x41\x4c\114\x45\x4e\x47\x45\x5f\x44\x55\117\137\120\x55\x53\110\x5f\116\117\124\111\x46\x49\x43\101\124\x49\x4f\x4e\123":
                $v1 = $this->mo2f_user_id ? $this->mo2f_user_id : MO2f_Utility::mo2f_get_transient($Ty, "\155\x6f\x32\146\x5f\x63\165\x72\x72\x65\x6e\x74\137\165\163\x65\x72\x5f\x69\x64");
                mo2f_get_duo_push_authentication_prompt($Uc, $ga, $ok, $Ty, $v1);
                goto Vt;
            case "\x4d\x4f\x5f\62\137\106\101\103\124\117\x52\137\x43\x48\101\x4c\114\105\x4e\107\x45\x5f\113\x42\x41\x5f\101\116\104\x5f\x4f\x54\120\137\117\x56\x45\122\x5f\x45\115\x41\x49\114":
                mo2f_get_forgotphone_form($Uc, $ga, $ok, $Ty);
                goto Vt;
            default:
                $this->mo_2_factor_pass2login_show_wp_login_form();
                goto Vt;
        }
        U3:
        Vt:
        exit;
    }
    public function miniorange_pass2login_check_forgotphone_status($Uc)
    {
        if (!("\x4d\x4f\137\62\x5f\x46\101\103\x54\x4f\x52\x5f\x43\x48\x41\114\114\x45\x4e\107\105\137\113\102\x41\137\x41\x4e\x44\x5f\117\124\120\137\x4f\x56\x45\122\x5f\x45\x4d\x41\x49\x4c" === $Uc)) {
            goto QG;
        }
        return true;
        QG:
        return false;
    }
    public function mo2f_redirect_shortcode_addon($YP, $Uc, $ga, $SJ)
    {
        do_action("\155\x6f\x32\146\137\x73\150\157\162\x74\143\x6f\x64\x65\137\x61\144\144\157\156", $YP, $Uc, $ga, $SJ);
    }
    public function miniorange_pass2login_check_kba_status($Uc)
    {
        if (!(MoWpnsConstants::MO_2_FACTOR_CHALLENGE_KBA_AUTHENTICATION === $Uc)) {
            goto bh;
        }
        return true;
        bh:
        return false;
    }
    public function mo_2_factor_pass2login_show_wp_login_form()
    {
        $Ty = $this->create_session();
        if (!class_exists("\124\150\x65\x6d\145\x5f\x4d\x79\x5f\x4c\x6f\147\x69\156")) {
            goto js;
        }
        wp_enqueue_script("\164\x6d\154\141\x6a\141\x78\137\x73\x63\162\151\160\x74", plugins_url("\x69\x6e\143\x6c\x75\144\x65\163\x2f\x6a\163\x2f\x74\x6d\x6c\141\x6a\141\x78\56\155\x69\156\56\x6a\x73", dirname(dirname(__FILE__))), array("\x6a\121\165\145\162\171"), MO2F_VERSION, false);
        wp_localize_script("\x74\155\154\141\152\x61\x78\x5f\x73\x63\x72\x69\x70\164", "\x6d\171\x5f\x61\152\x61\x78\x5f\x6f\x62\x6a\145\x63\x74", array("\141\152\x61\170\137\x75\x72\154" => admin_url("\141\144\x6d\x69\x6e\55\x61\x6a\x61\x78\56\x70\x68\x70")));
        js:
        if (!class_exists("\x4c\x6f\147\x69\x6e\127\151\x74\150\x41\x6a\141\x78")) {
            goto ue;
        }
        wp_enqueue_script("\154\x6f\147\x69\156\137\167\151\x74\150\x5f\x61\x6a\x61\x78\137\163\143\162\x69\x70\x74", plugins_url("\x69\156\143\x6c\x75\144\145\x73\x2f\x6a\x73\x2f\x6c\157\147\151\x6e\137\x77\151\164\x68\137\x61\152\x61\170\x2e\x6d\151\x6e\x2e\152\x73", dirname(dirname(__FILE__))), array("\x6a\x51\x75\x65\x72\x79"), MO2F_VERSION, false);
        wp_localize_script("\x6c\157\147\x69\156\x5f\x77\x69\x74\x68\x5f\141\152\141\x78\x5f\163\x63\x72\x69\x70\164", "\155\171\x5f\141\x6a\141\x78\137\157\x62\152\145\143\164", array("\141\152\141\170\137\165\162\154" => admin_url("\x61\144\155\151\156\x2d\x61\x6a\141\x78\x2e\160\x68\x70")));
        ue:
        echo "\11\x9\x3c\x70\x3e\74\x69\156\160\x75\x74\40\x74\x79\160\x65\75\42\150\151\144\144\145\156\x22\40\x6e\141\155\x65\75\42\x6d\151\x6e\151\x6f\x72\141\156\x67\x65\137\154\157\x67\151\x6e\x5f\156\157\x6e\143\x65\x22\xd\xa\x9\x9\x9\x9\x76\x61\x6c\x75\x65\75\42";
        echo esc_attr(wp_create_nonce("\x6d\x69\156\x69\x6f\162\x61\x6e\147\x65\x2d\62\x2d\x66\141\143\x74\157\x72\x2d\154\157\147\151\156\55\156\x6f\156\x63\145"));
        echo "\42\x2f\x3e\xd\xa\15\xa\11\x9\11\x3c\151\x6e\160\165\x74\40\x74\171\160\145\x3d\42\150\151\144\144\145\156\x22\x20\x69\144\x3d\42\x73\145\x73\163\x69\x64\42\x20\x6e\141\x6d\x65\75\x22\163\x65\x73\163\151\x6f\x6e\x5f\x69\144\42\xd\12\11\x9\11\x9\166\x61\154\x75\x65\75\42";
        echo esc_attr($Ty);
        echo "\42\x2f\76\15\xa\15\12\11\11\x3c\x2f\x70\76\15\xa\xd\xa\x9\x9\11";
    }
    public function mo2f_pass2login_duo_push_verification($cs, $Z0, $ok, $Ty)
    {
        global $Gw;
        include_once dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . "\x68\x61\156\x64\x6c\145\x72" . DIRECTORY_SEPARATOR . "\x74\167\x6f\146\x61" . DIRECTORY_SEPARATOR . "\x74\167\157\137\x66\x61\137\144\165\157\x5f\x68\141\x6e\x64\154\145\x72\x2e\160\150\x70";
        if (!is_null($Ty)) {
            goto Vs;
        }
        $Ty = $this->create_session();
        Vs:
        $we = '';
        $AP = "\115\117\x5f\62\x5f\x46\x41\103\124\117\x52\x5f\103\x48\101\114\114\x45\116\107\105\x5f\x44\125\x4f\137\x50\x55\123\110\x5f\x4e\x4f\x54\x49\106\x49\103\x41\124\x49\117\x4e\x53";
        $this->miniorange_pass2login_form_fields($AP, $we, $ok, null, $Ty);
    }
    public function mo2fa_pass2login($ok = null, $bJ = null)
    {
        if (empty($this->mo2f_user_id) && empty($this->fstfactor)) {
            goto gG;
        }
        $v1 = $this->mo2f_user_id;
        $W0 = $this->fstfactor;
        goto NJ;
        gG:
        $v1 = MO2f_Utility::mo2f_get_transient($bJ, "\x6d\157\62\146\137\143\x75\162\x72\x65\x6e\164\x5f\165\x73\x65\162\x5f\x69\x64");
        $W0 = MO2f_Utility::mo2f_get_transient($bJ, "\x6d\x6f\62\x66\137\61\x73\164\x66\141\143\164\x6f\162\137\x73\164\141\x74\x75\163");
        NJ:
        if ($v1 && $W0 && "\x56\x41\x4c\111\104\x41\x54\105\x5f\123\125\103\x43\x45\123\123" === $W0) {
            goto d8;
        }
        $this->remove_current_activity($bJ);
        goto of;
        d8:
        $cs = get_user_by("\151\x64", $v1);
        wp_set_current_user($v1, $cs->user_login);
        $KG = new Miniorange_Mobile_Login();
        $KG->remove_current_activity($bJ);
        delete_expired_transients(true);
        delete_site_option($bJ);
        wp_set_auth_cookie($v1, true);
        do_action("\x77\x70\x5f\154\157\x67\151\156", $cs->user_login, $cs);
        redirect_user_to($cs, $ok);
        exit;
        of:
    }
    public function create_session()
    {
        global $Gw;
        $jg = MO2f_Utility::random_str(20);
        $iQ = md5($jg);
        $Gw->insert_user_login_session($iQ);
        $t8 = get_site_option("\x6d\x6f\62\146\x5f\x65\x6e\143\162\x79\x70\x74\151\157\x6e\x5f\153\x65\171");
        $Ty = MO2f_Utility::encrypt_data($jg, $t8);
        return $Ty;
    }
    public function mo2f_redirect_url_for_um($cs)
    {
        MO2f_Utility::mo2f_debug_file("\x55\163\x69\x6e\x67\x20\x55\115\40\154\x6f\x67\x69\156\x20\x66\157\x72\155\56");
        $ok = '';
        if (!(!isset($_POST["\x77\160\55\x73\x75\142\x6d\x69\164"]) && isset($_POST["\x75\x6d\137\162\x65\161\165\x65\163\x74"]))) {
            goto S8;
        }
        $hY = get_site_option("\x75\x6d\137\x72\x6f\154\x65\x5f" . $cs->roles[0] . "\x5f\x6d\145\164\x61");
        if (!(isset($hY) && !empty($hY))) {
            goto nq;
        }
        if (!isset($hY["\137\165\x6d\137\154\x6f\x67\x69\156\x5f\162\x65\144\x69\x72\x65\x63\164\137\165\x72\154"])) {
            goto bC;
        }
        $ok = $hY["\x5f\x75\155\x5f\154\x6f\x67\151\156\x5f\162\x65\144\151\x72\x65\x63\164\137\x75\x72\154"];
        bC:
        if (!empty($ok)) {
            goto KS;
        }
        $ok = get_site_url();
        KS:
        nq:
        $Yi = '';
        if (!isset($_POST["\x72\145\x64\151\x72\145\143\x74\137\x74\x6f"])) {
            goto Tg;
        }
        $Yi = esc_url_raw(wp_unslash($_POST["\x72\145\x64\151\x72\x65\143\x74\x5f\x74\x6f"]));
        Tg:
        if (!(!empty($Yi) && !is_null($Yi))) {
            goto s5;
        }
        $ok = $Yi;
        s5:
        S8:
        return $ok;
    }
    public function mo2fa_select_method($cs, $Z0, $Ty, $ok)
    {
        global $uz, $Gw;
        if (!(MoWpnsConstants::OTP_OVER_EMAIL === $Z0)) {
            goto vE;
        }
        if (!(MoWpnsUtility::get_mo2f_db_option("\143\x6d\126\164\x59\127\x6c\x75\x61\127\65\156\x54\x31\x52\x51", "\x73\151\x74\145\137\x6f\160\x74\x69\157\156") <= 0)) {
            goto GQ;
        }
        update_site_option("\x62\107\x6c\164\141\130\x52\x53\x5a\x57\106\152\141\x47\126\x6b", 1);
        GQ:
        vE:
        $Mn = array(MoWpnsConstants::OUT_OF_BAND_EMAIL => array($this, "\155\x6f\62\146\x5f\160\141\163\x73\62\x6c\157\x67\151\156\137\x70\165\163\150\137\x6f\157\x62\x65\155\x61\x69\154\x5f\x76\145\162\151\146\x69\143\x61\164\151\x6f\156"), MoWpnsConstants::OTP_OVER_SMS => array($this, "\155\x6f\62\x66\137\x70\141\x73\x73\x32\154\x6f\x67\x69\156\x5f\x6f\164\160\x5f\166\x65\162\151\x66\x69\143\141\164\x69\157\156"), MoWpnsConstants::OTP_OVER_EMAIL => array($this, "\x6d\157\x32\x66\x5f\x70\x61\163\163\x32\x6c\157\147\151\156\137\x6f\x74\x70\x5f\166\145\162\151\x66\151\143\x61\164\151\x6f\156"), MoWpnsConstants::OTP_OVER_TELEGRAM => array($this, "\x6d\x6f\62\146\137\x70\x61\x73\163\62\x6c\x6f\147\151\156\x5f\157\x74\160\137\x76\145\162\151\146\151\143\x61\164\151\x6f\x6e"), MoWpnsConstants::GOOGLE_AUTHENTICATOR => array($this, "\x6d\x6f\62\x66\x5f\x70\141\163\163\x32\x6c\x6f\x67\151\x6e\x5f\157\x74\x70\137\x76\x65\x72\x69\146\151\x63\x61\x74\151\157\156"), MoWpnsConstants::SECURITY_QUESTIONS => array($this->mo2f_onprem_cloud_obj, "\x6d\x6f\62\x66\137\x70\141\x73\x73\62\x6c\x6f\147\x69\156\137\x6b\x62\x61\x5f\166\145\162\151\146\151\143\141\x74\151\157\x6e"), MoWpnsConstants::DUO_AUTHENTICATOR => array($this, "\155\x6f\62\x66\137\160\x61\163\x73\62\154\157\147\151\156\137\x64\165\157\x5f\160\165\x73\x68\137\166\145\162\151\x66\151\143\x61\164\x69\x6f\156"));
        if (!empty($Mn[$Z0])) {
            goto n0;
        }
        if ("\x4e\117\116\x45" === $Z0) {
            goto T0;
        }
        $this->remove_current_activity($Ty);
        $jY = new WP_Error();
        if (MO2f_Utility::get_index_value("\107\114\117\102\101\114\123", "\155\x6f\62\x66\x5f\x69\163\137\141\152\x61\x78\137\162\145\161\x75\145\x73\x74")) {
            goto Tc;
        }
        MO2f_Utility::mo2f_debug_file("\124\x77\157\x20\x66\x61\x63\x74\157\x72\40\155\145\164\x68\157\144\40\150\141\163\x20\x6e\157\164\x20\x62\145\145\x6e\40\x63\157\156\146\x69\147\x75\x72\145\144\40\125\x73\145\x72\x5f\x49\120\x2d" . $uz->get_client_ip() . "\40\x55\163\145\x72\137\x49\144\55" . $cs->ID . "\40\x45\x6d\x61\151\154\55" . $cs->user_email);
        $jY->add("\x65\155\x70\x74\171\137\x75\x73\x65\162\156\x61\x6d\145", __("\x3c\163\164\x72\x6f\x6e\x67\76\x45\122\x52\x4f\122\x3c\57\x73\164\x72\157\156\147\x3e\72\40\124\167\157\x20\x46\x61\143\164\x6f\x72\x20\155\x65\x74\150\x6f\144\x20\150\141\x73\x20\156\x6f\164\x20\142\145\145\x6e\40\x63\x6f\x6e\146\151\147\165\162\145\x64\56"));
        return $jY;
        goto gl;
        Tc:
        MO2f_Utility::mo2f_debug_file("\124\167\x6f\x20\146\x61\x63\x74\157\162\40\x6d\x65\x74\150\x6f\x64\x20\150\141\x73\x20\156\x6f\164\x20\x62\145\x65\156\x20\x63\157\156\x66\x69\x67\165\162\145\x64\40\125\163\x65\162\137\x49\120\55" . $uz->get_client_ip() . "\x20\x55\163\x65\x72\137\111\144\55" . $cs->ID . "\40\105\x6d\141\x69\154\x2d" . $cs->user_email);
        $mC = array("\156\157\x74\x69\x63\145" => "\74\x64\151\166\40\x73\164\x79\x6c\x65\75\x22\x62\157\162\x64\x65\x72\55\154\145\x66\164\72\x33\x70\x78\x20\x73\x6f\x6c\151\144\40\x23\x64\143\63\62\x33\x32\x3b\42\x3e\x26\156\142\x73\160\73\40\x54\x77\157\x20\106\141\143\164\157\162\x20\155\x65\x74\x68\157\144\x20\x68\141\163\40\156\x6f\164\x20\142\x65\x65\156\x20\143\x6f\156\146\151\147\165\162\145\144\x2e");
        wp_send_json_success($mC);
        gl:
        goto Fo;
        n0:
        call_user_func($Mn[$Z0], $cs, $Z0, $ok, $Ty);
        goto Fo;
        T0:
        MO2f_Utility::mo2f_debug_file("\155\157\62\x66\x5f\x73\145\x63\x6f\x6e\x64\137\146\x61\143\164\x6f\x72\x20\x69\x73\40\x4e\x4f\116\x45\40\x55\163\x65\x72\x5f\111\x50\55" . $uz->get_client_ip() . "\x20\x55\x73\145\162\137\111\144\x2d" . $cs->ID . "\x20\105\x6d\x61\x69\154\55" . $cs->user_email);
        if (MO2f_Utility::get_index_value("\107\114\x4f\102\x41\x4c\123", "\x6d\157\x32\x66\x5f\x69\163\x5f\x61\x6a\141\x78\x5f\162\145\161\x75\x65\163\x74")) {
            goto AY;
        }
        return $cs;
        goto x3;
        AY:
        $this->mo2fa_pass2login($ok, $Ty);
        x3:
        Fo:
    }
    public function mo2f_validate_soft_token($cs, $Z0, $GC, $Ty, $ok = null)
    {
        global $Gw;
        $fK = $Gw->get_user_detail("\x6d\157\62\x66\x5f\165\163\x65\162\137\x65\155\141\151\154", $cs->ID);
        $hP = json_decode($this->mo2f_onprem_cloud_obj->validate_otp_token($Z0, $fK, null, $GC), true);
        if (strcasecmp($hP["\163\164\141\x74\165\x73"], "\123\x55\103\x43\105\x53\x53") === 0) {
            goto Gv;
        }
        if (MO2f_Utility::get_index_value("\x47\x4c\x4f\x42\101\x4c\x53", "\x6d\157\x32\146\137\x69\x73\137\141\x6a\141\x78\137\x72\145\x71\x75\145\x73\164")) {
            goto Uq;
        }
        return new WP_Error("\151\156\x76\141\154\151\144\x5f\x6f\156\x65\137\164\x69\155\x65\x5f\x70\x61\x73\163\143\157\x64\x65", "\74\163\164\162\157\x6e\x67\76\x45\122\x52\x4f\122\x3c\x2f\163\x74\x72\157\x6e\x67\76\x3a\x20\x49\156\x76\141\x6c\151\x64\40\x4f\x6e\145\40\x54\151\x6d\x65\40\120\x61\x73\x73\x63\x6f\x64\x65\56");
        goto NM;
        Uq:
        $mC = array("\x6e\x6f\x74\x69\x63\x65" => "\x3c\144\151\166\x20\x73\x74\171\x6c\x65\x3d\x22\x62\x6f\162\144\x65\x72\55\154\x65\x66\x74\x3a\63\x70\170\x20\x73\x6f\x6c\x69\144\40\x23\x64\143\x33\62\x33\x32\x3b\42\76\x26\156\x62\163\x70\73\x20\x49\x6e\166\x61\x6c\x69\144\40\x4f\x6e\145\x20\x54\x69\x6d\145\40\120\x61\x73\x73\x63\x6f\144\x65\56");
        wp_send_json_success($mC);
        NM:
        goto gJ;
        Gv:
        $this->mo2fa_pass2login($ok, $Ty);
        gJ:
    }
    public function mo2f_otp_over_email_send($fK, $ok, $Ty, $current_user)
    {
        $bC = array();
        if (get_site_option("\x63\x6d\126\x74\x59\127\154\165\141\x57\65\x6e\124\x31\x52\121") > 0) {
            goto AO;
        }
        $bC["\163\164\141\164\x75\163"] = "\x46\101\x49\x4c\105\x44";
        goto y4;
        AO:
        $hP = $this->mo2f_onprem_cloud_obj->send_otp_token(null, $fK, MoWpnsConstants::OTP_OVER_EMAIL, $current_user);
        $bC = json_decode($hP, true);
        if (MO2F_IS_ONPREM) {
            goto Lx;
        }
        if (!isset($bC["\164\x78\111\x64"])) {
            goto CH;
        }
        MO2f_Utility::mo2f_set_transient($Ty, "\x6d\x6f\62\x66\137\164\162\x61\x6e\x73\141\x63\x74\151\x6f\156\111\x64", $bC["\164\170\x49\x64"]);
        CH:
        Lx:
        y4:
        if (!(json_last_error() === JSON_ERROR_NONE)) {
            goto Tu;
        }
        if ("\x53\x55\103\x43\105\123\x53" === $bC["\163\x74\141\x74\165\163"]) {
            goto Vm;
        }
        $AP = "\x4d\x4f\x5f\x32\137\106\x41\103\124\x4f\x52\137\120\x52\x4f\115\120\124\x5f\x55\123\105\x52\x5f\x46\x4f\x52\137\62\106\x41\137\x4d\105\124\x48\x4f\104\123";
        $we = user_can($current_user->ID, "\141\x64\155\151\x6e\x69\163\164\x72\x61\x74\x6f\x72") ? MoWpnsMessages::ERROR_DURING_PROCESS_EMAIL : MoWpnsMessages::ERROR_DURING_PROCESS;
        $this->miniorange_pass2login_form_fields($AP, $we, $ok, null, $Ty, 1);
        goto wy;
        Vm:
        $Bj = get_site_option("\143\x6d\126\x74\x59\x57\x6c\x75\141\127\65\x6e\x54\x31\x52\121");
        if (!($Bj > 0)) {
            goto Og;
        }
        update_site_option("\143\x6d\x56\x74\x59\x57\x6c\x75\x61\127\x35\156\124\61\x52\x51", $Bj - 1);
        Og:
        $we = "\x41\x6e\x20\117\x54\120\40\150\141\x73\40\142\x65\145\x6e\x20\x73\145\x6e\x74\x20\164\x6f\x20" . MO2f_Utility::mo2f_get_hidden_email($fK) . "\56\40\120\154\x65\x61\x73\x65\x20\166\x65\162\151\x66\171\x20\x74\157\x20\x73\145\164\x20\x74\150\145\40\164\x77\157\x2d\146\x61\x63\164\x6f\162";
        $AP = MoWpnsConstants::MO_2_FACTOR_CHALLENGE_OTP_OVER_EMAIL;
        $vj = isset($bC["\164\x78\x49\144"]) ? $bC["\x74\x78\x49\144"] : null;
        $this->miniorange_pass2login_form_fields($AP, $we, $ok, null, $Ty, 1, $vj);
        wy:
        Tu:
    }
    public function mo2f_get_redirect_url()
    {
        if (isset($_REQUEST["\x77\157\157\143\x6f\155\155\145\x72\143\x65\x2d\x6c\x6f\147\x69\156\x2d\156\x6f\x6e\143\x65"])) {
            goto zh;
        }
        if (get_site_option("\155\157\x32\x66\137\145\156\x61\x62\154\145\137\x63\165\163\x74\157\x6d\x5f\162\145\144\x69\x72\x65\143\164")) {
            goto SC;
        }
        $ok = isset($_REQUEST["\162\x65\144\x69\x72\145\x63\x74\137\x74\157"]) ? sanitize_text_field(wp_unslash($_REQUEST["\x72\x65\144\151\162\x65\x63\164\x5f\x74\157"])) : (isset($_REQUEST["\x72\145\144\x69\x72\x65\x63\164"]) ? sanitize_text_field(wp_unslash($_REQUEST["\x72\x65\x64\x69\x72\x65\143\164"])) : '');
        goto eO;
        zh:
        MO2f_Utility::mo2f_debug_file("\111\x74\40\151\x73\x20\x61\40\167\x6f\157\x63\x6f\x6d\155\145\x72\x63\x65\40\154\157\x67\x69\x6e\x20\146\x6f\162\x6d\x2e\x20\107\x65\164\40\167\157\x6f\143\x6f\155\x6d\x65\x72\143\145\x20\x72\145\144\151\x72\x65\143\164\125\162\x6c");
        if (!empty($_REQUEST["\x72\x65\144\x69\162\145\x63\164\137\164\x6f"])) {
            goto Rb;
        }
        if (isset($_REQUEST["\137\x77\x70\137\150\x74\164\160\x5f\x72\x65\x66\145\162\145\162"])) {
            goto UU;
        }
        if (!function_exists("\167\x63\x5f\x67\x65\x74\137\160\x61\x67\x65\x5f\160\145\162\x6d\x61\154\151\x6e\153")) {
            goto aw;
        }
        $ok = wc_get_page_permalink("\x6d\x79\141\143\x63\157\165\x6e\x74");
        aw:
        goto Ic;
        Rb:
        $ok = sanitize_text_field(wp_unslash($_REQUEST["\x72\145\144\x69\x72\x65\143\164\x5f\164\157"]));
        goto Ic;
        UU:
        $ok = sanitize_text_field(wp_unslash($_REQUEST["\x5f\x77\x70\x5f\150\164\x74\160\x5f\x72\x65\x66\145\162\145\x72"]));
        Ic:
        goto eO;
        SC:
        $ok = get_site_option("\155\x6f\62\146\x5f\x63\165\163\164\157\155\x5f\162\x65\144\x69\x72\x65\143\x74\137\165\x72\154");
        eO:
        return esc_url_raw($ok);
    }
    public function mo_2_factor_enable_jquery_default_login()
    {
        wp_enqueue_script("\x6a\161\165\x65\x72\171");
    }
    public function mo2fa_update_user_details($v1, $eX, $ix, $Yx, $KW, $p4, $fK = null, $T7 = null)
    {
        global $Gw;
        $AC = array();
        $Rb = array("\155\157\x32\x66\137" . implode('', explode("\x20", MoWpnsConstants::mo2f_convert_method_name($ix, "\143\141\x70\x5f\x74\157\137\163\x6d\141\x6c\x6c"))) . "\137\x63\157\156\x66\151\x67\137\x73\x74\x61\164\165\x73" => $eX, "\155\157\x32\x66\137\143\x6f\156\146\x69\147\x75\x72\145\144\x5f\62\106\x41\x5f\x6d\145\164\150\157\144" => $ix, "\x75\x73\x65\162\137\x72\145\147\151\163\164\162\141\x74\151\157\x6e\x5f\x77\x69\164\150\137\x6d\x69\x6e\151\x6f\162\x61\156\147\145" => $Yx, "\155\x6f\x5f\x32\146\x61\143\x74\157\162\x5f\165\163\145\162\x5f\162\x65\x67\x69\x73\164\x72\141\164\151\x6f\156\137\163\164\x61\164\x75\163" => $KW, "\155\x6f\x32\x66\x5f\x32\146\x61\143\x74\x6f\x72\x5f\x65\156\x61\142\154\145\137\62\x66\x61\x5f\142\x79\165\163\145\162\x73" => $p4, "\155\x6f\62\x66\x5f\x75\x73\145\162\137\x65\x6d\x61\151\x6c" => $fK, "\155\x6f\x32\146\137\x75\x73\x65\162\x5f\160\150\x6f\156\x65" => $T7);
        foreach ($Rb as $t8 => $iY) {
            if (!isset($iY)) {
                goto mH;
            }
            $AC = array_merge($AC, array($t8 => $iY));
            mH:
            kb:
        }
        ZE:
        delete_user_meta($v1, "\155\x6f\x32\x66\x5f\x67\x72\x61\143\x65\137\160\x65\162\151\x6f\x64\137\163\x74\x61\x72\x74\137\x74\151\155\145");
        $Gw->update_user_details($v1, $AC);
    }
}
new Miniorange_Password_2Factor_Login();
W4:
