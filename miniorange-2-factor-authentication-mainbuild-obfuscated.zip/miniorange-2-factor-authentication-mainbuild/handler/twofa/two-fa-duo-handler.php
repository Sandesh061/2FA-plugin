<?php


if (defined("\x41\102\123\x50\x41\124\x48")) {
    goto Jm;
}
exit;
Jm:
const INITIAL_BACKOFF_SECONDS = 1;
const MAX_BACKOFF_SECONDS = 32;
const BACKOFF_FACTOR = 2;
const RATE_LIMIT_HTTP_CODE = 429;
function ping($dU, $OG, $ax)
{
    $la = "\x47\105\x54";
    $ZH = "\x2f\141\165\x74\x68\x2f\x76\62\x2f\160\151\156\147";
    $LM = array();
    return json_api_call($la, $ZH, $LM, $dU, $OG, $ax);
}
function check($dU, $OG, $ax)
{
    $la = "\x47\x45\x54";
    $ZH = "\57\141\165\x74\150\57\166\x32\57\143\150\x65\143\153";
    $LM = array();
    return json_api_call($la, $ZH, $LM, $dU, $OG, $ax);
}
function delete($dU, $OG, $ax, $v1)
{
    $la = "\104\105\x4c\105\x54\x45";
    $ZH = "\57\x61\x64\155\151\x6e\57\166\x31\x2f\x75\163\x65\x72\163\x2f" . $v1;
    $LM = array();
    return json_api_call($la, $ZH, $LM, $dU, $OG, $ax);
}
function enroll($Zi = null, $MF = null)
{
    $OG = get_site_option("\x6d\x6f\x32\x66\x5f\x64\x5f\151\156\164\145\147\162\141\164\151\x6f\x6e\x5f\153\145\171");
    $dU = get_site_option("\x6d\x6f\x32\146\x5f\144\137\163\x65\x63\x72\x65\164\x5f\153\x65\171");
    $ax = get_site_option("\x6d\x6f\x32\146\137\144\137\x61\160\151\x5f\150\157\x73\x74\156\141\155\145");
    assert(is_string($Zi) || is_null($Zi));
    assert(is_int($MF) || is_null($MF));
    $la = "\120\117\123\124";
    $ZH = "\x2f\x61\165\x74\150\x2f\166\62\57\x65\x6e\162\157\x6c\154";
    $LM = array();
    if (!$Zi) {
        goto Ae;
    }
    $LM["\x75\163\x65\162\x6e\x61\155\x65"] = $Zi;
    Ae:
    if (!$MF) {
        goto p4;
    }
    $LM["\x76\141\154\x69\144\x5f\163\x65\x63\x73"] = $MF;
    p4:
    return json_api_call($la, $ZH, $LM, $dU, $OG, $ax);
}
function enroll_status($v1, $TF, $dU, $OG, $ax)
{
    assert(is_string($v1));
    assert(is_string($TF));
    $la = "\x50\117\123\x54";
    $ZH = "\57\x61\165\164\150\57\166\62\x2f\x65\156\x72\157\154\154\137\x73\x74\x61\164\165\163";
    $LM = array("\x75\163\x65\162\137\151\144" => $v1, "\141\x63\x74\151\166\141\x74\x69\157\x6e\x5f\x63\x6f\144\x65" => $TF);
    return json_api_call($la, $ZH, $LM, $dU, $OG, $ax);
}
function preauth($FG, $Zi, $dU, $OG, $ax, $zb = null, $V2 = null)
{
    assert(is_string($zb) || is_null($zb));
    assert(is_string($V2) || is_null($V2));
    $la = "\120\x4f\123\x54";
    $ZH = "\x2f\141\x75\x74\150\x2f\x76\x32\57\160\162\145\x61\165\x74\150";
    $LM = array();
    if ($Zi) {
        goto qo;
    }
    $LM["\x75\x73\145\162\137\151\144"] = $FG;
    goto fb;
    qo:
    $LM["\165\163\x65\x72\x6e\141\x6d\x65"] = $FG;
    fb:
    if (!$zb) {
        goto E4;
    }
    $LM["\151\160\x61\144\144\x72"] = $zb;
    E4:
    if (!$V2) {
        goto KC;
    }
    $LM["\164\162\165\163\164\145\x64\x5f\144\145\x76\x69\x63\x65\137\x74\x6f\153\145\x6e"] = $V2;
    KC:
    return json_api_call($la, $ZH, $LM, $dU, $OG, $ax);
}
function mo2f_duo_auth($FG, $eP, $Lw, $dU, $OG, $ax, $Zi = true, $zb = null, $c4 = false, $bn = 60)
{
    assert(is_string($FG));
    assert(is_string($eP) && in_array($eP, array("\141\x75\164\x6f", "\160\165\x73\x68", "\160\141\x73\x73\x63\x6f\144\145", "\163\x6d\163", "\x70\150\x6f\x6e\x65"), true));
    assert(is_array($Lw));
    assert(is_string($zb) || is_null($zb));
    assert(is_bool($c4));
    assert(is_bool($Zi));
    $la = "\x50\117\x53\x54";
    $ZH = "\57\141\165\x74\x68\x2f\166\x32\57\141\165\164\150";
    $LM = array();
    if ($Zi) {
        goto z2;
    }
    $LM["\165\163\145\162\137\x69\x64"] = $FG;
    goto q2;
    z2:
    $LM["\165\163\x65\x72\x6e\x61\155\x65"] = $FG;
    q2:
    if (!$zb) {
        goto P_;
    }
    $LM["\x69\x70\141\144\144\x72"] = $zb;
    P_:
    if (!$c4) {
        goto Rh;
    }
    $LM["\x61\x73\171\x6e\143"] = "\61";
    Rh:
    $LM["\x66\x61\143\x74\x6f\x72"] = $eP;
    if ("\x70\165\x73\x68" === $eP) {
        goto M5;
    }
    if ("\160\x61\163\x73\143\x6f\x64\145" === $eP) {
        goto T2;
    }
    if ("\x70\150\x6f\x6e\145" === $eP) {
        goto WT;
    }
    if ("\163\x6d\x73" === $eP) {
        goto Cr;
    }
    if ("\x61\165\x74\157" === $eP) {
        goto UP;
    }
    goto ep;
    M5:
    assert(array_key_exists("\x64\145\166\151\143\x65", $Lw) && is_string($Lw["\144\x65\x76\151\143\x65"]));
    $LM["\x64\x65\x76\x69\143\x65"] = $Lw["\144\x65\x76\x69\143\x65"];
    if (!array_key_exists("\164\x79\160\145", $Lw)) {
        goto LL;
    }
    $LM["\164\x79\x70\145"] = $Lw["\x74\171\160\x65"];
    LL:
    if (!array_key_exists("\144\151\x73\160\154\141\x79\137\165\163\x65\x72\x6e\x61\x6d\x65", $Lw)) {
        goto MU;
    }
    $LM["\x64\151\x73\160\154\141\x79\137\x75\163\x65\x72\156\x61\155\145"] = $Lw["\x64\151\163\x70\x6c\x61\171\137\165\x73\x65\162\156\x61\x6d\x65"];
    MU:
    if (!array_key_exists("\160\x75\x73\150\151\x6e\146\x6f", $Lw)) {
        goto OH;
    }
    $LM["\x70\x75\x73\x68\151\156\146\x6f"] = $Lw["\x70\x75\x73\x68\x69\x6e\146\157"];
    OH:
    goto ep;
    T2:
    assert(array_key_exists("\x70\141\163\x73\143\x6f\144\145", $Lw) && is_string($Lw["\x70\141\x73\163\143\157\x64\145"]));
    $LM["\160\141\x73\163\x63\157\x64\145"] = $Lw["\160\x61\x73\163\143\157\144\x65"];
    goto ep;
    WT:
    assert(array_key_exists("\144\145\166\151\x63\145", $Lw) && is_string($Lw["\x64\x65\x76\151\x63\145"]));
    $LM["\x64\145\166\151\143\x65"] = $Lw["\144\x65\x76\151\x63\145"];
    goto ep;
    Cr:
    assert(array_key_exists("\144\x65\x76\x69\x63\x65", $Lw) && is_string($Lw["\x64\x65\x76\151\x63\x65"]));
    $LM["\x64\145\166\x69\x63\x65"] = $Lw["\x64\x65\x76\151\143\145"];
    goto ep;
    UP:
    assert(array_key_exists("\144\x65\x76\151\x63\x65", $Lw) && is_string($Lw["\144\145\x76\151\x63\x65"]));
    $LM["\144\145\166\151\x63\x65"] = $Lw["\x64\x65\x76\x69\x63\x65"];
    ep:
    $PF = array("\164\151\155\145\x6f\x75\164" => $bn);
    $dq = array_key_exists("\x74\151\155\145\157\165\x74", $PF) ? $PF["\x74\x69\x6d\145\157\165\x74"] : null;
    if (!(!$dq || $dq < $bn)) {
        goto Zk;
    }
    set_requester_option("\164\x69\x6d\145\x6f\165\x74", $bn);
    Zk:
    try {
        $vv = json_api_call($la, $ZH, $LM, $dU, $OG, $ax);
    } finally {
        if ($dq) {
            goto uf;
        }
        unset($PF["\164\x69\x6d\x65\x6f\165\x74"]);
        goto yn;
        uf:
        set_requester_option("\x74\x69\x6d\x65\157\165\x74", $dq);
        yn:
    }
    return $vv;
}
function set_requester_option($Xh, $iY)
{
    $PF[$Xh] = $iY;
    return $PF;
}
function mo2f_sleep($Qt)
{
    usleep($Qt * 1000000);
}
function execute($xz, $la, $Tp, $zI = null)
{
    assert(is_string($xz));
    assert(is_string($la));
    assert(is_array($Tp));
    assert(is_string($zI) || is_null($zI));
    $Tp = array_map(function ($t8, $iY) {
        return sprintf("\x25\163\x3a\40\x25\163", $t8, $iY);
    }, array_keys($Tp), array_values($Tp));
    $as = array("\155\145\164\x68\157\144" => $la, "\164\151\x6d\x65\157\165\164" => "\x35", "\162\145\x64\x69\162\x65\x63\164\151\157\x6e" => "\65", "\150\x74\164\x70\x76\145\x72\163\151\x6f\x6e" => "\x31\x2e\x30", "\x62\x6c\157\143\x6b\151\156\x67" => true, "\150\x65\141\144\145\x72\x73" => $Tp);
    if (!("\x50\x4f\x53\x54" === $la)) {
        goto Cv;
    }
    $as["\x62\x6f\144\171"] = $zI;
    Cv:
    $vv = wp_remote_post($xz, $as);
    if (!is_wp_error($vv)) {
        goto MR;
    }
    return array("\162\145\x73\160\x6f\x6e\x73\145" => '', "\x73\x75\x63\143\145\163\x73" => '', "\x68\164\164\160\x5f\x73\164\141\164\165\x73\x5f\x63\x6f\144\x65" => '');
    MR:
    $l_ = wp_remote_retrieve_response_code($vv);
    $pB = null;
    $PW = true;
    if (false === $vv) {
        goto Oa;
    }
    $pB = isset($l_) ? $l_ : "\x34\x30\x34";
    goto K0;
    Oa:
    $vv = wp_json_encode(array("\x73\x74\141\164" => "\106\101\x49\114"));
    $PW = false;
    K0:
    return array("\x72\x65\x73\160\x6f\156\163\x65" => $vv["\142\x6f\144\171"], "\163\x75\143\x63\x65\163\163" => $PW, "\x68\x74\x74\160\x5f\163\x74\141\164\x75\163\137\x63\157\x64\145" => $pB);
}
function json_api_call($la, $z_, $LM, $dU, $OG, $ax)
{
    assert(is_string($la));
    assert(is_string($z_));
    assert(is_array($LM));
    $vv = api_call($la, $z_, $LM, $dU, $OG, $ax);
    $vv["\x72\145\163\160\x6f\156\x73\145"] = json_decode($vv["\162\x65\x73\160\157\156\163\x65"], true);
    return $vv;
}
function url_encode_parameters($LM)
{
    assert(is_array($LM));
    ksort($LM);
    $as = array_map(function ($t8, $iY) {
        return sprintf("\x25\x73\75\45\x73", rawurlencode($t8), rawurlencode($iY));
    }, array_keys($LM), array_values($LM));
    return implode("\x26", $as);
}
function canonicalize($la, $ax, $z_, $LM, $Wj)
{
    assert(is_string($la));
    assert(is_string($ax));
    assert(is_string($z_));
    assert(is_array($LM));
    assert(is_string($Wj));
    $as = url_encode_parameters($LM);
    $Gk = array($Wj, strtoupper($la), strtolower($ax), $z_, $as);
    $Gk = implode("\12", $Gk);
    return $Gk;
}
function sign($xM, $t8)
{
    assert(is_string($xM));
    assert(is_string($t8));
    return hash_hmac("\x73\x68\x61\61", $xM, $t8);
}
function sign_parameters($la, $ax, $z_, $LM, $dU, $OG, $Wj)
{
    assert(is_string($la));
    assert(is_string($ax));
    assert(is_string($z_));
    assert(is_array($LM));
    assert(is_string($dU));
    assert(is_string($OG));
    assert(is_string($Wj));
    $Gk = canonicalize($la, $ax, $z_, $LM, $Wj);
    $Y9 = sign($Gk, $dU);
    $wX = sprintf("\45\163\72\45\163", $OG, $Y9);
    $mW = base64_encode($wX);
    return sprintf("\x42\141\163\x69\x63\x20\x25\163", $mW);
}
function make_request($la, $yj, $zI, $Tp, $ax)
{
    assert(is_string($la));
    assert(is_string($yj));
    assert(is_string($zI) || is_null($zI));
    assert(is_array($Tp));
    $xz = "\x68\164\164\x70\x73\72\57\57" . $ax . $yj;
    $sG = INITIAL_BACKOFF_SECONDS;
    bp:
    if (!true) {
        goto Q1;
    }
    $vv = execute($xz, $la, $Tp, $zI);
    if (!(RATE_LIMIT_HTTP_CODE !== $vv["\x68\164\x74\x70\137\x73\x74\141\164\165\x73\137\143\157\144\x65"] || $sG > MAX_BACKOFF_SECONDS)) {
        goto On;
    }
    return $vv;
    On:
    mo2f_sleep($sG + wp_rand(0, 1000) / 1000.0);
    $sG *= BACKOFF_FACTOR;
    goto bp;
    Q1:
}
function api_call($la, $z_, $LM, $dU, $OG, $ax)
{
    assert(is_string($la));
    assert(is_string($z_));
    assert(is_array($LM));
    $Wj = gmdate(DateTime::RFC2822);
    $Tp = array();
    $Tp["\x44\141\x74\145"] = $Wj;
    $Tp["\110\x6f\x73\164"] = $ax;
    $Tp["\x41\x75\164\x68\157\162\151\172\141\164\151\157\156"] = sign_parameters($la, $ax, $z_, $LM, $dU, $OG, $Wj);
    if (in_array($la, array("\x50\x4f\x53\x54", "\120\x55\x54"), true)) {
        goto fh;
    }
    $zI = null;
    $yj = $z_ . (!empty($LM) ? "\x3f" . url_encode_parameters($LM) : '');
    goto Qm;
    fh:
    $zI = http_build_query($LM);
    $Tp["\x43\x6f\156\164\x65\x6e\164\x2d\124\x79\160\x65"] = "\141\160\x70\x6c\151\x63\x61\x74\151\157\x6e\57\170\x2d\x77\167\x77\x2d\146\x6f\x72\155\55\x75\x72\154\145\x6e\143\157\x64\x65\x64";
    $Tp["\103\157\x6e\164\145\x6e\164\55\114\145\x6e\x67\x74\x68"] = strval(strlen($zI));
    $yj = $z_;
    Qm:
    return make_request($la, $yj, $zI, $Tp, $ax);
}
