<?php


use TwoFA\Handler\TwoFACustomRegFormAPI;
use TwoFA\Helper\MoWpnsMessages;
if (defined("\101\102\123\x50\x41\x54\110")) {
    goto n8;
}
exit;
n8:
require_once "\143\x6c\x61\x73\163\55\164\167\157\x66\x61\x63\x75\x73\x74\157\x6d\162\145\x67\146\157\162\x6d\x61\x70\x69\56\160\x68\160";
if (class_exists("\x54\x77\157\x46\x41\x43\x75\x73\164\x6f\155\122\x65\x67\x46\x6f\162\155\x53\150\157\x72\x74\143\157\144\x65")) {
    goto oF;
}
class TwoFACustomRegFormShortcode
{
    public function __construct()
    {
        if (!get_site_option("\155\157\x32\x66\x5f\x65\x6e\141\x62\x6c\145\x5f\x66\157\x72\x6d\137\163\150\157\162\x74\143\x6f\x64\x65")) {
            goto en;
        }
        add_action("\167\x6f\157\x63\x6f\x6d\x6d\145\x72\143\x65\x5f\143\162\145\141\164\145\x64\x5f\143\x75\x73\164\x6f\155\145\x72", array($this, "\x77\x63\x5f\x70\x6f\x73\164\137\x72\145\147\x69\163\164\162\141\164\x69\x6f\156"), 1, 3);
        en:
    }
    public function mo_enqueue_shortcode()
    {
        add_action("\167\x70\137\141\152\x61\x78\137\155\157\x5f\163\150\x6f\x72\x74\143\x6f\x64\x65", array($this, "\x6d\157\x5f\x73\x68\x6f\x72\x74\x63\157\144\145"));
        add_action("\167\160\137\141\152\141\x78\x5f\x6e\157\x70\x72\151\166\137\x6d\157\137\163\150\x6f\162\x74\x63\x6f\144\x65", array($this, "\x6d\x6f\137\163\150\157\x72\x74\143\x6f\x64\x65"));
        add_action("\167\x70\x5f\141\152\x61\x78\137\155\157\x5f\x61\x6a\x61\x78\x5f\x72\x65\147\x69\163\x74\x65\162", array($this, "\155\x6f\x5f\141\x6a\x61\170\x5f\162\145\147\151\x73\x74\x65\162"));
        add_action("\167\x70\137\141\x6a\141\x78\x5f\x6e\x6f\x70\162\151\x76\x5f\x6d\157\137\x61\x6a\x61\170\x5f\162\145\x67\x69\163\164\x65\x72", array($this, "\155\x6f\x5f\141\x6a\x61\x78\x5f\x72\145\x67\151\x73\x74\145\162"));
    }
    public function mo_shortcode()
    {
        $pd = new MoWpnsMessages();
        $dk = isset($_POST["\156\157\156\143\145"]) ? sanitize_text_field(wp_unslash($_POST["\156\x6f\156\x63\145"])) : '';
        if (wp_verify_nonce($dk, "\x61\x6a\x61\x78\x2d\156\157\x6e\x63\145")) {
            goto eB;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\x45\x52\122\117\122");
        eB:
        $iO = isset($_POST["\155\x6f\137\x61\143\164\x69\x6f\x6e"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\157\137\141\143\164\x69\157\156"])) : '';
        switch ($iO) {
            case "\x63\150\141\154\154\x65\x6e\x67\x65":
                $fK = isset($_POST["\145\155\141\151\x6c"]) ? sanitize_email(wp_unslash($_POST["\145\x6d\141\x69\154"])) : '';
                $T7 = isset($_POST["\160\x68\157\x6e\x65"]) ? sanitize_text_field(wp_unslash($_POST["\160\x68\x6f\x6e\145"])) : '';
                $GV = isset($_POST["\x61\x75\x74\x68\x54\171\x70\x65\x53\x65\x6e\144"]) ? sanitize_text_field(wp_unslash($_POST["\141\x75\164\150\x54\x79\x70\x65\123\x65\x6e\144"])) : '';
                TwoFACustomRegFormAPI::challenge($T7, $fK, $GV);
                goto h0;
            case "\166\x61\154\151\x64\x61\x74\x65":
                $DF = isset($_POST["\157\x74\160"]) ? sanitize_text_field(wp_unslash($_POST["\x6f\164\160"])) : '';
                $e9 = isset($_POST["\x74\x78\111\144"]) ? sanitize_key($_POST["\x74\170\x49\x64"]) : '';
                $dX = isset($_POST["\141\165\x74\150\x54\171\x70\x65"]) ? sanitize_text_field(wp_unslash($_POST["\141\165\164\150\x54\171\160\x65"])) : '';
                TwoFACustomRegFormAPI::validate($dX, $e9, $DF);
                goto h0;
        }
        j0:
        h0:
    }
    public function mo_ajax_register()
    {
        $pd = new MoWpnsMessages();
        $dk = isset($_POST["\156\x6f\156\x63\145"]) ? sanitize_text_field(wp_unslash($_POST["\x6e\x6f\x6e\143\145"])) : '';
        if (wp_verify_nonce($dk, "\x61\152\x61\x78\x2d\x6e\x6f\156\x63\x65")) {
            goto nM;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\122\x52\117\122");
        nM:
        $iO = isset($_POST["\x6d\x6f\137\x61\x63\164\151\x6f\x6e"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\157\x5f\x61\143\164\x69\x6f\x6e"])) : '';
        switch ($iO) {
            case "\163\x65\x6e\x64\137\x6f\x74\x70\137\157\166\x65\x72\x5f\145\155\x61\x69\154":
                $fK = isset($_POST["\x65\x6d\141\151\154"]) ? sanitize_email(wp_unslash($_POST["\145\x6d\x61\x69\154"])) : '';
                $T7 = isset($_POST["\x70\150\x6f\156\145"]) ? sanitize_text_field(wp_unslash($_POST["\x70\150\x6f\156\145"])) : '';
                $GV = isset($_POST["\141\165\164\150\124\x79\160\145\123\145\156\x64"]) ? sanitize_text_field(wp_unslash($_POST["\141\x75\164\x68\x54\171\x70\x65\123\145\156\144"])) : '';
                TwoFACustomRegFormAPI::challenge($T7, $fK, $GV);
                goto bb;
            case "\x73\145\156\144\x5f\x6f\x74\x70\x5f\x6f\x76\145\x72\x5f\x73\155\163":
                $fK = isset($_POST["\145\x6d\x61\x69\x6c"]) ? sanitize_email(wp_unslash($_POST["\x65\155\141\151\154"])) : '';
                $T7 = isset($_POST["\x70\150\x6f\x6e\145"]) ? sanitize_text_field(wp_unslash($_POST["\160\150\157\x6e\x65"])) : '';
                $GV = sanitize_text_field(wp_unslash($_POST["\141\165\x74\150\x54\x79\x70\x65\123\x65\156\x64"]));
                TwoFACustomRegFormAPI::challenge($T7, $fK, $GV);
                goto bb;
            default:
                $DF = isset($_POST["\157\164\160"]) ? sanitize_text_field(wp_unslash($_POST["\x6f\164\x70"])) : '';
                $e9 = isset($_POST["\164\x78\x69\x64"]) ? sanitize_key($_POST["\164\x78\151\144"]) : '';
                $dX = isset($_POST["\141\165\164\150\124\171\x70\x65"]) ? sanitize_text_field(wp_unslash($_POST["\x61\165\164\150\x54\x79\x70\x65"])) : '';
                TwoFACustomRegFormAPI::validate($dX, $e9, $DF);
                goto bb;
        }
        a5:
        bb:
    }
    public function wc_post_registration($v1, $AI, $Jn)
    {
        $pd = new MoWpnsMessages();
        $dk = isset($_POST["\x6e\x6f\x6e\x63\145"]) ? sanitize_text_field(wp_unslash($_POST["\x6e\x6f\156\143\145"])) : '';
        if (wp_verify_nonce($dk, "\141\152\141\x78\55\x6e\157\156\143\x65")) {
            goto I2;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\122\x52\117\122");
        I2:
        if (!isset($_POST["\160\x68\x6f\156\x65"])) {
            goto EK;
        }
        update_user_meta($v1, "\142\x69\154\x6c\151\156\x67\x5f\x70\150\157\156\x65", sanitize_text_field(wp_unslash($_POST["\160\150\x6f\x6e\145"])));
        EK:
    }
}
oF:
