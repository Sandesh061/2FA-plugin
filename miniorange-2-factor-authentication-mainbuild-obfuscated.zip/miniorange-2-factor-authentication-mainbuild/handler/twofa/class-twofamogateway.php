<?php


namespace TwoFA\Handler;

use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Onprem\MO2f_Cloud_Onprem_Interface;
use TwoFA\Helper\TwoFAMoSessions;
use TwoFA\Helper\MoWpnsConstants;
if (defined("\101\x42\123\120\101\x54\x48")) {
    goto gj;
}
exit;
gj:
global $V0;
require_once $V0 . "\150\145\154\x70\x65\x72" . DIRECTORY_SEPARATOR . "\x63\x6c\x61\163\x73\x2d\164\167\157\146\x61\155\x6f\163\145\x73\x73\x69\157\x6e\x73\x2e\160\x68\x70";
if (defined("\x41\x42\x53\120\x41\x54\x48")) {
    goto jm;
}
exit;
jm:
define("\x4d\117\x32\x46\x5f\x44\x45\106\x41\x55\x4c\x54\137\x41\x50\111\113\105\131", "\x66\106\144\62\x58\x63\x76\x54\x47\x44\x65\x6d\x5a\166\142\x77\x31\x62\x63\125\x65\x73\116\x4a\x57\105\161\x4b\142\142\x55\161");
define("\x4d\x4f\62\106\x5f\x46\101\x49\x4c\x5f\115\117\x44\105", false);
define("\x4d\x4f\x32\106\x5f\123\x45\x53\123\111\x4f\116\x5f\124\x59\120\105", "\x54\122\x41\116\123\x49\105\116\x54");
if (class_exists("\x54\x77\157\x46\x41\x4d\117\x47\141\x74\x65\x77\x61\171")) {
    goto Ie;
}
class TwoFAMOGateway
{
    public static function mo_send_otp_token($dX, $T7, $fK)
    {
        if (MO2F_TEST_MODE) {
            goto ls;
        }
        $hS = get_site_option("\x6d\x6f\62\x66\x5f\143\x75\163\164\157\155\x65\162\x4b\x65\x79");
        $Yl = get_site_option("\x6d\157\62\x66\x5f\141\x70\x69\137\x6b\145\171");
        TwoFAMoSessions::add_session_var("\155\157\62\146\x5f\164\162\141\x6e\x73\x61\143\164\x69\x6f\156\x49\144", true);
        TwoFAMoSessions::add_session_var("\163\145\x6e\x74\137\157\156", time());
        if (MoWpnsConstants::OTP_OVER_EMAIL === $dX) {
            goto Jc;
        }
        $ra = get_site_option("\143\x6d\x56\x74\x59\x57\x6c\165\141\x57\x35\x6e\124\x31\x52\x51\126\x48\112\150\142\156\116\x68\131\63\122\160\142\62\65\x7a");
        if (!($ra > 0)) {
            goto S6;
        }
        update_site_option("\143\155\x56\164\x59\x57\x6c\x75\x61\x57\65\x6e\124\61\x52\x51\x56\110\x4a\x68\142\156\x4e\x68\131\x33\x52\160\142\62\x35\x7a", $ra - 1);
        S6:
        $hP = (new MO2f_Cloud_Onprem_Interface())->send_otp_token($T7, null, $dX, null);
        goto ml;
        Jc:
        $Bj = MoWpnsUtility::get_mo2f_db_option("\143\155\126\x74\x59\x57\154\x75\141\x57\65\156\124\x31\x52\x51", "\163\x69\164\145\137\157\160\x74\x69\157\156");
        if (!($Bj > 0)) {
            goto pP;
        }
        update_site_option("\143\x6d\126\164\131\127\x6c\x75\x61\x57\x35\x6e\124\x31\122\121", $Bj - 1);
        pP:
        $hP = (new MO2f_Cloud_Onprem_Interface())->send_otp_token(null, $fK, $dX, null);
        ml:
        return json_decode($hP, true);
        goto IO;
        ls:
        return array("\155\x65\x73\x73\x61\x67\x65" => "\117\124\x50\40\x53\145\156\x74\x20\123\x75\143\143\x65\x73\163\x66\x75\154\154\171", "\163\164\141\x74\x75\x73" => "\123\125\x43\103\105\x53\x53", "\164\170\x69\144" => wp_rand(1000, 9999));
        IO:
    }
    public static function mo_validate_otp_token($dX, $e9, $li)
    {
        if (MO2F_TEST_MODE) {
            goto hg;
        }
        $hP = '';
        if (!TwoFAMoSessions::get_session_var("\x6d\157\x32\146\137\x74\x72\x61\x6e\x73\x61\x63\x74\151\157\x6e\x49\x64")) {
            goto os;
        }
        $hS = get_site_option("\x6d\x6f\62\146\x5f\143\165\x73\x74\x6f\x6d\145\x72\x4b\x65\171");
        $Yl = get_site_option("\x6d\x6f\62\146\137\141\x70\151\x5f\x6b\x65\171");
        $hP = (new MO2f_Cloud_Onprem_Interface())->validate_otp_token(strtoupper($dX), null, $e9, $li);
        $hP = json_decode($hP, true);
        if (!("\x53\125\103\x43\x45\123\123" === $hP["\x73\164\141\164\x75\163"])) {
            goto dW;
        }
        TwoFAMoSessions::unset_session("\x6d\157\x32\146\x5f\164\162\141\x6e\163\141\x63\x74\151\157\x6e\111\x64");
        dW:
        os:
        return $hP;
        goto Rn;
        hg:
        TwoFAMoSessions::unset_session("\155\157\62\x66\137\164\x72\x61\x6e\x73\x61\143\164\x69\157\156\111\x64");
        return MO2F_FAIL_MODE ? array("\163\x74\x61\164\x75\163" => "\106\x41\x49\x4c\x45\104", "\x6d\145\x73\x73\x61\147\x65" => "\117\x54\x50\x20\x69\x73\40\111\x6e\x76\141\x6c\x69\144") : array("\163\x74\x61\x74\x75\163" => "\123\125\x43\103\105\123\x53", "\x6d\145\163\163\141\147\145" => "\123\165\x63\x63\x65\x73\163\146\x75\154\x6c\x79\40\x56\141\x6c\151\x64\x61\164\145\x64");
        Rn:
    }
}
Ie:
