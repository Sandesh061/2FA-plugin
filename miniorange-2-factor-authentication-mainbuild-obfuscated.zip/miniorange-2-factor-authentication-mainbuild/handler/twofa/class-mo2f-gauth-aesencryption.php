<?php


namespace TwoFA\Handler;

if (defined("\x41\x42\x53\x50\101\124\x48")) {
    goto xu;
}
exit;
xu:
if (class_exists("\x4d\x6f\x32\146\x5f\x47\x41\165\x74\150\137\x41\105\x53\105\156\x63\162\171\x70\164\x69\157\156")) {
    goto hQ;
}
class Mo2f_GAuth_AESEncryption
{
    public static function encrypt_data_ga($mC, $t8)
    {
        $xf = $mC;
        $Ap = "\x41\105\123\x2d\61\x32\70\55\103\102\103";
        $sH = openssl_cipher_iv_length($Ap);
        $e6 = openssl_random_pseudo_bytes($sH);
        $Mg = openssl_encrypt($xf, $Ap, $t8, $PF = OPENSSL_RAW_DATA, $e6);
        $JK = hash_hmac("\x73\150\x61\x32\x35\x36", $Mg, $t8, $Q4 = true);
        $gk = base64_encode($e6 . $JK . $Mg);
        return $gk;
    }
    public static function decrypt_data($mC, $t8)
    {
        $eA = base64_decode($mC);
        $Ap = "\101\105\x53\55\61\x32\70\55\103\x42\x43";
        $sH = openssl_cipher_iv_length($Ap);
        $e6 = substr($eA, 0, $sH);
        $Mg = substr($eA, $sH + 32);
        $OU = openssl_decrypt($Mg, $Ap, $t8, $PF = OPENSSL_RAW_DATA, $e6);
        return $OU;
    }
}
hQ:
