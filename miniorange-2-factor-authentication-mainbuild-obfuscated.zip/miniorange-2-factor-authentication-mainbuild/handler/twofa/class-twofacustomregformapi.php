<?php


namespace TwoFA\Handler;

use TwoFA\Helper\MoWpnsMessages;
use TwoFA\Onprem\MO2f_Utility;
use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Helper\MoWpnsConstants;
if (defined("\x41\102\x53\120\x41\124\x48")) {
    goto kO;
}
exit;
kO:
require_once "\143\154\141\x73\x73\x2d\164\167\x6f\146\x61\x6d\157\x67\141\x74\145\167\141\171\x2e\x70\x68\x70";
if (class_exists("\124\x77\x6f\x46\x41\x43\165\163\x74\x6f\x6d\x52\145\147\106\157\162\x6d\x41\x50\111")) {
    goto D_;
}
class TwoFACustomRegFormAPI
{
    public function __construct()
    {
    }
    public static function challenge($bo, $fK, $GV)
    {
        if (MoWpnsConstants::OTP_OVER_EMAIL === $GV) {
            goto Lj;
        }
        $bC = TwoFAMOGateway::mo_send_otp_token(MoWpnsConstants::OTP_OVER_SMS, $bo, $fK);
        goto gX;
        Lj:
        $IG = MoWpnsUtility::get_mo2f_db_option("\143\155\x56\x74\131\127\x6c\x75\141\127\x35\156\x54\x31\122\x51", "\x73\x69\164\145\137\157\160\164\x69\x6f\156");
        $Bj = $IG ? $IG : 0;
        if ($Bj > 0) {
            goto hy;
        }
        $bC = array("\x73\164\x61\164\x75\163" => "\105\x52\122\117\122", "\155\x65\163\163\x61\x67\145" => __("\105\x6d\x61\x69\154\x20\124\x72\141\x6e\163\141\143\x74\151\157\156\40\x4c\x69\155\x69\x74\x20\x45\x78\143\x65\145\x64\x65\144", "\155\x69\x6e\x69\157\162\x61\156\147\145\x2d\x32\55\146\x61\143\x74\x6f\x72\x2d\x61\x75\x74\x68\x65\156\164\151\x63\x61\164\x69\x6f\156"));
        wp_send_json($bC);
        goto dz;
        hy:
        $bC = TwoFAMOGateway::mo_send_otp_token("\x45\115\101\111\114", '', $fK);
        update_site_option("\143\155\126\x74\x59\x57\154\x75\x61\x57\65\156\124\x31\122\x51", $Bj - 1);
        dz:
        gX:
        if (!(isset($bC["\x73\x74\141\164\165\x73"]) && isset($bC["\x6d\145\163\x73\141\147\145"]) && "\x45\x52\x52\x4f\x52" === $bC["\x73\164\141\164\x75\x73"] && strpos($bC["\155\145\x73\163\x61\147\x65"], "\x63\x75\162\154\40\x65\170\x74\x65\x6e\x73\x69\157\156") !== false)) {
            goto Zf;
        }
        $bC["\155\145\163\x73\x61\147\145"] = "\x50\154\x65\x61\x73\145\40\x65\156\x61\x62\x6c\x65\x20\143\165\162\154\40\145\170\164\x65\x6e\163\151\x6f\x6e\56";
        Zf:
        if (isset($bC["\160\x68\x6f\x6e\x65\104\145\x6c\x69\x76\145\162\x79"]) && isset($bC["\160\150\157\156\145\104\x65\154\151\x76\145\162\171"]["\x63\157\x6e\164\141\143\x74"]) && isset($bC["\163\x74\141\x74\x75\163"]) && "\x46\101\x49\x4c\x45\x44" !== $bC["\x73\164\141\x74\165\163"]) {
            goto UX;
        }
        if (isset($bC["\145\x6d\141\x69\154\104\145\154\151\x76\x65\162\x79"]) && isset($bC["\x65\x6d\x61\x69\154\104\145\154\151\166\145\x72\x79"]["\x63\157\156\x74\x61\143\x74"]) && isset($bC["\x73\x74\141\164\x75\x73"]) && "\106\x41\111\114\105\104" !== $bC["\x73\164\141\x74\165\163"]) {
            goto GV;
        }
        if (isset($bC["\x6d\145\x73\163\141\x67\145"])) {
            goto vp;
        }
        goto Ge;
        UX:
        $bC["\155\x65\163\x73\141\147\x65"] = MoWpnsMessages::lang_translate(MoWpnsMessages::SENT_OTP) . "\x20" . MO2f_Utility::get_hidden_phone($bC["\x70\x68\x6f\x6e\145\x44\145\x6c\151\166\145\x72\x79"]["\x63\157\156\x74\141\143\x74"]) . MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_SENT_OTP);
        goto Ge;
        GV:
        $bC["\155\x65\x73\163\x61\x67\145"] = MoWpnsMessages::lang_translate(MoWpnsMessages::SENT_OTP) . "\40" . MO2f_Utility::get_hidden_phone($bC["\145\155\x61\x69\154\x44\145\154\x69\166\x65\x72\x79"]["\143\157\x6e\x74\x61\x63\x74"]) . MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_SENT_OTP);
        goto Ge;
        vp:
        $bC["\155\x65\x73\163\141\x67\x65"] = MoWpnsMessages::lang_translate($bC["\155\x65\163\163\x61\x67\x65"]);
        Ge:
        wp_send_json($bC);
    }
    public static function validate($dX, $e9, $DF)
    {
        $bC = TwoFAMOGateway::mo_validate_otp_token($dX, $e9, $DF);
        if (!isset($bC["\155\145\x73\x73\x61\x67\x65"])) {
            goto Sw;
        }
        $bC["\x6d\x65\x73\163\141\147\145"] = MoWpnsMessages::lang_translate($bC["\155\145\x73\x73\x61\147\x65"]);
        Sw:
        wp_send_json($bC);
    }
}
D_:
