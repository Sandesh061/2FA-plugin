<?php


namespace TwoFA\Onprem;

use TwoFA\Handler\Mo2f_GAuth_AESEncryption;
use Exception;
if (defined("\x41\102\x53\120\x41\124\110")) {
    goto TO;
}
exit;
TO:
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . "\x63\154\x61\163\x73\55\x6d\157\x32\146\55\147\141\165\164\150\x2d\141\x65\x73\145\x6e\x63\x72\171\160\164\151\157\156\x2e\160\x68\x70";
if (class_exists("\107\x6f\x6f\x67\x6c\x65\x5f\x41\165\x74\x68\137\117\156\x70\162\x65\x6d\151\x73\x65")) {
    goto C8;
}
class Google_Auth_Onpremise
{
    protected $code_length = 6;
    public function __construct()
    {
    }
    public function mo_g_auth_set_secret($v1, $wG)
    {
        $t8 = $this->random_str(8);
        update_user_meta($v1, "\155\157\x32\x66\137\147\145\164\137\x61\x75\164\x68\x5f\x72\x6e\x64\137\163\x74\162\x69\156\147", $t8);
        $wG = Mo2f_GAuth_AESEncryption::encrypt_data_ga($wG, $t8);
        update_user_meta($v1, "\155\x6f\x32\x66\137\x67\141\x75\164\x68\137\x6b\x65\171", $wG);
    }
    public function mo_a_auth_get_secret($v1)
    {
        $t8 = get_user_meta($v1, "\155\x6f\x32\x66\137\147\145\164\x5f\x61\165\x74\150\x5f\x72\x6e\144\137\163\x74\162\x69\x6e\x67", true);
        $wG = get_user_meta($v1, "\x6d\157\x32\146\137\x67\141\165\x74\150\x5f\153\x65\171", true);
        $wG = Mo2f_GAuth_AESEncryption::decrypt_data($wG, $t8);
        return $wG;
    }
    public function random_str($La, $qZ = "\60\x31\62\63\x34\65\x36\x37\x38\x39\141\142\143\x64\x65\146\x67\150\x69\152\153\154\155\x6e\157\160\x71\x72\163\x74\165\166\x77\x78\x79\172\x41\102\103\104\105\106\x47\x48\x49\112\x4b\x4c\115\x4e\117\x50\x51\x52\123\x54\125\x56\x57\130\131\x5a")
    {
        $S6 = '';
        $d4 = strlen($qZ);
        $ET = 0;
        vX:
        if (!($ET < $La)) {
            goto kG;
        }
        $S6 .= $qZ[random_int(0, $d4 - 1)];
        DL:
        $ET++;
        goto vX;
        kG:
        return $S6;
    }
    public function mo2f_create_secret($tY = 16)
    {
        $R4 = $this->mo2f_get_base32_lookup_table();
        if (!($tY < 16 || $tY > 128)) {
            goto jd;
        }
        throw new Exception("\102\141\x64\x20\x73\145\x63\x72\x65\x74\40\154\x65\156\x67\164\x68");
        jd:
        $wG = '';
        $Wz = false;
        if (function_exists("\162\141\156\x64\157\x6d\x5f\x62\x79\x74\145\163")) {
            goto vA;
        }
        if (function_exists("\157\160\145\x6e\163\163\x6c\137\x72\x61\x6e\x64\x6f\x6d\137\160\163\x65\165\144\157\137\142\x79\x74\145\x73")) {
            goto VU;
        }
        goto YH;
        vA:
        $Wz = random_bytes($tY);
        goto YH;
        VU:
        $Wz = openssl_random_pseudo_bytes($tY, $pv);
        if ($pv) {
            goto hZ;
        }
        $Wz = false;
        hZ:
        YH:
        if (false !== $Wz) {
            goto q5;
        }
        throw new Exception("\x4e\x6f\40\163\x6f\165\x72\x63\145\40\157\146\x20\x73\x65\x63\165\x72\145\40\162\x61\156\144\x6f\155");
        goto dD;
        q5:
        $ET = 0;
        bE:
        if (!($ET < $tY)) {
            goto WH;
        }
        $wG .= $R4[ord($Wz[$ET]) & 31];
        px:
        ++$ET;
        goto bE;
        WH:
        dD:
        return $wG;
    }
    public function mo2f_get_base32_lookup_table()
    {
        return array("\101", "\102", "\x43", "\104", "\x45", "\x46", "\107", "\x48", "\111", "\112", "\x4b", "\114", "\x4d", "\116", "\117", "\x50", "\121", "\122", "\123", "\x54", "\125", "\x56", "\127", "\x58", "\x59", "\132", "\62", "\63", "\64", "\x35", "\x36", "\67", "\75");
    }
    public function mo2f_verify_code($wG, $w9, $fz = 3, $o2 = null)
    {
        $bC = array("\x73\164\x61\x74\x75\x73" => "\146\x61\x6c\x73\x65");
        if (!(null === $o2)) {
            goto ZT;
        }
        $o2 = floor(time() / 30);
        ZT:
        if (!(strlen($w9) !== 6)) {
            goto ij;
        }
        return wp_json_encode($bC);
        ij:
        $wG = strtoupper($wG);
        $ET = -$fz;
        pU:
        if (!($ET <= $fz)) {
            goto WX;
        }
        $q7 = $this->mo2f_get_code($wG, $o2 + $ET);
        if (!$this->mo2f_timing_safe_equals($q7, $w9)) {
            goto V8;
        }
        update_site_option("\x6d\157\62\146\x5f\164\x69\155\x65\137\x73\154\151\143\x65", $ET);
        $bC["\163\164\141\164\165\x73"] = "\x53\125\103\x43\x45\x53\x53";
        return wp_json_encode($bC);
        V8:
        xn:
        ++$ET;
        goto pU;
        WX:
        return wp_json_encode($bC);
    }
    public function mo2f_geturl($wG, $G1, $fK)
    {
        $xz = "\x6f\164\x70\141\165\x74\x68\x3a\57\57\164\157\x74\160\57";
        $xz .= $fK . "\77\163\145\x63\x72\x65\x74\x3d" . $wG . "\46\x69\163\163\165\x65\162\x3d" . $G1;
        return $xz;
    }
    public function mo2f_timing_safe_equals($hw, $U6)
    {
        if (!function_exists("\x68\141\x73\x68\137\x65\161\165\141\154\x73")) {
            goto tN;
        }
        return hash_equals($hw, $U6);
        tN:
        $zn = strlen($hw);
        $NV = strlen($U6);
        if (!($NV !== $zn)) {
            goto f5;
        }
        return false;
        f5:
        $vv = 0;
        $ET = 0;
        EO:
        if (!($ET < $NV)) {
            goto Xq;
        }
        $vv |= ord($hw[$ET]) ^ ord($U6[$ET]);
        aD:
        ++$ET;
        goto EO;
        Xq:
        return 0 === $vv;
    }
    public function mo2f_get_code($wG, $EX = null)
    {
        if (!(null === $EX)) {
            goto Ei;
        }
        $EX = floor(time() / 30);
        Ei:
        $qK = $this->mo2f_base32_decode($wG);
        $rs = chr(0) . chr(0) . chr(0) . chr(0) . pack("\x4e\52", $EX);
        $qv = hash_hmac("\123\110\x41\61", $rs, $qK, true);
        $kp = ord(substr($qv, -1)) & 0xf;
        $Fh = substr($qv, $kp, 4);
        $iY = unpack("\116", $Fh);
        $iY = $iY[1];
        $iY = $iY & 0x7fffffff;
        $Rp = pow(10, $this->code_length);
        return str_pad($iY % $Rp, $this->code_length, "\x30", STR_PAD_LEFT);
    }
    public function mo2f_base32_decode($wG)
    {
        if (!empty($wG)) {
            goto TP;
        }
        return '';
        TP:
        $hQ = $this->mo2f_get_base32_lookup_table();
        $Qk = array_flip($hQ);
        $MW = substr_count($wG, $hQ[32]);
        $Fo = array(6, 4, 3, 1, 0);
        if (in_array($MW, $Fo, true)) {
            goto NC;
        }
        return false;
        NC:
        $ET = 0;
        C5:
        if (!($ET < 4)) {
            goto jo;
        }
        if (!($MW === $Fo[$ET] && substr($wG, -$Fo[$ET]) !== str_repeat($hQ[32], $Fo[$ET]))) {
            goto MH;
        }
        return false;
        MH:
        PT:
        ++$ET;
        goto C5;
        jo:
        $wG = str_replace("\x3d", '', $wG);
        $wG = str_split($wG);
        $T4 = '';
        $tV = count($wG);
        $ET = 0;
        y_:
        if (!($ET < $tV)) {
            goto Jh;
        }
        $T8 = '';
        if (in_array($wG[$ET], $hQ, true)) {
            goto YJ;
        }
        return false;
        YJ:
        $NN = 0;
        Wx:
        if (!($NN < 8)) {
            goto R7;
        }
        $T8 .= str_pad(base_convert($Qk[$wG[$ET + $NN]], 10, 2), 5, "\x30", STR_PAD_LEFT);
        K8:
        ++$NN;
        goto Wx;
        R7:
        $wC = str_split($T8, 8);
        $Cu = count($wC);
        $Gp = 0;
        pf:
        if (!($Gp < $Cu)) {
            goto uq;
        }
        $Bo = chr(base_convert($wC[$Gp], 2, 10));
        $T4 .= $Bo || ord($Bo) === 48 ? $Bo : '';
        zp:
        ++$Gp;
        goto pf;
        uq:
        T8:
        $ET = $ET + 8;
        goto y_;
        Jh:
        return $T4;
    }
}
C8:
