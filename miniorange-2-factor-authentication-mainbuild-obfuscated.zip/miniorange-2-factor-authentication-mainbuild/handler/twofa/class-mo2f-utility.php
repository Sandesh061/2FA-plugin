<?php


namespace TwoFA\Onprem;

use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Helper\MocURL;
use TwoFA\Helper\MoWpnsConstants;
use DateTime;
if (defined("\x41\x42\x53\x50\x41\124\x48")) {
    goto Rj;
}
exit;
Rj:
if (class_exists("\115\x4f\62\146\x5f\x55\x74\x69\154\151\x74\x79")) {
    goto zX;
}
class MO2f_Utility
{
    public static function get_hidden_phone($T7)
    {
        $Dl = "\x78\170\x78\x78\x78\x78\x78" . substr($T7, strlen($T7) - 3);
        return $Dl;
    }
    public static function mo2f_check_empty_or_null($iY)
    {
        if (!(!isset($iY) || empty($iY))) {
            goto UK;
        }
        return true;
        UK:
        return false;
    }
    public static function is_curl_installed()
    {
        if (in_array("\x63\x75\162\154", get_loaded_extensions(), true)) {
            goto X5;
        }
        return 0;
        goto gd;
        X5:
        return 1;
        gd:
    }
    public static function get_all_plugins_installed()
    {
        $U4 = get_plugins();
        $eb = array();
        $form = '';
        $eb["\116\x6f\x6e\x65"] = "\116\157\156\145";
        foreach ($U4 as $pa => $Fn) {
            $eb[$pa] = $Fn["\x4e\141\x6d\x65"];
            Zq:
        }
        Sa:
        unset($eb["\x6d\151\x6e\x69\157\x72\141\156\147\x65\x2d\62\55\x66\x61\x63\x74\157\x72\55\141\x75\x74\x68\145\x6e\x74\151\143\x61\x74\x69\x6f\156\x2f\155\x69\156\x69\x6f\x72\141\156\147\145\55\x32\x2d\146\141\143\164\x6f\162\55\163\145\x74\x74\151\x6e\147\163\56\160\x68\160"]);
        echo "\x3c\x64\x69\x76\40\x63\154\x61\x73\163\x3d\42\155\157\62\146\137\160\x6c\x75\x67\x69\x6e\137\163\145\154\145\143\x74\42\76\x50\154\145\x61\x73\145\40\x73\145\x6c\145\x63\164\x20\x74\150\x65\40\x70\x6c\165\147\x69\156\74\142\x72\76\15\12\x9\x9\x9\x3c\x73\145\154\x65\143\164\40\156\x61\155\145\x3d\x22\x6d\x6f\x32\x66\137\x70\x6c\165\x67\x69\156\137\163\145\154\x65\143\x74\145\x64\42\40\x69\x64\75\x22\x6d\x6f\62\x66\x2d\160\x6c\165\147\151\x6e\x2d\x73\x65\x6c\x65\x63\x74\x65\x64\42\x3e";
        foreach ($eb as $Os => $rD) {
            echo "\x3c\157\x70\x74\x69\x6f\156\40\166\x61\x6c\x75\145\75\42" . esc_attr($Os) . "\42\x3e" . esc_attr($rD) . "\x3c\x2f\x6f\x70\164\151\157\x6e\76";
            br:
        }
        ck:
        echo "\x3c\57\163\x65\x6c\x65\x63\164\x3e\74\x2f\144\151\x76\76";
    }
    public static function mo2f_check_number_length($CS)
    {
        if (is_numeric($CS)) {
            goto Op;
        }
        return false;
        goto wc;
        Op:
        if (strlen($CS) >= 4 && strlen($CS) <= 8) {
            goto YB;
        }
        return false;
        goto Ug;
        YB:
        return true;
        Ug:
        wc:
    }
    public static function mo2f_get_hidden_email($fK)
    {
        if (!(!isset($fK) || trim($fK) === '')) {
            goto gE;
        }
        return '';
        gE:
        $My = strlen($fK);
        $u0 = substr($fK, 0, 1);
        $Kx = strrpos($fK, "\x40");
        $Eq = substr($fK, $Kx - 1, $My);
        $ET = 1;
        mD:
        if (!($ET < $Kx)) {
            goto tn;
        }
        $u0 = $u0 . "\170";
        Yo:
        $ET++;
        goto mD;
        tn:
        $vW = $u0 . $Eq;
        return $vW;
    }
    public static function check_if_request_is_from_mobile_device($d_)
    {
        if (preg_match("\57\50\141\x6e\144\162\157\151\144\174\142\142\134\x64\53\x7c\x6d\x65\145\x67\x6f\51\56\x2b\x6d\157\142\x69\154\145\x7c\141\x76\x61\x6e\x74\x67\x6f\x7c\142\x61\x64\141\x5c\57\x7c\142\154\x61\143\x6b\x62\145\x72\x72\171\174\x62\154\141\172\145\x72\x7c\x63\157\155\x70\x61\154\174\145\x6c\141\151\x6e\145\174\x66\x65\156\156\x65\143\x7c\x68\151\x70\x74\x6f\160\174\151\145\155\157\142\x69\x6c\x65\x7c\151\160\x28\150\x6f\156\145\174\157\x64\x29\x7c\x69\x72\x69\x73\174\153\x69\x6e\144\154\145\x7c\x6c\x67\x65\40\x7c\155\x61\x65\155\157\x7c\155\x69\144\x70\x7c\155\x6d\160\174\155\x6f\142\151\154\x65\x2e\53\146\151\x72\x65\146\157\170\x7c\x6e\x65\164\x66\162\x6f\x6e\x74\x7c\x6f\x70\145\162\141\x20\x6d\x28\x6f\142\174\x69\156\51\151\x7c\160\141\154\x6d\50\40\157\x73\51\x3f\x7c\x70\x68\157\156\x65\174\160\50\151\170\151\x7c\x72\145\x29\134\57\x7c\x70\154\x75\x63\153\x65\162\174\160\157\x63\x6b\x65\x74\174\x70\x73\160\174\x73\145\162\151\x65\x73\50\64\174\x36\x29\60\174\163\171\155\142\x69\141\156\x7c\164\x72\145\157\174\165\160\x5c\56\x28\x62\x72\x6f\x77\163\x65\162\x7c\x6c\151\x6e\153\51\174\x76\157\x64\x61\146\x6f\156\x65\x7c\x77\141\160\x7c\x77\151\x6e\144\157\x77\x73\40\x63\145\x7c\x78\144\x61\x7c\170\x69\x69\156\x6f\x2f\151", $d_) || preg_match("\57\61\x32\60\x37\174\x36\63\x31\x30\174\66\65\71\x30\174\63\x67\x73\x6f\174\x34\164\150\x70\174\x35\60\x5b\x31\55\x36\x5d\151\x7c\67\67\x30\x73\x7c\x38\60\62\163\174\x61\40\x77\141\x7c\x61\x62\141\143\174\x61\143\50\145\x72\174\x6f\x6f\x7c\163\x5c\55\51\x7c\141\x69\50\x6b\x6f\174\162\x6e\x29\174\141\x6c\50\141\x76\174\x63\141\x7c\143\x6f\x29\x7c\x61\155\157\151\x7c\x61\156\50\x65\x78\x7c\156\171\174\171\167\x29\x7c\141\160\x74\x75\174\141\162\x28\143\150\174\x67\x6f\51\174\x61\x73\x28\x74\x65\174\x75\x73\x29\x7c\x61\164\164\x77\x7c\141\165\50\144\151\174\x5c\x2d\x6d\174\162\x20\x7c\x73\x20\51\x7c\141\166\141\x6e\x7c\x62\x65\x28\143\x6b\174\x6c\154\174\156\161\x29\x7c\142\151\x28\154\142\174\162\144\x29\174\x62\x6c\50\x61\x63\174\141\172\51\174\x62\x72\x28\145\x7c\x76\51\x77\174\x62\165\155\x62\x7c\x62\x77\x5c\55\x28\156\x7c\165\51\x7c\x63\65\65\x5c\57\x7c\143\x61\x70\151\174\143\143\167\141\x7c\143\144\155\134\55\174\x63\145\x6c\x6c\x7c\143\x68\164\x6d\174\x63\x6c\x64\143\x7c\x63\155\144\134\x2d\174\x63\157\50\155\x70\x7c\x6e\x64\51\174\x63\162\x61\x77\x7c\144\x61\x28\151\x74\174\154\154\x7c\156\x67\51\x7c\144\x62\x74\145\x7c\x64\x63\134\55\163\x7c\144\145\x76\x69\174\144\x69\x63\x61\174\144\x6d\x6f\x62\174\x64\157\x28\143\x7c\160\x29\x6f\174\144\x73\x28\x31\x32\x7c\134\55\x64\x29\x7c\145\x6c\50\x34\x39\x7c\x61\151\51\174\145\x6d\50\x6c\x32\174\165\x6c\x29\x7c\145\x72\50\x69\143\x7c\153\x30\x29\174\145\x73\x6c\x38\x7c\x65\172\50\x5b\x34\x2d\x37\135\60\x7c\157\163\174\x77\x61\x7c\x7a\145\51\x7c\x66\x65\164\143\x7c\146\154\171\50\134\55\x7c\137\51\174\x67\61\x20\x75\174\x67\x35\66\x30\x7c\147\145\156\145\x7c\x67\146\x5c\x2d\x35\174\x67\134\x2d\155\x6f\174\147\157\x28\134\56\167\174\x6f\x64\x29\174\x67\162\50\141\144\x7c\165\156\x29\174\x68\141\x69\x65\x7c\x68\x63\151\164\x7c\150\x64\x5c\x2d\x28\x6d\174\x70\x7c\x74\x29\174\x68\145\151\x5c\55\x7c\150\151\x28\160\164\x7c\x74\x61\x29\174\x68\160\x28\40\151\x7c\x69\x70\x29\x7c\x68\x73\134\55\143\174\x68\x74\x28\x63\x28\x5c\55\x7c\x20\x7c\x5f\x7c\x61\174\x67\174\160\174\163\x7c\164\x29\x7c\164\160\51\x7c\x68\x75\x28\x61\x77\174\x74\x63\x29\x7c\x69\134\55\50\x32\60\174\147\157\x7c\x6d\x61\x29\174\x69\x32\x33\60\x7c\151\x61\143\50\40\x7c\x5c\x2d\x7c\x5c\57\51\x7c\151\x62\x72\157\174\x69\144\x65\141\x7c\151\147\60\x31\174\151\153\x6f\155\x7c\151\155\x31\153\174\x69\156\156\157\174\x69\160\x61\161\x7c\x69\162\x69\x73\174\x6a\141\50\164\x7c\x76\x29\141\x7c\152\x62\162\157\x7c\x6a\145\155\165\174\x6a\x69\147\163\x7c\x6b\x64\144\151\x7c\x6b\145\x6a\151\x7c\x6b\147\164\50\x20\x7c\134\x2f\x29\174\x6b\154\157\x6e\x7c\x6b\160\164\x20\174\153\167\x63\x5c\x2d\174\153\171\157\50\x63\174\x6b\51\174\154\x65\x28\156\x6f\174\170\x69\x29\174\154\x67\x28\x20\147\x7c\x5c\57\x28\153\174\154\x7c\x75\x29\174\65\60\174\65\64\174\134\x2d\133\141\55\x77\135\x29\174\x6c\x69\x62\x77\174\x6c\171\156\170\174\155\61\134\x2d\167\174\x6d\63\147\141\174\x6d\65\x30\134\57\174\155\x61\x28\x74\145\174\165\151\174\x78\x6f\51\x7c\x6d\143\50\x30\x31\x7c\62\61\174\143\141\x29\174\x6d\x5c\55\143\162\x7c\155\145\x28\162\143\174\x72\x69\51\x7c\155\x69\50\157\70\x7c\157\141\174\164\163\x29\x7c\x6d\x6d\x65\146\174\155\157\x28\60\x31\x7c\x30\x32\174\x62\x69\x7c\144\x65\x7c\x64\157\x7c\x74\x28\134\x2d\174\40\174\x6f\174\x76\51\174\172\x7a\x29\x7c\155\x74\x28\65\60\174\x70\x31\174\x76\x20\x29\174\x6d\x77\142\160\x7c\155\171\x77\141\174\x6e\61\x30\x5b\60\x2d\62\x5d\x7c\x6e\62\60\x5b\x32\x2d\x33\x5d\174\156\63\x30\50\x30\x7c\x32\x29\x7c\156\65\60\50\x30\174\x32\x7c\x35\x29\x7c\x6e\x37\x28\x30\x28\60\x7c\x31\x29\x7c\61\x30\51\x7c\156\145\x28\50\x63\174\155\x29\x5c\55\x7c\157\x6e\174\164\x66\174\x77\x66\x7c\x77\147\x7c\x77\x74\x29\174\156\x6f\153\50\66\174\x69\51\x7c\x6e\172\x70\150\x7c\157\62\151\155\174\157\x70\50\164\151\x7c\x77\166\x29\x7c\x6f\x72\141\156\x7c\157\167\147\61\174\160\x38\x30\60\174\160\141\x6e\x28\141\x7c\144\x7c\x74\x29\x7c\x70\x64\x78\x67\x7c\x70\147\50\61\x33\x7c\x5c\x2d\50\133\61\x2d\70\135\x7c\x63\x29\51\x7c\160\x68\x69\x6c\174\160\151\162\x65\174\160\154\x28\x61\x79\174\165\143\x29\x7c\x70\x6e\134\55\x32\x7c\160\x6f\x28\x63\x6b\174\162\164\174\163\x65\x29\174\160\162\x6f\170\x7c\x70\163\151\157\174\160\x74\x5c\55\x67\x7c\x71\141\134\x2d\141\x7c\x71\143\50\x30\x37\174\61\x32\174\x32\x31\x7c\x33\62\174\x36\x30\174\134\55\133\62\x2d\67\x5d\174\x69\x5c\55\x29\x7c\161\164\x65\x6b\174\x72\63\70\x30\174\x72\66\x30\60\174\162\141\153\x73\x7c\x72\x69\x6d\71\x7c\162\x6f\50\166\145\x7c\x7a\x6f\x29\174\x73\x35\65\134\57\174\163\x61\x28\147\x65\x7c\155\x61\x7c\x6d\x6d\174\x6d\x73\x7c\156\x79\x7c\x76\141\x29\x7c\163\143\50\x30\61\x7c\150\x5c\55\x7c\x6f\x6f\174\x70\x5c\x2d\x29\174\x73\x64\x6b\x5c\x2f\174\x73\x65\x28\143\x28\x5c\55\174\60\x7c\x31\x29\174\x34\x37\x7c\x6d\x63\x7c\x6e\144\x7c\162\151\51\174\163\x67\x68\x5c\x2d\174\163\150\141\162\174\x73\151\145\50\134\55\x7c\155\51\174\163\153\134\55\60\174\163\x6c\x28\64\65\174\151\144\x29\x7c\163\155\x28\x61\154\174\141\x72\174\142\63\174\x69\x74\x7c\x74\65\x29\x7c\x73\157\50\x66\x74\x7c\156\171\51\174\x73\x70\x28\x30\61\174\150\134\55\174\x76\134\55\174\166\x20\51\174\163\171\50\x30\61\x7c\155\x62\51\174\x74\62\x28\x31\x38\174\x35\60\51\x7c\164\66\50\x30\60\x7c\61\60\x7c\61\70\51\x7c\x74\141\x28\x67\164\174\x6c\153\x29\x7c\x74\143\x6c\x5c\55\x7c\x74\x64\x67\x5c\x2d\x7c\164\x65\154\x28\151\174\x6d\x29\x7c\x74\151\155\x5c\55\x7c\x74\x5c\x2d\155\x6f\x7c\164\x6f\50\x70\154\x7c\163\150\x29\174\164\x73\x28\67\60\174\155\x5c\55\174\x6d\63\174\x6d\x35\51\x7c\164\x78\x5c\x2d\71\174\x75\x70\50\134\56\142\x7c\147\x31\174\x73\x69\x29\174\165\x74\163\x74\x7c\166\64\60\x30\x7c\166\x37\x35\60\174\x76\x65\162\151\174\x76\151\x28\162\x67\x7c\x74\145\51\174\166\153\50\x34\60\x7c\x35\x5b\x30\55\63\135\174\134\x2d\166\x29\174\x76\155\x34\60\174\166\157\144\x61\x7c\x76\x75\x6c\143\x7c\x76\170\50\65\62\174\x35\x33\174\66\x30\174\66\x31\174\67\60\x7c\70\60\x7c\x38\x31\174\70\x33\x7c\70\x35\x7c\71\70\51\174\167\x33\143\50\134\55\174\x20\x29\x7c\x77\145\x62\x63\x7c\167\x68\151\164\x7c\167\151\50\147\x20\174\x6e\143\174\x6e\x77\51\x7c\167\x6d\x6c\142\x7c\167\x6f\x6e\x75\174\170\67\60\60\x7c\171\141\163\x5c\x2d\x7c\171\x6f\165\162\174\172\x65\164\x6f\174\172\x74\x65\134\x2d\x2f\x69", substr($d_, 0, 4))) {
            goto no;
        }
        return false;
        goto xa;
        no:
        return true;
        xa:
    }
    public static function set_user_values($BN, $ez, $iY)
    {
        global $Gw;
        $t8 = get_site_option("\155\157\x32\x66\x5f\x65\156\x63\x72\171\x70\164\151\157\x6e\x5f\153\145\171");
        $b6 = null;
        if (empty($b6)) {
            goto Qd;
        }
        if (!empty($b6) && "\163\x65\163\x73\151\157\156\163" === $b6) {
            goto Sf;
        }
        if (!empty($b6) && "\143\157\157\153\x69\145\163" === $b6) {
            goto DB;
        }
        if (!empty($b6) && "\164\141\142\x6c\145\163" === $b6) {
            goto o5;
        }
        goto wq;
        Qd:
        $_SESSION[$ez] = $iY;
        if (is_array($iY)) {
            goto rW;
        }
        self::mo2f_set_cookie_values($ez, $iY);
        goto Mt;
        rW:
        if (!("\155\x6f\x5f\x32\137\x66\x61\x63\164\x6f\x72\137\x6b\x62\141\x5f\161\x75\x65\x73\x74\151\157\x6e\x73" === $ez)) {
            goto ru;
        }
        self::mo2f_set_cookie_values("\153\x62\141\x5f\161\165\145\x73\x74\151\x6f\156\x31", $iY[0]["\161\x75\x65\x73\x74\x69\x6f\x6e"]);
        self::mo2f_set_cookie_values("\153\142\x61\137\x71\165\145\163\164\151\157\156\x32", $iY[1]["\x71\165\x65\x73\164\151\x6f\156"]);
        ru:
        Mt:
        $BN = self::decrypt_data($BN, $t8);
        $iQ = md5($BN);
        if (is_array($iY)) {
            goto ZM;
        }
        $Gw->save_user_login_details($iQ, array($ez => $iY));
        goto xX;
        ZM:
        $MZ = maybe_serialize($iY);
        $Gw->save_user_login_details($iQ, array($ez => $MZ));
        xX:
        goto wq;
        Sf:
        $_SESSION[$ez] = $iY;
        goto wq;
        DB:
        if (is_array($iY)) {
            goto Rm;
        }
        self::mo2f_set_cookie_values($ez, $iY);
        goto Ga;
        Rm:
        if (!("\x6d\x6f\x5f\62\x5f\146\141\143\164\x6f\162\x5f\153\x62\x61\137\161\165\x65\163\x74\x69\157\156\163" === $ez)) {
            goto Wy;
        }
        self::mo2f_set_cookie_values("\153\x62\141\x5f\161\x75\x65\163\164\151\x6f\156\61", $iY[0]);
        self::mo2f_set_cookie_values("\153\x62\x61\x5f\161\165\145\163\164\x69\x6f\156\x32", $iY[1]);
        Wy:
        Ga:
        goto wq;
        o5:
        $BN = self::decrypt_data($BN, $t8);
        $iQ = md5($BN);
        if (is_array($iY)) {
            goto yE;
        }
        $Gw->save_user_login_details($iQ, array($ez => $iY));
        goto Cp;
        yE:
        $MZ = maybe_serialize($iY);
        $Gw->save_user_login_details($iQ, array($ez => $MZ));
        Cp:
        wq:
    }
    public static function decrypt_data($mC, $t8)
    {
        $eA = base64_decode($mC);
        $Ap = "\x41\x45\123\55\x31\62\x38\x2d\103\102\103";
        $sH = openssl_cipher_iv_length($Ap);
        $e6 = substr($eA, 0, $sH);
        $JK = substr($eA, $sH, $Yb = 32);
        $Mg = substr($eA, $sH + $Yb);
        $OU = openssl_decrypt($Mg, $Ap, $t8, $PF = OPENSSL_RAW_DATA, $e6);
        $dj = hash_hmac("\163\x68\x61\x32\x35\66", $Mg, $t8, $Q4 = true);
        $WY = '';
        if (!(is_string($JK) && is_string($dj))) {
            goto GG;
        }
        if (!hash_equals($JK, $dj)) {
            goto GZ;
        }
        $WY = $OU;
        GZ:
        GG:
        return $WY;
    }
    public static function random_str($La, $qZ = "\60\61\62\63\64\x35\x36\67\70\71\x61\x62\143\x64\145\146\147\150\x69\152\153\154\x6d\x6e\157\160\x71\162\x73\x74\165\166\167\170\171\172\x41\x42\103\104\105\106\107\x48\111\112\x4b\x4c\115\x4e\117\120\x51\122\x53\x54\125\126\127\x58\x59\132")
    {
        $S6 = '';
        $d4 = strlen($qZ);
        $qZ = $qZ . microtime(true);
        $qZ = str_shuffle($qZ);
        $ET = 0;
        p_:
        if (!($ET < $La)) {
            goto wD;
        }
        $S6 .= $qZ[wp_rand(0, $d4 - 1)];
        tV:
        $ET++;
        goto p_;
        wD:
        return $S6;
    }
    public static function mo2f_set_transient($jg, $t8, $iY, $OH = 300)
    {
        set_transient($jg . $t8, $iY, $OH);
        $rm = get_site_option($jg, array());
        $rm[$t8] = $iY;
        update_site_option($jg, $rm);
        self::mo2f_set_session_value($jg, $rm);
        if (!is_array($iY)) {
            goto ZN;
        }
        $iY = wp_json_encode($iY);
        ZN:
        self::mo2f_set_cookie_values(base64_encode($jg), $iY);
    }
    public static function mo2f_get_transient($jg, $t8)
    {
        self::mo2f_start_session();
        if (isset($_SESSION[$jg])) {
            goto Rq;
        }
        if (isset($_COOKIE[base64_decode($jg)])) {
            goto XZ;
        }
        $lX = get_transient($jg . $t8);
        if ($lX) {
            goto Fi;
        }
        $rm = get_site_option($jg);
        $lX = isset($rm[$t8]) ? $rm[$t8] : null;
        Fi:
        return $lX;
        goto sL;
        Rq:
        $rm = $_SESSION[$jg];
        $lX = isset($rm[$t8]) ? $rm[$t8] : null;
        return $lX;
        goto sL;
        XZ:
        $lX = self::mo2f_get_cookie_values(base64_decode($jg));
        return $lX;
        sL:
    }
    public static function mo2f_set_session_value($jg, $rm)
    {
        self::mo2f_start_session();
        $_SESSION[$jg] = $rm;
    }
    public static function mo2f_start_session()
    {
        if (!(!session_id() || '' === session_id() || !isset($_SESSION))) {
            goto I4;
        }
        $aj = ini_get("\x73\x65\x73\163\151\157\x6e\x2e\163\x61\166\145\137\160\141\164\x68");
        if (!(is_writable($aj) && is_readable($aj) && !headers_sent())) {
            goto Nk;
        }
        if (!(session_status() !== PHP_SESSION_DISABLED)) {
            goto B8;
        }
        session_start();
        B8:
        Nk:
        I4:
    }
    public static function mo2f_retrieve_user_temp_values($ez, $jg = null)
    {
        global $Gw;
        $b6 = null;
        if (empty($b6)) {
            goto zu;
        }
        if (!empty($b6) && "\163\145\x73\x73\151\x6f\x6e\163" === $b6) {
            goto yb;
        }
        if (!empty($b6) && "\143\157\x6f\153\151\145\163" === $b6) {
            goto fr;
        }
        if (!empty($b6) && "\164\141\x62\154\x65\163" === $b6) {
            goto I3;
        }
        goto jY;
        zu:
        if (isset($_SESSION[$ez]) && !empty($_SESSION[$ez])) {
            goto bZ;
        }
        $t8 = get_site_option("\x6d\157\62\146\137\x65\x6e\143\162\x79\160\164\x69\x6f\x6e\137\153\x65\171");
        $Hn = false;
        if ("\x6d\157\x5f\62\137\x66\141\143\164\x6f\x72\137\153\x62\141\137\161\x75\x65\163\x74\151\x6f\x6e\163" === $ez) {
            goto Ke;
        }
        $Hn = self::mo2f_get_cookie_values($ez);
        goto BW;
        Ke:
        if (!(isset($_COOKIE["\153\x62\x61\137\161\x75\145\x73\164\151\157\x6e\61"]) && !empty($_COOKIE["\153\x62\x61\137\x71\165\145\x73\164\151\x6f\x6e\x31"]))) {
            goto fd;
        }
        $SA["\161\165\x65\x73\x74\151\157\156"] = self::mo2f_get_cookie_values("\153\x62\x61\x5f\x71\x75\x65\x73\164\151\x6f\156\61");
        $f2["\x71\x75\x65\163\x74\x69\x6f\x6e"] = self::mo2f_get_cookie_values("\153\142\141\137\161\x75\x65\x73\x74\151\157\156\62");
        $Hn = array($SA, $f2);
        fd:
        BW:
        if ($Hn) {
            goto Xa;
        }
        $jg = self::decrypt_data($jg, $t8);
        $iQ = md5($jg);
        $hJ = $Gw->get_user_login_details($ez, $iQ);
        if (!("\x6d\157\137\x32\137\146\141\x63\164\157\x72\x5f\153\x62\141\x5f\x71\165\145\163\164\x69\x6f\x6e\x73" === $ez)) {
            goto CV;
        }
        $hJ = maybe_unserialize($hJ);
        CV:
        return $hJ;
        goto tI;
        Xa:
        return $Hn;
        tI:
        goto Ro;
        bZ:
        return $_SESSION[$ez];
        Ro:
        goto jY;
        yb:
        if (!(isset($_SESSION[$ez]) && !empty($_SESSION[$ez]))) {
            goto RI;
        }
        return $_SESSION[$ez];
        RI:
        goto jY;
        fr:
        $t8 = get_site_option("\x6d\157\x32\146\137\145\156\x63\162\x79\160\x74\x69\x6f\156\x5f\153\x65\x79");
        $Hn = false;
        if ("\x6d\x6f\x5f\x32\x5f\146\141\x63\164\x6f\x72\x5f\153\142\x61\137\x71\x75\145\163\x74\151\157\x6e\163" === $ez) {
            goto ef;
        }
        $Hn = self::mo2f_get_cookie_values($ez);
        goto dR;
        ef:
        if (!(isset($_COOKIE["\x6b\142\141\137\161\165\x65\163\164\x69\x6f\x6e\x31"]) && !empty($_COOKIE["\x6b\x62\x61\137\x71\x75\x65\x73\x74\x69\x6f\x6e\61"]))) {
            goto o1;
        }
        $SA = self::mo2f_get_cookie_values("\x6b\142\x61\x5f\161\x75\x65\x73\x74\151\157\x6e\61");
        $f2 = self::mo2f_get_cookie_values("\153\x62\141\x5f\x71\x75\x65\x73\164\x69\x6f\156\62");
        $Hn = array($SA, $f2);
        o1:
        dR:
        if (!$Hn) {
            goto yw;
        }
        return $Hn;
        yw:
        goto jY;
        I3:
        $t8 = get_site_option("\x6d\157\x32\146\137\145\x6e\143\x72\x79\160\164\x69\157\156\x5f\153\x65\171");
        $jg = self::decrypt_data($jg, $t8);
        $iQ = md5($jg);
        $hJ = $Gw->get_user_login_details($ez, $iQ);
        if (!("\x6d\157\x5f\62\137\146\141\143\x74\x6f\x72\x5f\153\142\141\x5f\161\165\145\x73\164\x69\x6f\156\163" === $ez)) {
            goto Cg;
        }
        $hJ = maybe_unserialize($hJ);
        Cg:
        return $hJ;
        jY:
    }
    public static function mo2f_get_cookie_values($yC)
    {
        $t8 = get_site_option("\x6d\x6f\62\x66\137\145\156\x63\162\171\160\164\x69\x6f\x6e\137\153\x65\x79");
        if (isset($_COOKIE[$yC])) {
            goto qd;
        }
        return false;
        goto pz;
        qd:
        $k7 = self::decrypt_data(base64_decode(sanitize_key(wp_unslash($_COOKIE[$yC]))), $t8);
        if (!self::is_json($k7)) {
            goto ZB;
        }
        $k7 = json_decode($k7);
        ZB:
        if ($k7) {
            goto LC;
        }
        return false;
        goto ej;
        LC:
        $ll = explode("\46", $k7);
        $Hn = $ll[0];
        if (count($ll) === 2) {
            goto PL;
        }
        $wd = new DateTime(array_pop($ll));
        $Hn = implode("\x26", $ll);
        goto jQ;
        PL:
        $wd = new DateTime($ll[1]);
        jQ:
        $uI = new DateTime("\x6e\x6f\167");
        $C_ = $wd->diff($uI);
        $Hp = $C_->format("\x25\151");
        $Se = $Hp <= 5 ? true : false;
        return $Se ? $Hn : false;
        ej:
        pz:
    }
    public static function is_json($WJ)
    {
        return is_string($WJ) && is_array(json_decode($WJ, true)) ? true : false;
    }
    public static function mo2f_set_cookie_values($yC, $Vg)
    {
        $t8 = get_site_option("\155\x6f\x32\146\x5f\x65\156\143\162\x79\160\x74\151\x6f\156\x5f\153\145\171");
        $uI = new DateTime("\156\x6f\167");
        $uI = $uI->format("\131\x2d\x6d\55\x64\x20\110\72\x69\x3a\x73\120");
        $Vg = $Vg . "\46" . $uI;
        $jb = self::encrypt_data($Vg, $t8);
        $_COOKIE[$yC] = base64_encode($jb);
    }
    public static function encrypt_data($mC, $t8)
    {
        $xf = $mC;
        $Ap = "\x41\105\x53\55\x31\62\70\55\x43\102\x43";
        $sH = openssl_cipher_iv_length($Ap);
        $e6 = openssl_random_pseudo_bytes($sH);
        $Mg = openssl_encrypt($xf, $Ap, $t8, $PF = OPENSSL_RAW_DATA, $e6);
        $JK = hash_hmac("\163\150\141\62\x35\x36", $Mg, $t8, $Q4 = true);
        $gk = base64_encode($e6 . $JK . $Mg);
        return $gk;
    }
    public static function unset_session_variables($aD)
    {
        if ("\x61\162\x72\141\x79" === gettype($aD)) {
            goto HT;
        }
        if (!isset($_SESSION[$aD])) {
            goto wx;
        }
        unset($_SESSION[$aD]);
        wx:
        goto oD;
        HT:
        foreach ($aD as $ez) {
            if (!isset($_SESSION[$ez])) {
                goto YE;
            }
            unset($_SESSION[$ez]);
            YE:
            Ww:
        }
        Q_:
        oD:
    }
    public static function unset_cookie_variables($aD)
    {
        if ("\x61\162\162\x61\171" === gettype($aD)) {
            goto g5;
        }
        if (!isset($_COOKIE[$aD])) {
            goto AN;
        }
        setcookie($aD, '', time() - 3600, null, null, null, true);
        AN:
        goto la;
        g5:
        foreach ($aD as $ez) {
            if (!isset($_COOKIE[$ez])) {
                goto RN;
            }
            setcookie($ez, '', time() - 3600, null, null, null, true);
            RN:
            im:
        }
        jH:
        la:
    }
    public static function unset_temp_user_details_in_table($aD, $jg, $GZ = '')
    {
        global $Gw;
        $t8 = get_site_option("\155\x6f\x32\146\137\145\156\x63\162\x79\160\x74\x69\x6f\x6e\x5f\x6b\145\x79");
        $jg = self::decrypt_data($jg, $t8);
        $iQ = md5($jg);
        if ("\x64\145\x73\164\x72\157\x79" === $GZ) {
            goto cv;
        }
        $Gw->save_user_login_details($iQ, array($aD => ''));
        goto Pm;
        cv:
        $Gw->delete_user_login_sessions($iQ);
        Pm:
    }
    public static function get_plugin_name_by_identifier($XF)
    {
        $U4 = get_plugins();
        $Fn = $U4[$XF];
        return $Fn["\116\x61\x6d\145"] ? $Fn["\116\141\155\x65"] : "\116\x6f\x20\x50\154\x75\x67\151\156\x20\x73\145\x6c\x65\x63\x74\x65\x64";
    }
    public static function get_index_value($W1, $ky)
    {
        switch ($W1) {
            case "\107\x4c\117\x42\x41\x4c\x53":
                return isset($GLOBALS[$ky]) ? $GLOBALS[$ky] : false;
            default:
                return false;
        }
        sO:
        sl:
    }
    public static function get_codes_warning_email_content($kB)
    {
        global $ai;
        $jD = "\74\164\x61\x62\154\x65\x20\x63\x65\x6c\x6c\x70\141\144\x64\151\156\x67\75\42\x32\x35\x22\x20\163\164\171\154\x65\75\42\155\141\x72\x67\x69\156\x3a\x30\x70\x78\40\141\x75\x74\157\42\x3e\15\12\40\40\40\40\x20\40\x20\x20\x3c\x74\142\157\x64\171\76\15\xa\40\x20\40\x20\40\x20\x20\40\x3c\x74\162\76\15\12\x20\x20\40\x20\x20\x20\x20\40\74\164\x64\x3e\15\12\x20\40\x20\40\40\40\40\40\x3c\x74\x61\x62\x6c\x65\x20\143\x65\x6c\x6c\x70\x61\x64\144\x69\156\x67\x3d\x22\62\64\42\x20\167\151\x64\164\x68\75\x22\x35\70\x34\160\170\42\40\163\x74\171\x6c\145\x3d\x22\x6d\141\162\x67\151\156\x3a\x30\x20\x61\165\164\157\x3b\155\141\170\55\x77\151\144\x74\150\72\65\70\x34\x70\170\73\142\141\143\153\147\162\x6f\165\156\144\x2d\143\157\154\x6f\162\x3a\43\146\x36\x66\x34\146\x34\73\x62\157\162\144\x65\162\x3a\61\x70\170\40\163\x6f\x6c\151\x64\x20\x23\x61\x38\x61\144\141\144\x22\76\15\xa\40\40\40\40\x20\40\x20\x20\74\164\x62\x6f\x64\171\76\xd\12\x20\x20\x20\x20\40\40\x20\x20\x3c\x74\162\76\xd\12\40\40\40\40\x20\40\x20\40\x3c\x74\144\76\x3c\x69\155\x67\40\x73\x72\x63\75\x22" . esc_url($ai) . "\x69\x6e\x63\x6c\x75\x64\145\x73\57\151\x6d\x61\147\x65\163\57\170\145\x63\x75\x72\151\x66\171\55\154\x6f\147\157\x2e\x70\x6e\147\42\x20\141\x6c\x74\75\x22\130\145\x63\x75\162\x69\146\171\x22\40\x73\164\x79\154\145\x3d\x22\143\x6f\154\x6f\x72\x3a\x23\65\x66\x62\63\63\66\73\x74\145\x78\164\x2d\x64\x65\143\157\162\x61\x74\x69\157\x6e\72\156\157\x6e\145\73\x64\151\x73\160\154\141\x79\x3a\x62\x6c\157\x63\x6b\x3b\167\x69\144\164\150\x3a\x61\165\164\157\73\150\x65\x69\x67\150\x74\72\141\x75\164\x6f\x3b\x6d\141\x78\x2d\x68\x65\x69\x67\150\x74\72\63\x35\160\170\42\x20\143\154\x61\163\x73\x3d\x22\103\x54\157\127\x55\x64\42\x3e\74\57\x74\x64\76\xd\12\40\x20\x20\x20\x20\40\x20\40\74\x2f\164\x72\76\xd\12\x20\40\x20\40\40\40\x20\x20\x3c\x2f\164\142\x6f\144\171\76\xd\xa\40\40\40\x20\x20\x20\x20\40\74\x2f\x74\x61\142\x6c\145\x3e\xd\12\x20\40\40\40\40\40\x20\x20\74\164\x61\142\154\145\40\x63\x65\x6c\154\x70\x61\144\144\x69\156\147\75\42\62\64\x22\x20\163\164\x79\154\145\x3d\x22\142\141\x63\153\x67\x72\x6f\165\x6e\144\72\43\146\146\x66\73\142\157\162\144\145\x72\x3a\61\x70\170\x20\163\157\x6c\151\x64\x20\x23\x61\70\141\x64\x61\x64\73\167\x69\144\164\x68\x3a\x35\x38\64\x70\x78\73\x62\x6f\162\144\x65\x72\55\x74\x6f\x70\72\156\157\x6e\145\x3b\x63\157\x6c\157\162\72\43\x34\144\64\x62\x34\x38\73\146\x6f\x6e\x74\x2d\146\141\x6d\x69\154\171\72\x41\162\151\x61\154\54\110\x65\x6c\x76\145\164\151\x63\141\x2c\x73\x61\156\163\55\163\145\x72\x69\x66\x3b\x66\157\x6e\164\55\x73\151\x7a\x65\x3a\61\63\x70\170\x3b\x6c\x69\156\145\55\x68\x65\151\x67\150\164\x3a\x31\70\x70\x78\x22\x3e\xd\xa\40\40\40\40\x20\x20\x20\x20\74\164\x62\157\144\171\76\15\12\x20\x20\x20\x20\x20\40\40\x20\x3c\x74\162\x3e\15\12\x20\x20\40\40\x20\40\40\x20\x3c\x74\144\x3e\15\12\40\x20\x20\x20\x20\x20\40\x20\74\160\x20\163\164\171\154\145\x3d\x22\155\x61\x72\x67\x69\156\55\x74\x6f\160\x3a\x30\73\x6d\141\162\147\151\156\55\x62\x6f\x74\164\157\x6d\72\x32\60\160\170\x22\76\x44\145\141\x72\x20\x43\165\163\x74\x6f\x6d\145\x72\54\74\57\x70\76\15\xa\x20\40\x20\40\x20\x20\x20\40\74\x70\40\x73\x74\x79\154\x65\x3d\x22\155\141\x72\147\x69\156\55\164\157\x70\x3a\60\73\155\141\x72\147\x69\x6e\55\x62\157\x74\x74\157\155\x3a\61\60\160\x78\x22\76\131\x6f\165\x20\x68\x61\x76\x65\40" . $kB . "\x20\142\141\143\x6b\x75\160\40\143\157\144\x65\163\40\162\145\x6d\141\x69\156\151\156\x67\56\40\x4b\x69\156\144\x6c\171\x20\162\145\143\157\x6e\x66\151\x67\x75\x72\145\40\x79\157\165\x72\40\164\167\157\x2d\146\x61\x63\x74\157\x72\40\164\157\40\x61\x76\x6f\151\144\x20\142\145\x69\x6e\x67\x20\154\x6f\143\x6b\145\144\40\x6f\x75\164\56\74\x2f\142\x3e\x3c\57\x70\x3e\15\xa\40\40\40\40\x20\x20\40\x20\74\x70\x20\163\164\x79\154\x65\75\42\155\x61\162\147\x69\x6e\x2d\x74\157\x70\x3a\x30\x3b\x6d\141\162\147\x69\156\x2d\x62\157\x74\x74\157\155\x3a\x31\x35\160\170\42\x3e\124\150\141\156\x6b\x20\x79\157\165\54\x3c\142\x72\76\155\151\156\x69\x4f\162\x61\x6e\x67\x65\x20\x54\x65\x61\155\x3c\x2f\160\x3e\15\12\40\40\x20\40\40\x20\40\x20\74\160\x20\x73\x74\x79\154\145\x3d\x22\x6d\x61\x72\x67\x69\156\55\164\x6f\160\72\60\x3b\155\x61\x72\147\x69\x6e\x2d\x62\157\164\x74\157\x6d\72\60\x70\170\x3b\146\157\x6e\164\x2d\x73\x69\x7a\145\72\x31\61\x70\170\42\76\x44\151\x73\143\154\x61\151\155\x65\162\72\x20\124\150\x69\x73\x20\145\x6d\141\x69\154\x20\x61\156\x64\x20\x61\156\171\x20\x66\x69\x6c\x65\x73\40\x74\162\x61\x6e\163\x6d\x69\x74\x74\145\x64\40\167\x69\164\150\x20\151\x74\40\141\x72\145\40\x63\x6f\156\146\151\x64\145\x6e\x74\151\x61\x6c\x20\141\156\x64\40\x69\156\164\x65\156\x64\145\x64\40\163\x6f\x6c\145\154\171\40\x66\x6f\162\40\x74\150\145\x20\165\x73\145\40\x6f\146\x20\164\150\x65\x20\151\x6e\144\x69\166\151\144\165\x61\x6c\40\157\x72\40\x65\x6e\164\x69\164\x79\x20\164\157\40\167\150\157\x6d\40\x74\x68\145\x79\40\141\162\x65\40\141\144\x64\162\145\x73\x73\145\x64\x2e\74\x2f\160\76\15\12\x20\40\40\40\x20\40\x20\40\74\57\x64\x69\x76\x3e\74\x2f\x64\151\x76\76\x3c\x2f\164\x64\x3e\15\12\40\40\x20\40\40\x20\40\x20\x3c\x2f\x74\x72\x3e\xd\12\40\x20\x20\x20\40\40\40\x20\74\57\164\142\x6f\x64\x79\76\xd\xa\x20\x20\x20\40\x20\x20\40\40\74\x2f\x74\141\x62\x6c\145\x3e\15\xa\x20\x20\40\x20\x20\40\x20\40\74\57\164\x64\x3e\15\12\40\x20\x20\40\x20\40\40\x20\x3c\57\x74\x72\76\15\xa\x20\x20\x20\40\40\x20\40\x20\x3c\57\x74\x62\x6f\x64\x79\76\xd\12\40\x20\40\40\40\40\40\x20\74\x2f\x74\141\142\154\145\x3e";
        return $jD;
    }
    public static function mo2f_email_backup_codes($oB, $y2)
    {
        $a3 = MoWpnsUtility::get_mo2f_db_option("\155\157\62\x66\x5f\62\x66\141\x5f\x62\141\x63\x6b\165\160\137\x63\x6f\144\145\x5f\145\155\141\151\x6c\137\163\165\x62\x6a\145\143\164", "\163\151\x74\145\x5f\x6f\x70\164\151\x6f\x6e");
        $Tp = array("\103\157\156\x74\x65\x6e\x74\55\124\171\x70\145\72\x20\x74\x65\x78\164\x2f\150\164\x6d\x6c\73\40\x63\x68\141\x72\163\145\x74\75\125\x54\106\x2d\70");
        $jD = MoWpnsUtility::get_mo2f_db_option("\155\x6f\62\146\x5f\x62\141\143\153\x75\160\x5f\x63\157\x64\145\x5f\x65\x6d\x61\151\154\137\x74\x65\x6d\160\x6c\141\164\145", "\163\x69\164\145\137\157\x70\164\151\157\156");
        $jD = str_replace("\x23\x23\143\157\144\145\61\x23\x23", isset($oB[0]) ? $oB[0] : '', $jD);
        $jD = str_replace("\43\x23\143\x6f\144\x65\x32\x23\43", isset($oB[1]) ? $oB[1] : '', $jD);
        $jD = str_replace("\43\x23\143\157\144\145\63\x23\x23", isset($oB[2]) ? $oB[2] : '', $jD);
        $jD = str_replace("\43\43\x63\157\x64\145\64\43\43", isset($oB[3]) ? $oB[3] : '', $jD);
        $jD = str_replace("\43\43\143\x6f\x64\x65\x35\43\43", isset($oB[4]) ? $oB[4] : '', $jD);
        $vv = wp_mail($y2, $a3, $jD, $Tp);
        return $vv;
    }
    public static function mo2f_download_backup_codes($L4, $oB)
    {
        update_user_meta($L4, "\x6d\x6f\x5f\x62\141\x63\153\x75\160\x5f\x63\157\x64\x65\x5f\x64\157\x77\x6e\154\157\141\144\x65\144", 1);
        header("\x43\157\x6e\164\x65\156\x74\55\x44\x69\x73\x70\157\163\x69\164\151\157\x6e\x3a\x20\141\164\164\x61\143\150\155\145\x6e\164\x3b\40\146\151\x6c\145\x6e\x61\x6d\145\75\155\151\x6e\x69\117\162\x61\156\x67\x65\x32\55\x66\x61\143\x74\x6f\162\55\x42\x61\x63\x6b\165\160\x43\157\144\x65\163\56\164\x78\164");
        echo "\124\x77\157\x20\x46\x61\143\164\x6f\162\x20\x42\x61\x63\153\x75\160\x20\x43\x6f\x64\145\163\x3a" . PHP_EOL . PHP_EOL;
        echo "\x54\x68\145\x73\145\x20\x61\162\x65\40\x74\150\x65\40\x63\x6f\x64\x65\x73\40\x74\x68\x61\x74\40\x63\141\156\x20\x62\145\40\165\x73\145\x64\40\151\x6e\40\143\141\163\145\x20\x79\157\165\40\154\157\x73\x65\40\x79\157\165\x72\x20\160\x68\x6f\x6e\x65\x20\157\x72\x20\143\141\x6e\156\157\x74\x20\141\143\143\145\163\163\40\171\157\x75\x72\x20\145\155\x61\x69\154\x2e\x20\x50\x6c\x65\x61\163\145\40\162\x65\143\x6f\156\x66\151\x67\x75\162\x65\x20\x79\157\x75\x72\40\x61\x75\164\x68\x65\x6e\164\151\143\x61\164\x69\157\x6e\40\x6d\145\x74\x68\x6f\x64\40\141\146\164\145\162\40\154\x6f\x67\151\x6e\56" . PHP_EOL . "\x50\x6c\145\141\x73\145\40\165\163\x65\x20\164\x68\151\163\40\143\x61\x72\x65\x66\165\x6c\x6c\171\x20\141\x73\40\x65\x61\143\150\40\143\x6f\144\x65\40\x63\141\156\40\x6f\x6e\x6c\x79\40\x62\145\x20\165\163\x65\x64\40\157\x6e\x63\145\x2e\x20\120\154\145\141\x73\x65\40\x64\x6f\40\156\157\164\x20\163\150\141\162\x65\x20\164\x68\x65\163\145\40\143\157\144\145\x73\40\167\x69\x74\150\x20\x61\x6e\x79\x6f\x6e\145\x2e\x2e" . PHP_EOL . PHP_EOL;
        $uD = count($oB);
        $T8 = 0;
        wh:
        if (!($T8 < $uD)) {
            goto lj;
        }
        $fr = $oB[$T8];
        echo intval($T8 + 1) . "\56\40" . esc_html($fr) . "\40";
        QM:
        $T8++;
        goto wh;
        lj:
        exit;
    }
    public static function mo2f_debug_file($K0)
    {
        if (!(MoWpnsUtility::get_mo2f_db_option("\155\x6f\62\x66\x5f\145\156\141\x62\x6c\x65\137\x64\x65\x62\x75\147\137\154\157\147", "\x73\x69\164\x65\137\x6f\x70\x74\x69\x6f\156") === "\x31")) {
            goto s0;
        }
        $gC = wp_upload_dir();
        $gC = $gC["\x62\x61\163\x65\144\151\x72"] . DIRECTORY_SEPARATOR;
        $ni = "\x6d\x69\156\x69\157\x72\141\156\x67\x65\x5f\144\x65\x62\165\147\x5f\154\157\147\x2e\164\x78\x74";
        $mC = "\133" . gmdate("\x59\x2f\155\57\x64") . "\x20" . time() . "\135\x3a" . $K0 . "\xa";
        $DY = fopen($gC . DIRECTORY_SEPARATOR . $ni, "\x61\x2b");
        fwrite($DY, $mC);
        fclose($DY);
        s0:
    }
    public static function mo2f_show_error_on_login($jD)
    {
        $mC = array("\156\157\x74\151\x63\x65" => "\x3c\144\151\166\x20\x73\164\171\154\x65\x3d\x22\x62\157\x72\x64\x65\162\55\x6c\145\x66\164\72\63\x70\170\x20\x73\157\154\x69\x64\x20\43\x64\143\63\x32\x33\x32\73\42\76\46\156\x62\163\160\73\x20" . $jD . '');
        return $mC;
    }
}
zX:
