<?php


namespace TwoFA\Onprem;

use TwoFA\Onprem\Mo2f_KBA_Handler;
use TwoFA\Cloud\Customer_Cloud_Setup;
use TwoFA\Onprem\MO2f_Cloud_Onprem_Interface;
use TwoFA\Helper\MoWpnsUtility;
use TwoFA\Onprem\Miniorange_Password_2Factor_Login;
use TwoFA\Traits\Instance;
use TwoFA\Helper\MoWpnsConstants;
use TwoFA\Handler\Miniorange_Mobile_Login;
use TwoFA\Database\Mo2fDB;
use TwoFA\Helper\MocURL;
use WP_Error;
use TwoFA\Cloud\Two_Factor_Setup;
use TwoFA\Cloud\Mo2f_Cloud_Utility;
use TwoFA\Helper\Mo2f_Common_Helper;
use TwoFA\Helper\MoWpnsMessages;
if (defined("\101\102\x53\x50\x41\124\x48")) {
    goto l1;
}
exit;
l1:
require "\143\154\141\x73\x73\x2d\x6d\x69\x6e\x69\x6f\x72\141\x6e\147\x65\55\160\141\x73\x73\167\x6f\162\x64\x2d\62\146\x61\143\164\157\x72\55\154\x6f\147\x69\x6e\56\160\x68\x70";
if (class_exists("\x4d\151\x6e\x69\157\162\x61\156\147\145\x5f\101\x75\164\x68\145\x6e\164\x69\x63\x61\x74\x69\157\156")) {
    goto Lp;
}
class Miniorange_Authentication
{
    use Instance;
    private $default_customer_key = "\61\66\x35\x35\65";
    private $default_api_key = "\x66\106\144\x32\x58\143\x76\x54\x47\x44\145\x6d\x5a\166\142\x77\x31\x62\143\x55\145\163\116\x4a\x57\x45\161\113\x62\x62\x55\x71";
    private $mo2f_onprem_cloud_obj;
    public function __construct()
    {
        $this->mo2f_onprem_cloud_obj = MO2f_Cloud_Onprem_Interface::instance();
        add_action("\141\x64\155\x69\156\137\151\156\x69\x74", array($this, "\x6d\157\62\146\x5f\x61\x75\x74\150\x5f\x73\x61\x76\x65\137\163\x65\x74\164\x69\156\x67\163"));
        add_action("\160\x6c\x75\x67\x69\156\x73\137\x6c\x6f\x61\x64\x65\x64", array($this, "\x6d\x6f\x32\146\x5f\x75\160\x64\141\164\145\x5f\x64\x62\137\x63\x68\x65\143\x6b"));
        $Yt = apply_filters("\x6d\157\62\146\137\151\163\137\154\166\x5f\x6e\145\x65\144\x65\x64", false);
        if (!((!$Yt || get_site_option("\155\x6f\62\x66\x61\137\154\x6b")) && (int) MoWpnsUtility::get_mo2f_db_option("\155\x6f\x32\146\x5f\141\x63\x74\x69\166\x61\164\x65\x5f\x70\x6c\x75\x67\151\156", "\163\x69\164\x65\137\x6f\160\x74\x69\x6f\156") === 1)) {
            goto na;
        }
        $kZ = new Miniorange_Password_2Factor_Login();
        add_action("\x69\x6e\151\164", array($kZ, "\155\151\156\x69\157\x72\x61\156\147\x65\137\160\141\163\163\62\x6c\157\147\x69\156\137\x72\x65\x64\x69\x72\x65\143\x74"));
        add_action("\x6c\157\x67\151\156\x5f\146\157\162\x6d", array($kZ, "\155\x6f\137\62\x5f\x66\x61\143\x74\x6f\162\137\x70\x61\163\x73\62\154\157\x67\x69\x6e\137\163\x68\157\x77\x5f\167\x70\137\154\x6f\147\151\156\x5f\x66\x6f\x72\x6d"), 10);
        add_filter("\x6d\x6f\62\x66\137\163\150\157\x72\x74\x63\x6f\144\145\137\x72\x62\141\x5f\x67\x61\165\x74\x68", array($this->mo2f_onprem_cloud_obj, "\155\x6f\x32\146\137\166\141\154\x69\144\x61\x74\x65\x5f\147\157\157\147\x6c\x65\137\141\x75\x74\150"), 10, 3);
        add_filter("\x6d\x6f\x32\x66\x5f\x73\x68\x6f\162\164\143\157\x64\x65\137\x6b\x62\x61", array($this->mo2f_onprem_cloud_obj, "\155\157\62\146\137\x72\145\x67\x69\x73\x74\x65\162\137\153\x62\x61\137\144\145\164\x61\x69\154\x73"), 10, 7);
        add_filter("\155\157\62\146\137\165\x70\x64\141\164\x65\137\x69\156\x66\x6f", array($this->mo2f_onprem_cloud_obj, "\x6d\157\62\x66\x5f\165\x70\144\141\164\x65\137\x75\163\x65\x72\137\151\156\146\x6f"), 10, 5);
        add_action("\155\157\62\146\137\x73\x68\x6f\162\164\143\x6f\144\145\x5f\146\x6f\x72\x6d\137\146\151\145\x6c\x64\163", array($kZ, "\x6d\151\156\x69\x6f\x72\x61\x6e\147\x65\x5f\x70\141\163\163\x32\154\157\x67\151\x6e\x5f\x66\157\x72\155\137\x66\x69\x65\154\144\163"), 10, 5);
        add_action("\x64\145\x6c\145\164\x65\x5f\x75\163\145\x72", array($this, "\155\157\62\146\x5f\144\145\154\145\x74\x65\137\165\163\x65\162"));
        add_filter("\155\157\x32\146\x5f\147\x61\165\x74\x68\x5f\x73\145\x72\166\x69\x63\x65", array($this->mo2f_onprem_cloud_obj, "\x6d\157\x32\146\x5f\x67\157\x6f\x67\154\145\137\141\x75\x74\x68\137\163\x65\x72\x76\151\x63\145"), 10, 1);
        if (!(get_site_option("\x6d\157\x5f\62\146\141\143\164\157\162\x5f\x61\x64\x6d\151\156\x5f\162\145\147\151\x73\164\162\x61\164\x69\157\x6e\x5f\163\x74\141\164\x75\163") === "\x4d\117\x5f\x32\x5f\106\101\x43\x54\x4f\122\137\x43\125\123\124\117\x4d\x45\122\137\122\105\107\x49\123\124\105\122\x45\104\x5f\x53\x55\x43\x43\x45\x53\x53" || MO2F_IS_ONPREM)) {
            goto PC;
        }
        remove_filter("\141\x75\164\150\145\156\x74\151\143\x61\x74\145", "\167\x70\x5f\141\x75\164\150\145\x6e\x74\151\143\141\x74\145\x5f\165\x73\x65\162\x6e\141\x6d\145\137\160\x61\163\163\x77\157\x72\x64", 20);
        $D0 = new Mo2f_Main_Handler();
        add_filter("\x61\x75\x74\150\145\x6e\164\x69\143\x61\164\145", array($D0, "\155\157\62\x66\137\x63\x68\145\143\153\137\x75\x73\145\162\x6e\x61\x6d\x65\x5f\160\141\x73\163\x77\x6f\x72\144"), 99999, 4);
        add_action("\151\156\x69\x74", array($kZ, "\x6d\x69\156\x69\157\162\x61\156\x67\x65\x5f\160\141\163\x73\x32\x6c\x6f\147\x69\156\137\x72\145\144\151\162\145\x63\164"));
        add_action("\x6c\x6f\x67\151\156\137\x66\157\162\x6d", array($kZ, "\155\157\x5f\x32\x5f\x66\x61\143\x74\x6f\x72\x5f\x70\x61\163\x73\62\x6c\x6f\147\151\156\137\163\x68\x6f\167\x5f\167\x70\137\154\157\147\151\x6e\x5f\x66\157\162\155"), 10);
        add_action("\154\x6f\x67\x69\156\x5f\145\x6e\161\165\145\x75\x65\x5f\163\x63\x72\x69\x70\164\x73", array($kZ, "\155\x6f\137\62\x5f\146\x61\143\164\157\x72\137\x65\156\x61\x62\154\145\137\x6a\161\x75\145\162\171\137\144\x65\146\x61\165\154\164\x5f\154\x6f\x67\151\156"));
        if (!get_site_option("\155\157\x32\146\137\x77\157\x6f\x63\157\155\x6d\145\162\x63\x65\x5f\x6c\x6f\x67\x69\156\137\x70\x72\x6f\155\160\164")) {
            goto bo;
        }
        add_action("\x77\157\157\143\157\x6d\x6d\145\x72\143\x65\137\x6c\x6f\x67\x69\x6e\137\146\x6f\x72\x6d", array($kZ, "\x6d\x6f\137\62\137\x66\x61\143\x74\157\x72\137\160\x61\x73\163\62\154\157\x67\151\x6e\137\163\x68\x6f\x77\x5f\x77\x70\137\154\x6f\x67\151\156\x5f\x66\x6f\162\x6d"));
        bo:
        add_action("\x77\x70\137\145\x6e\161\165\x65\165\145\x5f\163\x63\162\x69\160\x74\163", array($kZ, "\x6d\x6f\x5f\62\137\146\x61\143\x74\x6f\x72\x5f\x65\x6e\x61\142\x6c\145\137\x6a\x71\165\145\162\171\x5f\144\145\x66\x61\165\154\x74\x5f\x6c\x6f\147\151\156"));
        add_action("\x6d\151\156\x69\157\162\141\156\x67\x65\x5f\x70\162\x65\x5f\x61\165\164\150\x65\x6e\164\151\x63\141\x74\145\137\165\x73\x65\162\x5f\x6c\x6f\x67\151\156", array($D0, "\x6d\x6f\62\x66\x5f\x63\x68\x65\143\153\x5f\x75\x73\145\x72\156\x61\155\x65\137\160\141\x73\x73\167\157\x72\x64"), 1, 4);
        add_action("\155\x69\156\x69\157\162\x61\x6e\x67\145\x5f\160\157\163\x74\x5f\141\165\164\x68\x65\156\164\x69\x63\141\x74\x65\137\x75\163\145\162\x5f\x6c\x6f\x67\x69\156", array($kZ, "\x6d\x69\x6e\x69\x6f\x72\141\x6e\x67\x65\137\151\156\x69\x74\x69\x61\164\145\137\x32\x6e\144\137\146\141\x63\164\157\162"), 1, 3);
        add_action("\x6d\151\156\151\157\x72\x61\156\147\145\x5f\x63\x6f\x6c\154\x65\x63\x74\x5f\x61\164\164\x72\x69\142\165\164\145\x73\x5f\146\x6f\x72\137\141\x75\164\150\x65\156\x74\x69\143\141\164\145\x64\x5f\x75\x73\x65\x72", array($kZ, "\x6d\157\x32\x66\x5f\x63\157\154\x6c\x65\143\x74\x5f\x64\x65\166\x69\x63\145\137\x61\164\x74\x72\151\142\x75\164\145\163\137\x66\157\x72\137\x61\165\x74\150\x65\x6e\164\151\x63\141\164\x65\144\137\165\x73\145\162"), 1, 2);
        PC:
        na:
    }
    public function mo2f_define_global()
    {
        global $Gw;
        $Gw = new Mo2fDB();
    }
    public function mo2f_delete_user($v1)
    {
        global $Gw;
        delete_user_meta($v1, "\155\157\62\x66\137\153\x62\141\x5f\x63\x68\141\x6c\x6c\145\x6e\147\145");
        delete_user_meta($v1, "\x6d\157\x32\x66\137\62\x46\x41\137\x6d\x65\164\x68\157\x64\x5f\164\x6f\137\x63\157\x6e\146\151\x67\x75\x72\x65");
        delete_user_meta($v1, MoWpnsConstants::SECURITY_QUESTIONS);
        delete_user_meta($v1, "\x6d\157\x32\146\137\143\x68\141\x74\x5f\151\x64");
        $Gw->delete_user_details($v1);
        delete_user_meta($v1, "\x6d\x6f\x32\x66\137\62\106\101\x5f\155\145\164\150\157\144\x5f\x74\x6f\x5f\x74\145\163\x74");
        delete_site_option("\155\157\62\x66\x5f\x67\x72\x61\x63\145\x5f\x70\145\x72\151\157\x64\137\x73\x74\141\164\x75\163\137" . $v1);
    }
    public function mo2f_update_db_check()
    {
        $qP = wp_get_current_user()->ID;
        add_option("\x6d\x6f\62\x66\137\157\x6e\x70\162\145\x6d\x5f\141\x64\x6d\151\156", $qP);
        if (!is_multisite()) {
            goto T4;
        }
        add_site_option("\x6d\x6f\62\x66\x61\137\x73\x75\x70\x65\162\141\144\155\x69\156", 1);
        T4:
        if (!(get_site_option("\x6d\x6f\62\x66\x5f\156\x65\164\x77\x6f\x72\153\x5f\146\145\141\164\x75\162\x65\163", "\156\x6f\164\x5f\145\170\151\164\163") === "\156\157\x74\x5f\x65\x78\x69\164\x73")) {
            goto Kc;
        }
        do_action("\x6d\157\62\146\137\x6e\145\164\x77\157\162\x6b\x5f\143\x72\145\x61\x74\x65\x5f\x64\x62");
        update_site_option("\155\157\x32\146\x5f\x6e\145\164\167\157\162\153\x5f\146\x65\x61\x74\165\162\x65\x73", 1);
        Kc:
        if (!(get_site_option("\155\x6f\x32\146\x5f\145\156\x63\162\x79\160\164\151\x6f\x6e\x5f\x6b\x65\x79", "\x6e\x6f\x74\137\x65\x78\151\164\x73") === "\156\157\x74\x5f\x65\x78\x69\x74\163")) {
            goto tl;
        }
        $O8 = MO2f_Utility::random_str(16);
        update_site_option("\x6d\x6f\62\146\137\x65\156\143\162\171\160\164\151\x6f\156\137\153\145\171", $O8);
        tl:
        global $Gw;
        $v1 = get_site_option("\x6d\x6f\x32\146\x5f\155\151\x6e\151\x6f\162\x61\x6e\x67\x65\137\141\x64\x6d\151\156");
        $sh = get_site_option("\155\x6f\x32\x66\137\x64\x62\166\x65\162\163\x69\x6f\x6e");
        if (!($sh < MoWpnsConstants::DB_VERSION)) {
            goto eJ;
        }
        update_site_option("\155\x6f\x32\x66\x5f\144\142\166\x65\x72\163\151\157\156", MoWpnsConstants::DB_VERSION);
        $Gw->generate_tables();
        eJ:
        if (!MO2F_IS_ONPREM) {
            goto x7;
        }
        $un = new Mo2fDB();
        $fT = get_site_option("\x6d\x6f\x32\x66\137\x75\163\145\x72\x5f\x73\171\156\x63");
        if (!($fT < 1)) {
            goto Wb;
        }
        update_site_option("\x6d\157\x32\146\137\165\x73\x65\162\x5f\x73\x79\x6e\143", 1);
        $un->get_all_onprem_userids();
        Wb:
        x7:
        if (!($v1 && !get_site_option("\155\x6f\x32\x66\137\x6c\157\147\x69\156\x5f\157\x70\x74\151\157\156\x5f\x75\160\144\x61\164\x65\144"))) {
            goto p6;
        }
        $JQ = $Gw->check_if_table_exists();
        if (!$JQ) {
            goto Y2;
        }
        $Cp = $Gw->check_if_user_column_exists($v1);
        if (!$Cp) {
            goto Qk;
        }
        $OL = $Gw->get_user_detail("\155\x6f\x32\x66\x5f\x63\157\156\x66\x69\x67\x75\x72\x65\144\137\62\106\x41\x5f\x6d\145\164\150\157\144", $v1);
        update_site_option("\155\x6f\62\x66\x5f\x6c\157\147\151\x6e\x5f\157\160\164\x69\157\156\x5f\165\x70\144\x61\x74\145\144", 1);
        Qk:
        Y2:
        p6:
    }
    public function mo2f_auth_save_settings()
    {
        $Yt = apply_filters("\x6d\x6f\x32\x66\x5f\151\163\137\154\166\137\x6e\x65\x65\x64\145\144", false);
        if (!(get_site_option("\x6d\x6f\x32\x66\137\160\154\x75\147\x69\x6e\137\162\145\x64\x69\162\x65\x63\164") && !$Yt)) {
            goto eD;
        }
        delete_site_option("\155\x6f\x32\146\x5f\160\154\165\x67\151\156\x5f\x72\145\144\x69\162\145\x63\164");
        $a_ = add_query_arg(array("\160\x61\x67\x65" => "\155\157\62\x66\x2d\163\145\x74\x75\x70\x2d\x77\151\x7a\x61\162\x64", "\143\x75\x72\162\145\x6e\x74\x2d\163\164\x65\160" => "\x77\x65\x6c\x63\x6f\x6d\x65"), admin_url("\141\144\x6d\151\156\56\x70\150\160"));
        wp_safe_redirect(esc_url_raw($a_));
        exit;
        eD:
        if (!(array_key_exists("\160\x61\147\x65", $_REQUEST) && sanitize_text_field(wp_unslash($_REQUEST["\160\141\147\145"])) === "\x6d\157\x5f\x32\x66\x61\x5f\x74\167\157\137\146\x61")) {
            goto Ik;
        }
        if (!(!session_id() || session_id() === '' || !isset($_SESSION))) {
            goto TB;
        }
        if (!(session_status() !== PHP_SESSION_DISABLED)) {
            goto Fg;
        }
        session_start();
        Fg:
        TB:
        Ik:
        global $user;
        global $Gw;
        $rY = $this->default_customer_key;
        $n4 = $this->default_api_key;
        $pd = new MoWpnsMessages();
        $cB = new Mo2f_Common_Helper();
        $user = wp_get_current_user();
        $v1 = $user->ID;
        if (!current_user_can("\155\x61\156\141\x67\145\x5f\x6f\x70\x74\x69\157\x6e\x73")) {
            goto yN;
        }
        if (!(strlen(get_site_option("\x6d\157\62\x66\x5f\145\x6e\143\162\x79\x70\164\151\157\156\137\153\145\x79")) > 17)) {
            goto BC;
        }
        $O8 = MO2f_Utility::random_str(16);
        update_site_option("\x6d\x6f\62\x66\137\x65\156\x63\162\x79\x70\x74\x69\x6f\x6e\137\153\x65\171", $O8);
        BC:
        if (isset($_POST["\x6f\x70\x74\151\157\x6e"]) && sanitize_text_field(wp_unslash($_POST["\x6f\x70\164\151\x6f\x6e"])) === "\155\x6f\137\x61\x75\164\x68\137\144\145\x61\x63\x74\151\166\141\164\x65\137\x61\143\143\157\x75\156\x74") {
            goto rE;
        }
        if (isset($_POST["\x6f\160\164\151\157\x6e"]) && sanitize_text_field(wp_unslash($_POST["\x6f\x70\164\151\x6f\x6e"])) === "\x6d\157\137\x61\x75\164\150\x5f\x72\145\155\x6f\x76\x65\x5f\141\x63\x63\157\165\156\x74") {
            goto cc;
        }
        if (isset($_POST["\157\160\x74\x69\x6f\156"]) && sanitize_text_field(wp_unslash($_POST["\x6f\x70\164\151\x6f\x6e"])) === "\155\x6f\x32\146\x5f\x73\x6b\x69\x70\x6c\x6f\x67\151\x6e") {
            goto Qt;
        }
        if (isset($_POST["\x6f\x70\164\151\157\x6e"]) && sanitize_text_field(wp_unslash($_POST["\x6f\160\x74\x69\x6f\x6e"])) === "\155\157\x32\x66\x5f\165\163\x65\162\x6c\x6f\x67\157\x75\164") {
            goto KQ;
        }
        if (isset($_POST["\157\x70\164\151\x6f\x6e"]) && sanitize_text_field(wp_unslash($_POST["\x6f\160\164\151\x6f\x6e"])) === "\x6d\x6f\x5f\x32\146\x61\x63\164\x6f\162\x5f\x72\145\163\x65\x6e\x64\x5f\157\x74\x70") {
            goto BP;
        }
        if (isset($_POST["\157\x70\164\x69\157\156"]) && sanitize_text_field(wp_unslash($_POST["\x6f\x70\x74\x69\x6f\156"])) === "\155\157\x32\146\137\144\x69\163\155\151\x73\x73\137\156\x6f\164\151\143\145\137\157\x70\x74\x69\x6f\x6e") {
            goto eo;
        }
        if (isset($_POST["\157\160\164\151\157\156"]) && sanitize_text_field(wp_unslash($_POST["\x6f\160\164\x69\x6f\x6e"])) === "\167\157\157\143\x6f\x6d\155\x65\x72\143\x65\137\144\151\163\x61\142\154\x65\x5f\154\157\147\x69\156\137\x70\x72\x6f\155\160\x74") {
            goto Lb;
        }
        goto Z4;
        rE:
        $dk = isset($_POST["\155\x6f\x5f\x61\165\164\x68\x5f\144\x65\141\x63\x74\x69\x76\141\164\x65\137\141\x63\143\157\165\156\164\x5f\x6e\157\156\x63\145"]) ? sanitize_key(wp_unslash($_POST["\x6d\157\137\141\x75\164\150\x5f\x64\145\x61\x63\164\151\166\x61\x74\x65\x5f\141\x63\143\x6f\x75\156\164\137\156\x6f\156\143\145"])) : null;
        if (!wp_verify_nonce($dk, "\155\x6f\x2d\141\165\x74\x68\55\144\x65\141\x63\164\151\x76\x61\x74\x65\x2d\x61\x63\143\157\x75\156\164\x2d\x6e\x6f\x6e\143\145")) {
            goto gZ;
        }
        $xz = admin_url("\x70\154\x75\x67\151\x6e\163\x2e\160\150\160");
        wp_safe_redirect($xz);
        exit;
        goto nx;
        gZ:
        $jY = new WP_Error();
        $jY->add("\145\x6d\x70\164\171\x5f\x75\x73\145\x72\x6e\x61\x6d\x65", "\74\x73\164\x72\157\156\x67\76" . esc_html__("\105\x52\x52\117\x52", "\155\151\156\151\157\162\141\x6e\147\x65\x2d\x32\x2d\x66\141\x63\x74\x6f\162\55\141\165\164\x68\x65\x6e\164\x69\143\141\x74\151\x6f\x6e") . "\x3c\x2f\163\164\162\x6f\x6e\147\76\x3a\x20" . esc_html__("\x49\x6e\166\x61\x6c\151\x64\x20\122\x65\161\165\145\x73\164\56", "\x6d\151\x6e\151\157\x72\x61\156\x67\145\55\62\55\x66\141\x63\164\157\162\x2d\x61\165\x74\x68\x65\156\164\x69\x63\x61\164\151\x6f\x6e"));
        return $jY;
        nx:
        goto Z4;
        cc:
        $dk = isset($_POST["\155\157\x5f\x61\x75\x74\150\137\x72\145\x6d\x6f\166\145\137\141\143\143\x6f\165\156\164\x5f\x6e\x6f\156\143\x65"]) ? sanitize_key(wp_unslash($_POST["\x6d\x6f\137\141\x75\x74\150\x5f\x72\x65\x6d\x6f\166\x65\x5f\141\x63\x63\157\x75\x6e\x74\137\156\157\156\143\145"])) : null;
        if (!wp_verify_nonce($dk, "\x6d\x6f\55\x61\x75\x74\x68\55\162\145\155\157\166\145\55\141\143\143\157\x75\156\164\x2d\x6e\157\x6e\x63\x65")) {
            goto wA;
        }
        update_site_option("\155\157\x32\146\x5f\x72\x65\x67\151\163\x74\145\x72\137\167\151\164\x68\x5f\x61\156\157\x74\150\x65\162\137\145\x6d\141\151\154", 1);
        $this->mo2f_auth_deactivate();
        goto fS;
        wA:
        $jY = new WP_Error();
        $jY->add("\x65\155\x70\x74\x79\137\165\163\x65\162\x6e\141\155\145", "\x3c\x73\164\x72\157\156\x67\x3e" . esc_html__("\x45\x52\122\x4f\122", "\x6d\151\x6e\x69\x6f\x72\x61\x6e\x67\145\55\62\55\x66\x61\x63\164\157\x72\55\141\x75\164\150\x65\x6e\x74\151\x63\x61\164\151\x6f\156") . "\74\57\163\x74\x72\157\156\x67\x3e\x3a\40" . esc_html__("\x49\x6e\x76\141\x6c\151\x64\x20\x52\x65\161\x75\x65\x73\x74\x2e", "\155\x69\x6e\151\157\x72\141\x6e\147\145\x2d\x32\x2d\x66\141\x63\x74\x6f\x72\55\x61\x75\164\x68\x65\156\x74\x69\x63\141\x74\151\x6f\156"));
        return $jY;
        fS:
        goto Z4;
        Qt:
        $dk = isset($_POST["\155\157\62\x66\x5f\x73\153\151\x70\154\157\x67\x69\x6e\137\156\157\156\143\145"]) ? sanitize_key(wp_unslash($_POST["\x6d\157\62\146\x5f\163\153\151\x70\x6c\x6f\147\x69\x6e\137\156\157\x6e\143\x65"])) : null;
        if (!wp_verify_nonce($dk, "\x6d\x69\x6e\x69\157\162\x61\156\x67\x65\x2d\x32\55\146\x61\143\164\x6f\162\x2d\163\153\151\x70\x6c\157\147\151\x6e\x2d\146\x61\151\154\x65\144\55\156\157\156\x63\x65")) {
            goto uA;
        }
        update_site_option("\155\x6f\62\146\x5f\x74\157\x75\162\x5f\x73\x74\141\162\x74\145\144", 2);
        goto X0;
        uA:
        $jY = new WP_Error();
        $jY->add("\145\x6d\x70\x74\171\137\165\163\x65\162\156\x61\x6d\145", "\74\x73\164\162\x6f\156\x67\x3e" . esc_html__("\x45\x52\122\117\122", "\155\151\x6e\151\157\162\x61\156\147\x65\55\x32\55\x66\x61\x63\164\x6f\162\55\x61\165\x74\150\x65\x6e\x74\x69\143\141\164\x69\157\x6e") . "\x3c\x2f\163\164\162\157\156\x67\76\x3a\40" . esc_html__("\x49\x6e\166\x61\154\x69\144\40\122\145\161\x75\145\163\x74\56", "\155\x69\156\x69\157\x72\141\156\147\145\x2d\62\x2d\146\x61\143\164\x6f\162\x2d\x61\x75\x74\x68\145\x6e\164\x69\143\x61\x74\151\157\x6e"));
        return $jY;
        X0:
        goto Z4;
        KQ:
        $dk = isset($_POST["\x6d\157\62\146\137\165\x73\145\x72\x6c\x6f\147\x6f\x75\x74\x5f\x6e\157\x6e\x63\x65"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\157\62\x66\x5f\165\163\x65\162\x6c\x6f\147\157\x75\x74\x5f\156\157\156\143\145"])) : null;
        if (!wp_verify_nonce($dk, "\x6d\151\156\151\157\x72\x61\x6e\x67\145\55\62\55\x66\x61\143\x74\157\162\55\x75\x73\x65\x72\x6c\x6f\147\157\x75\x74\x2d\146\141\151\x6c\x65\144\55\x6e\157\x6e\x63\145")) {
            goto Pg;
        }
        update_site_option("\x6d\157\62\x66\x5f\164\157\165\x72\x5f\x73\x74\141\162\164\145\144", 2);
        wp_logout();
        wp_safe_redirect(admin_url());
        exit;
        goto kT;
        Pg:
        $jY = new WP_Error();
        $jY->add("\x65\x6d\x70\164\171\x5f\165\163\145\x72\x6e\x61\155\x65", "\74\163\164\x72\157\x6e\x67\x3e" . esc_html__("\105\122\122\117\122", "\x6d\151\156\x69\157\x72\141\x6e\x67\x65\55\62\x2d\146\141\143\164\157\162\55\x61\165\x74\150\x65\x6e\x74\x69\x63\141\x74\x69\157\156") . "\74\57\x73\x74\x72\157\156\x67\x3e\x3a\x20" . esc_html__("\x49\x6e\x76\x61\154\151\x64\40\x52\x65\161\165\x65\163\164\56", "\x6d\151\156\x69\157\x72\141\156\147\145\x2d\62\55\146\x61\143\x74\x6f\162\55\x61\165\x74\x68\x65\156\x74\151\x63\x61\164\x69\x6f\x6e"));
        return $jY;
        kT:
        goto Z4;
        BP:
        $dk = isset($_POST["\155\x6f\x5f\62\x66\x61\143\x74\x6f\162\x5f\x72\145\x73\145\x6e\144\x5f\157\x74\160\137\156\x6f\x6e\x63\x65"]) ? sanitize_key(wp_unslash($_POST["\x6d\157\x5f\x32\x66\x61\x63\164\157\x72\137\162\145\x73\145\156\144\x5f\x6f\164\x70\x5f\156\x6f\x6e\143\x65"])) : null;
        if (!wp_verify_nonce($dk, "\155\157\x2d\62\146\141\x63\x74\x6f\162\x2d\x72\x65\x73\145\x6e\144\55\157\164\x70\x2d\156\157\156\x63\145")) {
            goto J7;
        }
        $hP = json_decode($this->mo2f_onprem_cloud_obj->send_otp_token(null, get_site_option("\155\157\62\146\137\x65\x6d\x61\x69\x6c"), MoWpnsConstants::OTP_OVER_EMAIL, null), true);
        if (strcasecmp($hP["\x73\164\141\164\165\x73"], "\x53\x55\103\x43\105\123\x53") === 0) {
            goto kS;
        }
        $BO = "\x4d\x4f\x5f\x32\x5f\x46\101\x43\x54\x4f\x52\137\117\x54\120\x5f\x44\x45\x4c\111\126\105\x52\x45\x44\x5f\106\x41\111\x4c\125\x52\x45";
        $Gw->update_user_details($user->ID, array("\x6d\157\x5f\62\x66\x61\x63\x74\x6f\x72\137\165\163\145\162\137\162\x65\147\151\163\164\162\141\x74\151\x6f\x6e\x5f\163\164\141\x74\165\163" => $BO));
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_IN_SENDING_EMAIL), "\x45\x52\x52\x4f\122");
        goto zr;
        kS:
        if (get_user_meta($user->ID, "\155\x6f\62\146\137\145\x6d\141\x69\x6c\137\157\164\x70\137\x63\x6f\165\x6e\164", true)) {
            goto S0;
        }
        update_user_meta($user->ID, "\x6d\157\62\146\137\145\x6d\141\151\x6c\137\157\x74\x70\137\143\x6f\x75\156\x74", 1);
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::OTP_SENT) . "\74\142\76\40" . get_site_option("\155\157\62\x66\x5f\x65\155\141\x69\154") . "\x20\74\x2f\x62\76" . MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_OTP), "\x53\x55\103\x43\105\x53\123");
        goto Ns;
        S0:
        update_user_meta($user->ID, "\x6d\157\62\146\137\145\155\x61\x69\154\x5f\157\x74\x70\137\143\157\165\156\x74", get_user_meta($user->ID, "\x6d\157\62\146\137\x65\155\141\x69\x6c\137\157\164\160\x5f\x63\x6f\x75\x6e\x74", true) + 1);
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::RESENT_OTP) . "\x20\x3c\142\76\x28\40" . get_user_meta($user->ID, "\155\x6f\x32\146\137\145\155\x61\x69\154\x5f\x6f\164\x70\137\x63\x6f\x75\156\x74", true) . "\40\51\74\57\x62\76\40\x74\x6f\40\x3c\142\76" . get_site_option("\155\157\x32\x66\x5f\x65\155\x61\x69\x6c") . "\74\x2f\x62\x3e\x20" . MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_OTP), "\123\125\x43\x43\105\x53\x53");
        Ns:
        $BO = "\115\117\x5f\62\x5f\106\x41\103\x54\x4f\x52\x5f\x4f\124\x50\137\x44\x45\114\111\126\x45\x52\x45\104\x5f\123\x55\x43\103\105\123\x53";
        $Gw->update_user_details($user->ID, array("\155\157\137\x32\x66\141\143\x74\x6f\x72\137\165\x73\x65\x72\x5f\x72\145\147\x69\163\x74\162\x61\164\x69\x6f\x6e\x5f\x73\x74\141\164\x75\163" => $BO));
        update_user_meta($user->ID, "\x6d\157\137\x32\x66\x61\137\166\x65\162\x69\146\x79\x5f\157\164\x70\x5f\x63\162\x65\x61\164\x65\137\141\143\143\x6f\165\156\164", $hP["\x74\170\x49\144"]);
        zr:
        goto p1;
        J7:
        $jY = new WP_Error();
        $jY->add("\x65\155\160\164\x79\x5f\165\163\145\x72\156\141\155\x65", "\74\x73\164\x72\157\156\147\x3e" . esc_html__("\105\x52\x52\117\122", "\x6d\x69\x6e\151\157\162\x61\156\147\x65\x2d\62\55\x66\x61\x63\x74\157\x72\x2d\141\165\164\150\x65\x6e\164\x69\143\x61\x74\x69\x6f\x6e") . "\74\x2f\163\164\x72\157\156\x67\76\72\x20" . esc_html__("\x49\156\166\141\154\151\x64\x20\122\x65\x71\165\145\x73\x74\56", "\155\151\156\x69\x6f\x72\141\156\x67\x65\x2d\x32\55\146\141\143\x74\157\162\x2d\x61\x75\164\150\x65\156\x74\x69\143\141\x74\x69\x6f\x6e"));
        return $jY;
        p1:
        goto Z4;
        eo:
        update_site_option("\155\x6f\62\146\137\142\x75\147\137\146\151\x78\x5f\144\157\156\145", 1);
        goto Z4;
        Lb:
        if (isset($_POST["\x77\x6f\157\143\157\155\x6d\145\x72\143\145\x5f\x6c\157\147\151\156\x5f\x70\x72\x6f\x6d\160\x74"])) {
            goto H6;
        }
        update_site_option("\x6d\x6f\x32\x66\137\167\x6f\x6f\x63\157\155\x6d\145\x72\x63\145\x5f\x6c\157\147\x69\156\x5f\160\162\x6f\155\x70\164", false);
        goto oC;
        H6:
        update_site_option("\x6d\157\62\146\137\x77\x6f\157\x63\157\x6d\155\x65\162\143\145\137\x6c\x6f\147\151\x6e\137\x70\162\x6f\x6d\x70\164", true);
        oC:
        Z4:
        yN:
        if (isset($_POST["\x6f\160\164\151\x6f\156"]) && sanitize_text_field(wp_unslash($_POST["\x6f\x70\x74\151\x6f\x6e"])) === "\x6d\157\62\146\137\x72\145\x67\x69\x73\x74\x72\x61\x74\151\x6f\156\137\143\x6c\157\163\145\x64") {
            goto Gt;
        }
        if (isset($_POST["\x6f\160\164\x69\157\x6e"]) && sanitize_text_field(wp_unslash($_POST["\157\160\164\151\x6f\x6e"])) === "\x6d\157\137\x32\146\141\143\x74\x6f\x72\137\x67\157\142\141\x63\153\x74\x6f\x5f\x72\145\x67\x69\163\x74\162\141\164\151\157\156\x5f\x70\141\x67\145") {
            goto l2;
        }
        if (isset($_POST["\157\160\x74\x69\x6f\156"]) && sanitize_text_field(wp_unslash($_POST["\157\160\164\151\x6f\156"])) === "\x6d\157\x32\146\137\155\157\x62\x69\x6c\x65\x5f\141\165\x74\150\x65\156\x74\x69\x63\x61\x74\145\x5f\x73\165\143\x63\145\163\x73") {
            goto x9;
        }
        if (isset($_POST["\157\160\x74\x69\x6f\156"]) && sanitize_text_field(wp_unslash($_POST["\157\x70\x74\x69\x6f\x6e"])) === "\x6d\x6f\62\146\x5f\x6d\157\142\x69\154\145\137\141\165\164\x68\145\156\x74\x69\x63\141\164\145\x5f\145\162\162\157\x72") {
            goto ea;
        }
        if (isset($_POST["\x6f\x70\x74\151\157\x6e"]) && sanitize_text_field(wp_unslash($_POST["\157\x70\164\x69\x6f\x6e"])) === "\155\157\137\141\165\x74\150\x5f\x73\x65\164\164\151\156\147\137\143\157\156\146\151\147\x75\162\141\x74\151\x6f\x6e") {
            goto PB;
        }
        if (isset($_POST["\157\160\x74\x69\x6f\x6e"]) && sanitize_text_field(wp_unslash($_POST["\x6f\x70\164\x69\x6f\x6e"])) === "\155\157\x5f\x32\x66\x61\143\x74\157\x72\x5f\142\x61\143\153\164\157\x5f\165\x73\x65\x72\x5f\162\145\x67\x69\x73\164\x72\141\164\151\x6f\156") {
            goto wg;
        }
        if (isset($_POST["\x6f\x70\164\x69\157\156"]) && sanitize_text_field(wp_unslash($_POST["\157\160\x74\x69\157\x6e"])) === "\155\x6f\x32\x66\x5f\x76\141\154\151\144\141\x74\145\x5f\x6f\164\x70\137\157\166\x65\162\x5f\124\x65\154\x65\147\162\141\x6d") {
            goto HR;
        }
        if (isset($_POST["\157\160\x74\x69\x6f\156"]) && sanitize_text_field(wp_unslash($_POST["\x6f\x70\164\x69\x6f\x6e"])) === "\155\x6f\x32\x66\x5f\166\x61\154\x69\144\141\164\145\137\157\164\x70\137\x6f\x76\x65\x72\x5f\x73\155\163") {
            goto ox;
        }
        if (isset($_POST["\157\160\164\151\157\156"]) && sanitize_text_field(wp_unslash($_POST["\x6f\160\164\151\157\x6e"])) === "\x6d\157\x32\x66\137\157\165\164\x5f\157\x66\x5f\x62\141\156\144\x5f\x73\165\143\143\x65\x73\163") {
            goto So;
        }
        if (isset($_POST["\157\x70\x74\x69\157\x6e"]) && sanitize_text_field(wp_unslash($_POST["\157\160\x74\151\x6f\x6e"])) === "\155\157\x32\146\x5f\157\165\164\x5f\157\x66\x5f\142\141\156\144\137\145\162\x72\x6f\x72") {
            goto BG;
        }
        if (isset($_POST["\157\160\x74\x69\157\x6e"]) && sanitize_text_field(wp_unslash($_POST["\157\x70\164\x69\157\156"])) === "\155\157\62\146\137\144\165\x6f\x5f\141\165\x74\150\x65\156\164\151\x63\x61\164\x6f\162\137\x73\165\x63\143\145\x73\163\x5f\146\157\162\x6d") {
            goto B2;
        }
        if (isset($_POST["\157\x70\164\x69\157\156"]) && sanitize_text_field(wp_unslash($_POST["\157\160\164\x69\157\x6e"])) === "\155\157\x32\x66\x5f\144\x75\x6f\x5f\141\165\164\x68\145\x6e\x74\151\x63\x61\164\157\162\x5f\145\x72\162\x6f\162") {
            goto up;
        }
        if (isset($_POST["\157\160\x74\151\x6f\156"]) && sanitize_text_field(wp_unslash($_POST["\x6f\160\164\151\x6f\x6e"])) === "\x6d\x6f\x32\146\137\x76\141\154\151\144\x61\x74\145\137\147\157\x6f\x67\x6c\x65\x5f\x61\x75\x74\150\x79\x5f\164\145\163\164") {
            goto sQ;
        }
        if (isset($_POST["\x6f\x70\164\151\x6f\156"]) && sanitize_text_field(wp_unslash($_POST["\x6f\x70\x74\151\x6f\156"])) === "\155\157\62\x66\137\x76\141\x6c\x69\x64\x61\x74\x65\137\157\164\x70\x5f\x6f\166\x65\x72\x5f\x65\155\x61\151\x6c") {
            goto QE;
        }
        if (isset($_POST["\157\x70\x74\151\x6f\x6e"]) && sanitize_text_field(wp_unslash($_POST["\157\160\x74\x69\x6f\156"])) === "\155\157\x32\x66\x5f\147\157\x6f\x67\x6c\x65\137\141\x70\160\x6e\141\155\x65") {
            goto qb;
        }
        if (isset($_POST["\x6f\x70\164\x69\x6f\x6e"]) && sanitize_text_field(wp_unslash($_POST["\x6f\160\164\x69\x6f\x6e"])) === "\x6d\x6f\62\x66\x5f\143\157\156\x66\151\147\165\162\145\x5f\x67\x6f\x6f\x67\x6c\x65\137\x61\x75\164\x68\145\156\164\151\143\141\x74\x6f\162\x5f\x76\141\154\151\144\141\164\x65") {
            goto C4;
        }
        if (isset($_POST["\157\160\x74\x69\x6f\156"]) && sanitize_text_field(wp_unslash($_POST["\157\160\x74\x69\157\x6e"])) === "\155\157\62\146\x5f\143\x6f\x6e\146\151\x67\x75\162\x65\x5f\144\x75\157\137\x61\x75\x74\150\145\156\164\151\143\141\164\157\x72\x5f\166\x61\x6c\x69\144\x61\x74\145\137\156\x6f\156\x63\x65") {
            goto er;
        }
        if (isset($_POST["\x6f\x70\164\x69\x6f\x6e"]) && sanitize_text_field(wp_unslash($_POST["\157\160\164\x69\x6f\156"])) === "\x6d\x6f\x32\x66\137\143\x6f\156\146\151\147\x75\162\145\x5f\141\x75\x74\x68\x79\x5f\141\x75\x74\x68\145\156\x74\x69\143\x61\164\x6f\162") {
            goto fQ;
        }
        if (isset($_POST["\157\x70\x74\151\157\156"]) && sanitize_text_field(wp_unslash($_POST["\x6f\160\164\x69\x6f\156"])) === "\155\157\x32\x66\137\143\157\156\146\x69\x67\165\162\x65\137\141\x75\x74\x68\171\137\141\165\164\150\145\156\164\151\x63\x61\164\x6f\162\x5f\x76\141\154\x69\144\x61\164\x65") {
            goto Ew;
        }
        if (isset($_POST["\x6f\160\x74\x69\157\x6e"]) && sanitize_text_field(wp_unslash($_POST["\x6f\160\x74\x69\x6f\x6e"])) === "\x6d\x6f\62\x66\x5f\x73\x61\166\145\x5f\x6b\142\x61") {
            goto Tz;
        }
        if (isset($_POST["\157\x70\164\151\157\x6e"]) && sanitize_text_field(wp_unslash($_POST["\157\160\164\151\x6f\156"])) === "\155\157\x32\146\137\x76\x61\154\151\144\x61\x74\x65\137\x6b\142\141\x5f\x64\x65\164\x61\151\x6c\x73") {
            goto ku;
        }
        if (isset($_POST["\157\x70\x74\151\157\156"]) && sanitize_text_field(wp_unslash($_POST["\x6f\160\164\151\x6f\156"])) === "\155\157\62\x66\137\62\x66\x61\x63\164\x6f\x72\x5f\x74\145\x73\164\137\x70\x72\x6f\155\x70\x74\x5f\143\x72\x6f\163\163") {
            goto rh;
        }
        if (isset($_POST["\157\160\x74\151\x6f\x6e"]) && sanitize_text_field(wp_unslash($_POST["\x6f\x70\x74\151\157\x6e"])) === "\x6d\157\x32\146\137\x63\157\156\146\151\147\x75\162\145\x5f\x64\165\x6f\x5f\141\x75\164\150\145\156\164\x69\x63\x61\x74\157\162") {
            goto Ne;
        }
        if (isset($_POST["\x6f\160\x74\x69\157\156"]) && sanitize_text_field(wp_unslash($_POST["\x6f\160\x74\151\157\156"])) === "\x6d\x6f\62\x66\137\x63\x6f\x6e\x66\x69\147\165\162\x65\x5f\x64\x75\x6f\137\x61\165\164\x68\x65\x6e\164\x69\143\x61\164\x6f\162\x5f\x61\142\143") {
            goto C3;
        }
        if (isset($_POST["\157\x70\x74\x69\x6f\x6e"]) && sanitize_text_field(wp_unslash($_POST["\x6f\x70\164\x69\x6f\156"])) === "\x64\165\x6f\x5f\155\x6f\142\151\x6c\145\x5f\163\145\x6e\144\137\x70\x75\x73\150\137\x6e\157\x74\x69\x66\151\143\141\164\x69\x6f\156\x5f\151\x6e\163\x69\x64\x65\x5f\160\154\x75\x67\x69\x6e") {
            goto WQ;
        }
        if (isset($_POST["\x6f\x70\x74\x69\157\x6e"]) && sanitize_text_field(wp_unslash($_POST["\157\x70\164\x69\157\x6e"])) === "\x6d\157\x32\x66\x5f\x73\141\x76\x65\137\x66\x72\145\145\137\160\154\x61\x6e\x5f\x61\x75\x74\x68\x5f\155\145\164\150\x6f\144\x73") {
            goto oW;
        }
        if (isset($_POST["\x6f\x70\164\x69\x6f\156"]) && sanitize_text_field(wp_unslash($_POST["\x6f\x70\x74\x69\157\156"])) === "\155\x6f\62\146\137\x65\x6e\141\x62\154\x65\137\62\x46\x41\137\x66\157\162\x5f\165\163\x65\162\x73\x5f\x6f\160\x74\151\x6f\156") {
            goto pm;
        }
        if (isset($_POST["\x6f\x70\x74\x69\157\156"]) && sanitize_text_field(wp_unslash($_POST["\x6f\x70\x74\151\157\156"])) === "\x6d\x6f\62\x66\137\145\x6e\x61\x62\154\x65\x5f\x32\106\x41\137\157\x70\x74\x69\x6f\x6e") {
            goto rJ;
        }
        if (isset($_POST["\157\x70\164\x69\157\x6e"]) && sanitize_text_field(wp_unslash($_POST["\157\x70\x74\x69\x6f\x6e"])) === "\x6d\157\x5f\62\x66\x61\x63\164\x6f\x72\137\164\x65\x73\164\x5f\141\165\x74\150\x65\x6e\x74\151\x63\141\x74\151\157\156\137\x6d\145\164\150\157\x64") {
            goto Ye;
        }
        if (isset($_POST["\x6f\x70\164\151\157\156"]) && sanitize_text_field(wp_unslash($_POST["\157\160\x74\151\157\x6e"])) === "\155\157\x32\x66\x5f\147\157\x5f\142\x61\x63\153") {
            goto Ky;
        }
        if (isset($_POST["\157\x70\x74\x69\157\156"]) && sanitize_text_field(wp_unslash($_POST["\x6f\x70\x74\151\x6f\156"])) === "\155\x6f\62\x66\x5f\x72\145\163\145\x74\137\x64\x75\157\137\143\x6f\x6e\x66\x69\147\x75\x72\141\x74\151\x6f\156") {
            goto XI;
        }
        goto lD;
        Gt:
        $dk = isset($_POST["\x6d\157\62\x66\x5f\x72\145\147\x69\x73\164\x72\x61\164\151\157\156\137\143\x6c\157\163\x65\144\137\x6e\157\156\x63\x65"]) ? sanitize_key(wp_unslash($_POST["\155\157\x32\x66\x5f\162\x65\x67\x69\163\164\162\x61\164\151\x6f\156\x5f\x63\x6c\157\163\x65\144\x5f\156\157\156\x63\x65"])) : null;
        if (!wp_verify_nonce($dk, "\x6d\157\x32\x66\x2d\162\145\x67\x69\163\164\x72\x61\164\151\x6f\156\x2d\143\154\x6f\x73\145\x64\55\156\x6f\156\143\145")) {
            goto lU;
        }
        delete_user_meta($user->ID, "\x72\x65\x67\x69\x73\164\145\162\x5f\x61\x63\x63\157\x75\156\164\x5f\160\157\x70\165\x70");
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SETUP_2FA), "\123\125\x43\x43\x45\123\x53");
        goto R_;
        lU:
        $jY = new WP_Error();
        $jY->add("\x65\155\x70\x74\171\137\165\x73\x65\162\156\141\155\145", "\x3c\163\x74\162\157\156\147\x3e" . esc_html__("\105\x52\122\117\x52", "\155\151\156\x69\157\x72\x61\x6e\147\145\55\x32\x2d\x66\x61\143\x74\x6f\162\55\141\165\x74\x68\x65\156\164\x69\143\141\x74\x69\157\156") . "\74\57\x73\x74\162\157\156\x67\x3e\x3a\40" . esc_html__("\x49\156\x76\141\x6c\x69\x64\40\x52\x65\161\165\145\x73\x74\56", "\155\151\x6e\151\157\x72\141\x6e\147\145\55\x32\55\x66\141\143\164\x6f\x72\x2d\x61\165\164\x68\x65\156\x74\151\143\x61\164\x69\x6f\156"));
        return $jY;
        R_:
        goto lD;
        l2:
        $dk = isset($_POST["\x6d\x6f\x5f\x32\x66\141\143\164\157\162\137\147\x6f\x62\x61\x63\153\164\x6f\x5f\x72\x65\x67\x69\x73\x74\162\141\x74\151\x6f\156\137\x70\141\147\145\137\x6e\157\156\x63\145"]) ? sanitize_key(wp_unslash($_POST["\155\x6f\x5f\62\x66\x61\x63\164\x6f\162\137\147\x6f\x62\x61\x63\x6b\164\157\137\x72\145\x67\x69\163\x74\162\141\164\x69\157\156\x5f\x70\x61\x67\x65\137\x6e\157\156\x63\145"])) : null;
        if (!wp_verify_nonce($dk, "\155\157\x2d\62\x66\141\x63\164\157\162\x2d\147\157\x62\x61\143\x6b\164\x6f\x2d\162\145\147\151\x73\x74\162\141\164\151\x6f\156\x2d\160\141\x67\x65\x2d\x6e\157\x6e\143\x65")) {
            goto gz;
        }
        delete_site_option("\155\x6f\62\146\137\145\x6d\x61\x69\154");
        delete_site_option("\155\157\62\x66\x5f\x70\x61\x73\163\167\157\x72\144");
        update_site_option("\155\x6f\62\146\x5f\x6d\x65\x73\163\x61\x67\145", '');
        MO2f_Utility::unset_session_variables("\155\157\62\146\x5f\x74\x72\x61\x6e\163\141\x63\x74\x69\157\156\x49\x64");
        delete_site_option("\155\x6f\x32\x66\x5f\164\162\141\156\163\x61\x63\x74\151\x6f\156\x49\x64");
        delete_user_meta($user->ID, "\155\157\x32\146\137\163\155\163\x5f\x6f\164\x70\x5f\x63\x6f\x75\156\164");
        delete_user_meta($user->ID, "\155\157\x32\x66\x5f\x65\x6d\x61\x69\154\x5f\x6f\164\x70\137\143\157\x75\x6e\164");
        delete_user_meta($user->ID, "\155\x6f\62\x66\x5f\x65\155\x61\151\154\x5f\157\x74\x70\x5f\x63\157\165\x6e\x74");
        $Gw->update_user_details($user->ID, array("\155\157\x5f\x32\146\x61\x63\164\157\x72\x5f\165\x73\x65\x72\137\162\x65\x67\x69\x73\x74\x72\x61\164\151\157\156\x5f\163\164\141\x74\x75\163" => "\122\105\107\111\x53\x54\122\101\124\x49\117\116\x5f\123\x54\x41\122\124\x45\x44"));
        goto BY;
        gz:
        $jY = new WP_Error();
        $jY->add("\145\155\x70\x74\x79\137\165\163\x65\x72\156\x61\155\145", "\74\163\x74\x72\157\x6e\147\x3e" . esc_html__("\105\x52\x52\117\122", "\x6d\x69\x6e\151\157\x72\x61\x6e\x67\x65\x2d\x32\55\x66\141\143\164\x6f\162\x2d\141\165\x74\x68\145\156\164\151\x63\141\x74\151\x6f\x6e") . "\x3c\57\163\x74\162\x6f\x6e\x67\76\x3a\40" . esc_html__("\111\156\166\141\154\x69\144\x20\x52\x65\x71\x75\x65\x73\164\x2e", "\155\151\x6e\151\x6f\162\x61\156\x67\145\55\x32\x2d\x66\141\143\164\157\162\x2d\x61\x75\x74\x68\x65\156\x74\151\143\141\164\x69\157\156"));
        return $jY;
        BY:
        goto lD;
        x9:
        $XQ = array("\x6d\x6f\x32\x66\x5f\161\162\x43\x6f\x64\x65", "\155\157\x32\146\137\x74\x72\x61\156\x73\x61\143\x74\151\157\156\x49\144", "\x6d\157\x32\x66\x5f\163\150\157\167\137\161\x72\137\143\157\x64\145");
        MO2f_Utility::unset_session_variables($XQ);
        delete_user_meta($user->ID, "\164\145\x73\164\137\62\106\101");
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::COMPLETED_TEST), "\x53\125\103\103\105\123\123");
        goto lD;
        ea:
        $dk = isset($_POST["\155\157\x32\146\x5f\x6d\x6f\142\x69\x6c\x65\137\x61\x75\164\150\x65\x6e\x74\x69\143\x61\x74\145\137\145\x72\162\157\162\x5f\x6e\157\x6e\143\x65"]) ? sanitize_key(wp_unslash($_POST["\x6d\157\x32\146\137\155\157\x62\x69\154\x65\137\x61\165\164\150\x65\x6e\x74\151\x63\141\x74\145\137\145\x72\162\x6f\x72\x5f\156\157\156\x63\x65"])) : null;
        if (!wp_verify_nonce($dk, "\155\157\62\x66\55\x6d\x6f\x62\151\154\x65\x2d\x61\x75\164\150\145\156\164\x69\x63\x61\164\145\55\145\x72\x72\157\x72\x2d\156\x6f\x6e\x63\145")) {
            goto M6;
        }
        MO2f_Utility::unset_session_variables("\x6d\x6f\62\146\137\x73\x68\157\167\137\x71\x72\137\x63\157\x64\x65");
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::AUTHENTICATION_FAILED), "\x45\122\122\x4f\122");
        goto n5;
        M6:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\x45\122\122\x4f\122");
        return;
        n5:
        goto lD;
        PB:
        $Gw->update_user_details($user->ID, array("\x6d\x6f\x5f\x32\x66\x61\x63\164\157\x72\x5f\165\x73\x65\x72\x5f\x72\145\147\x69\163\x74\x72\x61\164\x69\x6f\x6e\137\163\x74\141\164\x75\163" => MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS));
        goto lD;
        wg:
        delete_user_meta($user->ID, "\x75\163\145\162\x5f\145\155\141\151\154");
        $Gw->delete_user_details($user->ID);
        MO2f_Utility::unset_session_variables("\155\x6f\62\x66\x5f\164\x72\x61\x6e\163\141\143\164\x69\157\x6e\111\x64");
        delete_site_option("\155\157\62\146\137\164\162\141\x6e\163\141\x63\x74\x69\x6f\x6e\x49\144");
        goto lD;
        HR:
        $dk = isset($_POST["\155\x6f\x32\x66\x5f\x74\145\x73\164\137\x76\141\x6c\x69\144\141\164\145\137\157\x74\160\137\156\157\156\x63\145"]) ? sanitize_key(wp_unslash($_POST["\155\x6f\62\x66\x5f\164\145\163\164\x5f\166\141\x6c\151\x64\141\164\145\x5f\157\164\160\137\156\157\156\x63\x65"])) : null;
        if (!wp_verify_nonce($dk, "\x6d\157\62\x66\55\166\141\x6c\151\x64\141\164\x65\x2d\157\x74\160\x2d\157\166\x65\162\x2d\x54\145\154\145\147\x72\x61\x6d\55\x6e\157\x6e\143\145")) {
            goto Y0;
        }
        $DF = isset($_POST["\157\164\160\137\164\x6f\153\145\156"]) ? sanitize_text_field(wp_unslash($_POST["\x6f\x74\160\137\x74\157\x6b\x65\156"])) : '';
        $li = get_user_meta($user->ID, "\x6d\157\62\146\x5f\157\x74\160\137\164\x6f\x6b\145\156", true);
        $rs = get_user_meta($user->ID, "\x6d\157\x32\146\137\164\x65\x6c\145\147\162\x61\155\x5f\x74\x69\155\145", true);
        $j9 = time() - 300;
        $rs = (int) $rs;
        global $Gw;
        if ((int) $li === (int) $DF) {
            goto FQ;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_OTP), "\105\122\122\117\122");
        goto wN;
        FQ:
        if ($j9 < $rs) {
            goto A3;
        }
        delete_user_meta($user->ID, "\x74\x65\163\164\137\x32\106\101");
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::OTP_EXPIRED), "\x45\x52\122\117\122");
        goto cP;
        A3:
        delete_user_meta($user->ID, "\164\145\163\x74\x5f\x32\106\x41");
        delete_user_meta($user->ID, "\155\x6f\x32\x66\137\x74\x65\x6c\145\x67\x72\x61\x6d\x5f\164\x69\x6d\x65");
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::COMPLETED_TEST), "\x53\125\x43\103\105\x53\123");
        cP:
        wN:
        goto KE;
        Y0:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\122\x52\x4f\122");
        return;
        KE:
        goto lD;
        ox:
        $dk = isset($_POST["\155\157\x32\x66\137\164\x65\163\x74\x5f\x76\x61\x6c\151\144\x61\x74\x65\137\x6f\164\x70\137\x6e\x6f\156\143\x65"]) ? sanitize_key(wp_unslash($_POST["\x6d\157\62\x66\x5f\x74\145\163\x74\x5f\166\141\154\151\x64\141\x74\x65\x5f\157\x74\x70\x5f\156\x6f\x6e\x63\145"])) : null;
        if (!wp_verify_nonce($dk, "\x6d\157\62\x66\55\x76\x61\x6c\151\x64\141\164\x65\55\x6f\x74\x70\55\157\166\145\162\55\163\155\x73\55\156\157\156\143\x65")) {
            goto dc;
        }
        $li = '';
        $su = isset($_POST["\157\164\x70\x5f\164\x6f\153\145\156"]) ? sanitize_text_field(wp_unslash($_POST["\157\x74\x70\x5f\x74\157\x6b\145\156"])) : '';
        if (MO2f_Utility::mo2f_check_empty_or_null($su)) {
            goto gf;
        }
        $li = isset($_POST["\x6f\164\160\x5f\164\157\153\145\x6e"]) ? sanitize_text_field(wp_unslash($_POST["\x6f\x74\x70\137\x74\157\x6b\x65\x6e"])) : '';
        goto VI;
        gf:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_VALUE), "\105\122\x52\117\x52");
        return;
        VI:
        $G5 = get_user_meta($user->ID, "\x6d\157\x32\146\x5f\x74\x72\x61\x6e\163\x61\x63\164\x69\157\x6e\x49\144", true);
        $fK = $Gw->get_user_detail("\155\x6f\62\146\x5f\x75\163\145\162\137\145\x6d\141\x69\x6c", $user->ID);
        $Oa = $Gw->get_user_detail("\x6d\x6f\x32\x66\137\x63\x6f\x6e\x66\x69\147\165\162\x65\x64\137\x32\x46\101\137\155\x65\x74\x68\157\x64", $user->ID);
        $hP = json_decode($this->mo2f_onprem_cloud_obj->validate_otp_token($Oa, $fK, $G5, $li), true);
        if ("\105\x52\x52\117\x52" === $hP["\163\164\x61\x74\x75\163"]) {
            goto o9;
        }
        if (strcasecmp($hP["\x73\x74\x61\164\165\x73"], "\x53\125\x43\103\x45\x53\123") === 0) {
            goto MB;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_OTP), "\105\122\122\x4f\122");
        goto Pb;
        MB:
        delete_user_meta($user->ID, "\164\x65\x73\x74\x5f\62\106\x41");
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::COMPLETED_TEST), "\123\125\x43\x43\105\x53\123");
        Pb:
        goto b5;
        o9:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate($hP["\x6d\x65\x73\163\x61\x67\145"]), "\105\122\122\x4f\122");
        b5:
        goto qD;
        dc:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\122\122\x4f\122");
        return;
        qD:
        goto lD;
        So:
        $dk = isset($_POST["\x6d\157\x32\x66\x5f\x6f\165\x74\137\157\146\137\142\141\156\x64\x5f\x73\x75\x63\x63\145\163\163\x5f\x6e\x6f\x6e\143\x65"]) ? sanitize_key(wp_unslash($_POST["\x6d\157\x32\x66\x5f\x6f\165\x74\x5f\x6f\146\137\142\141\156\x64\x5f\163\165\143\143\145\x73\x73\137\156\x6f\156\143\145"])) : null;
        if (!wp_verify_nonce($dk, "\155\x6f\x32\x66\x2d\157\165\x74\x2d\157\146\55\142\141\x6e\x64\x2d\x73\x75\143\x63\145\x73\x73\55\156\x6f\156\143\x65")) {
            goto CP;
        }
        if (!MO2F_IS_ONPREM) {
            goto r1;
        }
        $e9 = isset($_POST["\x54\170\151\144\105\x6d\141\151\154"]) ? sanitize_text_field(wp_unslash($_POST["\x54\170\x69\x64\105\155\141\x69\x6c"])) : null;
        $yY = get_site_option($e9);
        if (empty($yY)) {
            goto hn;
        }
        if (!(1 !== (int) $yY)) {
            goto PN;
        }
        delete_user_meta($user->ID, "\x74\x65\163\x74\x5f\62\x46\x41");
        delete_user_meta($user->ID, "\155\x6f\62\x66\x5f\x63\157\156\x66\151\147\x75\x72\145\137\x32\x46\x41");
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_EMAIL_VER_REQ), "\105\x52\122\117\122");
        return;
        PN:
        hn:
        r1:
        $Tr = $Gw->get_user_detail("\x6d\157\x32\x66\x5f\143\x6f\x6e\146\151\147\165\162\x65\x64\137\62\106\101\x5f\x6d\145\164\150\157\x64", $user->ID);
        if (!(MO2F_IS_ONPREM && isset($_POST["\124\x78\151\x64\105\155\141\x69\154"]))) {
            goto kx;
        }
        $Tr = MoWpnsConstants::OUT_OF_BAND_EMAIL;
        kx:
        $TW = $Gw->get_user_detail("\155\157\62\x66\137\105\x6d\141\151\x6c\x56\145\x72\x69\x66\x69\143\141\164\151\157\156\x5f\143\157\x6e\x66\151\147\137\163\x74\x61\164\165\163", $user->ID);
        if (!current_user_can("\155\141\x6e\141\147\145\137\157\160\x74\x69\x6f\156\163") && MoWpnsConstants::OUT_OF_BAND_EMAIL === $Tr) {
            goto pv;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::COMPLETED_TEST), "\123\x55\x43\x43\105\123\123");
        goto Vr;
        pv:
        if ($TW) {
            goto vV;
        }
        $fK = $Gw->get_user_detail("\x6d\157\x32\146\137\x75\163\145\x72\137\x65\155\x61\151\154", $user->ID);
        $this->mo2f_onprem_cloud_obj->mo2f_update_user_info($user->ID, true, $Tr, null, null, null, $fK);
        $pd->mo2f_show_message("\74\142\x3e\x20" . MoWpnsMessages::lang_translate(MoWpnsConstants::mo2f_convert_method_name(MoWpnsConstants::OUT_OF_BAND_EMAIL, "\143\141\160\137\x74\157\x5f\163\155\141\154\x6c")) . "\x3c\57\x62\x3e\x20" . MoWpnsMessages::lang_translate(MoWpnsMessages::SET_AS_2ND_FACTOR), "\x53\125\x43\x43\x45\x53\123");
        goto zV;
        vV:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::COMPLETED_TEST), "\x53\125\x43\x43\105\x53\x53");
        zV:
        Vr:
        $fK = $Gw->get_user_detail("\x6d\x6f\62\146\137\x75\163\x65\162\x5f\x65\155\x61\151\x6c", $user->ID);
        $IR = $fK ? $fK : get_user_meta($user->ID, "\x74\x65\x6d\160\x45\x6d\x61\151\x6c", true);
        delete_user_meta($user->ID, "\x6d\157\x32\x66\x5f\x63\x6f\x6e\146\x69\x67\x75\162\x65\x5f\x32\x46\101");
        delete_user_meta($user->ID, "\x74\x65\163\164\x5f\x32\x46\x41");
        $this->mo2f_onprem_cloud_obj->mo2f_update_user_info($user->ID, true, $Tr, MoWpnsConstants::SUCCESS_RESPONSE, MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, true, $IR);
        $cB->mo2f_display_test_2fa_notification($user);
        goto Jf;
        CP:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\x45\122\122\x4f\122");
        return;
        Jf:
        goto lD;
        BG:
        $dk = isset($_POST["\155\x6f\x32\x66\137\157\x75\x74\x5f\157\146\137\x62\x61\x6e\144\x5f\x65\x72\x72\x6f\x72\137\x6e\157\156\x63\x65"]) ? sanitize_key(wp_unslash($_POST["\x6d\x6f\62\x66\137\x6f\x75\164\x5f\157\146\137\x62\x61\x6e\x64\137\145\162\162\157\x72\x5f\156\x6f\x6e\x63\145"])) : null;
        if (!wp_verify_nonce($dk, "\x6d\157\62\146\x2d\x6f\x75\x74\x2d\157\x66\55\x62\141\156\x64\x2d\x65\x72\x72\157\162\x2d\x6e\157\x6e\x63\x65")) {
            goto Co;
        }
        delete_user_meta($user->ID, "\x6d\x6f\x32\146\x5f\143\x6f\156\x66\x69\x67\165\162\145\x5f\62\106\x41");
        $IR = get_user_meta($user->ID, "\x74\x65\x6d\x70\105\155\x61\x69\154", true);
        delete_user_meta($user->ID, "\164\x65\163\x74\x5f\62\x46\101");
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::DENIED_REQUEST), "\105\122\122\117\x52");
        goto lu;
        Co:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\122\x52\x4f\x52");
        return;
        lu:
        goto lD;
        B2:
        $dk = isset($_POST["\155\157\62\146\x5f\144\165\x6f\x5f\x61\x75\164\150\145\x6e\164\151\x63\x61\x74\x6f\x72\137\x73\165\x63\143\145\163\x73\137\x6e\157\156\x63\145"]) ? sanitize_key(wp_unslash($_POST["\155\x6f\x32\146\x5f\144\165\x6f\137\x61\165\x74\150\145\156\164\x69\x63\141\164\x6f\162\x5f\x73\x75\143\x63\145\x73\163\137\156\x6f\x6e\143\x65"])) : null;
        if (!wp_verify_nonce($dk, "\155\157\x32\146\x2d\144\165\x6f\55\141\165\x74\x68\145\x6e\164\151\x63\x61\164\x6f\162\x2d\163\165\x63\x63\145\x73\x73\x2d\x6e\157\156\x63\x65")) {
            goto tA;
        }
        delete_user_meta($user->ID, "\164\145\163\164\137\x32\x46\x41");
        $Gw->update_user_details($user->ID, array("\x6d\x6f\x5f\62\146\141\x63\164\x6f\x72\137\165\x73\145\x72\137\162\x65\x67\151\163\x74\162\141\x74\x69\157\x6e\137\163\x74\141\164\165\163" => MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, "\155\157\62\x66\137\x44\x75\157\101\165\x74\150\x65\156\x74\151\x63\141\164\157\162\x5f\143\x6f\156\146\x69\147\x5f\x73\164\141\x74\165\163" => true));
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::COMPLETED_TEST), "\x53\125\x43\103\x45\123\123");
        goto AX;
        tA:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\x45\x52\x52\x4f\x52");
        return;
        AX:
        goto lD;
        up:
        $dk = isset($_POST["\x6d\157\62\146\137\x64\x75\x6f\137\141\165\x74\150\x65\156\164\x63\141\164\157\162\x5f\145\162\162\x6f\x72\137\156\157\x6e\143\145"]) ? sanitize_key(wp_unslash($_POST["\x6d\157\x32\146\137\x64\165\x6f\137\x61\165\164\x68\145\156\164\143\141\x74\x6f\x72\137\x65\162\162\157\162\x5f\156\157\156\x63\145"])) : null;
        if (!wp_verify_nonce($dk, "\x6d\157\x32\x66\55\144\x75\x6f\x2d\x61\x75\164\150\x65\x6e\x74\151\143\x61\164\157\x72\55\145\x72\162\x6f\162\55\x6e\157\156\143\x65")) {
            goto vG;
        }
        global $Gw;
        delete_user_meta($user->ID, "\x74\x65\163\x74\137\62\106\101");
        $Gw->update_user_details($user->ID, array("\155\x6f\142\151\x6c\145\137\x72\x65\x67\x69\x73\164\x72\x61\x74\151\157\x6e\x5f\163\164\x61\x74\165\163" => false));
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::DENIED_DUO_REQUEST), "\x45\122\122\x4f\122");
        goto Xx;
        vG:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\122\x52\x4f\122");
        return;
        Xx:
        goto lD;
        sQ:
        $dk = isset($_POST["\x6d\x6f\62\146\137\x74\x65\163\x74\137\x76\x61\x6c\151\144\141\x74\x65\137\x6f\164\x70\137\x6e\x6f\x6e\143\145"]) ? sanitize_key(wp_unslash($_POST["\x6d\x6f\62\146\x5f\x74\145\163\x74\x5f\166\x61\x6c\151\x64\x61\x74\145\x5f\157\164\x70\x5f\156\157\156\143\x65"])) : null;
        if (!wp_verify_nonce($dk, "\x6d\157\62\146\x2d\x76\141\154\151\144\x61\x74\145\55\147\157\x6f\147\154\145\x2d\141\x75\164\150\171\55\164\145\x73\164\x2d\156\x6f\x6e\x63\145")) {
            goto Ri;
        }
        $li = '';
        $su = isset($_POST["\x6f\164\x70\137\164\157\153\145\156"]) ? sanitize_text_field(wp_unslash($_POST["\x6f\164\x70\137\164\x6f\153\x65\156"])) : '';
        if (MO2f_Utility::mo2f_check_empty_or_null($su)) {
            goto we;
        }
        $li = sanitize_text_field(wp_unslash($_POST["\157\x74\x70\137\x74\157\153\x65\156"]));
        goto v0;
        we:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_VALUE), "\x45\x52\122\117\x52");
        return;
        v0:
        $fK = $Gw->get_user_detail("\x6d\x6f\62\x66\x5f\165\163\145\x72\137\145\155\141\x69\x6c", $user->ID);
        $hP = json_decode($this->mo2f_onprem_cloud_obj->validate_otp_token(MoWpnsConstants::GOOGLE_AUTHENTICATOR, $fK, null, $li), true);
        if (json_last_error() === JSON_ERROR_NONE) {
            goto EG;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_WHILE_VALIDATING_OTP), "\105\122\122\117\122");
        goto mj;
        EG:
        if (strcasecmp($hP["\x73\x74\141\x74\165\163"], "\x53\x55\103\x43\105\123\x53") === 0) {
            goto ud;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_OTP), "\105\x52\x52\x4f\122");
        goto Vp;
        ud:
        delete_user_meta($user->ID, "\164\x65\163\x74\137\62\106\x41");
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::COMPLETED_TEST), "\x53\125\x43\103\x45\x53\x53");
        Vp:
        mj:
        goto BQ;
        Ri:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\x52\122\x4f\122");
        return;
        BQ:
        goto lD;
        QE:
        $dk = isset($_POST["\x6d\x6f\62\146\137\x74\145\163\164\x5f\166\141\x6c\x69\144\141\x74\x65\137\x6f\x74\160\x5f\156\157\156\x63\x65"]) ? sanitize_key(wp_unslash($_POST["\155\157\62\x66\137\x74\145\x73\164\137\x76\x61\154\151\x64\x61\164\145\x5f\157\164\160\x5f\156\x6f\156\143\x65"])) : null;
        if (!wp_verify_nonce($dk, "\155\x6f\x32\x66\55\166\141\x6c\151\144\x61\x74\x65\x2d\157\164\160\x2d\x6f\166\x65\162\55\x65\155\x61\151\x6c\x2d\x74\x65\163\x74\55\x6e\x6f\x6e\x63\145")) {
            goto JJ;
        }
        $li = '';
        $su = isset($_POST["\157\164\x70\137\164\x6f\x6b\145\156"]) ? sanitize_text_field(wp_unslash($_POST["\157\164\160\137\164\157\153\x65\x6e"])) : '';
        if (MO2f_Utility::mo2f_check_empty_or_null($su)) {
            goto Ao;
        }
        $li = sanitize_text_field(wp_unslash($_POST["\x6f\164\160\137\164\157\153\145\156"]));
        goto qU;
        Ao:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_VALUE), "\x45\122\122\x4f\122");
        return;
        qU:
        $fK = $Gw->get_user_detail("\x6d\157\x32\x66\137\165\163\145\162\x5f\145\155\x61\x69\154", $user->ID);
        $G5 = get_user_meta($user->ID, "\x6d\x6f\x32\146\x5f\164\162\141\x6e\163\141\143\164\x69\157\156\111\x64", true);
        $hP = json_decode($this->mo2f_onprem_cloud_obj->validate_otp_token(MoWpnsConstants::OTP_OVER_EMAIL, $fK, $G5, $li), true);
        if (json_last_error() === JSON_ERROR_NONE) {
            goto wY;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_WHILE_VALIDATING_OTP), "\x45\x52\x52\x4f\122");
        goto UN;
        wY:
        if (strcasecmp($hP["\163\164\x61\x74\165\x73"], "\123\x55\x43\103\x45\x53\x53") === 0) {
            goto on;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_OTP), "\x45\x52\x52\x4f\x52");
        goto DC;
        on:
        delete_user_meta($user->ID, "\155\x6f\x32\x66\137\x63\x6f\x6e\146\151\x67\x75\x72\145\137\62\106\101");
        $Gw->update_user_details($user->ID, array("\x6d\x6f\62\146\x5f\x63\157\x6e\x66\151\147\x75\x72\x65\144\x5f\62\x46\101\x5f\x6d\145\164\150\157\144" => MoWpnsConstants::OTP_OVER_EMAIL, "\x6d\157\62\x66\x5f\117\x54\x50\117\166\145\x72\105\155\141\151\154\137\143\157\156\x66\151\x67\x5f\x73\164\141\164\165\x73" => true));
        delete_user_meta($user->ID, "\x74\x65\163\164\137\62\106\101");
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::COMPLETED_TEST), "\x53\125\103\103\x45\123\x53");
        DC:
        UN:
        goto jq;
        JJ:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\x52\122\117\x52");
        return;
        jq:
        goto lD;
        qb:
        $dk = isset($_POST["\155\157\62\x66\x5f\147\157\x6f\x67\154\145\x5f\x61\x70\x70\156\x61\x6d\145\x5f\156\157\156\143\145"]) ? sanitize_key(wp_unslash($_POST["\x6d\x6f\62\146\x5f\147\x6f\x6f\x67\154\145\137\x61\160\160\156\x61\155\145\137\156\157\156\143\145"])) : null;
        if (!wp_verify_nonce($dk, "\x6d\157\x32\x66\55\x67\157\x6f\x67\154\145\x2d\141\x70\160\x6e\x61\155\x65\x2d\156\x6f\x6e\x63\145")) {
            goto XR;
        }
        update_site_option("\x6d\157\62\x66\137\x67\157\157\147\154\x65\x5f\x61\x70\x70\x6e\141\x6d\x65", isset($_POST["\x6d\x6f\x32\146\x5f\147\157\x6f\147\154\145\137\141\x75\164\150\x5f\x61\160\x70\156\x61\x6d\145"]) && !empty($_POST["\155\157\x32\x66\x5f\147\x6f\157\147\x6c\145\137\141\165\164\x68\137\141\160\160\x6e\141\x6d\145"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\x6f\62\146\x5f\x67\x6f\157\x67\154\145\x5f\x61\165\x74\x68\x5f\x61\x70\x70\156\141\x6d\145"])) : DEFAULT_GOOGLE_APPNAME);
        goto V1;
        XR:
        $jY = new WP_Error();
        $jY->add("\x65\155\160\164\x79\x5f\x75\163\145\x72\156\141\155\145", "\74\x73\x74\162\157\x6e\147\76" . esc_html__("\105\x52\x52\117\122", "\155\x69\x6e\x69\157\x72\141\x6e\x67\x65\x2d\x32\55\146\x61\143\164\x6f\162\55\x61\x75\x74\150\145\156\x74\151\x63\141\x74\151\x6f\156") . "\x3c\57\x73\x74\x72\157\x6e\x67\x3e\72\40" . esc_html__("\x49\x6e\x76\x61\x6c\151\x64\40\x52\x65\x71\165\145\x73\x74\56", "\x6d\151\x6e\x69\x6f\x72\x61\156\x67\x65\x2d\62\x2d\x66\x61\143\x74\x6f\162\55\x61\x75\x74\x68\145\156\x74\151\143\x61\x74\x69\157\x6e"));
        return $jY;
        V1:
        goto lD;
        C4:
        $dk = isset($_POST["\x6d\157\62\x66\x5f\x63\157\156\x66\x69\x67\x75\162\x65\137\147\x6f\157\147\154\x65\137\141\165\x74\x68\x65\156\x74\151\143\141\164\x6f\162\137\166\x61\154\x69\144\x61\164\x65\x5f\x6e\x6f\156\143\145"]) ? sanitize_key(wp_unslash($_POST["\155\x6f\x32\x66\x5f\143\157\x6e\146\x69\147\165\x72\x65\137\x67\x6f\x6f\x67\x6c\x65\137\141\165\164\x68\x65\x6e\x74\x69\143\x61\164\157\162\137\166\141\x6c\x69\144\141\x74\145\x5f\x6e\157\156\143\145"])) : null;
        if (!wp_verify_nonce($dk, "\x6d\x6f\62\x66\55\x63\x6f\x6e\146\151\x67\x75\162\x65\x2d\x67\157\x6f\x67\x6c\145\x2d\x61\x75\164\x68\145\x6e\x74\x69\143\141\164\x6f\x72\x2d\x76\x61\154\x69\x64\x61\x74\145\x2d\x6e\157\156\x63\x65")) {
            goto RS;
        }
        $li = isset($_POST["\147\x6f\157\x67\x6c\145\137\164\x6f\153\145\156"]) ? sanitize_text_field(wp_unslash($_POST["\x67\157\157\147\x6c\x65\137\x74\x6f\x6b\145\156"])) : null;
        $CM = isset($_POST["\147\x6f\157\147\154\145\137\141\165\x74\x68\x5f\163\x65\143\162\145\164"]) ? sanitize_text_field(wp_unslash($_POST["\x67\157\157\x67\x6c\x65\137\x61\165\164\150\137\x73\x65\x63\162\x65\x74"])) : null;
        if (MO2f_Utility::mo2f_check_number_length($li)) {
            goto jV;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ONLY_DIGITS_ALLOWED), "\x45\122\122\117\122");
        goto e0;
        jV:
        $fK = $Gw->get_user_detail("\155\x6f\62\x66\137\165\x73\x65\x72\x5f\145\155\x61\151\x6c", $user->ID);
        $user = wp_get_current_user();
        $fK = empty($fK) ? $user->user_email : $fK;
        $Zf = new Mo2fDB();
        $VX = $Zf->check_alluser_limit_exceeded($v1);
        if (!$VX) {
            goto vn;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::USER_LIMIT_EXCEEDED), "\105\x52\122\x4f\x52");
        return;
        vn:
        $SV = json_decode($this->mo2f_onprem_cloud_obj->mo2f_validate_google_auth($fK, $li, $CM), true);
        if (json_last_error() === JSON_ERROR_NONE) {
            goto Eh;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_WHILE_VALIDATING_USER), "\x45\x52\x52\117\x52");
        goto Bk;
        Eh:
        if (MoWpnsConstants::SUCCESS_RESPONSE === $SV["\163\x74\141\x74\165\x73"]) {
            goto l_;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_IN_SENDING_OTP_CAUSES) . "\x3c\x62\162\76\61\56\40" . MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_OTP) . "\x3c\x62\x72\76\62\56\40" . MoWpnsMessages::lang_translate(MoWpnsMessages::APP_TIME_SYNC) . "\x3c\x62\x72\76\x33\56" . MoWpnsMessages::lang_translate(MoWpnsMessages::SERVER_TIME_SYNC), "\105\122\122\x4f\x52");
        goto P8;
        l_:
        $bC = json_decode($this->mo2f_onprem_cloud_obj->mo2f_update_user_info($user->ID, true, MoWpnsConstants::GOOGLE_AUTHENTICATOR, MoWpnsConstants::SUCCESS_RESPONSE, MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, true, $fK, null), true);
        if (json_last_error() === JSON_ERROR_NONE) {
            goto tY;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_DURING_PROCESS), "\x45\122\x52\117\x52");
        goto pT;
        tY:
        if (MoWpnsConstants::SUCCESS_RESPONSE === $bC["\x73\164\x61\164\x75\163"]) {
            goto nf;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_DURING_PROCESS), "\105\122\x52\x4f\122");
        goto FA;
        nf:
        delete_user_meta($user->ID, "\x6d\x6f\x32\146\137\x32\x46\x41\x5f\155\145\x74\x68\x6f\x64\137\x74\157\137\x63\157\x6e\x66\151\147\x75\x72\x65");
        delete_user_meta($user->ID, "\155\x6f\62\x66\x5f\x63\157\156\146\151\x67\x75\162\145\x5f\x32\106\101");
        update_user_meta($user->ID, "\x6d\157\62\x66\137\145\170\x74\x65\162\x6e\141\x6c\137\x61\160\x70\x5f\x74\x79\160\x65", MoWpnsConstants::GOOGLE_AUTHENTICATOR);
        $cB->mo2f_display_test_2fa_notification($user);
        delete_user_meta($user->ID, "\155\157\x32\x66\x5f\x67\157\157\x67\x6c\x65\x5f\141\x75\164\150");
        FA:
        pT:
        P8:
        Bk:
        e0:
        goto Cx;
        RS:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\x45\x52\x52\x4f\122");
        return;
        Cx:
        goto lD;
        er:
        $dk = isset($_POST["\155\x6f\x32\146\137\x63\157\156\x66\151\x67\165\162\x65\x5f\144\165\157\137\x61\x75\164\x68\x65\x6e\x74\151\x63\x61\x74\157\162\137\166\141\154\x69\x64\141\x74\145\x5f\x6e\157\x6e\143\x65"]) ? sanitize_key(wp_unslash($_POST["\155\157\x32\x66\137\x63\x6f\x6e\146\151\147\x75\x72\x65\x5f\x64\165\x6f\137\x61\165\x74\150\x65\156\x74\x69\143\x61\x74\157\x72\137\x76\x61\154\151\x64\x61\164\x65\x5f\x6e\157\x6e\143\x65"])) : null;
        if (!wp_verify_nonce($dk, "\x6d\x6f\x32\x66\55\x63\157\x6e\x66\x69\x67\x75\x72\x65\x2d\x64\x75\x6f\x2d\x61\165\164\x68\x65\156\x74\x69\x63\x61\164\157\162\x2d\x76\141\154\x69\144\141\164\145\55\156\157\156\x63\x65")) {
            goto n9;
        }
        delete_user_meta($user->ID, "\x6d\x6f\62\146\x5f\62\106\x41\137\155\145\x74\x68\x6f\x64\137\164\x6f\137\x63\x6f\x6e\x66\x69\x67\x75\x72\145");
        delete_user_meta($user->ID, "\x6d\x6f\x32\146\137\143\x6f\x6e\146\x69\147\x75\162\x65\x5f\62\x46\x41");
        delete_user_meta($user->ID, "\x75\x73\145\162\137\156\x6f\164\137\145\x6e\162\157\154\154");
        $Mc = new Miniorange_Password_2Factor_Login();
        $Mc->mo2fa_update_user_details($user->ID, true, MoWpnsConstants::DUO_AUTHENTICATOR, MoWpnsConstants::SUCCESS_RESPONSE, MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, 1);
        update_user_meta($user->ID, "\x6d\x6f\62\146\x5f\145\x78\x74\145\x72\156\141\x6c\137\141\x70\160\x5f\164\171\160\145", MoWpnsConstants::DUO_AUTHENTICATOR);
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::VALIDATE_DUO), "\123\125\x43\x43\x45\123\x53");
        goto Iu;
        n9:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\x45\x52\122\x4f\122");
        return;
        Iu:
        goto lD;
        fQ:
        $dk = isset($_POST["\x6d\x6f\62\146\137\143\x6f\156\146\x69\x67\x75\162\x65\x5f\x61\x75\164\150\171\137\141\165\164\x68\145\156\x74\151\143\x61\164\x6f\x72\137\x6e\157\156\143\145"]) ? sanitize_key(wp_unslash($_POST["\155\x6f\x32\146\137\x63\157\x6e\146\x69\x67\165\162\145\x5f\141\x75\x74\x68\171\x5f\141\165\164\150\x65\x6e\164\x69\143\x61\164\x6f\x72\x5f\x6e\x6f\x6e\x63\145"])) : null;
        if (!wp_verify_nonce($dk, "\x6d\157\x32\x66\55\143\x6f\x6e\x66\x69\x67\x75\162\x65\55\x61\165\164\x68\171\55\x61\x75\x74\x68\145\x6e\x74\151\x63\x61\x74\x6f\x72\55\x6e\157\156\x63\x65")) {
            goto hM;
        }
        $SH = new Mo2f_Cloud_Utility();
        $oJ = $Gw->get_user_detail("\x6d\x6f\x32\x66\x5f\x75\x73\145\x72\x5f\145\155\141\151\x6c", $user->ID);
        $rN = json_decode($SH->mo2f_google_auth_service($oJ), true);
        if (json_last_error() === JSON_ERROR_NONE) {
            goto lZ;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_DURING_USER_REGISTRATION), "\105\x52\122\x4f\122");
        goto Nv;
        lZ:
        if (MoWpnsConstants::SUCCESS_RESPONSE === $rN["\163\164\141\164\x75\x73"]) {
            goto bw;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_DURING_USER_REGISTRATION), "\105\122\x52\117\x52");
        goto M9;
        bw:
        $vK = array();
        $vK["\141\165\164\150\x79\137\161\162\103\157\144\x65"] = $rN["\x71\x72\x43\x6f\x64\145\104\x61\x74\x61"];
        $vK["\155\x6f\62\x66\x5f\x61\x75\164\x68\x79\137\163\x65\x63\162\x65\164"] = $rN["\x73\x65\x63\162\x65\164"];
        $_SESSION["\155\157\62\x66\x5f\141\165\x74\x68\171\137\153\145\171\x73"] = $vK;
        M9:
        Nv:
        goto a7;
        hM:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\x52\122\x4f\x52");
        return;
        a7:
        goto lD;
        Ew:
        $dk = isset($_POST["\x6d\157\62\x66\x5f\x63\x6f\x6e\x66\x69\x67\x75\x72\x65\x5f\141\x75\x74\x68\x79\137\x61\165\x74\x68\x65\156\164\x69\x63\x61\x74\x6f\x72\137\x76\x61\x6c\x69\144\x61\164\x65\137\x6e\157\x6e\x63\145"]) ? sanitize_key(wp_unslash($_POST["\x6d\157\x32\146\x5f\143\x6f\156\x66\x69\x67\x75\x72\x65\x5f\141\x75\164\x68\171\137\x61\x75\x74\x68\x65\156\x74\151\x63\x61\164\x6f\162\137\x76\141\154\x69\x64\x61\x74\145\137\x6e\x6f\156\x63\145"])) : null;
        if (!wp_verify_nonce($dk, "\155\157\62\x66\x2d\x63\157\156\x66\151\147\x75\x72\145\x2d\141\165\164\x68\171\x2d\x61\x75\164\x68\145\156\x74\x69\x63\x61\x74\157\162\x2d\166\x61\154\151\144\x61\x74\145\55\x6e\x6f\x6e\x63\145")) {
            goto w6;
        }
        $li = isset($_POST["\155\x6f\62\146\x5f\x61\x75\164\150\x79\137\164\157\x6b\145\x6e"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\x6f\62\x66\137\141\x75\164\x68\171\x5f\x74\x6f\x6b\x65\x6e"])) : null;
        $C5 = isset($_POST["\x6d\157\x32\146\137\x61\165\164\150\171\137\x73\x65\143\x72\x65\x74"]) ? sanitize_text_field(wp_unslash($_POST["\155\157\x32\x66\137\x61\165\164\150\171\x5f\163\x65\x63\x72\145\x74"])) : null;
        if (MO2f_Utility::mo2f_check_number_length($li)) {
            goto Mi;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ONLY_DIGITS_ALLOWED), "\105\122\122\117\x52");
        goto j9;
        Mi:
        $fK = $Gw->get_user_detail("\x6d\157\x32\146\x5f\165\163\145\162\x5f\145\x6d\141\x69\x6c", $user->ID);
        $rN = json_decode($this->mo2f_onprem_cloud_obj->mo2f_validate_google_auth($fK, $li, $C5), true);
        if (json_last_error() === JSON_ERROR_NONE) {
            goto Np;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_WHILE_VALIDATING_USER), "\105\x52\x52\x4f\x52");
        goto Qo;
        Np:
        if (MoWpnsConstants::SUCCESS_RESPONSE === $rN["\163\x74\x61\164\165\x73"]) {
            goto Bz;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_IN_SENDING_OTP_CAUSES) . "\74\x62\162\x3e\61\x2e\40" . MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_OTP) . "\x3c\142\162\x3e\62\56\40" . MoWpnsMessages::lang_translate(MoWpnsMessages::APP_TIME_SYNC), "\105\x52\x52\x4f\122");
        goto xH;
        Bz:
        $bC = json_decode($this->mo2f_onprem_cloud_obj->mo2f_update_user_info($user->ID, true, MoWpnsConstants::AUTHY_AUTHENTICATOR, MoWpnsConstants::SUCCESS_RESPONSE, MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, true, $fK, null), true);
        if (json_last_error() === JSON_ERROR_NONE) {
            goto Ir;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_DURING_PROCESS), "\x45\x52\122\x4f\122");
        goto BX;
        Ir:
        if (MoWpnsConstants::SUCCESS_RESPONSE === $bC["\163\x74\x61\164\165\163"]) {
            goto ZK;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_DURING_PROCESS), "\x45\122\x52\117\x52");
        goto sN;
        ZK:
        $Gw->update_user_details($user->ID, array("\155\x6f\x32\146\137\x47\x6f\157\x67\154\x65\x41\x75\164\x68\145\x6e\164\x69\x63\141\x74\157\x72\137\143\x6f\156\146\x69\x67\137\163\164\141\x74\165\163" => false));
        update_user_meta($user->ID, "\x6d\x6f\x32\146\x5f\145\x78\x74\145\x72\x6e\x61\154\137\141\x70\160\x5f\x74\171\x70\x65", MoWpnsConstants::AUTHY_AUTHENTICATOR);
        delete_user_meta($user->ID, "\155\x6f\x32\x66\x5f\62\106\101\137\155\x65\x74\x68\x6f\x64\x5f\164\x6f\137\143\157\156\x66\x69\x67\x75\x72\145");
        delete_user_meta($user->ID, "\x6d\157\x32\x66\x5f\143\x6f\156\146\151\x67\x75\x72\x65\x5f\x32\x46\101");
        $cB->mo2f_display_test_2fa_notification($user);
        sN:
        BX:
        xH:
        Qo:
        j9:
        goto ug;
        w6:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\122\x52\117\122");
        return;
        ug:
        goto lD;
        Tz:
        $dk = isset($_POST["\155\157\x32\x66\x5f\x73\141\166\145\x5f\x6b\142\141\x5f\x6e\x6f\156\143\145"]) ? sanitize_key(wp_unslash($_POST["\155\x6f\62\x66\x5f\163\141\166\145\x5f\153\142\x61\137\x6e\157\156\x63\145"])) : null;
        if (wp_verify_nonce($dk, "\x6d\157\x32\x66\55\163\141\166\x65\55\153\142\x61\55\156\157\x6e\x63\145")) {
            goto kI;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\x45\x52\122\117\x52");
        return;
        kI:
        $Zf = new Mo2fDB();
        $VX = $Zf->check_alluser_limit_exceeded($v1);
        if (!$VX) {
            goto OS;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::USER_LIMIT_EXCEEDED), "\105\122\122\x4f\122");
        return;
        OS:
        $cE = new Mo2f_KBA_Handler();
        $MX = $cE->mo2f_get_kba_details($_POST);
        if (!(MO2f_Utility::mo2f_check_empty_or_null($MX["\153\142\141\x5f\161\61"]) || MO2f_Utility::mo2f_check_empty_or_null($MX["\x6b\x62\x61\137\141\x31"]) || MO2f_Utility::mo2f_check_empty_or_null($MX["\153\x62\x61\137\x71\x32"]) || MO2f_Utility::mo2f_check_empty_or_null($MX["\153\x62\141\x5f\141\x32"]) || MO2f_Utility::mo2f_check_empty_or_null($MX["\x6b\x62\141\137\x71\x33"]) || MO2f_Utility::mo2f_check_empty_or_null($MX["\x6b\x62\141\137\141\63"]))) {
            goto ws;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_ENTRY), "\105\122\x52\117\x52");
        return;
        ws:
        if (!(0 === strcasecmp($MX["\153\x62\x61\137\x71\x31"], $MX["\153\142\x61\137\161\x32"]) || 0 === strcasecmp($MX["\153\x62\141\137\161\62"], $MX["\153\x62\x61\137\x71\x33"]) || 0 === strcasecmp($MX["\x6b\x62\141\x5f\161\63"], $MX["\x6b\x62\141\137\161\x31"]))) {
            goto j3;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::UNIQUE_QUESTION), "\105\122\122\117\122");
        return;
        j3:
        $fK = $Gw->get_user_detail("\x6d\157\x32\146\x5f\x75\x73\145\x72\x5f\x65\155\x61\x69\x6c", $user->ID);
        $fK = empty($fK) ? $user->user_email : $fK;
        $w1 = json_decode($this->mo2f_onprem_cloud_obj->mo2f_register_kba_details($fK, $MX["\153\142\x61\137\x71\x31"], $MX["\153\x62\x61\137\x61\x31"], $MX["\x6b\x62\141\137\161\62"], $MX["\153\x62\141\137\141\62"], $MX["\153\142\x61\x5f\x71\x33"], $MX["\153\x62\141\x5f\x61\63"], $user->ID), true);
        if (json_last_error() === JSON_ERROR_NONE) {
            goto nm;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_WHILE_SAVING_KBA), "\105\122\122\117\x52");
        return;
        goto Mf;
        nm:
        if (MoWpnsConstants::SUCCESS_RESPONSE === $w1["\163\x74\141\x74\165\x73"]) {
            goto td;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_WHILE_SAVING_KBA), "\x45\x52\122\117\x52");
        return;
        goto TH;
        td:
        if (isset($_POST["\155\157\x62\x69\x6c\145\137\x6b\x62\141\137\157\160\x74\x69\157\156"]) && sanitize_text_field(wp_unslash($_POST["\x6d\x6f\142\x69\x6c\x65\137\x6b\142\x61\x5f\157\x70\164\x69\157\156"])) === "\x6d\x6f\62\x66\137\162\x65\161\165\x65\163\164\x5f\x66\157\162\x5f\153\142\141\x5f\x61\x73\137\145\x6d\x61\x69\154\x62\141\143\153\165\x70") {
            goto ty;
        }
        $bC = json_decode($this->mo2f_onprem_cloud_obj->mo2f_update_user_info($user->ID, true, MoWpnsConstants::SECURITY_QUESTIONS, MoWpnsConstants::SUCCESS_RESPONSE, MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, true, $fK, null), true);
        if (json_last_error() === JSON_ERROR_NONE) {
            goto eC;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_REQ), "\x45\122\122\x4f\x52");
        goto gO;
        eC:
        if ("\x45\x52\122\117\122" === $bC["\x73\x74\x61\x74\x75\x73"]) {
            goto P7;
        }
        if (MoWpnsConstants::SUCCESS_RESPONSE === $bC["\163\x74\x61\164\165\x73"]) {
            goto Qq;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_DURING_PROCESS), "\105\x52\122\x4f\122");
        goto XS;
        P7:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate($bC["\155\145\x73\x73\141\x67\x65"]), "\105\x52\x52\117\122");
        goto XS;
        Qq:
        delete_user_meta($user->ID, "\x6d\x6f\62\146\137\x63\x6f\x6e\x66\151\147\x75\162\x65\137\62\x46\101");
        $cB->mo2f_display_test_2fa_notification($user);
        XS:
        gO:
        goto UE;
        ty:
        MO2f_Utility::unset_session_variables("\155\157\62\146\137\155\x6f\x62\151\x6c\x65\137\x73\x75\160\x70\157\162\164");
        delete_user_meta($user->ID, "\x6d\x6f\62\x66\x5f\143\x6f\156\146\151\147\165\162\145\x5f\62\x46\101");
        delete_user_meta($user->ID, "\155\157\x32\x66\x5f\x32\x46\101\x5f\x6d\145\164\x68\157\x64\x5f\164\157\x5f\143\x6f\x6e\x66\x69\147\165\x72\145");
        $jD = esc_html__("\131\157\165\162\x20\113\x42\101\x20\x61\x73\40\x61\154\164\x65\x72\x6e\141\x74\145\x20\62\x20\x66\x61\143\164\x6f\162\40\151\163\x20\143\157\156\x66\151\x67\x75\162\x65\x64\40\x73\x75\x63\143\145\x73\x73\146\x75\x6c\x6c\171\x2e", "\155\x69\156\151\x6f\162\141\156\147\145\x2d\x32\55\146\x61\143\164\x6f\162\x2d\141\x75\164\150\x65\x6e\x74\151\143\141\164\151\157\156");
        $pd->mo2f_show_message($jD, "\123\x55\x43\x43\x45\123\123");
        UE:
        TH:
        Mf:
        goto lD;
        ku:
        $dk = isset($_POST["\x6d\x6f\x32\x66\x5f\x61\165\164\x68\x65\x6e\x74\151\x63\x61\164\145\137\156\x6f\156\x63\x65"]) ? sanitize_key(wp_unslash($_POST["\x6d\157\62\146\x5f\141\x75\x74\x68\145\x6e\164\x69\x63\x61\x74\145\137\156\x6f\156\143\x65"])) : null;
        if (!wp_verify_nonce($dk, "\155\x69\156\x69\x6f\162\x61\x6e\147\145\x2d\62\55\x66\141\143\x74\157\162\x2d\163\157\x66\164\55\x74\157\x6b\145\x6e\55\x6e\157\x6e\x63\x65")) {
            goto kw;
        }
        $Ku = '';
        $J6 = '';
        if (MO2f_Utility::mo2f_check_empty_or_null(isset($_POST["\155\x6f\x32\146\137\x61\x6e\x73\x77\x65\162\x5f\61"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\x6f\x32\146\x5f\141\156\163\x77\145\162\x5f\x31"])) : null) || MO2f_Utility::mo2f_check_empty_or_null(isset($_POST["\155\x6f\x32\x66\x5f\141\x6e\x73\x77\145\x72\137\x32"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\157\62\x66\x5f\x61\x6e\x73\167\145\x72\x5f\62"])) : null)) {
            goto wb;
        }
        $Ku = sanitize_text_field(wp_unslash($_POST["\x6d\x6f\62\x66\x5f\x61\x6e\x73\x77\x65\x72\x5f\x31"]));
        $J6 = sanitize_text_field(wp_unslash($_POST["\155\x6f\62\x66\137\x61\156\163\x77\x65\162\x5f\62"]));
        goto Za;
        wb:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_ENTRY), "\105\122\x52\117\x52");
        return;
        Za:
        $g7 = get_user_meta($user->ID, "\155\157\137\62\x5f\146\141\x63\164\x6f\x72\x5f\153\142\x61\137\x71\x75\145\163\x74\x69\157\156\x73", true);
        $D3 = array();
        if (MO2F_IS_ONPREM) {
            goto sx;
        }
        $D3[0] = $g7[0]["\x71\165\145\x73\x74\x69\x6f\156"];
        $D3[1] = $Ku;
        $D3[2] = $g7[1]["\161\x75\145\163\164\x69\157\x6e"];
        $D3[3] = $J6;
        sx:
        $G5 = get_site_option("\x6d\157\62\146\x5f\x74\x72\x61\x6e\x73\141\x63\x74\x69\x6f\156\111\144");
        $Z_ = json_decode($this->mo2f_onprem_cloud_obj->validate_otp_token(MoWpnsConstants::SECURITY_QUESTIONS, null, $G5, $D3), true);
        if (!(json_last_error() === JSON_ERROR_NONE)) {
            goto ae;
        }
        if (strcasecmp($Z_["\163\x74\141\x74\x75\x73"], "\123\125\103\x43\x45\123\123") === 0) {
            goto SW;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_ANSWERS), "\105\x52\x52\117\122");
        goto hR;
        SW:
        delete_site_option("\x6d\x6f\62\x66\x5f\164\x72\141\156\163\x61\143\x74\x69\x6f\x6e\x49\144");
        delete_site_option("\153\142\141\x5f\x71\165\x65\163\164\151\x6f\156\x73");
        delete_user_meta($user->ID, "\x74\x65\163\164\x5f\62\x46\x41");
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::COMPLETED_TEST), "\x53\x55\x43\x43\x45\x53\123");
        hR:
        ae:
        goto jM;
        kw:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\122\x52\117\x52");
        return;
        jM:
        goto lD;
        rh:
        $dk = isset($_POST["\x6d\x6f\x32\146\137\62\x66\x61\143\164\157\x72\137\x74\145\x73\x74\x5f\160\x72\157\155\x70\x74\137\x63\x72\157\x73\163\x5f\x6e\157\156\143\x65"]) ? sanitize_key(wp_unslash($_POST["\x6d\x6f\62\146\137\62\x66\141\143\x74\157\162\137\164\x65\x73\164\137\x70\x72\157\x6d\x70\164\x5f\143\x72\157\163\x73\x5f\156\x6f\156\143\x65"])) : null;
        if (wp_verify_nonce($dk, "\x6d\x6f\62\146\55\62\146\x61\143\x74\157\x72\55\x74\x65\x73\164\55\x70\x72\x6f\x6d\x70\x74\x2d\143\x72\157\x73\163\x2d\156\157\x6e\x63\145")) {
            goto w4;
        }
        update_user_meta($user->ID, "\x6d\x6f\x32\146\137\157\x74\x70\x5f\163\145\156\144\137\164\162\x75\x65", true);
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\x52\122\x4f\x52");
        return;
        w4:
        set_site_transient("\x6d\157\62\x66\137\x73\150\157\x77\x5f\163\x65\164\165\x70\x5f\163\165\x63\143\x65\x73\163\x5f\x70\x72\157\x6d\x70\164" . $user->ID, true, 30);
        goto lD;
        Ne:
        $dk = isset($_POST["\155\x6f\62\x66\137\x63\157\x6e\x66\x69\x67\165\162\145\137\x64\x75\x6f\137\x61\165\x74\150\x65\156\164\151\x63\141\x74\157\162\137\x6e\x6f\156\x63\x65"]) ? sanitize_key(wp_unslash($_POST["\x6d\157\62\x66\x5f\143\x6f\x6e\146\x69\147\x75\162\x65\x5f\x64\x75\x6f\x5f\x61\165\164\x68\145\x6e\164\151\x63\x61\x74\x6f\162\x5f\x6e\157\x6e\143\145"])) : null;
        if (!wp_verify_nonce($dk, "\x6d\x6f\x32\146\x2d\143\x6f\156\146\151\x67\x75\162\145\x2d\144\165\x6f\55\141\165\x74\150\x65\156\x74\x69\143\x61\164\157\x72")) {
            goto GU;
        }
        if (isset($_POST["\x69\153\x65\171"]) && sanitize_key($_POST["\x69\x6b\x65\171"]) === '' || isset($_POST["\x73\153\145\171"]) && sanitize_key($_POST["\x73\153\145\171"]) === '' || empty($_POST["\x61\160\x69\150\x6f\163\164\156\x61\155\x65"]) && esc_url_raw(wp_unslash($_POST["\x61\x70\x69\150\x6f\x73\x74\x6e\x61\155\x65"])) === '') {
            goto fa;
        }
        update_site_option("\x6d\157\62\x66\137\x64\x5f\151\156\x74\145\147\x72\141\164\x69\x6f\156\137\153\145\x79", isset($_POST["\151\x6b\145\171"]) ? sanitize_key($_POST["\151\x6b\x65\171"]) : '');
        update_site_option("\155\x6f\x32\x66\137\x64\x5f\x73\x65\x63\162\145\x74\137\x6b\x65\x79", isset($_POST["\x73\153\145\171"]) ? sanitize_key($_POST["\163\153\x65\171"]) : '');
        update_site_option("\155\x6f\62\146\x5f\x64\x5f\x61\x70\151\137\150\x6f\163\164\x6e\x61\x6d\145", isset($_POST["\141\160\151\x68\157\x73\x74\156\x61\x6d\x65"]) ? esc_url_raw(wp_unslash($_POST["\x61\160\151\x68\x6f\163\x74\x6e\141\x6d\145"])) : '');
        $OG = isset($_POST["\151\153\x65\x79"]) ? sanitize_key(wp_unslash($_POST["\151\x6b\145\171"])) : '';
        $dU = isset($_POST["\163\153\145\x79"]) ? sanitize_key(wp_unslash($_POST["\163\153\145\171"])) : '';
        $ax = isset($_POST["\141\x70\x69\x68\157\x73\164\x6e\141\155\145"]) ? esc_url_raw(wp_unslash($_POST["\x61\160\x69\x68\x6f\x73\x74\156\141\155\x65"])) : '';
        include_once dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . "\x68\x61\156\x64\154\145\162" . DIRECTORY_SEPARATOR . "\x74\167\x6f\146\141" . DIRECTORY_SEPARATOR . "\164\x77\157\55\146\x61\x2d\144\165\x6f\55\150\141\x6e\144\x6c\145\162\56\x70\150\x70";
        $oq = ping($dU, $OG, $ax);
        if ("\x4f\113" === $oq["\x72\x65\163\160\x6f\156\163\x65"]["\163\x74\x61\164"]) {
            goto J1;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::DUO_SERVER_NOT_RESPONDING), "\x45\122\122\x4f\122");
        return;
        goto qO;
        J1:
        $mo = check($dU, $OG, $ax);
        if (!("\x4f\x4b" !== $mo["\162\x65\x73\160\x6f\156\x73\145"]["\163\x74\x61\x74"])) {
            goto Ln;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_CREDENTIALS), "\x45\x52\x52\117\x52");
        return;
        Ln:
        qO:
        update_site_option("\x64\165\157\x5f\143\x72\x65\x64\145\156\x74\151\x61\154\x73\137\x73\x61\166\145\x5f\163\x75\143\x63\x65\x73\x73\146\165\154\x6c\x79", 1);
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SETTINGS_SAVED), "\123\x55\103\103\x45\x53\x53");
        return;
        goto hB;
        fa:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::FIELD_MISSING), "\x45\x52\x52\x4f\x52");
        return;
        hB:
        goto E9;
        GU:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\122\122\117\122");
        return;
        E9:
        goto lD;
        C3:
        $dk = isset($_POST["\155\157\62\146\137\x63\157\x6e\146\151\147\165\162\x65\137\x64\165\157\137\141\x75\164\x68\145\x6e\x74\151\143\x61\164\x6f\x72\x5f\156\157\x6e\x63\x65"]) ? sanitize_key(wp_unslash($_POST["\x6d\157\62\146\x5f\143\157\x6e\146\151\147\165\162\x65\137\144\165\x6f\137\141\x75\164\x68\x65\156\x74\x69\x63\x61\164\157\162\x5f\156\157\156\x63\x65"])) : null;
        if (!wp_verify_nonce($dk, "\x6d\x6f\62\x66\55\x63\x6f\x6e\146\151\147\x75\x72\145\x2d\x64\165\157\55\x61\x75\164\x68\145\x6e\x74\151\143\x61\164\157\x72\x2d\x6e\x6f\156\x63\145")) {
            goto NH;
        }
        include_once dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . "\150\141\x6e\x64\x6c\x65\x72" . DIRECTORY_SEPARATOR . "\164\x77\x6f\x66\141" . DIRECTORY_SEPARATOR . "\164\x77\x6f\x2d\146\141\55\144\x75\157\x2d\150\141\x6e\144\x6c\145\162\x2e\x70\150\x70";
        $OG = get_site_option("\155\x6f\x32\x66\x5f\144\x5f\151\x6e\164\145\x67\162\141\x74\x69\157\x6e\x5f\x6b\x65\x79");
        $dU = get_site_option("\155\x6f\62\x66\137\144\137\x73\x65\x63\162\x65\164\x5f\x6b\145\x79");
        $ax = get_site_option("\155\157\62\146\137\144\137\x61\x70\151\x5f\150\x6f\x73\x74\156\x61\155\x65");
        $oJ = $user->user_email;
        $HO = preauth($oJ, true, $dU, $OG, $ax);
        if ("\x4f\x4b" === $HO["\162\x65\x73\x70\x6f\156\163\145"]["\x73\x74\x61\x74"]) {
            goto by;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::DUO_INVALID_REQ), "\x45\122\122\x4f\x52");
        return;
        goto MT;
        by:
        if (isset($HO["\x72\x65\x73\x70\x6f\156\163\x65"]["\162\x65\163\160\x6f\156\163\145"]["\x73\x74\x61\164\x75\163\137\x6d\163\x67"]) && "\101\x63\143\157\x75\x6e\164\40\151\163\40\x61\143\x74\x69\166\x65" === $HO["\x72\x65\163\x70\x6f\x6e\163\x65"]["\162\x65\163\160\157\156\x73\x65"]["\163\x74\141\x74\x75\163\137\x6d\163\x67"]) {
            goto eu;
        }
        if (isset($HO["\x72\145\x73\x70\157\x6e\x73\x65"]["\162\x65\163\x70\x6f\x6e\x73\145"]["\x65\156\x72\157\154\154\x5f\160\157\162\164\x61\x6c\137\165\x72\x6c"])) {
            goto ux;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::DUO_ACCOUNT_INACTIVE), "\105\122\122\117\x52");
        return;
        goto in;
        eu:
        update_user_meta($user->ID, "\165\x73\x65\x72\x5f\x6e\x6f\164\x5f\145\156\x72\x6f\154\154", true);
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::DUO_USER_EXISTS), "\123\x55\103\x43\105\x53\123");
        return;
        goto in;
        ux:
        $G8 = $HO["\162\x65\163\160\157\x6e\x73\145"]["\162\x65\x73\x70\x6f\156\x73\145"]["\x65\x6e\162\x6f\x6c\154\x5f\160\x6f\x72\164\x61\x6c\137\x75\162\x6c"];
        update_user_meta($user->ID, "\165\x73\x65\162\137\156\x6f\164\137\145\156\162\157\154\x6c\x5f\x6f\x6e\137\144\x75\157\x5f\142\145\146\x6f\x72\x65", $G8);
        update_user_meta($user->ID, "\x75\163\x65\162\137\156\x6f\164\137\145\156\x72\157\x6c\154", true);
        in:
        MT:
        goto dd;
        NH:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\x52\122\x4f\122");
        return;
        dd:
        goto lD;
        WQ:
        $dk = isset($_POST["\144\x75\157\x5f\155\157\142\151\x6c\145\137\163\145\156\144\x5f\x70\165\x73\150\137\156\157\x74\151\146\151\x63\141\164\x69\157\x6e\137\151\x6e\x73\x69\x64\x65\137\x70\x6c\165\147\151\x6e\x5f\x6e\x6f\156\143\x65"]) ? sanitize_key(wp_unslash($_POST["\144\x75\x6f\x5f\x6d\x6f\142\151\154\x65\x5f\163\x65\x6e\x64\x5f\x70\x75\163\x68\x5f\x6e\157\x74\151\146\151\x63\x61\164\x69\x6f\x6e\x5f\151\156\163\x69\144\145\137\x70\x6c\x75\x67\151\x6e\x5f\x6e\x6f\156\x63\145"])) : null;
        if (!(!isset($_POST["\144\165\157\137\x6d\157\x62\151\154\145\137\163\x65\x6e\144\137\160\x75\163\x68\x5f\x6e\x6f\x74\151\x66\x69\x63\141\x74\x69\157\x6e\137\151\x6e\x73\151\x64\145\x5f\x70\x6c\165\147\x69\156\x5f\x6e\157\x6e\143\145"]) || !wp_verify_nonce($dk, "\x6d\157\x32\x66\55\163\x65\156\x64\x2d\x64\x75\x6f\x2d\x70\165\163\150\55\156\x6f\x74\x69\x66\151\x63\x61\164\x69\x6f\x6e\x2d\x69\156\x73\151\144\145\55\x70\x6c\x75\x67\x69\156\x2d\x6e\x6f\156\143\145"))) {
            goto vu;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\x52\x52\117\122");
        return;
        vu:
        goto lD;
        oW:
        $dk = isset($_POST["\155\x69\156\151\x6f\162\x61\156\147\x65\137\163\141\166\x65\x5f\x66\157\162\155\137\141\x75\164\150\x5f\155\x65\x74\150\x6f\144\x73\x5f\156\157\x6e\143\x65"]) ? sanitize_key(wp_unslash($_POST["\155\x69\156\x69\x6f\x72\x61\156\147\145\x5f\163\141\166\x65\137\146\x6f\162\155\137\141\165\x74\150\x5f\155\x65\164\150\x6f\x64\163\x5f\x6e\157\156\143\145"])) : null;
        if (!wp_verify_nonce($dk, "\155\151\x6e\x69\x6f\x72\141\156\147\x65\55\x73\x61\166\x65\x2d\x66\x6f\x72\x6d\55\x61\165\164\x68\55\155\145\164\x68\157\x64\x73\55\x6e\x6f\156\x63\145")) {
            goto X2;
        }
        $ks = isset($_POST["\x6d\157\x32\x66\137\x63\157\x6e\146\151\147\165\x72\x65\144\137\x32\106\x41\x5f\155\x65\x74\x68\157\144\x5f\x66\162\x65\x65\x5f\160\154\x61\x6e"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\x6f\62\146\137\x63\x6f\x6e\146\151\x67\165\x72\145\144\x5f\x32\106\x41\137\155\x65\x74\x68\x6f\144\137\x66\x72\x65\x65\x5f\160\154\141\x6e"])) : '';
        $OL = MoWpnsConstants::mo2f_convert_method_name($ks, "\x70\141\163\x63\x61\x6c\x5f\164\x6f\x5f\143\x61\160");
        $N1 = $Gw->get_user_detail("\155\x6f\x32\146\x5f" . $ks . "\137\143\157\x6e\146\151\147\x5f\x73\164\141\164\x75\163", $user->ID);
        $lY = true;
        if (!(!MO2F_IS_ONPREM || MoWpnsConstants::OTP_OVER_SMS === $OL)) {
            goto KO;
        }
        $lY = get_site_option("\155\157\x32\146\137\x61\x70\x69\137\153\145\x79") ? true : false;
        if ($lY) {
            goto fH;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ADD_MINIORANGE_ACCOUNT), "\x45\x52\x52\117\x52");
        return;
        fH:
        KO:
        $fK = $Gw->get_user_detail("\x6d\157\62\146\137\165\x73\x65\162\137\x65\x6d\141\x69\x6c", $user->ID);
        if (!(!isset($fK) || is_null($fK) || empty($fK))) {
            goto Mr;
        }
        $fK = $user->user_email;
        Mr:
        if (!(!MO2F_IS_ONPREM && !$N1)) {
            goto V0;
        }
        $VX = apply_filters("\155\x6f\x32\146\x5f\x62\141\x73\x69\143\x5f\x70\x6c\141\156\137\x73\x65\x74\x74\x69\x6e\147\163\x5f\146\151\x6c\x74\145\162", $Gw->check_alluser_limit_exceeded($user->ID), "\151\163\137\x75\163\x65\162\137\x6c\x69\x6d\x69\x74\137\x65\x78\143\x65\x65\x64\x65\x64", array());
        if (!$VX) {
            goto U5;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::USER_LIMIT_EXCEEDED), "\105\122\x52\x4f\x52");
        return;
        U5:
        $gQ = new Customer_Cloud_Setup();
        $gQ->mo2f_create_user_in_miniorange($user, $fK);
        V0:
        $Gw->update_user_details($user->ID, array("\155\157\x32\146\137\x63\x6f\x6e\x66\151\x67\x75\162\x65\144\137\x32\x46\101\137\x6d\145\x74\x68\x6f\x64" => $OL));
        if (MO2F_IS_ONPREM) {
            goto Gs;
        }
        $this->mo2f_save_2_factor_method($user, $OL);
        return;
        Gs:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsConstants::mo2f_convert_method_name($OL, "\143\x61\160\137\164\157\137\x73\155\x61\x6c\x6c")) . "\40" . MoWpnsMessages::lang_translate(MoWpnsMessages::SET_2FA), "\x53\x55\103\x43\x45\x53\x53");
        return;
        goto qm;
        X2:
        $jY = new WP_Error();
        $jY->add("\x65\x6d\x70\164\x79\x5f\165\163\145\162\156\141\x6d\x65", "\x3c\x73\x74\x72\157\156\147\76" . esc_html__("\x45\122\122\117\x52", "\155\151\156\151\157\x72\x61\156\147\x65\55\x32\x2d\x66\x61\x63\164\157\x72\55\x61\165\164\x68\x65\156\164\x69\x63\141\164\151\157\156") . "\74\57\163\164\162\157\x6e\147\x3e\x3a\x20" . esc_html__("\111\x6e\166\x61\x6c\x69\x64\x20\122\x65\161\165\x65\163\x74\56", "\155\151\x6e\151\157\x72\141\x6e\147\145\x2d\x32\x2d\146\x61\143\x74\x6f\x72\55\141\165\x74\x68\x65\x6e\x74\151\143\141\164\151\x6f\156"));
        return $jY;
        qm:
        goto lD;
        pm:
        $dk = isset($_POST["\x6d\157\62\x66\x5f\145\156\x61\x62\154\x65\137\x32\x46\x41\x5f\x66\x6f\x72\x5f\165\x73\x65\x72\163\137\x6f\160\x74\151\157\156\x5f\156\157\x6e\x63\145"]) ? sanitize_text_field(wp_unslash($_POST["\155\157\62\146\x5f\145\x6e\141\142\154\x65\137\62\x46\101\137\146\157\x72\x5f\165\x73\145\162\x73\137\x6f\x70\164\151\x6f\156\137\x6e\157\156\143\145"])) : null;
        if (!wp_verify_nonce($dk, "\x6d\157\x32\x66\55\145\x6e\x61\x62\154\x65\x2d\62\x46\x41\x2d\x66\x6f\162\x2d\x75\163\x65\x72\163\55\157\x70\164\151\157\x6e\55\156\157\156\143\x65")) {
            goto D6;
        }
        update_site_option("\155\157\62\x66\137\x65\156\141\x62\154\x65\137\62\x66\141\137\x66\x6f\x72\137\165\x73\x65\x72\163", isset($_POST["\155\157\62\146\x5f\x65\156\141\142\x6c\145\137\x32\146\141\137\146\x6f\162\x5f\165\x73\145\162\x73"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\x6f\x32\x66\x5f\x65\156\x61\142\154\x65\137\62\146\x61\x5f\x66\157\x72\137\165\x73\145\x72\x73"])) : 0);
        goto Od;
        D6:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\122\122\x4f\x52");
        return;
        Od:
        goto lD;
        rJ:
        $dk = isset($_POST["\155\x6f\62\x66\x5f\x65\156\x61\x62\154\145\137\x32\106\x41\x5f\x6f\x70\x74\151\157\x6e\137\156\157\x6e\x63\145"]) ? sanitize_key(wp_unslash($_POST["\155\x6f\62\146\x5f\145\156\141\x62\x6c\x65\137\62\106\x41\x5f\157\x70\x74\x69\x6f\x6e\137\156\157\x6e\x63\x65"])) : null;
        if (!wp_verify_nonce($dk, "\155\x6f\x32\x66\55\145\x6e\141\142\x6c\x65\x2d\62\106\101\x2d\x6f\x70\164\151\x6f\x6e\x2d\x6e\157\x6e\143\145")) {
            goto yc;
        }
        update_site_option("\x6d\157\62\x66\x5f\x65\x6e\141\x62\154\145\x5f\x32\146\x61", isset($_POST["\155\x6f\62\x66\x5f\145\156\141\x62\154\145\x5f\62\x66\141"]) ? sanitize_text_field(wp_unslash($_POST["\155\157\x32\146\x5f\x65\x6e\141\x62\x6c\x65\x5f\x32\x66\x61"])) : 0);
        goto Nr;
        yc:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\x45\122\122\117\122");
        return;
        Nr:
        goto lD;
        Ye:
        $dk = isset($_POST["\x6d\157\x5f\62\146\x61\143\164\x6f\x72\137\x74\145\x73\x74\x5f\x61\x75\164\150\145\x6e\x74\x69\x63\141\164\151\157\x6e\x5f\x6d\145\x74\150\157\144\137\x6e\157\x6e\x63\x65"]) ? sanitize_key(wp_unslash($_POST["\x6d\157\137\x32\146\141\x63\164\x6f\162\137\x74\x65\x73\164\137\x61\x75\164\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\137\155\x65\x74\150\x6f\x64\137\156\157\156\x63\x65"])) : null;
        if (!wp_verify_nonce($dk, "\155\x6f\x2d\62\146\141\143\164\157\162\x2d\x74\x65\163\164\x2d\141\x75\x74\x68\145\x6e\x74\x69\143\141\164\x69\x6f\156\x2d\x6d\145\x74\150\157\x64\55\156\157\x6e\143\145")) {
            goto Vj;
        }
        update_user_meta($user->ID, "\164\145\x73\x74\137\x32\106\101", 1);
        $OL = isset($_POST["\155\x6f\x32\x66\x5f\x63\157\x6e\146\151\x67\165\162\145\144\137\62\x46\x41\x5f\x6d\x65\x74\150\157\x64\x5f\164\x65\x73\x74"]) ? sanitize_text_field(wp_unslash($_POST["\x6d\157\62\x66\x5f\x63\x6f\x6e\146\x69\147\165\x72\x65\144\137\62\x46\x41\137\x6d\x65\164\150\x6f\x64\x5f\x74\145\163\164"])) : '';
        $fK = $Gw->get_user_detail("\x6d\157\x32\146\137\165\x73\x65\x72\x5f\145\155\141\151\x6c", $user->ID);
        $hS = get_site_option("\155\x6f\x32\x66\137\143\x75\x73\164\157\155\145\162\x4b\x65\x79");
        $Yl = get_site_option("\155\x6f\x32\146\137\141\160\x69\x5f\153\145\171");
        if (MoWpnsConstants::SECURITY_QUESTIONS === $OL) {
            goto iI;
        }
        if (MoWpnsConstants::OTP_OVER_TELEGRAM === $OL) {
            goto Rc;
        }
        if (MoWpnsConstants::OTP_OVER_SMS === $OL || MoWpnsConstants::OTP_OVER_EMAIL === $OL) {
            goto mC;
        }
        if (MoWpnsConstants::OUT_OF_BAND_EMAIL === $OL) {
            goto gh;
        }
        goto Bs;
        iI:
        $bC = json_decode($this->mo2f_onprem_cloud_obj->send_otp_token(null, $fK, $OL, null), true);
        if (json_last_error() === JSON_ERROR_NONE) {
            goto bt;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_FETCHING_QUESTIONS), "\x45\122\x52\x4f\x52");
        goto FO;
        bt:
        if (MoWpnsConstants::SUCCESS_RESPONSE === $bC["\163\164\x61\x74\165\x73"]) {
            goto fl;
        }
        if ("\x45\122\x52\x4f\122" === $bC["\x73\164\141\x74\x75\163"]) {
            goto Ld;
        }
        goto YS;
        fl:
        update_site_option("\x6d\157\x32\146\137\164\x72\141\x6e\x73\141\143\x74\x69\157\156\x49\144", $bC["\164\x78\111\144"]);
        $yp = array();
        $yp[0] = $bC["\x71\x75\145\163\x74\151\x6f\156\163"][0];
        $yp[1] = $bC["\x71\165\145\163\x74\x69\157\156\163"][1];
        update_user_meta($user->ID, "\x6d\157\x5f\x32\x5f\146\x61\143\x74\x6f\162\x5f\153\142\x61\137\x71\x75\145\163\x74\151\157\x6e\x73", $yp);
        $pd = new MoWpnsMessages();
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ANSWER_SECURITY_QUESTIONS), "\123\125\103\x43\105\x53\123");
        goto YS;
        Ld:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_FETCHING_QUESTIONS), "\105\x52\x52\x4f\122");
        YS:
        FO:
        goto Bs;
        Rc:
        $user = wp_get_current_user();
        $cY = get_user_meta($user->ID, "\x6d\x6f\62\x66\137\143\150\x61\x74\x5f\x69\144", true);
        $li = '';
        $ET = 1;
        RP:
        if (!($ET < 7)) {
            goto yt;
        }
        $li .= wp_rand(0, 9);
        UH:
        $ET++;
        goto RP;
        yt:
        update_user_meta($user->ID, "\x6d\157\x32\146\x5f\157\164\160\x5f\164\157\x6b\145\x6e", $li);
        update_user_meta($user->ID, "\x6d\157\x32\146\x5f\164\x65\x6c\145\x67\x72\x61\155\x5f\164\151\x6d\x65", time());
        $xz = esc_url(MoWpnsConstants::TELEGRAM_OTP_LINK);
        $HC = array("\155\x6f\62\146\137\157\164\160\x5f\x74\x6f\x6b\x65\x6e" => $li, "\155\157\x32\x66\x5f\143\x68\141\x74\x69\x64" => $cY);
        $as = array("\x6d\145\x74\x68\x6f\x64" => "\x50\117\123\x54", "\x74\x69\155\x65\x6f\x75\x74" => 10, "\163\163\154\166\x65\x72\151\x66\x79" => false, "\x68\x65\141\144\x65\x72\x73" => array(), "\x62\157\x64\x79" => $HC);
        $it = new Mo2f_Api();
        $mC = $it->mo2f_wp_remote_post($xz, $as);
        if (MoWpnsConstants::SUCCESS_RESPONSE === $mC) {
            goto J0;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::VERIFY_CHAT_ID), "\105\122\122\117\x52");
        goto S2;
        J0:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::OTP_SENT) . "\x79\157\165\162\x20\164\145\x6c\145\x67\x72\141\155\x20\156\165\x6d\x62\x65\162\56" . MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_OTP), "\x53\125\103\103\105\123\123");
        S2:
        goto Bs;
        mC:
        $T7 = $Gw->get_user_detail("\155\157\x32\x66\x5f\x75\x73\x65\162\137\160\150\157\156\x65", $user->ID);
        $x0 = 1;
        if (!(MoWpnsConstants::OTP_OVER_EMAIL === $OL)) {
            goto xR;
        }
        $T7 = $Gw->get_user_detail("\x6d\157\x32\x66\137\165\x73\x65\x72\x5f\x65\155\x61\151\x6c", $user->ID);
        if (!(MoWpnsUtility::get_mo2f_db_option("\x63\155\x56\164\131\127\154\165\141\x57\65\156\x54\61\122\x51", "\x73\151\164\145\137\x6f\x70\x74\x69\x6f\x6e") <= 0)) {
            goto fW;
        }
        update_site_option("\x62\x47\154\164\141\130\122\123\x5a\x57\x46\x6a\x61\x47\x56\153", 1);
        $x0 = 0;
        fW:
        xR:
        if (1 === $x0) {
            goto iq;
        }
        $bC["\163\164\141\x74\x75\x73"] = "\106\x41\111\x4c\105\104";
        goto G5;
        iq:
        $bC = json_decode($this->mo2f_onprem_cloud_obj->send_otp_token($T7, null, $OL, null), true);
        G5:
        if (strcasecmp($bC["\163\164\141\164\165\x73"], "\x53\125\103\x43\105\x53\123") === 0) {
            goto iQ;
        }
        if (!MO2F_IS_ONPREM || MoWpnsConstants::OTP_OVER_SMS === $OL) {
            goto MO;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_IN_SENDING_OTP_ONPREM), "\105\122\x52\x4f\x52");
        goto EM;
        MO:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_IN_SENDING_OTP), "\x45\x52\122\x4f\122");
        EM:
        goto Qn;
        iQ:
        if (MoWpnsConstants::OTP_OVER_EMAIL === $OL || MoWpnsConstants::OUT_OF_BAND_EMAIL === $OL) {
            goto VL;
        }
        if (MoWpnsConstants::OTP_OVER_SMS === $OL) {
            goto uB;
        }
        goto oN;
        VL:
        $R7 = MoWpnsUtility::get_mo2f_db_option("\x63\155\126\164\131\127\x6c\x75\141\127\65\156\x54\x31\122\121", "\163\x69\164\145\137\x6f\160\164\x69\x6f\x6e");
        if (!($R7 > 0)) {
            goto Zj;
        }
        update_site_option("\x63\x6d\x56\x74\x59\127\154\165\x61\x57\65\156\x54\x31\122\x51", $R7 - 1);
        Zj:
        goto oN;
        uB:
        $ra = get_site_option("\x63\155\126\x74\x59\127\x6c\165\x61\x57\65\156\124\61\x52\121\x56\x48\112\150\x62\x6e\x4e\x68\x59\x33\x52\160\142\x32\x35\172");
        if (!($ra > 0)) {
            goto LP;
        }
        update_site_option("\x63\x6d\x56\164\x59\127\154\x75\141\x57\65\156\124\61\x52\x51\126\x48\112\150\x62\156\x4e\x68\131\63\122\160\x62\x32\x35\x7a", $ra - 1);
        LP:
        oN:
        update_site_option("\155\x6f\x32\146\137\156\165\x6d\x62\x65\162\137\157\x66\137\164\x72\141\x6e\x73\141\x63\x74\151\157\x6e\163", MoWpnsUtility::get_mo2f_db_option("\x6d\x6f\62\x66\x5f\156\165\x6d\142\145\x72\x5f\157\146\x5f\x74\x72\141\x6e\163\x61\143\x74\x69\x6f\156\163", "\163\151\164\145\x5f\157\x70\x74\151\x6f\156") - 1);
        update_user_meta($user->ID, "\x6d\x6f\x32\x66\137\164\x72\141\156\x73\x61\143\x74\151\157\x6e\111\x64", $bC["\x74\170\x49\144"]);
        update_site_option("\x6d\x6f\62\146\137\164\162\141\x6e\x73\141\143\164\151\157\156\111\x64", $bC["\x74\x78\111\x64"]);
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::OTP_SENT) . "\40\x3c\142\76" . $T7 . "\x3c\57\142\76\56\40" . MoWpnsMessages::lang_translate(MoWpnsMessages::ENTER_OTP), "\x53\125\x43\103\x45\x53\x53");
        Qn:
        goto Bs;
        gh:
        global $Xw;
        $Xw->mo2f_email_verification_call($user);
        Bs:
        update_user_meta($user->ID, "\155\157\x32\146\137\x32\x46\101\137\x6d\145\x74\x68\157\x64\x5f\x74\157\137\x74\145\163\164", $OL);
        goto e1;
        Vj:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\x52\122\117\x52");
        return;
        e1:
        goto lD;
        Ky:
        $dk = isset($_POST["\155\157\62\146\137\147\x6f\137\142\141\143\153\x5f\156\x6f\x6e\143\x65"]) ? sanitize_key(wp_unslash($_POST["\155\x6f\x32\x66\137\x67\157\x5f\x62\141\x63\153\x5f\156\157\156\143\145"])) : null;
        if (!wp_verify_nonce($dk, "\x6d\157\62\x66\x2d\147\157\x2d\x62\141\143\153\x2d\156\x6f\x6e\x63\x65")) {
            goto pJ;
        }
        $XQ = array("\155\x6f\x32\x66\x5f\161\162\103\157\144\x65", "\155\157\62\x66\x5f\164\x72\141\x6e\163\x61\x63\x74\151\157\156\x49\x64", "\155\157\x32\146\x5f\x73\150\157\167\x5f\x71\x72\x5f\143\157\x64\145", "\165\x73\145\x72\x5f\x70\150\x6f\x6e\x65", "\x6d\x6f\62\x66\137\x67\x6f\157\x67\154\145\137\141\165\164\x68", "\155\x6f\62\146\137\155\157\x62\x69\154\x65\x5f\x73\165\160\x70\157\x72\164", "\155\157\x32\x66\x5f\141\165\164\150\x79\x5f\x6b\x65\171\x73");
        MO2f_Utility::unset_session_variables($XQ);
        delete_site_option("\155\157\x32\146\137\x74\162\x61\156\163\x61\143\164\151\x6f\156\111\x64");
        delete_user_meta($user->ID, "\x75\x73\145\x72\x5f\160\x68\x6f\156\x65\x5f\164\x65\x6d\x70");
        delete_user_meta($user->ID, "\x74\145\163\x74\137\x32\106\x41");
        delete_user_meta($user->ID, "\x6d\157\x32\x66\137\143\157\x6e\x66\x69\x67\165\x72\145\137\62\106\x41");
        delete_user_meta($user->ID, "\x6d\x6f\62\146\x5f\x6f\x74\x70\x5f\163\x65\x6e\144\x5f\x74\x72\x75\x65");
        goto Tn;
        pJ:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::SOMETHING_WENT_WRONG), "\105\x52\122\x4f\122");
        return;
        Tn:
        goto lD;
        XI:
        $dk = isset($_POST["\x6d\157\x32\146\137\144\165\157\137\162\x65\x73\145\164\137\143\157\156\146\x69\x67\165\162\141\164\x69\157\156\x5f\156\x6f\156\143\145"]) ? sanitize_key(wp_unslash($_POST["\x6d\157\x32\x66\137\144\165\157\137\x72\x65\163\145\x74\x5f\143\157\x6e\x66\151\x67\165\162\x61\x74\x69\157\x6e\137\156\x6f\x6e\143\x65"])) : null;
        if (!wp_verify_nonce($dk, "\x6d\x6f\x32\x66\x2d\144\x75\157\x2d\x72\145\163\145\164\55\143\157\x6e\x66\x69\x67\x75\x72\x61\x74\x69\157\x6e\55\x6e\157\156\143\145")) {
            goto Ch;
        }
        delete_site_option("\144\x75\x6f\137\143\162\x65\x64\x65\156\x74\151\141\154\163\x5f\163\141\166\145\x5f\163\165\143\x63\x65\163\x73\x66\x75\154\x6c\171");
        delete_user_meta($user->ID, "\165\x73\x65\162\x5f\x6e\x6f\164\137\145\x6e\x72\x6f\x6c\x6c");
        delete_site_option("\x6d\157\62\x66\x5f\144\137\151\156\164\x65\x67\162\141\164\x69\157\156\137\x6b\x65\171");
        delete_site_option("\155\157\62\x66\137\144\137\x73\145\x63\162\x65\164\x5f\153\145\171");
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::RESET_DUO_CONFIGURATON), "\x53\x55\103\x43\x45\x53\x53");
        goto UJ;
        Ch:
        $jY = new WP_Error();
        $jY->add("\x65\x6d\x70\x74\x79\137\x75\x73\145\162\156\141\x6d\145", "\x3c\x73\164\x72\x6f\x6e\147\76" . __("\x45\122\x52\x4f\122", "\x6d\x69\x6e\x69\157\x72\x61\x6e\147\x65\x2d\62\55\146\141\143\x74\157\162\55\141\165\x74\x68\x65\156\x74\151\143\141\164\151\157\156") . "\74\x2f\163\x74\162\x6f\156\147\x3e\72\x20" . __("\111\156\166\141\154\151\x64\40\122\x65\161\x75\x65\163\164\x2e", "\x6d\151\x6e\x69\157\162\141\x6e\x67\x65\x2d\62\x2d\146\141\x63\x74\x6f\x72\x2d\141\165\164\150\145\x6e\x74\x69\x63\x61\x74\151\157\156"));
        return $jY;
        UJ:
        lD:
    }
    public function mo2f_auth_deactivate()
    {
        global $Gw;
        $UN = get_site_option("\x6d\x6f\x32\x66\x5f\162\x65\x67\151\163\164\145\162\x5f\x77\151\164\150\x5f\x61\x6e\x6f\x74\x68\x65\x72\137\x65\155\x61\151\x6c");
        if (!$UN) {
            goto Mg;
        }
        update_site_option("\155\x6f\x32\146\137\162\x65\147\151\x73\x74\145\x72\x5f\167\151\164\150\137\x61\x6e\157\164\x68\x65\x72\x5f\x65\155\x61\x69\154", 0);
        $Gw->mo2f_delete_user_details();
        Mg:
    }
    public function mo2f_save_2_factor_method($user, $Tr)
    {
        global $Gw;
        $fK = $Gw->get_user_detail("\x6d\157\x32\146\x5f\x75\x73\x65\x72\137\145\x6d\x61\x69\154", $user->ID);
        $pd = new MoWpnsMessages();
        $bC = json_decode($this->mo2f_onprem_cloud_obj->mo2f_update_user_info($user->ID, true, $Tr, null, MoWpnsConstants::MO_2_FACTOR_PLUGIN_SETTINGS, null, $fK, null), true);
        if (json_last_error() === JSON_ERROR_NONE) {
            goto Ks;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::INVALID_REQ), "\105\122\x52\x4f\x52");
        goto AD;
        Ks:
        if ("\x45\x52\122\117\x52" === $bC["\163\x74\x61\x74\165\x73"]) {
            goto yu;
        }
        if (MoWpnsConstants::SUCCESS_RESPONSE === $bC["\x73\x74\x61\x74\165\x73"]) {
            goto Qr;
        }
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsMessages::ERROR_DURING_PROCESS), "\105\122\x52\x4f\x52");
        goto Mm;
        yu:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate($bC["\x6d\145\163\163\x61\x67\145"]), "\105\122\122\x4f\122");
        goto Mm;
        Qr:
        $pd->mo2f_show_message(MoWpnsMessages::lang_translate(MoWpnsConstants::mo2f_convert_method_name($Tr, "\x63\x61\x70\x5f\x74\x6f\137\163\x6d\141\154\154")) . "\x20" . MoWpnsMessages::lang_translate(MoWpnsMessages::SET_2FA), "\123\x55\x43\x43\105\x53\x53");
        Mm:
        AD:
    }
    public static function mo2f_low_otp_alert($dX)
    {
        global $ai;
        $fK = get_site_option("\x6d\157\62\x66\137\x65\155\141\151\x6c") ? get_site_option("\155\157\x32\x66\x5f\x65\x6d\141\x69\154") : get_site_option("\141\144\155\151\x6e\x5f\145\155\x61\x69\154");
        if (!MO2F_IS_ONPREM) {
            goto L1;
        }
        $Iv = 0;
        if ("\145\x6d\141\151\x6c" === $dX) {
            goto h7;
        }
        if ("\x73\x6d\x73" === $dX) {
            goto Jv;
        }
        goto ww;
        h7:
        $a3 = "\124\x77\157\x20\106\141\143\164\157\162\x20\x41\x75\164\150\x65\156\x74\151\143\141\164\151\x6f\156\50\114\x6f\167\40\x45\155\141\x69\154\x20\101\x6c\145\x72\x74\51";
        $Iv = get_site_option("\x63\x6d\126\164\131\127\x6c\x75\x61\x57\x35\x6e\x54\61\122\121") - 1;
        $WJ = "\105\x6d\x61\x69\x6c";
        goto ww;
        Jv:
        $a3 = "\x54\x77\x6f\x20\106\141\x63\164\x6f\x72\40\x41\x75\164\150\x65\x6e\x74\151\x63\141\164\x69\x6f\x6e\50\114\x6f\167\x20\x53\115\x53\x20\101\154\x65\162\x74\x29";
        $Iv = get_site_option("\x63\x6d\126\x74\x59\127\154\165\x61\127\x35\156\124\x31\x52\x51\x56\110\112\x68\x62\x6e\116\x68\x59\x33\x52\x70\142\62\65\172") - 1;
        $WJ = "\x53\115\123";
        ww:
        $ZR = network_site_url();
        $xz = explode("\57\167\x70\55\x61\144\x6d\x69\156\x2f\x61\144\155\151\x6e\x2e\160\x68\160\x3f\160\141\x67\145\x3d\x6d\x6f\x5f\62\146\x61\x5f\x75\x70\147\162\x61\x64\145", $ZR);
        $Tp = array("\x43\x6f\156\164\x65\156\x74\x2d\124\x79\160\x65\72\40\164\145\170\x74\x2f\150\x74\155\154\x3b\40\x63\150\x61\162\x73\145\164\75\125\124\x46\x2d\70");
        $Tp[] = "\103\x63\x3a\40\62\146\141\x73\x75\160\160\157\162\164\40\74\x6d\146\x61\163\x75\x70\160\157\x72\164\100\x78\x65\143\x75\x72\x69\146\171\x2e\x63\x6f\155\x3e";
        $jD = "\x3c\164\x61\x62\154\x65\x20\x63\145\x6c\x6c\160\x61\144\144\x69\x6e\x67\x3d\x22\x32\x35\42\40\163\x74\x79\x6c\145\75\42\x6d\141\x72\147\151\156\72\x30\160\170\40\141\x75\164\157\42\76\15\12\x9\11\11\x3c\x74\142\x6f\x64\x79\x3e\xd\12\11\11\x9\x3c\x74\144\76\15\xa\x9\11\11\74\164\144\x3e\15\xa\11\x9\11\74\x74\141\142\154\145\40\x63\145\x6c\x6c\160\141\x64\144\151\x6e\147\x3d\x22\62\64\x22\40\x77\x69\x64\x74\x68\75\42\65\x38\64\x70\x78\42\40\163\x74\171\x6c\145\75\x22\x6d\x61\162\147\151\x6e\72\60\x20\141\165\164\157\73\155\141\x78\x2d\x77\x69\x64\164\x68\72\x35\x38\x34\160\170\73\x62\141\143\x6b\147\162\x6f\x75\156\x64\55\x63\x6f\x6c\x6f\x72\72\43\x66\66\146\64\x66\64\x3b\x62\157\162\x64\145\x72\x3a\x31\x70\170\x20\x73\157\154\151\x64\40\43\x61\70\x61\x64\141\x64\x22\76\15\12\11\x9\11\x3c\164\142\x6f\144\x79\x3e\xd\xa\11\11\11\74\x74\x64\x3e\15\xa\11\11\11\74\x74\x64\76\74\x69\x6d\x67\x20\163\162\x63\x3d\42" . $ai . "\x69\x6e\x63\x6c\165\144\145\163\x2f\151\155\x61\147\145\163\x2f\x78\x65\143\165\x72\x69\146\171\x2d\154\x6f\147\x6f\56\x70\x6e\x67\42\40\141\154\x74\75\42\x58\x65\143\x75\162\151\146\x79\x22\x20\163\x74\171\154\x65\75\x22\143\157\x6c\x6f\162\x3a\x23\65\146\x62\x33\63\x36\73\x74\145\170\164\x2d\x64\x65\143\x6f\162\x61\x74\151\x6f\156\72\x6e\157\x6e\x65\x3b\144\151\x73\x70\x6c\x61\171\72\142\154\x6f\143\153\73\x77\151\x64\x74\x68\x3a\x61\165\164\157\73\x68\145\x69\x67\x68\x74\x3a\141\165\x74\x6f\x3b\155\141\170\x2d\150\x65\x69\x67\150\x74\x3a\63\65\x70\170\x22\x20\x63\x6c\x61\x73\x73\x3d\x22\x43\124\157\x57\x55\x64\42\x3e\74\57\164\144\76\15\12\x9\x9\x9\74\x2f\x74\162\x3e\15\xa\11\x9\x9\x3c\x2f\164\x62\157\144\171\76\15\12\11\11\11\74\57\164\x61\x62\x6c\x65\76\xd\12\11\11\x9\x3c\x74\x61\142\154\145\x20\143\x65\154\154\160\141\144\144\151\156\x67\75\42\x32\x34\x22\x20\163\x74\x79\x6c\x65\75\x22\x62\x61\143\x6b\x67\162\157\x75\x6e\x64\x3a\43\146\146\x66\73\142\x6f\x72\144\x65\162\72\x31\x70\170\40\163\157\154\x69\x64\40\43\141\70\141\x64\141\x64\x3b\x77\x69\x64\x74\x68\x3a\65\x38\64\160\170\73\142\157\x72\144\145\162\x2d\164\x6f\160\x3a\x6e\x6f\156\145\x3b\x63\157\x6c\x6f\x72\72\x23\x34\144\64\142\x34\70\x3b\146\x6f\156\164\55\146\141\x6d\x69\x6c\171\x3a\x41\162\x69\x61\x6c\54\110\145\154\x76\145\164\x69\143\141\x2c\163\141\156\x73\x2d\x73\145\162\151\146\73\146\x6f\156\164\x2d\x73\x69\x7a\145\72\x31\x33\x70\170\x3b\154\151\156\145\x2d\x68\145\x69\x67\x68\x74\72\x31\70\x70\x78\x22\x3e\15\xa\11\11\11\x3c\164\142\157\x64\171\76\15\12\x9\11\11\x3c\164\144\x3e\15\12\x9\x9\11\x3c\x74\144\x3e\xd\12\x9\11\x9\74\160\40\x73\164\x79\154\145\x3d\42\155\141\162\x67\151\156\x2d\164\x6f\160\72\60\73\155\141\162\147\x69\156\x2d\x62\x6f\164\164\x6f\x6d\72\62\60\160\x78\42\76\104\145\x61\x72\40\103\165\x73\x74\x6f\x6d\x65\x72\x2c\x3c\57\160\76\15\12\11\x9\11\74\x70\x20\x73\164\x79\x6c\145\x3d\x22\155\141\162\x67\151\x6e\55\x74\157\x70\x3a\x30\x3b\x6d\x61\x72\147\x69\x6e\55\x62\157\x74\x74\157\155\72\62\60\x70\170\42\x3e\x20\131\x6f\x75\x20\141\x72\145\40\147\x6f\151\x6e\x67\x20\164\157\x20\145\x78\150\141\x75\x73\x74\x20\141\154\x6c\40\x79\x6f\x75\x72\40" . $WJ . "\56\40\x59\x6f\165\40\x68\141\x76\x65\40\x6f\x6e\x6c\171\x20\x3c\142\x3e" . $Iv . "\74\57\x62\x3e\x20" . $WJ . "\40\162\145\x6d\x61\x69\x6e\151\x6e\147\56\40\x59\x6f\x75\40\143\141\x6e\x20\162\145\143\150\x61\162\147\x65\x20\174\x7c\x20\141\x64\x64\x20" . $WJ . "\40\164\x6f\40\x79\157\165\x72\x20\141\143\143\157\x75\156\x74\72\x20\x3c\141\40\x68\162\x65\x66\x3d" . MoWpnsConstants::RECHARGELINK . "\76\x52\145\x63\x68\141\162\147\145\74\x2f\x61\x3e\74\57\160\x3e\15\12\11\x9\11\74\160\x20\x73\164\171\154\145\75\x22\x6d\x61\x72\x67\x69\x6e\55\x74\157\160\72\x30\73\x6d\x61\x72\147\x69\x6e\55\142\x6f\164\164\x6f\155\x3a\61\x30\x70\x78\42\x3e\101\x66\164\x65\162\40\122\145\143\150\x61\162\x67\145\40\171\x6f\165\40\x63\141\x6e\40\x63\x6f\156\164\151\156\x75\x65\x20\x75\x73\x69\156\x67\40\171\157\165\162\x20\x63\165\x72\x72\145\156\164\x20\160\154\x61\156\56\x20\124\157\40\153\x6e\157\167\x20\155\157\162\145\x20\x61\x62\157\x75\x74\40\157\x75\162\x20\x70\x6c\141\x6e\x73\x20\171\x6f\165\x20\x63\x61\156\x20\141\154\163\157\x20\166\151\x73\151\x74\x20\x6f\165\x72\x20\163\x69\164\145\x3a\x20\74\141\x20\150\162\x65\146\x3d" . $xz[0] . "\x2f\167\160\55\141\x64\155\x69\x6e\x2f\141\144\x6d\151\156\56\x70\x68\x70\x3f\160\x61\147\145\75\155\x6f\x5f\x32\146\x61\137\x75\160\x67\x72\141\144\x65\x3e\x32\x46\x41\40\120\154\141\156\163\74\x2f\141\76\56\74\57\x70\x3e\15\12\x9\x9\11\74\160\x20\163\164\x79\x6c\x65\x3d\42\155\141\x72\x67\x69\156\x2d\164\x6f\160\x3a\x30\73\x6d\141\x72\147\151\156\55\142\x6f\164\164\x6f\155\x3a\x31\x30\160\170\x22\x3e\111\x66\40\x79\157\x75\40\144\157\40\156\x6f\164\x20\167\151\163\150\x20\x74\157\40\162\145\143\150\141\x72\x67\145\x2c\40\167\145\x20\x61\x64\166\151\163\x65\x20\x79\x6f\x75\x20\x74\x6f\40\74\141\x20\150\162\x65\146\x3d" . $xz[0] . "\57\x77\160\55\141\144\x6d\151\156\57\x61\x64\x6d\x69\156\56\160\x68\x70\x3f\160\x61\x67\145\x3d\155\x6f\x5f\62\x66\x61\x5f\x74\167\157\x5f\146\x61\x3e\143\150\141\156\147\x65\40\x74\150\145\40\62\106\101\40\155\145\x74\150\x6f\144\x3c\57\141\76\40\x62\x65\x66\x6f\x72\145\40\x79\157\165\x20\150\141\x76\x65\40\156\x6f\x20" . $WJ . "\x20\154\x65\146\x74\x2e\40\x49\x6e\x20\143\x61\x73\x65\40\x79\x6f\165\x20\x67\145\x74\x20\154\157\143\x6b\x65\144\x20\157\165\x74\x2c\x20\160\154\145\141\x73\145\x20\165\163\145\x20\x74\150\x69\163\40\147\165\x69\x64\145\x20\x74\x6f\40\147\141\x69\156\40\x61\x63\x63\x65\163\x73\x3a\40\x3c\x61\40\150\x72\145\146\75" . MoWpnsConstants::ONPREMISELOCKEDOUT . "\76\107\x75\x69\x64\x65\40\x6c\151\x6e\153\74\x2f\x61\76\74\x2f\160\x3e\xd\xa\x9\x9\x9\x3c\x70\40\163\x74\171\x6c\145\75\x22\x6d\x61\162\x67\151\156\55\164\x6f\160\72\60\x3b\155\141\x72\x67\x69\x6e\x2d\x62\157\164\x74\x6f\x6d\72\x32\x30\x70\170\42\x3e\x46\157\162\40\155\157\x72\x65\x20\151\x6e\146\157\162\155\141\x74\151\x6f\156\x2c\x20\x79\157\x75\x20\143\141\156\40\143\x6f\x6e\x74\x61\143\164\40\165\x73\40\144\151\x72\x65\143\x74\x6c\x79\40\141\x74\x20\x32\x66\x61\163\x75\160\160\x6f\162\x74\x40\170\145\143\x75\162\151\146\171\x2e\143\x6f\x6d\x2e\x3c\57\x70\76\xd\xa\x9\11\x9\74\x70\40\x73\x74\171\154\145\x3d\42\x6d\141\162\x67\151\x6e\55\164\157\160\x3a\x30\73\155\x61\x72\x67\x69\156\55\x62\x6f\164\164\157\155\72\x31\65\x70\x78\42\x3e\124\x68\141\156\x6b\x20\171\x6f\x75\x2c\x3c\142\162\x3e\155\x69\x6e\x69\x4f\x72\x61\156\147\x65\40\124\x65\141\155\74\x2f\160\76\15\12\11\11\x9\74\160\x20\x73\x74\x79\154\x65\x3d\42\155\141\162\x67\x69\156\x2d\164\157\x70\72\x30\73\155\141\162\147\151\156\55\x62\x6f\x74\164\x6f\x6d\x3a\x30\160\x78\73\146\x6f\156\x74\x2d\x73\x69\172\x65\72\x31\61\x70\170\x22\76\104\151\163\143\x6c\x61\x69\x6d\x65\162\x3a\40\x54\150\151\163\40\x65\155\141\151\154\40\x61\156\144\40\141\156\171\40\146\x69\x6c\145\x73\40\x74\162\141\156\x73\155\151\x74\x74\145\144\x20\x77\151\164\150\40\x69\x74\40\141\162\145\40\x63\x6f\x6e\146\x69\144\x65\156\x74\151\x61\x6c\x20\141\x6e\x64\x20\151\156\164\x65\156\x64\x65\144\x20\163\157\x6c\145\154\x79\40\146\x6f\x72\x20\164\x68\145\40\x75\163\x65\40\x6f\146\40\164\x68\x65\40\151\x6e\x64\151\x76\151\144\x75\x61\154\40\174\174\40\x65\x6e\x74\x69\164\171\x20\164\x6f\40\167\x68\157\x6d\x20\x74\x68\x65\171\x20\141\x72\x65\x20\x61\144\144\162\x65\x73\x73\x65\x64\56\x3c\x2f\160\x3e\xd\xa\x9\x9\11\x3c\57\144\151\166\76\74\x2f\144\x69\166\76\74\x2f\x74\x64\76\15\12\11\x9\11\74\x2f\x74\162\76\xd\xa\11\x9\11\x3c\x2f\x74\x62\157\x64\171\76\xd\12\11\x9\x9\74\x2f\x74\141\142\x6c\145\x3e\xd\xa\11\x9\x9\x3c\57\x74\x64\76\xd\xa\11\x9\11\74\x2f\164\162\x3e\15\12\11\x9\x9\74\57\x74\142\x6f\144\171\x3e\15\xa\11\11\x9\74\x2f\164\141\x62\x6c\145\76";
        $vv = wp_mail($fK, $a3, $jD, $Tp);
        L1:
    }
    public static function mo2f_is_customer_registered()
    {
        $fK = get_site_option("\x6d\157\62\146\x5f\x65\x6d\141\151\x6c");
        $hS = get_site_option("\155\x6f\62\146\137\x63\x75\x73\164\157\x6d\145\x72\113\145\171");
        if (!$fK || !$hS || !is_numeric(trim($hS))) {
            goto B1;
        }
        return 1;
        goto Dt;
        B1:
        return 0;
        Dt:
    }
}
new Miniorange_Authentication();
Lp:
