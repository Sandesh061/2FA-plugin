<?php


namespace TwoFA\Onprem;

use TwoFA\Traits\Instance;
use TwoFA\Helper\MoWpnsConstants;
if (defined("\x41\102\x53\x50\x41\x54\x48")) {
    goto HG;
}
exit;
HG:
require_once dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . "\x68\x65\x6c\160\145\x72" . DIRECTORY_SEPARATOR . "\143\x6c\141\163\x73\x2d\155\157\62\146\55\x61\x70\x69\x2e\160\150\160";
if (class_exists("\x4d\117\62\146\137\103\154\157\x75\144\x5f\x4f\x6e\160\x72\145\155\x5f\111\x6e\164\x65\162\146\141\x63\145")) {
    goto RM;
}
class MO2f_Cloud_Onprem_Interface
{
    use Instance;
    private $default_customer_key = "\61\x36\65\65\x35";
    private $default_api_key = "\146\106\144\x32\x58\143\166\124\x47\104\145\155\x5a\166\x62\x77\x31\142\x63\125\x65\x73\116\112\127\105\161\x4b\142\x62\x55\161";
    private $class_object;
    private $plugin_type_to_class = array("\x4d\x6f\62\x66\x5f\117\156\120\162\145\155" => "\124\x77\157\x46\x41\134\x4f\x6e\x50\162\x65\x6d\x5c\x4d\157\62\146\x5f\x4f\156\160\x72\x65\x6d\x5f\x53\x65\164\x75\x70", "\x4d\x6f\x32\x66\x5f\x43\x6c\x6f\x75\x64" => "\x54\167\x6f\106\101\x5c\103\x6c\157\x75\x64\134\x43\x75\163\x74\x6f\x6d\145\162\x5f\103\x6c\157\x75\144\x5f\x53\145\164\x75\160");
    public $mo2f_plan_methods;
    public function __construct()
    {
        $So = MO2F_IS_ONPREM ? "\x4d\x6f\x32\146\137\117\156\120\162\145\x6d" : "\115\157\62\146\x5f\103\154\157\165\144";
        $tx = $this->plugin_type_to_class[$So];
        $this->class_object = $tx::instance();
    }
    public function mo2f_plan_methods()
    {
        return $this->class_object->mo2f_plan_methods();
    }
    public function send_otp_token($T7, $fK, $dX, $cs = null)
    {
        $hP = $this->class_object->send_otp_token($T7, $fK, $dX, $cs);
        return $hP;
    }
    public function validate_otp_token($dX, $Zi, $bO, $li, $current_user = null)
    {
        $hP = $this->class_object->validate_otp_token($dX, $Zi, $bO, $li, $current_user);
        return $hP;
    }
    public function mo2f_validate_google_auth($UG, $CH, $wG)
    {
        $hP = $this->class_object->mo2f_google_auth_validate($UG, $CH, $wG);
        return $hP;
    }
    public function mo2f_update_user_info($v1, $eX, $ix, $Bv, $Q3, $yG, $fK, $T7 = null, $hF = null, $M4 = null)
    {
        $bC = $this->class_object->mo2f_update_user_info($v1, $eX, $ix, $Bv, $Q3, $yG, $fK, $T7, $hF, $M4);
        return $bC;
    }
    public function mo2f_register_kba_details($fK, $MX, $v1 = null)
    {
        $bC = $this->class_object->mo2f_cloud_register_kba($fK, $MX, $v1);
        return $bC;
    }
    public function mo2f_pass2login_kba_verification($cs, $Z0, $ok, $jg)
    {
        $kZ = new Miniorange_Password_2Factor_Login();
        if (!is_null($jg)) {
            goto f4;
        }
        $jg = $kZ->create_session();
        f4:
        $hP = $this->class_object->mo2f_login_kba_verification($cs->ID, $jg, $ok);
        return $hP;
    }
    public function mo2f_set_gauth_secret($v1, $fK, $CM)
    {
        $hP = $this->class_object->mo2f_set_gauth_secret($v1, $fK, $CM);
        return $hP;
    }
    public function mo2f_google_auth_setup($user, $jg)
    {
        $this->class_object->mo2f_gauth_setup($user, $jg);
    }
    public function mo2f_send_link($current_user, $Z0, $fK)
    {
        MO2f_Utility::mo2f_debug_file("\x45\x6d\141\x69\154\40\x76\x65\162\x69\146\x69\x63\x61\x74\x69\x6f\x6e\x20\x6c\x69\x6e\x6b\x20\x68\141\163\x20\142\x65\x65\156\40\163\x65\156\164\x20\x73\x75\143\143\145\x73\163\146\x75\x6c\154\x79\40\x66\157\162\x20" . $Z0 . "\x20\125\163\x65\162\137\x49\144\55" . $current_user->ID . "\40\x45\x6d\x61\151\154\x2d" . $current_user->user_email);
        $hP = $this->class_object->mo2f_send_verification_link($fK, $Z0, $current_user);
        return $hP;
    }
    public function mo2f_oobe_get_dashboard_script($Sl, $bO)
    {
        $hP = $this->class_object->mo2f_oobe_get_dashboard_script($Sl, $bO);
        return $hP;
    }
    public function mo2f_oobe_get_login_script($Sl, $bO)
    {
        $hP = $this->class_object->mo2f_oobe_get_login_script($Sl, $bO);
        return $hP;
    }
    public function mo2f_email_verification_call($current_user)
    {
        $this->class_object->mo2f_email_verification_call($current_user);
    }
    public function mo2f_set_oob_email($current_user, $YE)
    {
        $bC = $this->class_object->mo2f_cloud_set_oob_email($current_user, $YE);
        return is_array($bC) ? array("\x6d\x6f\62\x66\x61\137\x6c\x6f\x67\x69\156\x5f\x73\x74\x61\x74\x75\x73" => $bC["\155\157\62\x66\141\x5f\154\x6f\147\151\156\137\163\164\141\x74\x75\x73"], "\155\x6f\62\x66\x61\x5f\154\157\147\151\156\x5f\155\145\163\163\141\x67\x65" => $bC["\x6d\157\x32\x66\141\137\x6c\157\147\151\156\137\x6d\145\163\x73\141\147\145"]) : null;
    }
    public function mo2f_set_otp_over_email($current_user, $YE, $Ty, $ok)
    {
        $bC = $this->class_object->mo2f_set_otp_over_email($current_user, $YE, $Ty, $ok);
        return is_array($bC) ? array("\155\x6f\62\x66\141\137\x6c\x6f\x67\151\156\x5f\163\x74\x61\x74\x75\163" => $bC["\155\157\62\x66\141\137\x6c\x6f\147\x69\x6e\137\x73\164\x61\164\165\163"], "\155\x6f\62\x66\141\x5f\x6c\157\x67\151\x6e\137\155\x65\163\x73\x61\x67\x65" => $bC["\155\x6f\62\146\x61\137\154\x6f\x67\151\156\x5f\155\145\163\163\x61\x67\x65"]) : null;
    }
    public function mo2f_set_google_authenticator($current_user, $YE, $EF, $Ty)
    {
        $bC = $this->class_object->mo2f_set_google_authenticator($current_user, $YE, $EF, $Ty);
        return is_array($bC) ? array("\x6d\157\x32\146\x61\x5f\154\x6f\x67\x69\x6e\x5f\x73\x74\x61\x74\x75\163" => $bC["\x6d\157\x32\x66\141\137\154\x6f\x67\x69\x6e\137\x73\x74\x61\164\165\x73"], "\x6d\157\x32\x66\141\137\154\x6f\147\151\x6e\137\x6d\x65\x73\163\141\147\x65" => $bC["\155\x6f\x32\146\141\x5f\x6c\157\147\x69\x6e\x5f\x6d\145\163\x73\141\x67\145"]) : null;
    }
    public function mo2f_set_user_two_fa($current_user, $YE)
    {
        $bC = $this->class_object->mo2f_set_user_two_fa($current_user, $YE);
        return is_array($bC) ? array("\155\x6f\62\146\141\x5f\154\x6f\147\151\156\137\x73\x74\x61\164\x75\163" => $bC["\x6d\x6f\x32\x66\141\x5f\154\157\147\151\x6e\137\163\x74\141\x74\x75\x73"], "\x6d\x6f\x32\x66\x61\137\154\157\x67\151\156\x5f\155\145\x73\x73\141\x67\145" => $bC["\x6d\x6f\62\x66\x61\x5f\154\x6f\x67\151\x6e\x5f\155\x65\x73\163\x61\x67\x65"]) : null;
    }
    public function locked_out_link()
    {
        if (MO2F_IS_ONPREM) {
            goto gP;
        }
        return MoWpnsConstants::CLOUDLOCKOUT;
        goto tK;
        gP:
        return MoWpnsConstants::ONPREMISELOCKEDOUT;
        tK:
    }
    public function mo2f_user_profile_ga_setup($user)
    {
        return $this->class_object->mo2f_user_profile_ga_setup($user);
    }
    public function mo2f_get_user_2ndfactor($user)
    {
        return $this->class_object->mo2f_get_user_2ndfactor($user);
    }
}
new MO2f_Cloud_Onprem_Interface();
RM:
