<?php


namespace TwoFA\Traits;

if (defined("\x41\x42\123\x50\101\124\x48")) {
    goto Be7;
}
exit;
Be7:
trait Instance
{
    private static $instance = null;
    public static function instance()
    {
        if (!is_null(self::$instance)) {
            goto e_X;
        }
        self::$instance = new self();
        e_X:
        return self::$instance;
    }
}
